
#include <stdio.h>

#include "noise.h"


void gen_print (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "printf(\"[\");
    {");
    {
        int i_1;

        for (i_1 = 0; i_1 < invarlengths[0]; ++i_1)
        {
            fprintf(out, "printf(\"%%f \", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_1);
    fprintf(out, ");");
        }
    }
    fprintf(out, "}
    printf(\"]\n\");");
    }

void gen_add_ri (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ";");
    }

void gen_add_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
    }

void gen_add_s (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_2;

        for (i_2 = 0; i_2 < invarlengths[0]; ++i_2)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_2);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_2);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_add_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_3;

        for (i_3 = 0; i_3 < invarlengths[0]; ++i_3)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_3);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_3);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_3);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_sub_ri (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ";");
    }

void gen_sub_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
    }

void gen_sub_s (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_4;

        for (i_4 = 0; i_4 < invarlengths[0]; ++i_4)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_4);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_4);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_sub_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_5;

        for (i_5 = 0; i_5 < invarlengths[0]; ++i_5)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_5);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_5);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_5);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_mul_ri (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float r1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";
    float r2 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";
    float c1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ";
    float c2 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = r1 * r2 - c1 * c2;
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = r1 * c2 + r2 * c1;");
    }


void gen_mul_m2x2 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a00 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ";
float a01 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, ";
float a10 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ";
float a11 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = a00;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = a01;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 2);
    fprintf(out, " = a10;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 3);
    fprintf(out, " = a11;
");
    }

void gen_mul_m3x3 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a00 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 6);
    fprintf(out, ";
float a01 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 4);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 7);
    fprintf(out, ";
float a02 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 5);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 8);
    fprintf(out, ";
float a10 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 4);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 5);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 6);
    fprintf(out, ";
float a11 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 4);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 4);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 5);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 7);
    fprintf(out, ";
float a12 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 4);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 5);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 5);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 8);
    fprintf(out, ";
float a20 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 6);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 7);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 8);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 6);
    fprintf(out, ";
float a21 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 6);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 7);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 4);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 8);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 7);
    fprintf(out, ";
float a22 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 6);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 7);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 5);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 8);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 8);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = a00;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = a01;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 2);
    fprintf(out, " = a02;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 3);
    fprintf(out, " = a10;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 4);
    fprintf(out, " = a11;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 5);
    fprintf(out, " = a12;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 6);
    fprintf(out, " = a20;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 7);
    fprintf(out, " = a21;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 8);
    fprintf(out, " = a22;
");
    }


void gen_mul_v2m2x2 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a0 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ";
float a1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = a0;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = a1;
");
    }

void gen_mul_v3m3x3 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a0 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 6);
    fprintf(out, ";
float a1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 4);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 7);
    fprintf(out, ";
float a2 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 5);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 8);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = a0;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = a1;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 2);
    fprintf(out, " = a2;
");
    }


void gen_mul_m2x2v2 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a0 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ";
float a1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = a0;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = a1;
");
    }

void gen_mul_m3x3v3 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a0 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ";
float a1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 4);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 5);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ";
float a2 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 6);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 7);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, "+");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 8);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = a0;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = a1;
");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 2);
    fprintf(out, " = a2;
");
    }

void gen_mul_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
    }

void gen_mul_s (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_6;

        for (i_6 = 0; i_6 < invarlengths[0]; ++i_6)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_6);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_6);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_mul_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_7;

        for (i_7 = 0; i_7 < invarlengths[0]; ++i_7)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_7);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_7);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_7);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_div_ri (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float r1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";
    float r2 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";
    float c1 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ";
    float c2 = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ";

    if (r2 == 0 && c2 == 0)
    {
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0;
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = 0;
    }
    else
    {
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = (r1 * r2 + c1 * c2) / (r2 * r2 + c2 * c2);
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = (-r1 * c2 + r2 * c1) / (r2 * r2 + c2 * c2);
    }");
    }

void gen_div_v2m2x2 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a[4] = { ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, " };
    float b[2] = { ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " };

    solve_linear_equations(2, a, b);

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = b[0];
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = b[1];");
    }

void gen_div_v3m3x3 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float a[9] = { ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 3);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 4);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 5);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 6);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 7);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 8);
    fprintf(out, " };
    float b[3] = { ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " };

    solve_linear_equations(3, a, b);

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = b[0];
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = b[1];
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 2);
    fprintf(out, " = b[2];");
    }

void gen_div_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, " == 0)
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " / ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
    }

void gen_div_s (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, " == 0)
        {");
    {
        int i_8;

        for (i_8 = 0; i_8 < invarlengths[0]; ++i_8)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_8);
    fprintf(out, " = 0.0;");
        }
    }
    fprintf(out, "}
    else
        {");
    {
        int i_9;

        for (i_9 = 0; i_9 < invarlengths[0]; ++i_9)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_9);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_9);
    fprintf(out, " / ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_div_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_10;

        for (i_10 = 0; i_10 < invarlengths[0]; ++i_10)
        {
            fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_10);
    fprintf(out, " == 0)
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_10);
    fprintf(out, " = 0.0;
        else
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_10);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_10);
    fprintf(out, " / ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_10);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_mod_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, " == 0)
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = fmod(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ");");
    }

void gen_mod_s (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, " == 0)
        {");
    {
        int i_11;

        for (i_11 = 0; i_11 < invarlengths[0]; ++i_11)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_11);
    fprintf(out, " = 0.0;");
        }
    }
    fprintf(out, "}
    else
        {");
    {
        int i_12;

        for (i_12 = 0; i_12 < invarlengths[0]; ++i_12)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_12);
    fprintf(out, " = fmod(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_12);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ");");
        }
    }
    fprintf(out, "}");
    }

void gen_mod_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_13;

        for (i_13 = 0; i_13 < invarlengths[0]; ++i_13)
        {
            fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_13);
    fprintf(out, " == 0)
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_13);
    fprintf(out, " = 0.0;
        else
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_13);
    fprintf(out, " = fmod(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_13);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_13);
    fprintf(out, ");");
        }
    }
    fprintf(out, "}");
    }

void gen_pmod (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float mod = fmod(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ");

    if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " < 0)
        mod += ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = mod;");
    }

void gen_dotp (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float sum = 0.0;

    {");
    {
        int i_14;

        for (i_14 = 0; i_14 < invarlengths[0]; ++i_14)
        {
            fprintf(out, "sum += ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_14);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_14);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = sum;
    dummy = 1;");
    }

void gen_crossp (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, ";
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 2);
    fprintf(out, ";
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 2);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 1);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
    }

void gen_det_m2x2 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, ";");
    }

void gen_det_m3x3 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 4);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 8);
    fprintf(out, "
                 + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 5);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 6);
    fprintf(out, "
                 + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 7);
    fprintf(out, "
                 - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 4);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 6);
    fprintf(out, "
                 - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 5);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 7);
    fprintf(out, "
                 - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 3);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 8);
    fprintf(out, ";");
    }

void gen_normalize (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float l = 0.0;

    {");
    {
        int i_15;

        for (i_15 = 0; i_15 < invarlengths[0]; ++i_15)
        {
            fprintf(out, "l += ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_15);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_15);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}
    l = sqrt(l);
    {");
    {
        int i_16;

        for (i_16 = 0; i_16 < invarlengths[0]; ++i_16)
        {
            fprintf(out, "if (l == 0)
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_16);
    fprintf(out, " = 0.0;
        else
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_16);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_16);
    fprintf(out, " / l;");
        }
    }
    fprintf(out, "}");
    }

void gen_neg (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_17;

        for (i_17 = 0; i_17 < invarlengths[0]; ++i_17)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_17);
    fprintf(out, " = -");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_17);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_sin (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = sin(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * M_PI / 180.0);");
    }

void gen_cos (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = cos(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * M_PI / 180.0);");
    }

void gen_tan (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = tan(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * M_PI / 180.0);");
    }

void gen_asin (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " < -1.0 || ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " > 1.0)
    {
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;
    }
    else
    {
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = asin(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ") * 180.0 / M_PI;
    }");
    }

void gen_acos (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " < -1.0 || ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " > 1.0)
    {
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;
    }
    else
    {
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = acos(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ") * 180.0 / M_PI;
    }");
    }

void gen_atan (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = atan(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ") * 180.0 / M_PI;");
    }

void gen_atan2 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = atan2(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ",");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ") * 180.0 / M_PI;");
    }

void gen_pow_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = pow(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ");");
    }

void gen_pow_s (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_18;

        for (i_18 = 0; i_18 < invarlengths[0]; ++i_18)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_18);
    fprintf(out, " = pow(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_18);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ");");
        }
    }
    fprintf(out, "}");
    }

void gen_abs_ri (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float r = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";
    float i = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = sqrt(r * r + i * i);
    dummy = 1;");
    }

void gen_abs_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = fabs(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ");");
    }

void gen_abs_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_19;

        for (i_19 = 0; i_19 < invarlengths[0]; ++i_19)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_19);
    fprintf(out, " = fabs(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_19);
    fprintf(out, ");");
        }
    }
    fprintf(out, "}");
    }

void gen_floor (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = floor(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ");");
    }

void gen_sign_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " < 0)
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = -1.0;
    else if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " > 0)
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_sign_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_20;

        for (i_20 = 0; i_20 < invarlengths[0]; ++i_20)
        {
            fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_20);
    fprintf(out, " < 0)
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_20);
    fprintf(out, " = -1.0;
        else if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_20);
    fprintf(out, " > 0)
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_20);
    fprintf(out, " = 1.0;
        else
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_20);
    fprintf(out, " = 0.0;");
        }
    }
    fprintf(out, "}");
    }

void gen_min_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " < ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
    }

void gen_min_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_21;

        for (i_21 = 0; i_21 < invarlengths[0]; ++i_21)
        {
            fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_21);
    fprintf(out, " < ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_21);
    fprintf(out, ")
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_21);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_21);
    fprintf(out, ";
        else
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_21);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_21);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_max_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " > ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ";");
    }

void gen_max_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_22;

        for (i_22 = 0; i_22 < invarlengths[0]; ++i_22)
        {
            fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_22);
    fprintf(out, " > ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_22);
    fprintf(out, ")
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_22);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_22);
    fprintf(out, ";
        else
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_22);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_22);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_clamp (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_23;

        for (i_23 = 0; i_23 < invarlengths[0]; ++i_23)
        {
            fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_23);
    fprintf(out, " < ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_23);
    fprintf(out, ")
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_23);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_23);
    fprintf(out, ";
        else if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_23);
    fprintf(out, " > ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[2], i_23);
    fprintf(out, ")
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_23);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[2], i_23);
    fprintf(out, ";
        else
            ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_23);
    fprintf(out, " = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_23);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_lerp_1 (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_24;

        for (i_24 = 0; i_24 < invarlengths[1]; ++i_24)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_24);
    fprintf(out, " = (1 - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ") * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_24);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[2], i_24);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_lerp_n (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "{");
    {
        int i_25;

        for (i_25 = 0; i_25 < invarlengths[0]; ++i_25)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_25);
    fprintf(out, " = (1 - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_25);
    fprintf(out, ") * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], i_25);
    fprintf(out, " + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_25);
    fprintf(out, " * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[2], i_25);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}");
    }

void gen_sum (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "float sum = 0.0;

    {");
    {
        int i_26;

        for (i_26 = 0; i_26 < invarlengths[0]; ++i_26)
        {
            fprintf(out, "sum += ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], i_26);
    fprintf(out, ";");
        }
    }
    fprintf(out, "}
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = sum;");
    }

void gen_not (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " != 0)
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;");
    }

void gen_or (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " || ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_and (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " && ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_equal (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " == ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_less (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " < ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_greater (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " > ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_lessequal (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " <= ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_greaterequal (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " >= ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_notequal (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " != ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_inintv (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "if (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " >= ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, " && ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " <= ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[2], 0);
    fprintf(out, ")
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 1.0;
    else
        ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.0;");
    }

void gen_rand (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = (random() / (double)0x7fffffff) * (");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, " - ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ") + ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";");
    }

void gen_origValXY (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "unsigned char pixel[4];

    getOrigValPixel(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ",");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ",pixel,");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ");

    {");
    {
        int i_27;

        for (i_27 = 0; i_27 < 4; ++i_27)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_27);
    fprintf(out, " = pixel[");
    fprintf(out, "%d", i_27);
    fprintf(out, "] / 255.0;");
        }
    }
    fprintf(out, "}
    dummy = 4;");
    }

void gen_origValXYIntersample (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "unsigned char pixel[4];

    getOrigValIntersamplePixel(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ",");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ",pixel,");
    fprintf(out, "tmpvar_%d[%d]", invarnums[1], 0);
    fprintf(out, ");

    {");
    {
        int i_28;

        for (i_28 = 0; i_28 < 4; ++i_28)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_28);
    fprintf(out, " = pixel[");
    fprintf(out, "%d", i_28);
    fprintf(out, "] / 255.0;");
        }
    }
    fprintf(out, "}
    dummy = 4;");
    }

void gen_gray (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = 0.299 * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " + 0.587 * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " + 0.114 * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, ";
    dummy = 1;");
    }

void gen_gradient (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "int index = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, " * (num_gradient_samples - 1);

    if (index < 0)
        index = 0;
    else if (index >= num_gradient_samples)
        index = num_gradient_samples - 1;

    {");
    {
        int i_29;

        for (i_29 = 0; i_29 < 4; ++i_29)
        {
            fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, i_29);
    fprintf(out, " = gradient_samples[index].data[");
    fprintf(out, "%d", i_29);
    fprintf(out, "];");
        }
    }
    fprintf(out, "}
    dummy = 4;");
    }

void gen_noise (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = noise(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ", ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 2);
    fprintf(out, ");");
    }

void gen_toXY (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "double x, y;

    x = cos(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * M_PI / 180) * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";
    y = sin(");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, " * M_PI / 180) * ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = x;
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = y;");
    }

void gen_toRA (FILE *out, int *invarnums, int *invarlengths, int outvarnum)
    {
        fprintf(out, "double x, y, r, a;

    x = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 0);
    fprintf(out, ";
    y = ");
    fprintf(out, "tmpvar_%d[%d]", invarnums[0], 1);
    fprintf(out, ";

    r = sqrt(x * x + y * y);
    if (r == 0)
        a = 0.0;
    else
        a = acos(x / r) * 180 / M_PI;

    if (y < 0)
        a = 360 - a;

    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 0);
    fprintf(out, " = r;
    ");
    fprintf(out, "tmpvar_%d[%d]", outvarnum, 1);
    fprintf(out, " = a;");
    }
