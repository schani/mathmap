#--------------------------------------------------------------------------------------------
# Original KALEIDOSCOPE by Nathan Du Gargoyle
# Modified for animation by PhotoMaster
# Only one line was modified so I can't take any real credit.
#--------------------------------------------------------------------------------------------

filter kaleidoscope (image in, int ng: 2-10, float rot: 0-6.28318, int sx: 0-2000, int sy: 0-2000, float rad: 0-100)
intang=2*pi/ng;na=a+pi/2;
ang=intang/2-na%intang;
ang=(rot*t)+(intang/2-sqrt(ang^2)); # <----------------------I changed this line
xr=r*rad;
rad=rad*min(X,Y);
if xr<rad then
nr=xr;
else
ang=2*ang;
nr=rad*xr/R;
end;
nx=nr*cos(ang);
ny=nr*sin(ang);
nx=(nx+sx)%(W-1)-(X-1);
ny=(ny+sy)%(H-1)-(Y-1);
in(xy:[nx,ny])
end
