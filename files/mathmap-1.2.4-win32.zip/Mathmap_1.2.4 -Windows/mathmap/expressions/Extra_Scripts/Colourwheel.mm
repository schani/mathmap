filter test1 (image in, float p1:1-5 (4),float s1:1-10 (5), float r1:0-1 (0.7))
toRGBA(hsva:[a/(2*pi),1.+r1*sin(p1*X/(r+X/s1)),1-r1*sin(p1*X/(r+X/s1)),0])
end