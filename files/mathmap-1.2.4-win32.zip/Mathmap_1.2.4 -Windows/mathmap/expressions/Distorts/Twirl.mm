filter twirl (image in)
    in(ra+ra:[0,(r/R-1)*(t-0.5)*4*pi])
end
