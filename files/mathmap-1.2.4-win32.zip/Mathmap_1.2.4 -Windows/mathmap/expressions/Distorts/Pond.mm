unit filter pond (unit image in, float height: 0-1 (0.05), float wavelength: 0-1 (0.04))
    in(ra+ra:[sin(r/wavelength+t*2*pi)*height,0])
end
