unit(stretched) filter square (unit(stretched) image in, float exponent: 1-10 (1.5))
    in(sign(xy)*abs(xy)^exponent)
end
