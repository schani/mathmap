filter colorify (image in, gradient colors)
    colors((gray(in(xy))+t)%1)
end
