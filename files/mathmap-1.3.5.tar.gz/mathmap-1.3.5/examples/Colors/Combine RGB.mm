filter color_combine_rgb (image in_red, image in_green, image in_blue)
  rgba:[gray(in_red(xy)), gray(in_green(xy)), gray(in_blue(xy)), 1]
end