#define TYPE_NIL 0
#define TYPE_INT 1
#define TYPE_FLOAT 2
#define TYPE_COMPLEX 3
#define TYPE_COLOR 4
#define TYPE_CURVE 5
#define TYPE_GRADIENT 6
#define TYPE_IMAGE 7
#define TYPE_TUPLE 8
#define TYPE_TREE_VECTOR 9

#define MAX_TYPE TYPE_TREE_VECTOR

#define RUNTIME_VALUE_DECL int int_value; float float_value; float _Complex complex_value; color_t color_value; curve_t * curve_value; gradient_t * gradient_value; image_t * image_value; float * tuple_value; tree_vector_t * tree_vector_value;

#define MAKE_TYPE_C_TYPE_NAME static char* \
type_c_type_name (int type) \
{ \
switch (type) \
{ \
case TYPE_NIL : return 0; \
case TYPE_INT : return "int"; \
case TYPE_FLOAT : return "float"; \
case TYPE_COMPLEX : return "float _Complex"; \
case TYPE_COLOR : return "color_t"; \
case TYPE_CURVE : return "curve_t *"; \
case TYPE_GRADIENT : return "gradient_t *"; \
case TYPE_IMAGE : return "image_t *"; \
case TYPE_TUPLE : return "float *"; \
case TYPE_TREE_VECTOR : return "tree_vector_t *"; \
default : assert(0); return 0; \
} \
}

#define MAKE_CONST_PRIMARY_FUNCS \
MAKE_CONST_PRIMARY(int, int, TYPE_INT) \
MAKE_CONST_PRIMARY(float, float, TYPE_FLOAT) \
MAKE_CONST_PRIMARY(complex, float _Complex, TYPE_COMPLEX) \
MAKE_CONST_PRIMARY(color, color_t, TYPE_COLOR) \
MAKE_CONST_PRIMARY(curve, curve_t *, TYPE_CURVE) \
MAKE_CONST_PRIMARY(gradient, gradient_t *, TYPE_GRADIENT) \
MAKE_CONST_PRIMARY(image, image_t *, TYPE_IMAGE) \
MAKE_CONST_PRIMARY(tuple, float *, TYPE_TUPLE) \
MAKE_CONST_PRIMARY(tree_vector, tree_vector_t *, TYPE_TREE_VECTOR)

#define MAKE_CONST_COMPARATOR \
case TYPE_INT : return prim1->v.constant.int_value == prim2->v.constant.int_value; \
case TYPE_FLOAT : return prim1->v.constant.float_value == prim2->v.constant.float_value; \
case TYPE_COMPLEX : return prim1->v.constant.complex_value == prim2->v.constant.complex_value; \
case TYPE_COLOR : return prim1->v.constant.color_value == prim2->v.constant.color_value; \
case TYPE_CURVE : return curves_equal(prim1->v.constant.curve_value, prim2->v.constant.curve_value);; \
case TYPE_GRADIENT : return gradients_equal(prim1->v.constant.gradient_value, prim2->v.constant.gradient_value);; \
case TYPE_IMAGE : return images_equal(prim1->v.constant.image_value, prim2->v.constant.image_value);; \
case TYPE_TUPLE : return tuples_equal(prim1->v.constant.tuple_value, prim2->v.constant.tuple_value);; \
case TYPE_TREE_VECTOR : return tree_vectors_equal(prim1->v.constant.tree_vector_value, prim2->v.constant.tree_vector_value);;

#define TYPE_DEBUG_PRINTER \
case TYPE_NIL : fputs("NIL", out); break; \
case TYPE_INT : fputs("", out); fprintf(out, "%d", primary->v.constant.int_value);  break; \
case TYPE_FLOAT : fputs("", out); { gchar buf[G_ASCII_DTOSTR_BUF_SIZE]; g_ascii_dtostr(buf, sizeof(buf), primary->v.constant.float_value); fputs(buf, out); }  break; \
case TYPE_COMPLEX : fputs("", out); { gchar buf[G_ASCII_DTOSTR_BUF_SIZE]; g_ascii_dtostr(buf, sizeof(buf), crealf(primary->v.constant.complex_value)); fputs(buf, out); } fputs(" + ", out); { gchar buf[G_ASCII_DTOSTR_BUF_SIZE]; g_ascii_dtostr(buf, sizeof(buf), cimagf(primary->v.constant.complex_value)); fputs(buf, out); } fputs(" i", out); break; \
case TYPE_COLOR : fputs("(", out); fprintf(out, "%d", RED(primary->v.constant.color_value)); fputs(",", out); fprintf(out, "%d", GREEN(primary->v.constant.color_value)); fputs(",", out); fprintf(out, "%d", BLUE(primary->v.constant.color_value)); fputs(",", out); fprintf(out, "%d", ALPHA(primary->v.constant.color_value)); fputs(")", out); break; \
case TYPE_CURVE : print_curve(primary->v.constant.curve_value); break; \
case TYPE_GRADIENT : print_gradient(primary->v.constant.gradient_value); break; \
case TYPE_IMAGE : print_image(primary->v.constant.image_value); break; \
case TYPE_TUPLE : print_tuple(primary->v.constant.tuple_value); break; \
case TYPE_TREE_VECTOR : print_tree_vector(primary->v.constant.tree_vector_value); break;

#define TYPE_C_PRINTER \
case TYPE_NIL : fputs("NIL", out); break; \
case TYPE_INT : fputs("", out); fprintf(out, "%d", primary->v.constant.int_value);  break; \
case TYPE_FLOAT : fputs("", out); { gchar buf[G_ASCII_DTOSTR_BUF_SIZE]; g_ascii_dtostr(buf, sizeof(buf), primary->v.constant.float_value); fputs(buf, out); }  break; \
case TYPE_COMPLEX : fputs("COMPLEX(", out); { gchar buf[G_ASCII_DTOSTR_BUF_SIZE]; g_ascii_dtostr(buf, sizeof(buf), crealf(primary->v.constant.complex_value)); fputs(buf, out); } fputs(",", out); { gchar buf[G_ASCII_DTOSTR_BUF_SIZE]; g_ascii_dtostr(buf, sizeof(buf), cimagf(primary->v.constant.complex_value)); fputs(buf, out); } fputs(")", out); break; \
case TYPE_COLOR : fputs("MAKE_RGBA_COLOR(", out); fprintf(out, "%d", RED(primary->v.constant.color_value)); fputs(",", out); fprintf(out, "%d", GREEN(primary->v.constant.color_value)); fputs(",", out); fprintf(out, "%d", BLUE(primary->v.constant.color_value)); fputs(",", out); fprintf(out, "%d", ALPHA(primary->v.constant.color_value)); fputs(")", out); break; \
case TYPE_CURVE : print_curve(primary->v.constant.curve_value); break; \
case TYPE_GRADIENT : print_gradient(primary->v.constant.gradient_value); break; \
case TYPE_IMAGE : print_image(primary->v.constant.image_value); break; \
case TYPE_TUPLE : print_tuple(primary->v.constant.tuple_value); break; \
case TYPE_TREE_VECTOR : print_tree_vector(primary->v.constant.tree_vector_value); break;

