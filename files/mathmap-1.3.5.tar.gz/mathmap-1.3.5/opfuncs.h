static void
init_ops (void)
{
    init_op(OP_NOP, "NOP", 0, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_INT_TO_FLOAT, "INT2FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_INT);
    init_op(OP_FLOAT_TO_INT, "FLOAT2INT", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT);
    init_op(OP_INT_TO_COMPLEX, "INT2COMPLEX", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_INT);
    init_op(OP_FLOAT_TO_COMPLEX, "FLOAT2COMPLEX", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_FLOAT);
    init_op(OP_ADD, "ADD", 2, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_SUB, "SUB", 2, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_NEG, "NEG", 1, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_MUL, "MUL", 2, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_DIV, "DIV", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_MOD, "MOD", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ABS, "fabs", 1, TYPE_PROP_MAX_FLOAT, TYPE_NIL, 1, 1);
    init_op(OP_MIN, "MIN", 2, TYPE_PROP_MAX_FLOAT, TYPE_NIL, 1, 1);
    init_op(OP_MAX, "MAX", 2, TYPE_PROP_MAX_FLOAT, TYPE_NIL, 1, 1);
    init_op(OP_SQRT, "sqrt", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_HYPOT, "hypot", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_SIN, "sin", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_COS, "cos", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_TAN, "tan", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ASIN, "asin", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ACOS, "acos", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ATAN, "atan", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ATAN2, "atan2", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_POW, "pow", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_EXP, "exp", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_LOG, "log", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_SINH, "sinh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_COSH, "cosh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_TANH, "tanh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ASINH, "asinh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ACOSH, "acosh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ATANH, "atanh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_GAMMA, "GAMMA", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_BETA, "gsl_sf_beta", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_FLOOR, "floor", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT);
    init_op(OP_CEIL, "ceil", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT);
    init_op(OP_EQ, "EQ", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LESS, "LESS", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LEQ, "LEQ", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_NOT, "NOT", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_INT);
    init_op(OP_PRINT, "PRINT_FLOAT", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_FLOAT);
    init_op(OP_NEWLINE, "NEWLINE", 0, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_START_DEBUG_TUPLE, "START_DEBUG_TUPLE", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_INT);
    init_op(OP_SET_DEBUG_TUPLE_DATA, "SET_DEBUG_TUPLE_DATA", 2, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_INT, TYPE_FLOAT);
    init_op(OP_APPLY_CURVE, "APPLY_CURVE", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_CURVE, TYPE_FLOAT);
    init_op(OP_APPLY_GRADIENT, "APPLY_GRADIENT", 2, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_GRADIENT, TYPE_FLOAT);
    init_op(OP_ORIG_VAL, "ORIG_VAL", 4, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_IMAGE, TYPE_FLOAT);
    init_op(OP_RESIZE_IMAGE, "RESIZE_IMAGE", 3, TYPE_PROP_CONST, TYPE_IMAGE, 1, 0, TYPE_IMAGE, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_STRIP_RESIZE, "STRIP_RESIZE", 1, TYPE_PROP_CONST, TYPE_IMAGE, 1, 0, TYPE_IMAGE);
    init_op(OP_RENDER, "RENDER", 3, TYPE_PROP_CONST, TYPE_IMAGE, 1, 0, TYPE_IMAGE, TYPE_INT, TYPE_INT);
    init_op(OP_IMAGE_PIXEL_WIDTH, "IMAGE_PIXEL_WIDTH", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0, TYPE_IMAGE);
    init_op(OP_IMAGE_PIXEL_HEIGHT, "IMAGE_PIXEL_HEIGHT", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0, TYPE_IMAGE);
    init_op(OP_MAKE_RGBA_COLOR, "MAKE_COLOR", 4, TYPE_PROP_CONST, TYPE_COLOR, 1, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_RED, "RED_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_GREEN, "GREEN_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_BLUE, "BLUE_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_ALPHA, "ALPHA_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_TUPLE_NTH, "TUPLE_NTH", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_TUPLE, TYPE_INT);
    init_op(OP_TREE_VECTOR_NTH, "TREE_VECTOR_NTH", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_INT, TYPE_TREE_VECTOR);
    init_op(OP_SET_TREE_VECTOR_NTH, "SET_TREE_VECTOR_NTH", 3, TYPE_PROP_CONST, TYPE_TREE_VECTOR, 1, 0, TYPE_INT, TYPE_TREE_VECTOR, TYPE_FLOAT);
    init_op(OP_COMPLEX, "COMPLEX", 2, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_C_REAL, "crealf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_IMAG, "cimagf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_SQRT, "csqrtf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_SIN, "csinf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_COS, "ccosf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_TAN, "ctanf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ASIN, "casinf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ACOS, "cacosf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ATAN, "catanf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_POW, "cpowf", 2, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX, TYPE_COMPLEX);
    init_op(OP_C_EXP, "cexpf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_LOG, "clogf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ARG, "cargf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_SINH, "csinhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_COSH, "ccoshf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_TANH, "ctanhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ASINH, "casinhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ACOSH, "cacoshf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ATANH, "catanhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_GAMMA, "cgamma", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_ELL_INT_K_COMP, "ELL_INT_K_COMP", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ELL_INT_E_COMP, "ELL_INT_E_COMP", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ELL_INT_F, "ELL_INT_F", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_E, "ELL_INT_E", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_P, "ELL_INT_P", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_D, "ELL_INT_D", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RC, "ELL_INT_RC", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RD, "ELL_INT_RD", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RF, "ELL_INT_RF", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RJ, "ELL_INT_RJ", 4, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_JAC, "ELL_JAC", 2, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_SOLVE_LINEAR_2, "SOLVE_LINEAR_2", 2, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_TUPLE, TYPE_TUPLE);
    init_op(OP_SOLVE_LINEAR_3, "SOLVE_LINEAR_3", 2, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_TUPLE, TYPE_TUPLE);
    init_op(OP_SOLVE_POLY_2, "SOLVE_POLY_2", 3, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_SOLVE_POLY_3, "SOLVE_POLY_3", 4, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_RAND, "RAND", 2, TYPE_PROP_CONST, TYPE_FLOAT, 0, 0, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LIBNOISE_PERLIN, "libnoise_perlin", 6, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_INT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LIBNOISE_BILLOW, "libnoise_billow", 6, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_INT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LIBNOISE_RIDGED_MULTI, "libnoise_ridged_multi", 5, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_INT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LIBNOISE_VORONOI, "libnoise_voronoi", 4, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_USERVAL_INT, "USERVAL_INT_ACCESS", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_FLOAT, "USERVAL_FLOAT_ACCESS", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_BOOL, "USERVAL_BOOL_ACCESS", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_COLOR, "USERVAL_COLOR_ACCESS", 1, TYPE_PROP_CONST, TYPE_COLOR, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_CURVE, "USERVAL_CURVE_ACCESS", 1, TYPE_PROP_CONST, TYPE_CURVE, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_GRADIENT, "USERVAL_GRADIENT_ACCESS", 1, TYPE_PROP_CONST, TYPE_GRADIENT, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_IMAGE, "USERVAL_IMAGE_ACCESS", 1, TYPE_PROP_CONST, TYPE_IMAGE, 1, 0, TYPE_INT);
    init_op(OP_OUTPUT_TUPLE, "OUTPUT_TUPLE", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_TUPLE);
}

static primary_t
fold_rhs (rhs_t *rhs)
{
assert(rhs_is_foldable(rhs));
switch(rhs->v.op.op->index)
{
case OP_NOP :
return make_int_const_primary(NOP());
case OP_INT_TO_FLOAT :
return make_float_const_primary(INT2FLOAT(OP_CONST_INT_VAL(0)));
case OP_FLOAT_TO_INT :
return make_int_const_primary(FLOAT2INT(OP_CONST_FLOAT_VAL(0)));
case OP_INT_TO_COMPLEX :
return make_complex_const_primary(INT2COMPLEX(OP_CONST_INT_VAL(0)));
case OP_FLOAT_TO_COMPLEX :
return make_complex_const_primary(FLOAT2COMPLEX(OP_CONST_FLOAT_VAL(0)));
case OP_ADD :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(ADD((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(ADD((float _Complex)rhs->v.op.args[0].v.constant.int_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(ADD((float _Complex)rhs->v.op.args[0].v.constant.float_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_complex_const_primary(ADD((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_complex_const_primary(ADD((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(ADD((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SUB :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(SUB((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(SUB((float _Complex)rhs->v.op.args[0].v.constant.int_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(SUB((float _Complex)rhs->v.op.args[0].v.constant.float_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_complex_const_primary(SUB((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_complex_const_primary(SUB((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(SUB((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_NEG :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
return make_int_const_primary(NEG((int)rhs->v.op.args[0].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(NEG((float)rhs->v.op.args[0].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(NEG((float _Complex)rhs->v.op.args[0].v.constant.complex_value));
default : assert(0); break;
}
case OP_MUL :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(MUL((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(MUL((float _Complex)rhs->v.op.args[0].v.constant.int_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(MUL((float _Complex)rhs->v.op.args[0].v.constant.float_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_complex_const_primary(MUL((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_complex_const_primary(MUL((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(MUL((float _Complex)rhs->v.op.args[0].v.constant.complex_value, (float _Complex)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_DIV :
return make_float_const_primary(DIV(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_MOD :
return make_float_const_primary(MOD(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ABS :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
return make_int_const_primary(fabs((int)rhs->v.op.args[0].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(fabs((float)rhs->v.op.args[0].v.constant.float_value));
default : assert(0); break;
}
case OP_MIN :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(MIN((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_MAX :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(MAX((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SQRT :
return make_float_const_primary(sqrt(OP_CONST_FLOAT_VAL(0)));
case OP_HYPOT :
return make_float_const_primary(hypot(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_SIN :
return make_float_const_primary(sin(OP_CONST_FLOAT_VAL(0)));
case OP_COS :
return make_float_const_primary(cos(OP_CONST_FLOAT_VAL(0)));
case OP_TAN :
return make_float_const_primary(tan(OP_CONST_FLOAT_VAL(0)));
case OP_ASIN :
return make_float_const_primary(asin(OP_CONST_FLOAT_VAL(0)));
case OP_ACOS :
return make_float_const_primary(acos(OP_CONST_FLOAT_VAL(0)));
case OP_ATAN :
return make_float_const_primary(atan(OP_CONST_FLOAT_VAL(0)));
case OP_ATAN2 :
return make_float_const_primary(atan2(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_POW :
return make_float_const_primary(pow(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_EXP :
return make_float_const_primary(exp(OP_CONST_FLOAT_VAL(0)));
case OP_LOG :
return make_float_const_primary(log(OP_CONST_FLOAT_VAL(0)));
case OP_SINH :
return make_float_const_primary(sinh(OP_CONST_FLOAT_VAL(0)));
case OP_COSH :
return make_float_const_primary(cosh(OP_CONST_FLOAT_VAL(0)));
case OP_TANH :
return make_float_const_primary(tanh(OP_CONST_FLOAT_VAL(0)));
case OP_ASINH :
return make_float_const_primary(asinh(OP_CONST_FLOAT_VAL(0)));
case OP_ACOSH :
return make_float_const_primary(acosh(OP_CONST_FLOAT_VAL(0)));
case OP_ATANH :
return make_float_const_primary(atanh(OP_CONST_FLOAT_VAL(0)));
case OP_GAMMA :
return make_float_const_primary(GAMMA(OP_CONST_FLOAT_VAL(0)));
case OP_BETA :
return make_float_const_primary(gsl_sf_beta(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_FLOOR :
return make_int_const_primary(floor(OP_CONST_FLOAT_VAL(0)));
case OP_CEIL :
return make_int_const_primary(ceil(OP_CONST_FLOAT_VAL(0)));
case OP_EQ :
return make_int_const_primary(EQ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_LESS :
return make_int_const_primary(LESS(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_LEQ :
return make_int_const_primary(LEQ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_NOT :
return make_int_const_primary(NOT(OP_CONST_INT_VAL(0)));
case OP_COMPLEX :
return make_complex_const_primary(COMPLEX(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_C_REAL :
return make_float_const_primary(crealf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_IMAG :
return make_float_const_primary(cimagf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_SQRT :
return make_complex_const_primary(csqrtf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_SIN :
return make_complex_const_primary(csinf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_COS :
return make_complex_const_primary(ccosf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_TAN :
return make_complex_const_primary(ctanf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ASIN :
return make_complex_const_primary(casinf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ACOS :
return make_complex_const_primary(cacosf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ATAN :
return make_complex_const_primary(catanf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_POW :
return make_complex_const_primary(cpowf(OP_CONST_COMPLEX_VAL(0), OP_CONST_COMPLEX_VAL(1)));
case OP_C_EXP :
return make_complex_const_primary(cexpf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_LOG :
return make_complex_const_primary(clogf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ARG :
return make_float_const_primary(cargf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_SINH :
return make_complex_const_primary(csinhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_COSH :
return make_complex_const_primary(ccoshf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_TANH :
return make_complex_const_primary(ctanhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ASINH :
return make_complex_const_primary(casinhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ACOSH :
return make_complex_const_primary(cacoshf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ATANH :
return make_complex_const_primary(catanhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_GAMMA :
return make_complex_const_primary(cgamma(OP_CONST_COMPLEX_VAL(0)));
case OP_ELL_INT_K_COMP :
return make_float_const_primary(ELL_INT_K_COMP(OP_CONST_FLOAT_VAL(0)));
case OP_ELL_INT_E_COMP :
return make_float_const_primary(ELL_INT_E_COMP(OP_CONST_FLOAT_VAL(0)));
case OP_ELL_INT_F :
return make_float_const_primary(ELL_INT_F(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ELL_INT_E :
return make_float_const_primary(ELL_INT_E(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ELL_INT_P :
return make_float_const_primary(ELL_INT_P(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_D :
return make_float_const_primary(ELL_INT_D(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_RC :
return make_float_const_primary(ELL_INT_RC(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ELL_INT_RD :
return make_float_const_primary(ELL_INT_RD(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_RF :
return make_float_const_primary(ELL_INT_RF(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_RJ :
return make_float_const_primary(ELL_INT_RJ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3)));
case OP_LIBNOISE_PERLIN :
return make_float_const_primary(libnoise_perlin(OP_CONST_INT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3), OP_CONST_FLOAT_VAL(4), OP_CONST_FLOAT_VAL(5)));
case OP_LIBNOISE_BILLOW :
return make_float_const_primary(libnoise_billow(OP_CONST_INT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3), OP_CONST_FLOAT_VAL(4), OP_CONST_FLOAT_VAL(5)));
case OP_LIBNOISE_RIDGED_MULTI :
return make_float_const_primary(libnoise_ridged_multi(OP_CONST_INT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3), OP_CONST_FLOAT_VAL(4)));
case OP_LIBNOISE_VORONOI :
return make_float_const_primary(libnoise_voronoi(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3)));
default : g_assert_not_reached();
}
}
char* compiler_function_name_for_op_rhs (rhs_t *rhs, type_t *promotion_type)
{switch(rhs->v.op.op->index)
{
case OP_NOP :
return "builtin_op_nop";
case OP_INT_TO_FLOAT :
return "builtin_op_int_to_float";
case OP_FLOAT_TO_INT :
return "builtin_op_float_to_int";
case OP_INT_TO_COMPLEX :
return "builtin_op_int_to_complex";
case OP_FLOAT_TO_COMPLEX :
return "builtin_op_float_to_complex";
case OP_ADD :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_INT; return "builtin_op_add_int";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_add_float";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_add_complex";
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_FLOAT; return "builtin_op_add_float";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_add_float";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_add_complex";
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_COMPLEX; return "builtin_op_add_complex";
case TYPE_FLOAT :
*promotion_type = TYPE_COMPLEX; return "builtin_op_add_complex";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_add_complex";
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SUB :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_INT; return "builtin_op_sub_int";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_sub_float";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_sub_complex";
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_FLOAT; return "builtin_op_sub_float";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_sub_float";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_sub_complex";
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_COMPLEX; return "builtin_op_sub_complex";
case TYPE_FLOAT :
*promotion_type = TYPE_COMPLEX; return "builtin_op_sub_complex";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_sub_complex";
default : assert(0); break;
}
default : assert(0); break;
}
case OP_NEG :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
*promotion_type = TYPE_INT; return "builtin_op_neg_int";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_neg_float";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_neg_complex";
default : assert(0); break;
}
case OP_MUL :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_INT; return "builtin_op_mul_int";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_mul_float";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_mul_complex";
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_FLOAT; return "builtin_op_mul_float";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_mul_float";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_mul_complex";
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_COMPLEX; return "builtin_op_mul_complex";
case TYPE_FLOAT :
*promotion_type = TYPE_COMPLEX; return "builtin_op_mul_complex";
case TYPE_COMPLEX :
*promotion_type = TYPE_COMPLEX; return "builtin_op_mul_complex";
default : assert(0); break;
}
default : assert(0); break;
}
case OP_DIV :
return "builtin_op_div";
case OP_MOD :
return "builtin_op_mod";
case OP_ABS :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
*promotion_type = TYPE_INT; return "builtin_op_abs_int";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_abs_float";
default : assert(0); break;
}
case OP_MIN :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_INT; return "builtin_op_min_int";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_min_float";
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_FLOAT; return "builtin_op_min_float";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_min_float";
default : assert(0); break;
}
default : assert(0); break;
}
case OP_MAX :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_INT; return "builtin_op_max_int";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_max_float";
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
*promotion_type = TYPE_FLOAT; return "builtin_op_max_float";
case TYPE_FLOAT :
*promotion_type = TYPE_FLOAT; return "builtin_op_max_float";
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SQRT :
return "builtin_op_sqrt";
case OP_HYPOT :
return "builtin_op_hypot";
case OP_SIN :
return "builtin_op_sin";
case OP_COS :
return "builtin_op_cos";
case OP_TAN :
return "builtin_op_tan";
case OP_ASIN :
return "builtin_op_asin";
case OP_ACOS :
return "builtin_op_acos";
case OP_ATAN :
return "builtin_op_atan";
case OP_ATAN2 :
return "builtin_op_atan2";
case OP_POW :
return "builtin_op_pow";
case OP_EXP :
return "builtin_op_exp";
case OP_LOG :
return "builtin_op_log";
case OP_SINH :
return "builtin_op_sinh";
case OP_COSH :
return "builtin_op_cosh";
case OP_TANH :
return "builtin_op_tanh";
case OP_ASINH :
return "builtin_op_asinh";
case OP_ACOSH :
return "builtin_op_acosh";
case OP_ATANH :
return "builtin_op_atanh";
case OP_GAMMA :
return "builtin_op_gamma";
case OP_BETA :
return "builtin_op_beta";
case OP_FLOOR :
return "builtin_op_floor";
case OP_CEIL :
return "builtin_op_ceil";
case OP_EQ :
return "builtin_op_eq";
case OP_LESS :
return "builtin_op_less";
case OP_LEQ :
return "builtin_op_leq";
case OP_NOT :
return "builtin_op_not";
case OP_PRINT :
return "builtin_op_print";
case OP_NEWLINE :
return "builtin_op_newline";
case OP_START_DEBUG_TUPLE :
return "builtin_op_start_debug_tuple";
case OP_SET_DEBUG_TUPLE_DATA :
return "builtin_op_set_debug_tuple_data";
case OP_APPLY_CURVE :
return "builtin_op_apply_curve";
case OP_APPLY_GRADIENT :
return "builtin_op_apply_gradient";
case OP_ORIG_VAL :
return "builtin_op_orig_val";
case OP_RESIZE_IMAGE :
return "builtin_op_resize_image";
case OP_STRIP_RESIZE :
return "builtin_op_strip_resize";
case OP_RENDER :
return "builtin_op_render";
case OP_IMAGE_PIXEL_WIDTH :
return "builtin_op_image_pixel_width";
case OP_IMAGE_PIXEL_HEIGHT :
return "builtin_op_image_pixel_height";
case OP_MAKE_RGBA_COLOR :
return "builtin_op_make_rgba_color";
case OP_RED :
return "builtin_op_red";
case OP_GREEN :
return "builtin_op_green";
case OP_BLUE :
return "builtin_op_blue";
case OP_ALPHA :
return "builtin_op_alpha";
case OP_TUPLE_NTH :
return "builtin_op_tuple_nth";
case OP_TREE_VECTOR_NTH :
return "builtin_op_tree_vector_nth";
case OP_SET_TREE_VECTOR_NTH :
return "builtin_op_set_tree_vector_nth";
case OP_COMPLEX :
return "builtin_op_complex";
case OP_C_REAL :
return "builtin_op_c_real";
case OP_C_IMAG :
return "builtin_op_c_imag";
case OP_C_SQRT :
return "builtin_op_c_sqrt";
case OP_C_SIN :
return "builtin_op_c_sin";
case OP_C_COS :
return "builtin_op_c_cos";
case OP_C_TAN :
return "builtin_op_c_tan";
case OP_C_ASIN :
return "builtin_op_c_asin";
case OP_C_ACOS :
return "builtin_op_c_acos";
case OP_C_ATAN :
return "builtin_op_c_atan";
case OP_C_POW :
return "builtin_op_c_pow";
case OP_C_EXP :
return "builtin_op_c_exp";
case OP_C_LOG :
return "builtin_op_c_log";
case OP_C_ARG :
return "builtin_op_c_arg";
case OP_C_SINH :
return "builtin_op_c_sinh";
case OP_C_COSH :
return "builtin_op_c_cosh";
case OP_C_TANH :
return "builtin_op_c_tanh";
case OP_C_ASINH :
return "builtin_op_c_asinh";
case OP_C_ACOSH :
return "builtin_op_c_acosh";
case OP_C_ATANH :
return "builtin_op_c_atanh";
case OP_C_GAMMA :
return "builtin_op_c_gamma";
case OP_ELL_INT_K_COMP :
return "builtin_op_ell_int_k_comp";
case OP_ELL_INT_E_COMP :
return "builtin_op_ell_int_e_comp";
case OP_ELL_INT_F :
return "builtin_op_ell_int_f";
case OP_ELL_INT_E :
return "builtin_op_ell_int_e";
case OP_ELL_INT_P :
return "builtin_op_ell_int_p";
case OP_ELL_INT_D :
return "builtin_op_ell_int_d";
case OP_ELL_INT_RC :
return "builtin_op_ell_int_rc";
case OP_ELL_INT_RD :
return "builtin_op_ell_int_rd";
case OP_ELL_INT_RF :
return "builtin_op_ell_int_rf";
case OP_ELL_INT_RJ :
return "builtin_op_ell_int_rj";
case OP_ELL_JAC :
return "builtin_op_ell_jac";
case OP_SOLVE_LINEAR_2 :
return "builtin_op_solve_linear_2";
case OP_SOLVE_LINEAR_3 :
return "builtin_op_solve_linear_3";
case OP_SOLVE_POLY_2 :
return "builtin_op_solve_poly_2";
case OP_SOLVE_POLY_3 :
return "builtin_op_solve_poly_3";
case OP_RAND :
return "builtin_op_rand";
case OP_LIBNOISE_PERLIN :
return "builtin_op_libnoise_perlin";
case OP_LIBNOISE_BILLOW :
return "builtin_op_libnoise_billow";
case OP_LIBNOISE_RIDGED_MULTI :
return "builtin_op_libnoise_ridged_multi";
case OP_LIBNOISE_VORONOI :
return "builtin_op_libnoise_voronoi";
case OP_USERVAL_INT :
return "builtin_op_userval_int";
case OP_USERVAL_FLOAT :
return "builtin_op_userval_float";
case OP_USERVAL_BOOL :
return "builtin_op_userval_bool";
case OP_USERVAL_COLOR :
return "builtin_op_userval_color";
case OP_USERVAL_CURVE :
return "builtin_op_userval_curve";
case OP_USERVAL_GRADIENT :
return "builtin_op_userval_gradient";
case OP_USERVAL_IMAGE :
return "builtin_op_userval_image";
case OP_OUTPUT_TUPLE :
return "builtin_op_output_tuple";
default : g_assert_not_reached();
}
}
