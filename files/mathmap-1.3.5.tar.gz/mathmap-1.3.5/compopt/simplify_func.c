static void recur (filter_t *filter, statement_t *stmt, gboolean *changed) {
while (stmt != NULL) {
again: switch (stmt->kind) {
case STMT_NIL: break;
case STMT_ASSIGN :
{ /* CLOSURE-PIXEL-HEIGHT */
gboolean does_match = FALSE;
statement_t *binding_s = stmt;
g_assert(binding_s->kind == STMT_ASSIGN);
if (binding_s->v.assign.rhs->kind != RHS_OP) goto done8701;
if (compiler_op_index(binding_s->v.assign.rhs->v.op.op) != OP_IMAGE_PIXEL_HEIGHT) goto done8701;
if (binding_s->v.assign.rhs->v.op.args[0].kind != PRIMARY_VALUE) goto done8701;
statement_t *binding_c = binding_s->v.assign.rhs->v.op.args[0].v.value->def;
g_assert(binding_c->kind == STMT_ASSIGN);
if (binding_c->v.assign.rhs->kind != RHS_CLOSURE) goto done8701;
does_match = TRUE;
done8701:
if (does_match) {
gboolean did_replace;
did_replace = simplify_closure_pixel_size(filter, binding_s, binding_c);
if (did_replace) { *changed = TRUE; goto again; }
}
}{ /* CLOSURE-PIXEL-WIDTH */
gboolean does_match = FALSE;
statement_t *binding_s = stmt;
g_assert(binding_s->kind == STMT_ASSIGN);
if (binding_s->v.assign.rhs->kind != RHS_OP) goto done8702;
if (compiler_op_index(binding_s->v.assign.rhs->v.op.op) != OP_IMAGE_PIXEL_WIDTH) goto done8702;
if (binding_s->v.assign.rhs->v.op.args[0].kind != PRIMARY_VALUE) goto done8702;
statement_t *binding_c = binding_s->v.assign.rhs->v.op.args[0].v.value->def;
g_assert(binding_c->kind == STMT_ASSIGN);
if (binding_c->v.assign.rhs->kind != RHS_CLOSURE) goto done8702;
does_match = TRUE;
done8702:
if (does_match) {
gboolean did_replace;
did_replace = simplify_closure_pixel_size(filter, binding_s, binding_c);
if (did_replace) { *changed = TRUE; goto again; }
}
}break;
case STMT_IF_COND :
recur(filter, stmt->v.if_cond.consequent, changed); recur(filter, stmt->v.if_cond.alternative, changed); break;
case STMT_WHILE_LOOP :
recur(filter, stmt->v.while_loop.body, changed); break;
default : g_assert_not_reached();
}
 stmt = stmt->next;
}
}
