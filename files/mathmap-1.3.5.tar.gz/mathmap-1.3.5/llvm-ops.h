int
builtin_op_nop (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools)
{
return NOP();
}
float
builtin_op_int_to_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return INT2FLOAT(arg_1);
}
int
builtin_op_float_to_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return FLOAT2INT(arg_1);
}
float _Complex
builtin_op_int_to_complex (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return INT2COMPLEX(arg_1);
}
float _Complex
builtin_op_float_to_complex (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return FLOAT2COMPLEX(arg_1);
}
int
builtin_op_add_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, int arg_2)
{
return ADD(arg_1, arg_2);
}
float
builtin_op_add_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return ADD(arg_1, arg_2);
}
float _Complex
builtin_op_add_complex (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1, float _Complex arg_2)
{
return ADD(arg_1, arg_2);
}
int
builtin_op_sub_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, int arg_2)
{
return SUB(arg_1, arg_2);
}
float
builtin_op_sub_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return SUB(arg_1, arg_2);
}
float _Complex
builtin_op_sub_complex (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1, float _Complex arg_2)
{
return SUB(arg_1, arg_2);
}
int
builtin_op_neg_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return NEG(arg_1);
}
float
builtin_op_neg_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return NEG(arg_1);
}
float _Complex
builtin_op_neg_complex (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return NEG(arg_1);
}
int
builtin_op_mul_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, int arg_2)
{
return MUL(arg_1, arg_2);
}
float
builtin_op_mul_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return MUL(arg_1, arg_2);
}
float _Complex
builtin_op_mul_complex (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1, float _Complex arg_2)
{
return MUL(arg_1, arg_2);
}
float
builtin_op_div (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return DIV(arg_1, arg_2);
}
float
builtin_op_mod (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return MOD(arg_1, arg_2);
}
int
builtin_op_abs_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return fabs(arg_1);
}
float
builtin_op_abs_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return fabs(arg_1);
}
int
builtin_op_min_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, int arg_2)
{
return MIN(arg_1, arg_2);
}
float
builtin_op_min_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return MIN(arg_1, arg_2);
}
int
builtin_op_max_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, int arg_2)
{
return MAX(arg_1, arg_2);
}
float
builtin_op_max_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return MAX(arg_1, arg_2);
}
float
builtin_op_sqrt (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return sqrt(arg_1);
}
float
builtin_op_hypot (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return hypot(arg_1, arg_2);
}
float
builtin_op_sin (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return sin(arg_1);
}
float
builtin_op_cos (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return cos(arg_1);
}
float
builtin_op_tan (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return tan(arg_1);
}
float
builtin_op_asin (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return asin(arg_1);
}
float
builtin_op_acos (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return acos(arg_1);
}
float
builtin_op_atan (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return atan(arg_1);
}
float
builtin_op_atan2 (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return atan2(arg_1, arg_2);
}
float
builtin_op_pow (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return pow(arg_1, arg_2);
}
float
builtin_op_exp (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return exp(arg_1);
}
float
builtin_op_log (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return log(arg_1);
}
float
builtin_op_sinh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return sinh(arg_1);
}
float
builtin_op_cosh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return cosh(arg_1);
}
float
builtin_op_tanh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return tanh(arg_1);
}
float
builtin_op_asinh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return asinh(arg_1);
}
float
builtin_op_acosh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return acosh(arg_1);
}
float
builtin_op_atanh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return atanh(arg_1);
}
float
builtin_op_gamma (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return GAMMA(arg_1);
}
float
builtin_op_beta (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return gsl_sf_beta(arg_1, arg_2);
}
int
builtin_op_floor (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return floor(arg_1);
}
int
builtin_op_ceil (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return ceil(arg_1);
}
int
builtin_op_eq (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return EQ(arg_1, arg_2);
}
int
builtin_op_less (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return LESS(arg_1, arg_2);
}
int
builtin_op_leq (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return LEQ(arg_1, arg_2);
}
int
builtin_op_not (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return NOT(arg_1);
}
int
builtin_op_print (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return PRINT_FLOAT(arg_1);
}
int
builtin_op_newline (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools)
{
return NEWLINE();
}
int
builtin_op_start_debug_tuple (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return START_DEBUG_TUPLE(arg_1);
}
int
builtin_op_set_debug_tuple_data (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, float arg_2)
{
return SET_DEBUG_TUPLE_DATA(arg_1, arg_2);
}
float
builtin_op_apply_curve (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, curve_t * arg_1, float arg_2)
{
return APPLY_CURVE(arg_1, arg_2);
}
float *
builtin_op_apply_gradient (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, gradient_t * arg_1, float arg_2)
{
return APPLY_GRADIENT(arg_1, arg_2);
}
float *
builtin_op_orig_val (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, image_t * arg_3, float arg_4)
{
return ORIG_VAL(arg_1, arg_2, arg_3, arg_4);
}
image_t *
builtin_op_resize_image (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, image_t * arg_1, float arg_2, float arg_3)
{
return RESIZE_IMAGE(arg_1, arg_2, arg_3);
}
image_t *
builtin_op_strip_resize (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, image_t * arg_1)
{
return STRIP_RESIZE(arg_1);
}
image_t *
builtin_op_render (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, image_t * arg_1, int arg_2, int arg_3)
{
return RENDER(arg_1, arg_2, arg_3);
}
int
builtin_op_image_pixel_width (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, image_t * arg_1)
{
return IMAGE_PIXEL_WIDTH(arg_1);
}
int
builtin_op_image_pixel_height (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, image_t * arg_1)
{
return IMAGE_PIXEL_HEIGHT(arg_1);
}
color_t
builtin_op_make_rgba_color (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3, float arg_4)
{
return MAKE_COLOR(arg_1, arg_2, arg_3, arg_4);
}
float
builtin_op_red (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, color_t arg_1)
{
return RED_FLOAT(arg_1);
}
float
builtin_op_green (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, color_t arg_1)
{
return GREEN_FLOAT(arg_1);
}
float
builtin_op_blue (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, color_t arg_1)
{
return BLUE_FLOAT(arg_1);
}
float
builtin_op_alpha (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, color_t arg_1)
{
return ALPHA_FLOAT(arg_1);
}
float
builtin_op_tuple_nth (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float * arg_1, int arg_2)
{
return TUPLE_NTH(arg_1, arg_2);
}
float
builtin_op_tree_vector_nth (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, tree_vector_t * arg_2)
{
return TREE_VECTOR_NTH(arg_1, arg_2);
}
tree_vector_t *
builtin_op_set_tree_vector_nth (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, tree_vector_t * arg_2, float arg_3)
{
return SET_TREE_VECTOR_NTH(arg_1, arg_2, arg_3);
}
float _Complex
builtin_op_complex (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return COMPLEX(arg_1, arg_2);
}
float
builtin_op_c_real (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return crealf(arg_1);
}
float
builtin_op_c_imag (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return cimagf(arg_1);
}
float _Complex
builtin_op_c_sqrt (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return csqrtf(arg_1);
}
float _Complex
builtin_op_c_sin (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return csinf(arg_1);
}
float _Complex
builtin_op_c_cos (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return ccosf(arg_1);
}
float _Complex
builtin_op_c_tan (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return ctanf(arg_1);
}
float _Complex
builtin_op_c_asin (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return casinf(arg_1);
}
float _Complex
builtin_op_c_acos (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return cacosf(arg_1);
}
float _Complex
builtin_op_c_atan (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return catanf(arg_1);
}
float _Complex
builtin_op_c_pow (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1, float _Complex arg_2)
{
return cpowf(arg_1, arg_2);
}
float _Complex
builtin_op_c_exp (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return cexpf(arg_1);
}
float _Complex
builtin_op_c_log (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return clogf(arg_1);
}
float
builtin_op_c_arg (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return cargf(arg_1);
}
float _Complex
builtin_op_c_sinh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return csinhf(arg_1);
}
float _Complex
builtin_op_c_cosh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return ccoshf(arg_1);
}
float _Complex
builtin_op_c_tanh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return ctanhf(arg_1);
}
float _Complex
builtin_op_c_asinh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return casinhf(arg_1);
}
float _Complex
builtin_op_c_acosh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return cacoshf(arg_1);
}
float _Complex
builtin_op_c_atanh (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return catanhf(arg_1);
}
float _Complex
builtin_op_c_gamma (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float _Complex arg_1)
{
return cgamma(arg_1);
}
float
builtin_op_ell_int_k_comp (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return ELL_INT_K_COMP(arg_1);
}
float
builtin_op_ell_int_e_comp (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1)
{
return ELL_INT_E_COMP(arg_1);
}
float
builtin_op_ell_int_f (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return ELL_INT_F(arg_1, arg_2);
}
float
builtin_op_ell_int_e (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return ELL_INT_E(arg_1, arg_2);
}
float
builtin_op_ell_int_p (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3)
{
return ELL_INT_P(arg_1, arg_2, arg_3);
}
float
builtin_op_ell_int_d (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3)
{
return ELL_INT_D(arg_1, arg_2, arg_3);
}
float
builtin_op_ell_int_rc (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return ELL_INT_RC(arg_1, arg_2);
}
float
builtin_op_ell_int_rd (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3)
{
return ELL_INT_RD(arg_1, arg_2, arg_3);
}
float
builtin_op_ell_int_rf (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3)
{
return ELL_INT_RF(arg_1, arg_2, arg_3);
}
float
builtin_op_ell_int_rj (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3, float arg_4)
{
return ELL_INT_RJ(arg_1, arg_2, arg_3, arg_4);
}
float *
builtin_op_ell_jac (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return ELL_JAC(arg_1, arg_2);
}
float *
builtin_op_solve_linear_2 (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float * arg_1, float * arg_2)
{
return SOLVE_LINEAR_2(arg_1, arg_2);
}
float *
builtin_op_solve_linear_3 (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float * arg_1, float * arg_2)
{
return SOLVE_LINEAR_3(arg_1, arg_2);
}
float *
builtin_op_solve_poly_2 (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3)
{
return SOLVE_POLY_2(arg_1, arg_2, arg_3);
}
float *
builtin_op_solve_poly_3 (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3, float arg_4)
{
return SOLVE_POLY_3(arg_1, arg_2, arg_3, arg_4);
}
float
builtin_op_rand (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2)
{
return RAND(arg_1, arg_2);
}
float
builtin_op_libnoise_perlin (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, float arg_2, float arg_3, float arg_4, float arg_5, float arg_6)
{
return libnoise_perlin(arg_1, arg_2, arg_3, arg_4, arg_5, arg_6);
}
float
builtin_op_libnoise_billow (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, float arg_2, float arg_3, float arg_4, float arg_5, float arg_6)
{
return libnoise_billow(arg_1, arg_2, arg_3, arg_4, arg_5, arg_6);
}
float
builtin_op_libnoise_ridged_multi (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1, float arg_2, float arg_3, float arg_4, float arg_5)
{
return libnoise_ridged_multi(arg_1, arg_2, arg_3, arg_4, arg_5);
}
float
builtin_op_libnoise_voronoi (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float arg_1, float arg_2, float arg_3, float arg_4)
{
return libnoise_voronoi(arg_1, arg_2, arg_3, arg_4);
}
int
builtin_op_userval_int (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return USERVAL_INT_ACCESS(arg_1);
}
float
builtin_op_userval_float (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return USERVAL_FLOAT_ACCESS(arg_1);
}
int
builtin_op_userval_bool (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return USERVAL_BOOL_ACCESS(arg_1);
}
color_t
builtin_op_userval_color (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return USERVAL_COLOR_ACCESS(arg_1);
}
curve_t *
builtin_op_userval_curve (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return USERVAL_CURVE_ACCESS(arg_1);
}
gradient_t *
builtin_op_userval_gradient (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return USERVAL_GRADIENT_ACCESS(arg_1);
}
image_t *
builtin_op_userval_image (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, int arg_1)
{
return USERVAL_IMAGE_ACCESS(arg_1);
}
int
builtin_op_output_tuple (mathmap_invocation_t *invocation, image_t *closure, mathmap_pools_t *pools, float * arg_1)
{
return OUTPUT_TUPLE(arg_1);
}
