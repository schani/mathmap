filter render_image (image in)
    rendered = render(in);
    rendered(xy)
end
