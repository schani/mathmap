filter ident (image in)
    in(xy)
end
