filter geom_scale (image in, float sx: -10-10 (1), float sy: -10-10 (1))
  in(xy * xy:[sx, sy])
end