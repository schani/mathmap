unit(stretched) filter tile (unit(stretched) image in, int n: 1-10 (3))
    in((xy+1)*n%2-1)
end
