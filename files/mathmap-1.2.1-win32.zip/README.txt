Hello, this is Mathmap.  I come with no warranty.  If your computer explodes upon using this application, please check your ventilation.
Assuming you get past the installation, there are quite a few cool things you can do with me.  Check out my Flickr group (http://www.flickr.com/groups/mathmap/).  Test out the examples.  Modify them to make them cooler.
And if you're tired of my tiny preview size (I think it's sufficient, myself), you can go to your .gimp-2.2 folder (try your main drive, usually c:\\, Documents and Settings, your user name, and it should be there), go to the mathmap folder inside of it, and make the number inside the "previewconf" file bigger.  Or smaller, that's cool too.
Have fun.
