filter mosaic (image in,
               float size: 0-2 (0.05))
  in(xy-(xy+XY)%size + size/2)
end
