filter render_gray (float value: 0-1)
  grayColor(value)
end
