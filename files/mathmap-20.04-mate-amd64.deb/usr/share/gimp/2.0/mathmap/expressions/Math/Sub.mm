filter math_sub (image i1, image i2)
  i1(xy) - i2(xy)
end