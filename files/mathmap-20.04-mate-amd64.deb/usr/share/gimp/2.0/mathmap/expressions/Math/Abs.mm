filter math_abs (image in)
  abs(in(xy))
end