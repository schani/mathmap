filter color_alpha_to_gray (image in)
  grayColor(alpha(in(xy)))
end