static void
gen_print (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_0;
for (tmp_0 = 0; tmp_0 < arglengths[0]; ++tmp_0)
{
{
compvar_t *tmp_1;
tmp_1 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_2;
tmp_2 = args[0][tmp_0];
emit_assign(make_lhs(tmp_1), make_op_rhs(OP_PRINT, make_compvar_primary(tmp_2)));
}
}
}
}
{
compvar_t *tmp_3;
tmp_3 = compiler_make_temporary(TYPE_INT);
{
emit_assign(make_lhs(tmp_3), make_op_rhs(OP_NEWLINE));
}
}
{
int tmp_4;
for (tmp_4 = 0; tmp_4 < 1; ++tmp_4)
{
switch (tmp_4)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_4]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_5;
for (tmp_5 = 0; tmp_5 < 2; ++tmp_5)
{
{
compvar_t *tmp_6, *tmp_7;
tmp_6 = args[0][tmp_5];
tmp_7 = args[1][tmp_5];
emit_assign(make_lhs(result_tmps[tmp_5]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_6), make_compvar_primary(tmp_7)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_ri_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_8;
for (tmp_8 = 0; tmp_8 < 2; ++tmp_8)
{
{
compvar_t *tmp_9, *tmp_10;
tmp_9 = args[0][tmp_8];
switch (tmp_8)
{
case 0 :
tmp_10 = args[1][0];
break;
case 1 :
tmp_10 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_10), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_8]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_9), make_compvar_primary(tmp_10)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_1_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_11;
for (tmp_11 = 0; tmp_11 < 2; ++tmp_11)
{
{
compvar_t *tmp_12, *tmp_13;
tmp_12 = args[1][tmp_11];
switch (tmp_11)
{
case 0 :
tmp_13 = args[0][0];
break;
case 1 :
tmp_13 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_13), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_11]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_12), make_compvar_primary(tmp_13)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_14;
for (tmp_14 = 0; tmp_14 < 1; ++tmp_14)
{
{
compvar_t *tmp_15, *tmp_16;
tmp_15 = args[0][tmp_14];
tmp_16 = args[1][tmp_14];
emit_assign(make_lhs(result_tmps[tmp_14]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_15), make_compvar_primary(tmp_16)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_s (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_17;
for (tmp_17 = 0; tmp_17 < arglengths[0]; ++tmp_17)
{
{
compvar_t *tmp_18, *tmp_19;
tmp_18 = args[0][tmp_17];
tmp_19 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_17]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_18), make_compvar_primary(tmp_19)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_20;
for (tmp_20 = 0; tmp_20 < arglengths[0]; ++tmp_20)
{
{
compvar_t *tmp_21, *tmp_22;
tmp_21 = args[0][tmp_20];
tmp_22 = args[1][tmp_20];
emit_assign(make_lhs(result_tmps[tmp_20]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_21), make_compvar_primary(tmp_22)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_23;
for (tmp_23 = 0; tmp_23 < 2; ++tmp_23)
{
{
compvar_t *tmp_24, *tmp_25;
tmp_24 = args[0][tmp_23];
tmp_25 = args[1][tmp_23];
emit_assign(make_lhs(result_tmps[tmp_23]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_24), make_compvar_primary(tmp_25)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_ri_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_26;
for (tmp_26 = 0; tmp_26 < 2; ++tmp_26)
{
{
compvar_t *tmp_27, *tmp_28;
tmp_27 = args[0][tmp_26];
switch (tmp_26)
{
case 0 :
tmp_28 = args[1][0];
break;
case 1 :
tmp_28 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_28), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_26]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_27), make_compvar_primary(tmp_28)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_1_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_29;
for (tmp_29 = 0; tmp_29 < 2; ++tmp_29)
{
{
compvar_t *tmp_30, *tmp_31;
switch (tmp_29)
{
case 0 :
tmp_30 = args[0][0];
break;
case 1 :
tmp_30 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_30), make_int_const_rhs(0));
break;
default :
assert(0);
}
tmp_31 = args[1][tmp_29];
emit_assign(make_lhs(result_tmps[tmp_29]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_30), make_compvar_primary(tmp_31)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_32;
for (tmp_32 = 0; tmp_32 < 1; ++tmp_32)
{
{
compvar_t *tmp_33, *tmp_34;
tmp_33 = args[0][tmp_32];
tmp_34 = args[1][tmp_32];
emit_assign(make_lhs(result_tmps[tmp_32]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_33), make_compvar_primary(tmp_34)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_s (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_35;
for (tmp_35 = 0; tmp_35 < arglengths[0]; ++tmp_35)
{
{
compvar_t *tmp_36, *tmp_37;
tmp_36 = args[0][tmp_35];
tmp_37 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_35]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_36), make_compvar_primary(tmp_37)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_38;
for (tmp_38 = 0; tmp_38 < arglengths[0]; ++tmp_38)
{
{
compvar_t *tmp_39, *tmp_40;
tmp_39 = args[0][tmp_38];
tmp_40 = args[1][tmp_38];
emit_assign(make_lhs(result_tmps[tmp_38]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_39), make_compvar_primary(tmp_40)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_neg (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_41;
for (tmp_41 = 0; tmp_41 < arglengths[0]; ++tmp_41)
{
{
compvar_t *tmp_42;
tmp_42 = args[0][tmp_41];
emit_assign(make_lhs(result_tmps[tmp_41]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_42)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_43;
for (tmp_43 = 0; tmp_43 < 2; ++tmp_43)
{
switch (tmp_43)
{
case 0 :
{
compvar_t *tmp_44, *tmp_45;
tmp_44 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_46, *tmp_47;
tmp_46 = args[0][0];
tmp_47 = args[1][0];
emit_assign(make_lhs(tmp_44), make_op_rhs(OP_MUL, make_compvar_primary(tmp_46), make_compvar_primary(tmp_47)));
}
tmp_45 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_48, *tmp_49;
tmp_48 = args[0][1];
tmp_49 = args[1][1];
emit_assign(make_lhs(tmp_45), make_op_rhs(OP_MUL, make_compvar_primary(tmp_48), make_compvar_primary(tmp_49)));
}
emit_assign(make_lhs(result_tmps[tmp_43]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_44), make_compvar_primary(tmp_45)));
}
break;
case 1 :
{
compvar_t *tmp_50, *tmp_51;
tmp_50 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_52, *tmp_53;
tmp_52 = args[0][0];
tmp_53 = args[1][1];
emit_assign(make_lhs(tmp_50), make_op_rhs(OP_MUL, make_compvar_primary(tmp_52), make_compvar_primary(tmp_53)));
}
tmp_51 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_54, *tmp_55;
tmp_54 = args[1][0];
tmp_55 = args[0][1];
emit_assign(make_lhs(tmp_51), make_op_rhs(OP_MUL, make_compvar_primary(tmp_54), make_compvar_primary(tmp_55)));
}
emit_assign(make_lhs(result_tmps[tmp_43]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_50), make_compvar_primary(tmp_51)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_1_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_56;
for (tmp_56 = 0; tmp_56 < 2; ++tmp_56)
{
{
compvar_t *tmp_57, *tmp_58;
tmp_57 = args[0][0];
tmp_58 = args[1][tmp_56];
emit_assign(make_lhs(result_tmps[tmp_56]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_57), make_compvar_primary(tmp_58)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m2x2 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_59;
for (tmp_59 = 0; tmp_59 < 4; ++tmp_59)
{
switch (tmp_59)
{
case 0 :
{
compvar_t *tmp_60, *tmp_61;
tmp_60 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_62, *tmp_63;
tmp_62 = args[0][0];
tmp_63 = args[1][0];
emit_assign(make_lhs(tmp_60), make_op_rhs(OP_MUL, make_compvar_primary(tmp_62), make_compvar_primary(tmp_63)));
}
tmp_61 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_64, *tmp_65;
tmp_64 = args[0][1];
tmp_65 = args[1][2];
emit_assign(make_lhs(tmp_61), make_op_rhs(OP_MUL, make_compvar_primary(tmp_64), make_compvar_primary(tmp_65)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_60), make_compvar_primary(tmp_61)));
}
break;
case 1 :
{
compvar_t *tmp_66, *tmp_67;
tmp_66 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_68, *tmp_69;
tmp_68 = args[0][0];
tmp_69 = args[1][1];
emit_assign(make_lhs(tmp_66), make_op_rhs(OP_MUL, make_compvar_primary(tmp_68), make_compvar_primary(tmp_69)));
}
tmp_67 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_70, *tmp_71;
tmp_70 = args[0][1];
tmp_71 = args[1][3];
emit_assign(make_lhs(tmp_67), make_op_rhs(OP_MUL, make_compvar_primary(tmp_70), make_compvar_primary(tmp_71)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_66), make_compvar_primary(tmp_67)));
}
break;
case 2 :
{
compvar_t *tmp_72, *tmp_73;
tmp_72 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_74, *tmp_75;
tmp_74 = args[0][2];
tmp_75 = args[1][0];
emit_assign(make_lhs(tmp_72), make_op_rhs(OP_MUL, make_compvar_primary(tmp_74), make_compvar_primary(tmp_75)));
}
tmp_73 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_76, *tmp_77;
tmp_76 = args[0][3];
tmp_77 = args[1][2];
emit_assign(make_lhs(tmp_73), make_op_rhs(OP_MUL, make_compvar_primary(tmp_76), make_compvar_primary(tmp_77)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_72), make_compvar_primary(tmp_73)));
}
break;
case 3 :
{
compvar_t *tmp_78, *tmp_79;
tmp_78 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_80, *tmp_81;
tmp_80 = args[0][2];
tmp_81 = args[1][1];
emit_assign(make_lhs(tmp_78), make_op_rhs(OP_MUL, make_compvar_primary(tmp_80), make_compvar_primary(tmp_81)));
}
tmp_79 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_82, *tmp_83;
tmp_82 = args[0][3];
tmp_83 = args[1][3];
emit_assign(make_lhs(tmp_79), make_op_rhs(OP_MUL, make_compvar_primary(tmp_82), make_compvar_primary(tmp_83)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_78), make_compvar_primary(tmp_79)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m3x3 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[9];
int i;
for (i = 0; i < 9; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_84;
for (tmp_84 = 0; tmp_84 < 9; ++tmp_84)
{
switch (tmp_84)
{
case 0 :
{
compvar_t *tmp_85, *tmp_86;
tmp_85 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_87, *tmp_88;
tmp_87 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_89, *tmp_90;
tmp_89 = args[0][0];
tmp_90 = args[1][0];
emit_assign(make_lhs(tmp_87), make_op_rhs(OP_MUL, make_compvar_primary(tmp_89), make_compvar_primary(tmp_90)));
}
tmp_88 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_91, *tmp_92;
tmp_91 = args[0][1];
tmp_92 = args[1][3];
emit_assign(make_lhs(tmp_88), make_op_rhs(OP_MUL, make_compvar_primary(tmp_91), make_compvar_primary(tmp_92)));
}
emit_assign(make_lhs(tmp_85), make_op_rhs(OP_ADD, make_compvar_primary(tmp_87), make_compvar_primary(tmp_88)));
}
tmp_86 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_93, *tmp_94;
tmp_93 = args[0][2];
tmp_94 = args[1][6];
emit_assign(make_lhs(tmp_86), make_op_rhs(OP_MUL, make_compvar_primary(tmp_93), make_compvar_primary(tmp_94)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_85), make_compvar_primary(tmp_86)));
}
break;
case 1 :
{
compvar_t *tmp_95, *tmp_96;
tmp_95 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_97, *tmp_98;
tmp_97 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_99, *tmp_100;
tmp_99 = args[0][0];
tmp_100 = args[1][1];
emit_assign(make_lhs(tmp_97), make_op_rhs(OP_MUL, make_compvar_primary(tmp_99), make_compvar_primary(tmp_100)));
}
tmp_98 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_101, *tmp_102;
tmp_101 = args[0][1];
tmp_102 = args[1][4];
emit_assign(make_lhs(tmp_98), make_op_rhs(OP_MUL, make_compvar_primary(tmp_101), make_compvar_primary(tmp_102)));
}
emit_assign(make_lhs(tmp_95), make_op_rhs(OP_ADD, make_compvar_primary(tmp_97), make_compvar_primary(tmp_98)));
}
tmp_96 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_103, *tmp_104;
tmp_103 = args[0][2];
tmp_104 = args[1][7];
emit_assign(make_lhs(tmp_96), make_op_rhs(OP_MUL, make_compvar_primary(tmp_103), make_compvar_primary(tmp_104)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_95), make_compvar_primary(tmp_96)));
}
break;
case 2 :
{
compvar_t *tmp_105, *tmp_106;
tmp_105 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_107, *tmp_108;
tmp_107 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_109, *tmp_110;
tmp_109 = args[0][0];
tmp_110 = args[1][2];
emit_assign(make_lhs(tmp_107), make_op_rhs(OP_MUL, make_compvar_primary(tmp_109), make_compvar_primary(tmp_110)));
}
tmp_108 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_111, *tmp_112;
tmp_111 = args[0][1];
tmp_112 = args[1][5];
emit_assign(make_lhs(tmp_108), make_op_rhs(OP_MUL, make_compvar_primary(tmp_111), make_compvar_primary(tmp_112)));
}
emit_assign(make_lhs(tmp_105), make_op_rhs(OP_ADD, make_compvar_primary(tmp_107), make_compvar_primary(tmp_108)));
}
tmp_106 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_113, *tmp_114;
tmp_113 = args[0][2];
tmp_114 = args[1][8];
emit_assign(make_lhs(tmp_106), make_op_rhs(OP_MUL, make_compvar_primary(tmp_113), make_compvar_primary(tmp_114)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_105), make_compvar_primary(tmp_106)));
}
break;
case 3 :
{
compvar_t *tmp_115, *tmp_116;
tmp_115 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_117, *tmp_118;
tmp_117 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_119, *tmp_120;
tmp_119 = args[0][3];
tmp_120 = args[1][0];
emit_assign(make_lhs(tmp_117), make_op_rhs(OP_MUL, make_compvar_primary(tmp_119), make_compvar_primary(tmp_120)));
}
tmp_118 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_121, *tmp_122;
tmp_121 = args[0][4];
tmp_122 = args[1][3];
emit_assign(make_lhs(tmp_118), make_op_rhs(OP_MUL, make_compvar_primary(tmp_121), make_compvar_primary(tmp_122)));
}
emit_assign(make_lhs(tmp_115), make_op_rhs(OP_ADD, make_compvar_primary(tmp_117), make_compvar_primary(tmp_118)));
}
tmp_116 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_123, *tmp_124;
tmp_123 = args[0][5];
tmp_124 = args[1][6];
emit_assign(make_lhs(tmp_116), make_op_rhs(OP_MUL, make_compvar_primary(tmp_123), make_compvar_primary(tmp_124)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_115), make_compvar_primary(tmp_116)));
}
break;
case 4 :
{
compvar_t *tmp_125, *tmp_126;
tmp_125 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_127, *tmp_128;
tmp_127 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_129, *tmp_130;
tmp_129 = args[0][3];
tmp_130 = args[1][1];
emit_assign(make_lhs(tmp_127), make_op_rhs(OP_MUL, make_compvar_primary(tmp_129), make_compvar_primary(tmp_130)));
}
tmp_128 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_131, *tmp_132;
tmp_131 = args[0][4];
tmp_132 = args[1][4];
emit_assign(make_lhs(tmp_128), make_op_rhs(OP_MUL, make_compvar_primary(tmp_131), make_compvar_primary(tmp_132)));
}
emit_assign(make_lhs(tmp_125), make_op_rhs(OP_ADD, make_compvar_primary(tmp_127), make_compvar_primary(tmp_128)));
}
tmp_126 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_133, *tmp_134;
tmp_133 = args[0][5];
tmp_134 = args[1][7];
emit_assign(make_lhs(tmp_126), make_op_rhs(OP_MUL, make_compvar_primary(tmp_133), make_compvar_primary(tmp_134)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_125), make_compvar_primary(tmp_126)));
}
break;
case 5 :
{
compvar_t *tmp_135, *tmp_136;
tmp_135 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_137, *tmp_138;
tmp_137 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_139, *tmp_140;
tmp_139 = args[0][3];
tmp_140 = args[1][2];
emit_assign(make_lhs(tmp_137), make_op_rhs(OP_MUL, make_compvar_primary(tmp_139), make_compvar_primary(tmp_140)));
}
tmp_138 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_141, *tmp_142;
tmp_141 = args[0][4];
tmp_142 = args[1][5];
emit_assign(make_lhs(tmp_138), make_op_rhs(OP_MUL, make_compvar_primary(tmp_141), make_compvar_primary(tmp_142)));
}
emit_assign(make_lhs(tmp_135), make_op_rhs(OP_ADD, make_compvar_primary(tmp_137), make_compvar_primary(tmp_138)));
}
tmp_136 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_143, *tmp_144;
tmp_143 = args[0][5];
tmp_144 = args[1][8];
emit_assign(make_lhs(tmp_136), make_op_rhs(OP_MUL, make_compvar_primary(tmp_143), make_compvar_primary(tmp_144)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_135), make_compvar_primary(tmp_136)));
}
break;
case 6 :
{
compvar_t *tmp_145, *tmp_146;
tmp_145 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_147, *tmp_148;
tmp_147 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_149, *tmp_150;
tmp_149 = args[0][6];
tmp_150 = args[1][0];
emit_assign(make_lhs(tmp_147), make_op_rhs(OP_MUL, make_compvar_primary(tmp_149), make_compvar_primary(tmp_150)));
}
tmp_148 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_151, *tmp_152;
tmp_151 = args[0][7];
tmp_152 = args[1][3];
emit_assign(make_lhs(tmp_148), make_op_rhs(OP_MUL, make_compvar_primary(tmp_151), make_compvar_primary(tmp_152)));
}
emit_assign(make_lhs(tmp_145), make_op_rhs(OP_ADD, make_compvar_primary(tmp_147), make_compvar_primary(tmp_148)));
}
tmp_146 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_153, *tmp_154;
tmp_153 = args[0][8];
tmp_154 = args[1][6];
emit_assign(make_lhs(tmp_146), make_op_rhs(OP_MUL, make_compvar_primary(tmp_153), make_compvar_primary(tmp_154)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_145), make_compvar_primary(tmp_146)));
}
break;
case 7 :
{
compvar_t *tmp_155, *tmp_156;
tmp_155 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_157, *tmp_158;
tmp_157 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_159, *tmp_160;
tmp_159 = args[0][6];
tmp_160 = args[1][1];
emit_assign(make_lhs(tmp_157), make_op_rhs(OP_MUL, make_compvar_primary(tmp_159), make_compvar_primary(tmp_160)));
}
tmp_158 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_161, *tmp_162;
tmp_161 = args[0][7];
tmp_162 = args[1][4];
emit_assign(make_lhs(tmp_158), make_op_rhs(OP_MUL, make_compvar_primary(tmp_161), make_compvar_primary(tmp_162)));
}
emit_assign(make_lhs(tmp_155), make_op_rhs(OP_ADD, make_compvar_primary(tmp_157), make_compvar_primary(tmp_158)));
}
tmp_156 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_163, *tmp_164;
tmp_163 = args[0][8];
tmp_164 = args[1][7];
emit_assign(make_lhs(tmp_156), make_op_rhs(OP_MUL, make_compvar_primary(tmp_163), make_compvar_primary(tmp_164)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_155), make_compvar_primary(tmp_156)));
}
break;
case 8 :
{
compvar_t *tmp_165, *tmp_166;
tmp_165 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_167, *tmp_168;
tmp_167 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_169, *tmp_170;
tmp_169 = args[0][6];
tmp_170 = args[1][2];
emit_assign(make_lhs(tmp_167), make_op_rhs(OP_MUL, make_compvar_primary(tmp_169), make_compvar_primary(tmp_170)));
}
tmp_168 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_171, *tmp_172;
tmp_171 = args[0][7];
tmp_172 = args[1][5];
emit_assign(make_lhs(tmp_168), make_op_rhs(OP_MUL, make_compvar_primary(tmp_171), make_compvar_primary(tmp_172)));
}
emit_assign(make_lhs(tmp_165), make_op_rhs(OP_ADD, make_compvar_primary(tmp_167), make_compvar_primary(tmp_168)));
}
tmp_166 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_173, *tmp_174;
tmp_173 = args[0][8];
tmp_174 = args[1][8];
emit_assign(make_lhs(tmp_166), make_op_rhs(OP_MUL, make_compvar_primary(tmp_173), make_compvar_primary(tmp_174)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_165), make_compvar_primary(tmp_166)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 9; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_v2m2x2 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_175;
for (tmp_175 = 0; tmp_175 < 2; ++tmp_175)
{
switch (tmp_175)
{
case 0 :
{
compvar_t *tmp_176, *tmp_177;
tmp_176 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_178, *tmp_179;
tmp_178 = args[0][0];
tmp_179 = args[1][0];
emit_assign(make_lhs(tmp_176), make_op_rhs(OP_MUL, make_compvar_primary(tmp_178), make_compvar_primary(tmp_179)));
}
tmp_177 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_180, *tmp_181;
tmp_180 = args[0][1];
tmp_181 = args[1][2];
emit_assign(make_lhs(tmp_177), make_op_rhs(OP_MUL, make_compvar_primary(tmp_180), make_compvar_primary(tmp_181)));
}
emit_assign(make_lhs(result_tmps[tmp_175]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_176), make_compvar_primary(tmp_177)));
}
break;
case 1 :
{
compvar_t *tmp_182, *tmp_183;
tmp_182 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_184, *tmp_185;
tmp_184 = args[0][0];
tmp_185 = args[1][1];
emit_assign(make_lhs(tmp_182), make_op_rhs(OP_MUL, make_compvar_primary(tmp_184), make_compvar_primary(tmp_185)));
}
tmp_183 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_186, *tmp_187;
tmp_186 = args[0][1];
tmp_187 = args[1][3];
emit_assign(make_lhs(tmp_183), make_op_rhs(OP_MUL, make_compvar_primary(tmp_186), make_compvar_primary(tmp_187)));
}
emit_assign(make_lhs(result_tmps[tmp_175]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_182), make_compvar_primary(tmp_183)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_v3m3x3 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_188;
for (tmp_188 = 0; tmp_188 < 3; ++tmp_188)
{
switch (tmp_188)
{
case 0 :
{
compvar_t *tmp_189, *tmp_190;
tmp_189 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_191, *tmp_192;
tmp_191 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_193, *tmp_194;
tmp_193 = args[0][0];
tmp_194 = args[1][0];
emit_assign(make_lhs(tmp_191), make_op_rhs(OP_MUL, make_compvar_primary(tmp_193), make_compvar_primary(tmp_194)));
}
tmp_192 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_195, *tmp_196;
tmp_195 = args[0][1];
tmp_196 = args[1][3];
emit_assign(make_lhs(tmp_192), make_op_rhs(OP_MUL, make_compvar_primary(tmp_195), make_compvar_primary(tmp_196)));
}
emit_assign(make_lhs(tmp_189), make_op_rhs(OP_ADD, make_compvar_primary(tmp_191), make_compvar_primary(tmp_192)));
}
tmp_190 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_197, *tmp_198;
tmp_197 = args[0][2];
tmp_198 = args[1][6];
emit_assign(make_lhs(tmp_190), make_op_rhs(OP_MUL, make_compvar_primary(tmp_197), make_compvar_primary(tmp_198)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_189), make_compvar_primary(tmp_190)));
}
break;
case 1 :
{
compvar_t *tmp_199, *tmp_200;
tmp_199 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_201, *tmp_202;
tmp_201 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_203, *tmp_204;
tmp_203 = args[0][0];
tmp_204 = args[1][1];
emit_assign(make_lhs(tmp_201), make_op_rhs(OP_MUL, make_compvar_primary(tmp_203), make_compvar_primary(tmp_204)));
}
tmp_202 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_205, *tmp_206;
tmp_205 = args[0][1];
tmp_206 = args[1][4];
emit_assign(make_lhs(tmp_202), make_op_rhs(OP_MUL, make_compvar_primary(tmp_205), make_compvar_primary(tmp_206)));
}
emit_assign(make_lhs(tmp_199), make_op_rhs(OP_ADD, make_compvar_primary(tmp_201), make_compvar_primary(tmp_202)));
}
tmp_200 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_207, *tmp_208;
tmp_207 = args[0][2];
tmp_208 = args[1][7];
emit_assign(make_lhs(tmp_200), make_op_rhs(OP_MUL, make_compvar_primary(tmp_207), make_compvar_primary(tmp_208)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_199), make_compvar_primary(tmp_200)));
}
break;
case 2 :
{
compvar_t *tmp_209, *tmp_210;
tmp_209 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_211, *tmp_212;
tmp_211 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_213, *tmp_214;
tmp_213 = args[0][0];
tmp_214 = args[1][2];
emit_assign(make_lhs(tmp_211), make_op_rhs(OP_MUL, make_compvar_primary(tmp_213), make_compvar_primary(tmp_214)));
}
tmp_212 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_215, *tmp_216;
tmp_215 = args[0][1];
tmp_216 = args[1][5];
emit_assign(make_lhs(tmp_212), make_op_rhs(OP_MUL, make_compvar_primary(tmp_215), make_compvar_primary(tmp_216)));
}
emit_assign(make_lhs(tmp_209), make_op_rhs(OP_ADD, make_compvar_primary(tmp_211), make_compvar_primary(tmp_212)));
}
tmp_210 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_217, *tmp_218;
tmp_217 = args[0][2];
tmp_218 = args[1][8];
emit_assign(make_lhs(tmp_210), make_op_rhs(OP_MUL, make_compvar_primary(tmp_217), make_compvar_primary(tmp_218)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_209), make_compvar_primary(tmp_210)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m2x2v2 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_219;
for (tmp_219 = 0; tmp_219 < 2; ++tmp_219)
{
switch (tmp_219)
{
case 0 :
{
compvar_t *tmp_220, *tmp_221;
tmp_220 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_222, *tmp_223;
tmp_222 = args[0][0];
tmp_223 = args[1][0];
emit_assign(make_lhs(tmp_220), make_op_rhs(OP_MUL, make_compvar_primary(tmp_222), make_compvar_primary(tmp_223)));
}
tmp_221 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_224, *tmp_225;
tmp_224 = args[0][1];
tmp_225 = args[1][1];
emit_assign(make_lhs(tmp_221), make_op_rhs(OP_MUL, make_compvar_primary(tmp_224), make_compvar_primary(tmp_225)));
}
emit_assign(make_lhs(result_tmps[tmp_219]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_220), make_compvar_primary(tmp_221)));
}
break;
case 1 :
{
compvar_t *tmp_226, *tmp_227;
tmp_226 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_228, *tmp_229;
tmp_228 = args[0][2];
tmp_229 = args[1][0];
emit_assign(make_lhs(tmp_226), make_op_rhs(OP_MUL, make_compvar_primary(tmp_228), make_compvar_primary(tmp_229)));
}
tmp_227 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_230, *tmp_231;
tmp_230 = args[0][3];
tmp_231 = args[1][1];
emit_assign(make_lhs(tmp_227), make_op_rhs(OP_MUL, make_compvar_primary(tmp_230), make_compvar_primary(tmp_231)));
}
emit_assign(make_lhs(result_tmps[tmp_219]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_226), make_compvar_primary(tmp_227)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m3x3v3 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_232;
for (tmp_232 = 0; tmp_232 < 3; ++tmp_232)
{
switch (tmp_232)
{
case 0 :
{
compvar_t *tmp_233, *tmp_234;
tmp_233 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_235, *tmp_236;
tmp_235 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_237, *tmp_238;
tmp_237 = args[0][0];
tmp_238 = args[1][0];
emit_assign(make_lhs(tmp_235), make_op_rhs(OP_MUL, make_compvar_primary(tmp_237), make_compvar_primary(tmp_238)));
}
tmp_236 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_239, *tmp_240;
tmp_239 = args[0][1];
tmp_240 = args[1][1];
emit_assign(make_lhs(tmp_236), make_op_rhs(OP_MUL, make_compvar_primary(tmp_239), make_compvar_primary(tmp_240)));
}
emit_assign(make_lhs(tmp_233), make_op_rhs(OP_ADD, make_compvar_primary(tmp_235), make_compvar_primary(tmp_236)));
}
tmp_234 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_241, *tmp_242;
tmp_241 = args[0][2];
tmp_242 = args[1][2];
emit_assign(make_lhs(tmp_234), make_op_rhs(OP_MUL, make_compvar_primary(tmp_241), make_compvar_primary(tmp_242)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_233), make_compvar_primary(tmp_234)));
}
break;
case 1 :
{
compvar_t *tmp_243, *tmp_244;
tmp_243 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_245, *tmp_246;
tmp_245 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_247, *tmp_248;
tmp_247 = args[0][3];
tmp_248 = args[1][0];
emit_assign(make_lhs(tmp_245), make_op_rhs(OP_MUL, make_compvar_primary(tmp_247), make_compvar_primary(tmp_248)));
}
tmp_246 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_249, *tmp_250;
tmp_249 = args[0][4];
tmp_250 = args[1][1];
emit_assign(make_lhs(tmp_246), make_op_rhs(OP_MUL, make_compvar_primary(tmp_249), make_compvar_primary(tmp_250)));
}
emit_assign(make_lhs(tmp_243), make_op_rhs(OP_ADD, make_compvar_primary(tmp_245), make_compvar_primary(tmp_246)));
}
tmp_244 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_251, *tmp_252;
tmp_251 = args[0][5];
tmp_252 = args[1][2];
emit_assign(make_lhs(tmp_244), make_op_rhs(OP_MUL, make_compvar_primary(tmp_251), make_compvar_primary(tmp_252)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_243), make_compvar_primary(tmp_244)));
}
break;
case 2 :
{
compvar_t *tmp_253, *tmp_254;
tmp_253 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_255, *tmp_256;
tmp_255 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_257, *tmp_258;
tmp_257 = args[0][6];
tmp_258 = args[1][0];
emit_assign(make_lhs(tmp_255), make_op_rhs(OP_MUL, make_compvar_primary(tmp_257), make_compvar_primary(tmp_258)));
}
tmp_256 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_259, *tmp_260;
tmp_259 = args[0][7];
tmp_260 = args[1][1];
emit_assign(make_lhs(tmp_256), make_op_rhs(OP_MUL, make_compvar_primary(tmp_259), make_compvar_primary(tmp_260)));
}
emit_assign(make_lhs(tmp_253), make_op_rhs(OP_ADD, make_compvar_primary(tmp_255), make_compvar_primary(tmp_256)));
}
tmp_254 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_261, *tmp_262;
tmp_261 = args[0][8];
tmp_262 = args[1][2];
emit_assign(make_lhs(tmp_254), make_op_rhs(OP_MUL, make_compvar_primary(tmp_261), make_compvar_primary(tmp_262)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_253), make_compvar_primary(tmp_254)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_quat (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_263;
for (tmp_263 = 0; tmp_263 < 4; ++tmp_263)
{
switch (tmp_263)
{
case 0 :
{
compvar_t *tmp_264, *tmp_265;
tmp_264 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_266, *tmp_267;
tmp_266 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_268, *tmp_269;
tmp_268 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_270, *tmp_271;
tmp_270 = args[0][0];
tmp_271 = args[1][0];
emit_assign(make_lhs(tmp_268), make_op_rhs(OP_MUL, make_compvar_primary(tmp_270), make_compvar_primary(tmp_271)));
}
tmp_269 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_272;
tmp_272 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_273, *tmp_274;
tmp_273 = args[0][1];
tmp_274 = args[1][1];
emit_assign(make_lhs(tmp_272), make_op_rhs(OP_MUL, make_compvar_primary(tmp_273), make_compvar_primary(tmp_274)));
}
emit_assign(make_lhs(tmp_269), make_op_rhs(OP_NEG, make_compvar_primary(tmp_272)));
}
emit_assign(make_lhs(tmp_266), make_op_rhs(OP_ADD, make_compvar_primary(tmp_268), make_compvar_primary(tmp_269)));
}
tmp_267 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_275;
tmp_275 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_276, *tmp_277;
tmp_276 = args[0][2];
tmp_277 = args[1][2];
emit_assign(make_lhs(tmp_275), make_op_rhs(OP_MUL, make_compvar_primary(tmp_276), make_compvar_primary(tmp_277)));
}
emit_assign(make_lhs(tmp_267), make_op_rhs(OP_NEG, make_compvar_primary(tmp_275)));
}
emit_assign(make_lhs(tmp_264), make_op_rhs(OP_ADD, make_compvar_primary(tmp_266), make_compvar_primary(tmp_267)));
}
tmp_265 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_278;
tmp_278 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_279, *tmp_280;
tmp_279 = args[0][3];
tmp_280 = args[1][3];
emit_assign(make_lhs(tmp_278), make_op_rhs(OP_MUL, make_compvar_primary(tmp_279), make_compvar_primary(tmp_280)));
}
emit_assign(make_lhs(tmp_265), make_op_rhs(OP_NEG, make_compvar_primary(tmp_278)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_264), make_compvar_primary(tmp_265)));
}
break;
case 1 :
{
compvar_t *tmp_281, *tmp_282;
tmp_281 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_283, *tmp_284;
tmp_283 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_285, *tmp_286;
tmp_285 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_287, *tmp_288;
tmp_287 = args[0][0];
tmp_288 = args[1][1];
emit_assign(make_lhs(tmp_285), make_op_rhs(OP_MUL, make_compvar_primary(tmp_287), make_compvar_primary(tmp_288)));
}
tmp_286 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_289, *tmp_290;
tmp_289 = args[0][1];
tmp_290 = args[1][0];
emit_assign(make_lhs(tmp_286), make_op_rhs(OP_MUL, make_compvar_primary(tmp_289), make_compvar_primary(tmp_290)));
}
emit_assign(make_lhs(tmp_283), make_op_rhs(OP_ADD, make_compvar_primary(tmp_285), make_compvar_primary(tmp_286)));
}
tmp_284 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_291, *tmp_292;
tmp_291 = args[0][2];
tmp_292 = args[1][3];
emit_assign(make_lhs(tmp_284), make_op_rhs(OP_MUL, make_compvar_primary(tmp_291), make_compvar_primary(tmp_292)));
}
emit_assign(make_lhs(tmp_281), make_op_rhs(OP_ADD, make_compvar_primary(tmp_283), make_compvar_primary(tmp_284)));
}
tmp_282 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_293;
tmp_293 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_294, *tmp_295;
tmp_294 = args[0][3];
tmp_295 = args[1][2];
emit_assign(make_lhs(tmp_293), make_op_rhs(OP_MUL, make_compvar_primary(tmp_294), make_compvar_primary(tmp_295)));
}
emit_assign(make_lhs(tmp_282), make_op_rhs(OP_NEG, make_compvar_primary(tmp_293)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_281), make_compvar_primary(tmp_282)));
}
break;
case 2 :
{
compvar_t *tmp_296, *tmp_297;
tmp_296 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_298, *tmp_299;
tmp_298 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_300, *tmp_301;
tmp_300 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_302, *tmp_303;
tmp_302 = args[0][0];
tmp_303 = args[1][2];
emit_assign(make_lhs(tmp_300), make_op_rhs(OP_MUL, make_compvar_primary(tmp_302), make_compvar_primary(tmp_303)));
}
tmp_301 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_304, *tmp_305;
tmp_304 = args[0][2];
tmp_305 = args[1][0];
emit_assign(make_lhs(tmp_301), make_op_rhs(OP_MUL, make_compvar_primary(tmp_304), make_compvar_primary(tmp_305)));
}
emit_assign(make_lhs(tmp_298), make_op_rhs(OP_ADD, make_compvar_primary(tmp_300), make_compvar_primary(tmp_301)));
}
tmp_299 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_306;
tmp_306 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_307, *tmp_308;
tmp_307 = args[0][1];
tmp_308 = args[1][3];
emit_assign(make_lhs(tmp_306), make_op_rhs(OP_MUL, make_compvar_primary(tmp_307), make_compvar_primary(tmp_308)));
}
emit_assign(make_lhs(tmp_299), make_op_rhs(OP_NEG, make_compvar_primary(tmp_306)));
}
emit_assign(make_lhs(tmp_296), make_op_rhs(OP_ADD, make_compvar_primary(tmp_298), make_compvar_primary(tmp_299)));
}
tmp_297 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_309, *tmp_310;
tmp_309 = args[0][3];
tmp_310 = args[1][1];
emit_assign(make_lhs(tmp_297), make_op_rhs(OP_MUL, make_compvar_primary(tmp_309), make_compvar_primary(tmp_310)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_296), make_compvar_primary(tmp_297)));
}
break;
case 3 :
{
compvar_t *tmp_311, *tmp_312;
tmp_311 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_313, *tmp_314;
tmp_313 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_315, *tmp_316;
tmp_315 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_317, *tmp_318;
tmp_317 = args[0][0];
tmp_318 = args[1][3];
emit_assign(make_lhs(tmp_315), make_op_rhs(OP_MUL, make_compvar_primary(tmp_317), make_compvar_primary(tmp_318)));
}
tmp_316 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_319, *tmp_320;
tmp_319 = args[0][3];
tmp_320 = args[1][0];
emit_assign(make_lhs(tmp_316), make_op_rhs(OP_MUL, make_compvar_primary(tmp_319), make_compvar_primary(tmp_320)));
}
emit_assign(make_lhs(tmp_313), make_op_rhs(OP_ADD, make_compvar_primary(tmp_315), make_compvar_primary(tmp_316)));
}
tmp_314 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_321, *tmp_322;
tmp_321 = args[0][1];
tmp_322 = args[1][2];
emit_assign(make_lhs(tmp_314), make_op_rhs(OP_MUL, make_compvar_primary(tmp_321), make_compvar_primary(tmp_322)));
}
emit_assign(make_lhs(tmp_311), make_op_rhs(OP_ADD, make_compvar_primary(tmp_313), make_compvar_primary(tmp_314)));
}
tmp_312 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_323;
tmp_323 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_324, *tmp_325;
tmp_324 = args[0][2];
tmp_325 = args[1][1];
emit_assign(make_lhs(tmp_323), make_op_rhs(OP_MUL, make_compvar_primary(tmp_324), make_compvar_primary(tmp_325)));
}
emit_assign(make_lhs(tmp_312), make_op_rhs(OP_NEG, make_compvar_primary(tmp_323)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_311), make_compvar_primary(tmp_312)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_cquat (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_326;
for (tmp_326 = 0; tmp_326 < 4; ++tmp_326)
{
switch (tmp_326)
{
case 0 :
{
compvar_t *tmp_327, *tmp_328;
tmp_327 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_329, *tmp_330;
tmp_329 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_331, *tmp_332;
tmp_331 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_333, *tmp_334;
tmp_333 = args[0][0];
tmp_334 = args[1][0];
emit_assign(make_lhs(tmp_331), make_op_rhs(OP_MUL, make_compvar_primary(tmp_333), make_compvar_primary(tmp_334)));
}
tmp_332 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_335;
tmp_335 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_336, *tmp_337;
tmp_336 = args[0][1];
tmp_337 = args[1][1];
emit_assign(make_lhs(tmp_335), make_op_rhs(OP_MUL, make_compvar_primary(tmp_336), make_compvar_primary(tmp_337)));
}
emit_assign(make_lhs(tmp_332), make_op_rhs(OP_NEG, make_compvar_primary(tmp_335)));
}
emit_assign(make_lhs(tmp_329), make_op_rhs(OP_ADD, make_compvar_primary(tmp_331), make_compvar_primary(tmp_332)));
}
tmp_330 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_338, *tmp_339;
tmp_338 = args[0][2];
tmp_339 = args[1][2];
emit_assign(make_lhs(tmp_330), make_op_rhs(OP_MUL, make_compvar_primary(tmp_338), make_compvar_primary(tmp_339)));
}
emit_assign(make_lhs(tmp_327), make_op_rhs(OP_ADD, make_compvar_primary(tmp_329), make_compvar_primary(tmp_330)));
}
tmp_328 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_340, *tmp_341;
tmp_340 = args[0][3];
tmp_341 = args[1][3];
emit_assign(make_lhs(tmp_328), make_op_rhs(OP_MUL, make_compvar_primary(tmp_340), make_compvar_primary(tmp_341)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_327), make_compvar_primary(tmp_328)));
}
break;
case 1 :
{
compvar_t *tmp_342, *tmp_343;
tmp_342 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_344, *tmp_345;
tmp_344 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_346, *tmp_347;
tmp_346 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_348, *tmp_349;
tmp_348 = args[0][0];
tmp_349 = args[1][1];
emit_assign(make_lhs(tmp_346), make_op_rhs(OP_MUL, make_compvar_primary(tmp_348), make_compvar_primary(tmp_349)));
}
tmp_347 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_350, *tmp_351;
tmp_350 = args[0][1];
tmp_351 = args[1][0];
emit_assign(make_lhs(tmp_347), make_op_rhs(OP_MUL, make_compvar_primary(tmp_350), make_compvar_primary(tmp_351)));
}
emit_assign(make_lhs(tmp_344), make_op_rhs(OP_ADD, make_compvar_primary(tmp_346), make_compvar_primary(tmp_347)));
}
tmp_345 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_352, *tmp_353;
tmp_352 = args[0][2];
tmp_353 = args[1][3];
emit_assign(make_lhs(tmp_345), make_op_rhs(OP_MUL, make_compvar_primary(tmp_352), make_compvar_primary(tmp_353)));
}
emit_assign(make_lhs(tmp_342), make_op_rhs(OP_ADD, make_compvar_primary(tmp_344), make_compvar_primary(tmp_345)));
}
tmp_343 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_354, *tmp_355;
tmp_354 = args[0][3];
tmp_355 = args[1][2];
emit_assign(make_lhs(tmp_343), make_op_rhs(OP_MUL, make_compvar_primary(tmp_354), make_compvar_primary(tmp_355)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_342), make_compvar_primary(tmp_343)));
}
break;
case 2 :
{
compvar_t *tmp_356, *tmp_357;
tmp_356 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_358, *tmp_359;
tmp_358 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_360, *tmp_361;
tmp_360 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_362, *tmp_363;
tmp_362 = args[0][0];
tmp_363 = args[1][2];
emit_assign(make_lhs(tmp_360), make_op_rhs(OP_MUL, make_compvar_primary(tmp_362), make_compvar_primary(tmp_363)));
}
tmp_361 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_364, *tmp_365;
tmp_364 = args[0][2];
tmp_365 = args[1][0];
emit_assign(make_lhs(tmp_361), make_op_rhs(OP_MUL, make_compvar_primary(tmp_364), make_compvar_primary(tmp_365)));
}
emit_assign(make_lhs(tmp_358), make_op_rhs(OP_ADD, make_compvar_primary(tmp_360), make_compvar_primary(tmp_361)));
}
tmp_359 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_366;
tmp_366 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_367, *tmp_368;
tmp_367 = args[0][1];
tmp_368 = args[1][3];
emit_assign(make_lhs(tmp_366), make_op_rhs(OP_MUL, make_compvar_primary(tmp_367), make_compvar_primary(tmp_368)));
}
emit_assign(make_lhs(tmp_359), make_op_rhs(OP_NEG, make_compvar_primary(tmp_366)));
}
emit_assign(make_lhs(tmp_356), make_op_rhs(OP_ADD, make_compvar_primary(tmp_358), make_compvar_primary(tmp_359)));
}
tmp_357 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_369;
tmp_369 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_370, *tmp_371;
tmp_370 = args[0][3];
tmp_371 = args[1][1];
emit_assign(make_lhs(tmp_369), make_op_rhs(OP_MUL, make_compvar_primary(tmp_370), make_compvar_primary(tmp_371)));
}
emit_assign(make_lhs(tmp_357), make_op_rhs(OP_NEG, make_compvar_primary(tmp_369)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_356), make_compvar_primary(tmp_357)));
}
break;
case 3 :
{
compvar_t *tmp_372, *tmp_373;
tmp_372 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_374, *tmp_375;
tmp_374 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_376, *tmp_377;
tmp_376 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_378, *tmp_379;
tmp_378 = args[0][0];
tmp_379 = args[1][3];
emit_assign(make_lhs(tmp_376), make_op_rhs(OP_MUL, make_compvar_primary(tmp_378), make_compvar_primary(tmp_379)));
}
tmp_377 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_380, *tmp_381;
tmp_380 = args[0][3];
tmp_381 = args[1][0];
emit_assign(make_lhs(tmp_377), make_op_rhs(OP_MUL, make_compvar_primary(tmp_380), make_compvar_primary(tmp_381)));
}
emit_assign(make_lhs(tmp_374), make_op_rhs(OP_ADD, make_compvar_primary(tmp_376), make_compvar_primary(tmp_377)));
}
tmp_375 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_382;
tmp_382 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_383, *tmp_384;
tmp_383 = args[0][1];
tmp_384 = args[1][2];
emit_assign(make_lhs(tmp_382), make_op_rhs(OP_MUL, make_compvar_primary(tmp_383), make_compvar_primary(tmp_384)));
}
emit_assign(make_lhs(tmp_375), make_op_rhs(OP_NEG, make_compvar_primary(tmp_382)));
}
emit_assign(make_lhs(tmp_372), make_op_rhs(OP_ADD, make_compvar_primary(tmp_374), make_compvar_primary(tmp_375)));
}
tmp_373 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_385;
tmp_385 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_386, *tmp_387;
tmp_386 = args[0][2];
tmp_387 = args[1][1];
emit_assign(make_lhs(tmp_385), make_op_rhs(OP_MUL, make_compvar_primary(tmp_386), make_compvar_primary(tmp_387)));
}
emit_assign(make_lhs(tmp_373), make_op_rhs(OP_NEG, make_compvar_primary(tmp_385)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_372), make_compvar_primary(tmp_373)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_hyper (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_388;
for (tmp_388 = 0; tmp_388 < 4; ++tmp_388)
{
switch (tmp_388)
{
case 0 :
{
compvar_t *tmp_389, *tmp_390;
tmp_389 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_391, *tmp_392;
tmp_391 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_393, *tmp_394;
tmp_393 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_395, *tmp_396;
tmp_395 = args[0][0];
tmp_396 = args[1][0];
emit_assign(make_lhs(tmp_393), make_op_rhs(OP_MUL, make_compvar_primary(tmp_395), make_compvar_primary(tmp_396)));
}
tmp_394 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_397;
tmp_397 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_398, *tmp_399;
tmp_398 = args[0][1];
tmp_399 = args[1][1];
emit_assign(make_lhs(tmp_397), make_op_rhs(OP_MUL, make_compvar_primary(tmp_398), make_compvar_primary(tmp_399)));
}
emit_assign(make_lhs(tmp_394), make_op_rhs(OP_NEG, make_compvar_primary(tmp_397)));
}
emit_assign(make_lhs(tmp_391), make_op_rhs(OP_ADD, make_compvar_primary(tmp_393), make_compvar_primary(tmp_394)));
}
tmp_392 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_400;
tmp_400 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_401, *tmp_402;
tmp_401 = args[0][2];
tmp_402 = args[1][2];
emit_assign(make_lhs(tmp_400), make_op_rhs(OP_MUL, make_compvar_primary(tmp_401), make_compvar_primary(tmp_402)));
}
emit_assign(make_lhs(tmp_392), make_op_rhs(OP_NEG, make_compvar_primary(tmp_400)));
}
emit_assign(make_lhs(tmp_389), make_op_rhs(OP_ADD, make_compvar_primary(tmp_391), make_compvar_primary(tmp_392)));
}
tmp_390 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_403, *tmp_404;
tmp_403 = args[0][3];
tmp_404 = args[1][3];
emit_assign(make_lhs(tmp_390), make_op_rhs(OP_MUL, make_compvar_primary(tmp_403), make_compvar_primary(tmp_404)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_389), make_compvar_primary(tmp_390)));
}
break;
case 1 :
{
compvar_t *tmp_405, *tmp_406;
tmp_405 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_407, *tmp_408;
tmp_407 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_409, *tmp_410;
tmp_409 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_411, *tmp_412;
tmp_411 = args[0][0];
tmp_412 = args[1][1];
emit_assign(make_lhs(tmp_409), make_op_rhs(OP_MUL, make_compvar_primary(tmp_411), make_compvar_primary(tmp_412)));
}
tmp_410 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_413, *tmp_414;
tmp_413 = args[0][1];
tmp_414 = args[1][0];
emit_assign(make_lhs(tmp_410), make_op_rhs(OP_MUL, make_compvar_primary(tmp_413), make_compvar_primary(tmp_414)));
}
emit_assign(make_lhs(tmp_407), make_op_rhs(OP_ADD, make_compvar_primary(tmp_409), make_compvar_primary(tmp_410)));
}
tmp_408 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_415;
tmp_415 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_416, *tmp_417;
tmp_416 = args[0][2];
tmp_417 = args[1][3];
emit_assign(make_lhs(tmp_415), make_op_rhs(OP_MUL, make_compvar_primary(tmp_416), make_compvar_primary(tmp_417)));
}
emit_assign(make_lhs(tmp_408), make_op_rhs(OP_NEG, make_compvar_primary(tmp_415)));
}
emit_assign(make_lhs(tmp_405), make_op_rhs(OP_ADD, make_compvar_primary(tmp_407), make_compvar_primary(tmp_408)));
}
tmp_406 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_418;
tmp_418 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_419, *tmp_420;
tmp_419 = args[0][3];
tmp_420 = args[1][2];
emit_assign(make_lhs(tmp_418), make_op_rhs(OP_MUL, make_compvar_primary(tmp_419), make_compvar_primary(tmp_420)));
}
emit_assign(make_lhs(tmp_406), make_op_rhs(OP_NEG, make_compvar_primary(tmp_418)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_405), make_compvar_primary(tmp_406)));
}
break;
case 2 :
{
compvar_t *tmp_421, *tmp_422;
tmp_421 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_423, *tmp_424;
tmp_423 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_425, *tmp_426;
tmp_425 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_427, *tmp_428;
tmp_427 = args[0][0];
tmp_428 = args[1][2];
emit_assign(make_lhs(tmp_425), make_op_rhs(OP_MUL, make_compvar_primary(tmp_427), make_compvar_primary(tmp_428)));
}
tmp_426 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_429, *tmp_430;
tmp_429 = args[0][2];
tmp_430 = args[1][0];
emit_assign(make_lhs(tmp_426), make_op_rhs(OP_MUL, make_compvar_primary(tmp_429), make_compvar_primary(tmp_430)));
}
emit_assign(make_lhs(tmp_423), make_op_rhs(OP_ADD, make_compvar_primary(tmp_425), make_compvar_primary(tmp_426)));
}
tmp_424 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_431;
tmp_431 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_432, *tmp_433;
tmp_432 = args[0][1];
tmp_433 = args[1][3];
emit_assign(make_lhs(tmp_431), make_op_rhs(OP_MUL, make_compvar_primary(tmp_432), make_compvar_primary(tmp_433)));
}
emit_assign(make_lhs(tmp_424), make_op_rhs(OP_NEG, make_compvar_primary(tmp_431)));
}
emit_assign(make_lhs(tmp_421), make_op_rhs(OP_ADD, make_compvar_primary(tmp_423), make_compvar_primary(tmp_424)));
}
tmp_422 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_434;
tmp_434 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_435, *tmp_436;
tmp_435 = args[0][3];
tmp_436 = args[1][1];
emit_assign(make_lhs(tmp_434), make_op_rhs(OP_MUL, make_compvar_primary(tmp_435), make_compvar_primary(tmp_436)));
}
emit_assign(make_lhs(tmp_422), make_op_rhs(OP_NEG, make_compvar_primary(tmp_434)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_421), make_compvar_primary(tmp_422)));
}
break;
case 3 :
{
compvar_t *tmp_437, *tmp_438;
tmp_437 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_439, *tmp_440;
tmp_439 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_441, *tmp_442;
tmp_441 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_443, *tmp_444;
tmp_443 = args[0][0];
tmp_444 = args[1][3];
emit_assign(make_lhs(tmp_441), make_op_rhs(OP_MUL, make_compvar_primary(tmp_443), make_compvar_primary(tmp_444)));
}
tmp_442 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_445, *tmp_446;
tmp_445 = args[0][3];
tmp_446 = args[1][0];
emit_assign(make_lhs(tmp_442), make_op_rhs(OP_MUL, make_compvar_primary(tmp_445), make_compvar_primary(tmp_446)));
}
emit_assign(make_lhs(tmp_439), make_op_rhs(OP_ADD, make_compvar_primary(tmp_441), make_compvar_primary(tmp_442)));
}
tmp_440 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_447, *tmp_448;
tmp_447 = args[0][1];
tmp_448 = args[1][2];
emit_assign(make_lhs(tmp_440), make_op_rhs(OP_MUL, make_compvar_primary(tmp_447), make_compvar_primary(tmp_448)));
}
emit_assign(make_lhs(tmp_437), make_op_rhs(OP_ADD, make_compvar_primary(tmp_439), make_compvar_primary(tmp_440)));
}
tmp_438 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_449, *tmp_450;
tmp_449 = args[0][2];
tmp_450 = args[1][1];
emit_assign(make_lhs(tmp_438), make_op_rhs(OP_MUL, make_compvar_primary(tmp_449), make_compvar_primary(tmp_450)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_437), make_compvar_primary(tmp_438)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_451;
for (tmp_451 = 0; tmp_451 < 1; ++tmp_451)
{
switch (tmp_451)
{
case 0 :
{
compvar_t *tmp_452, *tmp_453;
tmp_452 = args[0][0];
tmp_453 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_451]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_452), make_compvar_primary(tmp_453)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_s (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_454;
for (tmp_454 = 0; tmp_454 < arglengths[0]; ++tmp_454)
{
{
compvar_t *tmp_455, *tmp_456;
tmp_455 = args[0][tmp_454];
tmp_456 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_454]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_455), make_compvar_primary(tmp_456)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_457;
for (tmp_457 = 0; tmp_457 < arglengths[0]; ++tmp_457)
{
{
compvar_t *tmp_458, *tmp_459;
tmp_458 = args[0][tmp_457];
tmp_459 = args[1][tmp_457];
emit_assign(make_lhs(result_tmps[tmp_457]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_458), make_compvar_primary(tmp_459)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_460;
tmp_460 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_461, *tmp_462;
tmp_461 = args[1][0];
tmp_462 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_462), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_460), make_op_rhs(OP_EQ, make_compvar_primary(tmp_461), make_compvar_primary(tmp_462)));
}
start_if_cond(make_compvar_rhs(tmp_460));
{
compvar_t *tmp_463, *tmp_464;
tmp_463 = args[1][1];
tmp_464 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_464), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_460), make_op_rhs(OP_EQ, make_compvar_primary(tmp_463), make_compvar_primary(tmp_464)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_460));
{
int tmp_465;
for (tmp_465 = 0; tmp_465 < 2; ++tmp_465)
{
switch (tmp_465)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_465]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_465]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_466;

if (2 == 1)
{
tmp_466 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_470, *tmp_471;
tmp_470 = args[1][0];
tmp_471 = args[1][0];
emit_assign(make_lhs(tmp_466), make_op_rhs(OP_MUL, make_compvar_primary(tmp_470), make_compvar_primary(tmp_471)));
}

}
else
{
compvar_t *tmp_467, *tmp_468;
int tmp_469;
tmp_466 = compiler_make_temporary(TYPE_INT);
tmp_467 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_472, *tmp_473;
tmp_472 = args[1][0];
tmp_473 = args[1][0];
emit_assign(make_lhs(tmp_467), make_op_rhs(OP_MUL, make_compvar_primary(tmp_472), make_compvar_primary(tmp_473)));
}
tmp_468 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_474, *tmp_475;
tmp_474 = args[1][1];
tmp_475 = args[1][1];
emit_assign(make_lhs(tmp_468), make_op_rhs(OP_MUL, make_compvar_primary(tmp_474), make_compvar_primary(tmp_475)));
}
emit_assign(make_lhs(tmp_466), make_op_rhs(OP_ADD, make_compvar_primary(tmp_467), make_compvar_primary(tmp_468)));
for (tmp_469 = 2; tmp_469 < 2; ++tmp_469)
{
tmp_467 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_476, *tmp_477;
tmp_476 = args[1][tmp_469];
tmp_477 = args[1][tmp_469];
emit_assign(make_lhs(tmp_467), make_op_rhs(OP_MUL, make_compvar_primary(tmp_476), make_compvar_primary(tmp_477)));
}
emit_assign(make_lhs(tmp_466), make_op_rhs(OP_ADD, make_compvar_primary(tmp_466), make_compvar_primary(tmp_467)));
}
}

{
int tmp_478;
for (tmp_478 = 0; tmp_478 < 2; ++tmp_478)
{
switch (tmp_478)
{
case 0 :
{
compvar_t *tmp_479, *tmp_480;
if (2 == 1)
{
tmp_479 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_484, *tmp_485;
tmp_484 = args[0][0];
tmp_485 = args[1][0];
emit_assign(make_lhs(tmp_479), make_op_rhs(OP_MUL, make_compvar_primary(tmp_484), make_compvar_primary(tmp_485)));
}

}
else
{
compvar_t *tmp_481, *tmp_482;
int tmp_483;
tmp_479 = compiler_make_temporary(TYPE_INT);
tmp_481 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_486, *tmp_487;
tmp_486 = args[0][0];
tmp_487 = args[1][0];
emit_assign(make_lhs(tmp_481), make_op_rhs(OP_MUL, make_compvar_primary(tmp_486), make_compvar_primary(tmp_487)));
}
tmp_482 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_488, *tmp_489;
tmp_488 = args[0][1];
tmp_489 = args[1][1];
emit_assign(make_lhs(tmp_482), make_op_rhs(OP_MUL, make_compvar_primary(tmp_488), make_compvar_primary(tmp_489)));
}
emit_assign(make_lhs(tmp_479), make_op_rhs(OP_ADD, make_compvar_primary(tmp_481), make_compvar_primary(tmp_482)));
for (tmp_483 = 2; tmp_483 < 2; ++tmp_483)
{
tmp_481 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_490, *tmp_491;
tmp_490 = args[0][tmp_483];
tmp_491 = args[1][tmp_483];
emit_assign(make_lhs(tmp_481), make_op_rhs(OP_MUL, make_compvar_primary(tmp_490), make_compvar_primary(tmp_491)));
}
emit_assign(make_lhs(tmp_479), make_op_rhs(OP_ADD, make_compvar_primary(tmp_479), make_compvar_primary(tmp_481)));
}
}
tmp_480 = tmp_466;
emit_assign(make_lhs(result_tmps[tmp_478]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_479), make_compvar_primary(tmp_480)));
}
break;
case 1 :
{
compvar_t *tmp_492, *tmp_493;
tmp_492 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_494, *tmp_495;
tmp_494 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_496, *tmp_497;
tmp_496 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_498;
tmp_498 = args[0][0];
emit_assign(make_lhs(tmp_496), make_op_rhs(OP_NEG, make_compvar_primary(tmp_498)));
}
tmp_497 = args[1][1];
emit_assign(make_lhs(tmp_494), make_op_rhs(OP_MUL, make_compvar_primary(tmp_496), make_compvar_primary(tmp_497)));
}
tmp_495 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_499, *tmp_500;
tmp_499 = args[1][0];
tmp_500 = args[0][1];
emit_assign(make_lhs(tmp_495), make_op_rhs(OP_MUL, make_compvar_primary(tmp_499), make_compvar_primary(tmp_500)));
}
emit_assign(make_lhs(tmp_492), make_op_rhs(OP_ADD, make_compvar_primary(tmp_494), make_compvar_primary(tmp_495)));
}
tmp_493 = tmp_466;
emit_assign(make_lhs(result_tmps[tmp_478]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_492), make_compvar_primary(tmp_493)));
}
break;
default :
assert(0);
}
}
}
}
end_if_cond();
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_1_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_501;

if (2 == 1)
{
tmp_501 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_505, *tmp_506;
tmp_505 = args[1][0];
tmp_506 = args[1][0];
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_MUL, make_compvar_primary(tmp_505), make_compvar_primary(tmp_506)));
}

}
else
{
compvar_t *tmp_502, *tmp_503;
int tmp_504;
tmp_501 = compiler_make_temporary(TYPE_INT);
tmp_502 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_507, *tmp_508;
tmp_507 = args[1][0];
tmp_508 = args[1][0];
emit_assign(make_lhs(tmp_502), make_op_rhs(OP_MUL, make_compvar_primary(tmp_507), make_compvar_primary(tmp_508)));
}
tmp_503 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_509, *tmp_510;
tmp_509 = args[1][1];
tmp_510 = args[1][1];
emit_assign(make_lhs(tmp_503), make_op_rhs(OP_MUL, make_compvar_primary(tmp_509), make_compvar_primary(tmp_510)));
}
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_ADD, make_compvar_primary(tmp_502), make_compvar_primary(tmp_503)));
for (tmp_504 = 2; tmp_504 < 2; ++tmp_504)
{
tmp_502 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_511, *tmp_512;
tmp_511 = args[1][tmp_504];
tmp_512 = args[1][tmp_504];
emit_assign(make_lhs(tmp_502), make_op_rhs(OP_MUL, make_compvar_primary(tmp_511), make_compvar_primary(tmp_512)));
}
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_ADD, make_compvar_primary(tmp_501), make_compvar_primary(tmp_502)));
}
}

{
compvar_t *tmp_513;
tmp_513 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_514, *tmp_515;
tmp_514 = tmp_501;
tmp_515 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_515), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_513), make_op_rhs(OP_EQ, make_compvar_primary(tmp_514), make_compvar_primary(tmp_515)));
}
start_if_cond(make_compvar_rhs(tmp_513));
{
int tmp_516;
for (tmp_516 = 0; tmp_516 < 2; ++tmp_516)
{
switch (tmp_516)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_516]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_516]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_517;
for (tmp_517 = 0; tmp_517 < 2; ++tmp_517)
{
switch (tmp_517)
{
case 0 :
{
compvar_t *tmp_518, *tmp_519;
tmp_518 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_520, *tmp_521;
tmp_520 = args[0][0];
tmp_521 = args[1][0];
emit_assign(make_lhs(tmp_518), make_op_rhs(OP_MUL, make_compvar_primary(tmp_520), make_compvar_primary(tmp_521)));
}
tmp_519 = tmp_501;
emit_assign(make_lhs(result_tmps[tmp_517]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_518), make_compvar_primary(tmp_519)));
}
break;
case 1 :
{
compvar_t *tmp_522;
tmp_522 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_523, *tmp_524;
tmp_523 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_525, *tmp_526;
tmp_525 = args[0][0];
tmp_526 = args[1][1];
emit_assign(make_lhs(tmp_523), make_op_rhs(OP_MUL, make_compvar_primary(tmp_525), make_compvar_primary(tmp_526)));
}
tmp_524 = tmp_501;
emit_assign(make_lhs(tmp_522), make_op_rhs(OP_DIV, make_compvar_primary(tmp_523), make_compvar_primary(tmp_524)));
}
emit_assign(make_lhs(result_tmps[tmp_517]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_522)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_v2m2x2 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_527;
compvar_t *tmp_532;

tmp_527 = compiler_make_temporary(TYPE_M2X2);
{
compvar_t *tmp_528, *tmp_529, *tmp_530, *tmp_531;
tmp_528 = args[1][0];
tmp_529 = args[1][1];
tmp_530 = args[1][2];
tmp_531 = args[1][3];
emit_assign(make_lhs(tmp_527), make_op_rhs(OP_MAKE_M2X2, make_compvar_primary(tmp_528), make_compvar_primary(tmp_529), make_compvar_primary(tmp_530), make_compvar_primary(tmp_531)));
}

tmp_532 = compiler_make_temporary(TYPE_V2);
{
compvar_t *tmp_533, *tmp_534;
tmp_533 = args[0][0];
tmp_534 = args[0][1];
emit_assign(make_lhs(tmp_532), make_op_rhs(OP_MAKE_V2, make_compvar_primary(tmp_533), make_compvar_primary(tmp_534)));
}

{
compvar_t *tmp_535;

tmp_535 = compiler_make_temporary(TYPE_V2);
{
compvar_t *tmp_536, *tmp_537;
tmp_536 = tmp_527;
tmp_537 = tmp_532;
emit_assign(make_lhs(tmp_535), make_op_rhs(OP_SOLVE_LINEAR_2, make_compvar_primary(tmp_536), make_compvar_primary(tmp_537)));
}

{
int tmp_538;
for (tmp_538 = 0; tmp_538 < 2; ++tmp_538)
{
switch (tmp_538)
{
case 0 :
{
compvar_t *tmp_539, *tmp_540;
tmp_539 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_539), make_int_const_rhs(0));
tmp_540 = tmp_535;
emit_assign(make_lhs(result_tmps[tmp_538]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_539), make_compvar_primary(tmp_540)));
}
break;
case 1 :
{
compvar_t *tmp_541, *tmp_542;
tmp_541 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_541), make_int_const_rhs(1));
tmp_542 = tmp_535;
emit_assign(make_lhs(result_tmps[tmp_538]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_541), make_compvar_primary(tmp_542)));
}
break;
default :
assert(0);
}
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_v3m3x3 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_543;
compvar_t *tmp_553;

tmp_543 = compiler_make_temporary(TYPE_GSL_MATRIX);
{
compvar_t *tmp_544, *tmp_545, *tmp_546, *tmp_547, *tmp_548, *tmp_549, *tmp_550, *tmp_551, *tmp_552;
tmp_544 = args[1][0];
tmp_545 = args[1][1];
tmp_546 = args[1][2];
tmp_547 = args[1][3];
tmp_548 = args[1][4];
tmp_549 = args[1][5];
tmp_550 = args[1][6];
tmp_551 = args[1][7];
tmp_552 = args[1][8];
emit_assign(make_lhs(tmp_543), make_op_rhs(OP_MAKE_M3X3, make_compvar_primary(tmp_544), make_compvar_primary(tmp_545), make_compvar_primary(tmp_546), make_compvar_primary(tmp_547), make_compvar_primary(tmp_548), make_compvar_primary(tmp_549), make_compvar_primary(tmp_550), make_compvar_primary(tmp_551), make_compvar_primary(tmp_552)));
}

tmp_553 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_554, *tmp_555, *tmp_556;
tmp_554 = args[0][0];
tmp_555 = args[0][1];
tmp_556 = args[0][2];
emit_assign(make_lhs(tmp_553), make_op_rhs(OP_MAKE_V3, make_compvar_primary(tmp_554), make_compvar_primary(tmp_555), make_compvar_primary(tmp_556)));
}

{
compvar_t *tmp_557;

tmp_557 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_558, *tmp_559;
tmp_558 = tmp_543;
tmp_559 = tmp_553;
emit_assign(make_lhs(tmp_557), make_op_rhs(OP_SOLVE_LINEAR_3, make_compvar_primary(tmp_558), make_compvar_primary(tmp_559)));
}

{
int tmp_560;
for (tmp_560 = 0; tmp_560 < 3; ++tmp_560)
{
switch (tmp_560)
{
case 0 :
{
compvar_t *tmp_561, *tmp_562;
tmp_561 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_561), make_int_const_rhs(0));
tmp_562 = tmp_557;
emit_assign(make_lhs(result_tmps[tmp_560]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_561), make_compvar_primary(tmp_562)));
}
break;
case 1 :
{
compvar_t *tmp_563, *tmp_564;
tmp_563 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_563), make_int_const_rhs(1));
tmp_564 = tmp_557;
emit_assign(make_lhs(result_tmps[tmp_560]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_563), make_compvar_primary(tmp_564)));
}
break;
case 2 :
{
compvar_t *tmp_565, *tmp_566;
tmp_565 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_565), make_int_const_rhs(2));
tmp_566 = tmp_557;
emit_assign(make_lhs(result_tmps[tmp_560]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_565), make_compvar_primary(tmp_566)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_567;
tmp_567 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_568;
tmp_568 = tmp_543;
emit_assign(make_lhs(tmp_567), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_568)));
}
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_569;
tmp_569 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_570, *tmp_571;
tmp_570 = args[1][0];
tmp_571 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_571), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_569), make_op_rhs(OP_EQ, make_compvar_primary(tmp_570), make_compvar_primary(tmp_571)));
}
start_if_cond(make_compvar_rhs(tmp_569));
{
int tmp_572;
for (tmp_572 = 0; tmp_572 < 1; ++tmp_572)
{
switch (tmp_572)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_572]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_573;
for (tmp_573 = 0; tmp_573 < 1; ++tmp_573)
{
{
compvar_t *tmp_574, *tmp_575;
tmp_574 = args[0][tmp_573];
tmp_575 = args[1][tmp_573];
emit_assign(make_lhs(result_tmps[tmp_573]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_574), make_compvar_primary(tmp_575)));
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_s (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_576;
tmp_576 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_577, *tmp_578;
tmp_577 = args[1][0];
tmp_578 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_578), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_576), make_op_rhs(OP_EQ, make_compvar_primary(tmp_577), make_compvar_primary(tmp_578)));
}
start_if_cond(make_compvar_rhs(tmp_576));
{
int tmp_579;
for (tmp_579 = 0; tmp_579 < arglengths[0]; ++tmp_579)
{
emit_assign(make_lhs(result_tmps[tmp_579]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_580;
for (tmp_580 = 0; tmp_580 < arglengths[0]; ++tmp_580)
{
{
compvar_t *tmp_581, *tmp_582;
tmp_581 = args[0][tmp_580];
tmp_582 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_580]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_581), make_compvar_primary(tmp_582)));
}
}
}
end_if_cond();
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_583;
for (tmp_583 = 0; tmp_583 < arglengths[1]; ++tmp_583)
{
{
compvar_t *tmp_584;
tmp_584 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_585, *tmp_586;
tmp_585 = args[1][tmp_583];
tmp_586 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_586), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_584), make_op_rhs(OP_EQ, make_compvar_primary(tmp_585), make_compvar_primary(tmp_586)));
}
start_if_cond(make_compvar_rhs(tmp_584));
emit_assign(make_lhs(result_tmps[tmp_583]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_587, *tmp_588;
tmp_587 = args[0][tmp_583];
tmp_588 = args[1][tmp_583];
emit_assign(make_lhs(result_tmps[tmp_583]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_587), make_compvar_primary(tmp_588)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_589;
tmp_589 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_590, *tmp_591;
tmp_590 = args[1][0];
tmp_591 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_591), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_589), make_op_rhs(OP_EQ, make_compvar_primary(tmp_590), make_compvar_primary(tmp_591)));
}
start_if_cond(make_compvar_rhs(tmp_589));
{
int tmp_592;
for (tmp_592 = 0; tmp_592 < 1; ++tmp_592)
{
switch (tmp_592)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_592]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_593;
for (tmp_593 = 0; tmp_593 < 1; ++tmp_593)
{
{
compvar_t *tmp_594, *tmp_595;
tmp_594 = args[0][tmp_593];
tmp_595 = args[1][tmp_593];
emit_assign(make_lhs(result_tmps[tmp_593]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_594), make_compvar_primary(tmp_595)));
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_s (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_596;
tmp_596 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_597, *tmp_598;
tmp_597 = args[1][0];
tmp_598 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_598), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_596), make_op_rhs(OP_EQ, make_compvar_primary(tmp_597), make_compvar_primary(tmp_598)));
}
start_if_cond(make_compvar_rhs(tmp_596));
{
int tmp_599;
for (tmp_599 = 0; tmp_599 < arglengths[0]; ++tmp_599)
{
emit_assign(make_lhs(result_tmps[tmp_599]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_600;
for (tmp_600 = 0; tmp_600 < arglengths[0]; ++tmp_600)
{
{
compvar_t *tmp_601, *tmp_602;
tmp_601 = args[0][tmp_600];
tmp_602 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_600]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_601), make_compvar_primary(tmp_602)));
}
}
}
end_if_cond();
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_603;
for (tmp_603 = 0; tmp_603 < arglengths[1]; ++tmp_603)
{
{
compvar_t *tmp_604;
tmp_604 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_605, *tmp_606;
tmp_605 = args[1][tmp_603];
tmp_606 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_606), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_604), make_op_rhs(OP_EQ, make_compvar_primary(tmp_605), make_compvar_primary(tmp_606)));
}
start_if_cond(make_compvar_rhs(tmp_604));
emit_assign(make_lhs(result_tmps[tmp_603]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_607, *tmp_608;
tmp_607 = args[0][tmp_603];
tmp_608 = args[1][tmp_603];
emit_assign(make_lhs(result_tmps[tmp_603]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_607), make_compvar_primary(tmp_608)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pmod (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_609;

tmp_609 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_610, *tmp_611;
tmp_610 = args[0][0];
tmp_611 = args[1][0];
emit_assign(make_lhs(tmp_609), make_op_rhs(OP_MOD, make_compvar_primary(tmp_610), make_compvar_primary(tmp_611)));
}

{
compvar_t *tmp_612;
tmp_612 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_613, *tmp_614;
tmp_613 = args[0][0];
tmp_614 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_614), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_612), make_op_rhs(OP_LESS, make_compvar_primary(tmp_613), make_compvar_primary(tmp_614)));
}
start_if_cond(make_compvar_rhs(tmp_612));
{
int tmp_615;
for (tmp_615 = 0; tmp_615 < 1; ++tmp_615)
{
switch (tmp_615)
{
case 0 :
{
compvar_t *tmp_616, *tmp_617;
tmp_616 = tmp_609;
tmp_617 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_615]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_616), make_compvar_primary(tmp_617)));
}
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_618;
for (tmp_618 = 0; tmp_618 < 1; ++tmp_618)
{
switch (tmp_618)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_618]), make_compvar_rhs(tmp_609));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sqrt_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_619;

tmp_619 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_620;
tmp_620 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_621, *tmp_622;
tmp_621 = args[0][0];
tmp_622 = args[0][1];
emit_assign(make_lhs(tmp_620), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_621), make_compvar_primary(tmp_622)));
}
emit_assign(make_lhs(tmp_619), make_op_rhs(OP_C_SQRT, make_compvar_primary(tmp_620)));
}

{
int tmp_623;
for (tmp_623 = 0; tmp_623 < 2; ++tmp_623)
{
switch (tmp_623)
{
case 0 :
{
compvar_t *tmp_624;
tmp_624 = tmp_619;
emit_assign(make_lhs(result_tmps[tmp_623]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_624)));
}
break;
case 1 :
{
compvar_t *tmp_625;
tmp_625 = tmp_619;
emit_assign(make_lhs(result_tmps[tmp_623]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_625)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sqrt_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_626;
for (tmp_626 = 0; tmp_626 < 1; ++tmp_626)
{
switch (tmp_626)
{
case 0 :
{
compvar_t *tmp_627;
tmp_627 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_626]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_627)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sum (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_628;
for (tmp_628 = 0; tmp_628 < 1; ++tmp_628)
{
switch (tmp_628)
{
case 0 :
if (arglengths[0] == 1)
{
emit_assign(make_lhs(result_tmps[tmp_628]), make_compvar_rhs(args[0][0]));

}
else
{
compvar_t *tmp_629, *tmp_630;
int tmp_631;
tmp_629 = args[0][0];
tmp_630 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_628]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_629), make_compvar_primary(tmp_630)));
for (tmp_631 = 2; tmp_631 < arglengths[0]; ++tmp_631)
{
tmp_629 = args[0][tmp_631];
emit_assign(make_lhs(result_tmps[tmp_628]), make_op_rhs(OP_ADD, make_compvar_primary(result_tmps[tmp_628]), make_compvar_primary(tmp_629)));
}
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_dotp (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_632;
for (tmp_632 = 0; tmp_632 < 1; ++tmp_632)
{
switch (tmp_632)
{
case 0 :
if (arglengths[0] == 1)
{
{
compvar_t *tmp_636, *tmp_637;
tmp_636 = args[0][0];
tmp_637 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_632]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_636), make_compvar_primary(tmp_637)));
}

}
else
{
compvar_t *tmp_633, *tmp_634;
int tmp_635;
tmp_633 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_638, *tmp_639;
tmp_638 = args[0][0];
tmp_639 = args[1][0];
emit_assign(make_lhs(tmp_633), make_op_rhs(OP_MUL, make_compvar_primary(tmp_638), make_compvar_primary(tmp_639)));
}
tmp_634 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_640, *tmp_641;
tmp_640 = args[0][1];
tmp_641 = args[1][1];
emit_assign(make_lhs(tmp_634), make_op_rhs(OP_MUL, make_compvar_primary(tmp_640), make_compvar_primary(tmp_641)));
}
emit_assign(make_lhs(result_tmps[tmp_632]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_633), make_compvar_primary(tmp_634)));
for (tmp_635 = 2; tmp_635 < arglengths[0]; ++tmp_635)
{
tmp_633 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_642, *tmp_643;
tmp_642 = args[0][tmp_635];
tmp_643 = args[1][tmp_635];
emit_assign(make_lhs(tmp_633), make_op_rhs(OP_MUL, make_compvar_primary(tmp_642), make_compvar_primary(tmp_643)));
}
emit_assign(make_lhs(result_tmps[tmp_632]), make_op_rhs(OP_ADD, make_compvar_primary(result_tmps[tmp_632]), make_compvar_primary(tmp_633)));
}
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_crossp (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_644;
for (tmp_644 = 0; tmp_644 < 3; ++tmp_644)
{
switch (tmp_644)
{
case 0 :
{
compvar_t *tmp_645, *tmp_646;
tmp_645 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_647, *tmp_648;
tmp_647 = args[0][1];
tmp_648 = args[1][2];
emit_assign(make_lhs(tmp_645), make_op_rhs(OP_MUL, make_compvar_primary(tmp_647), make_compvar_primary(tmp_648)));
}
tmp_646 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_649, *tmp_650;
tmp_649 = args[0][2];
tmp_650 = args[1][1];
emit_assign(make_lhs(tmp_646), make_op_rhs(OP_MUL, make_compvar_primary(tmp_649), make_compvar_primary(tmp_650)));
}
emit_assign(make_lhs(result_tmps[tmp_644]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_645), make_compvar_primary(tmp_646)));
}
break;
case 1 :
{
compvar_t *tmp_651, *tmp_652;
tmp_651 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_653, *tmp_654;
tmp_653 = args[0][2];
tmp_654 = args[1][0];
emit_assign(make_lhs(tmp_651), make_op_rhs(OP_MUL, make_compvar_primary(tmp_653), make_compvar_primary(tmp_654)));
}
tmp_652 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_655, *tmp_656;
tmp_655 = args[0][0];
tmp_656 = args[1][2];
emit_assign(make_lhs(tmp_652), make_op_rhs(OP_MUL, make_compvar_primary(tmp_655), make_compvar_primary(tmp_656)));
}
emit_assign(make_lhs(result_tmps[tmp_644]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_651), make_compvar_primary(tmp_652)));
}
break;
case 2 :
{
compvar_t *tmp_657, *tmp_658;
tmp_657 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_659, *tmp_660;
tmp_659 = args[0][0];
tmp_660 = args[1][1];
emit_assign(make_lhs(tmp_657), make_op_rhs(OP_MUL, make_compvar_primary(tmp_659), make_compvar_primary(tmp_660)));
}
tmp_658 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_661, *tmp_662;
tmp_661 = args[0][1];
tmp_662 = args[1][0];
emit_assign(make_lhs(tmp_658), make_op_rhs(OP_MUL, make_compvar_primary(tmp_661), make_compvar_primary(tmp_662)));
}
emit_assign(make_lhs(result_tmps[tmp_644]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_657), make_compvar_primary(tmp_658)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_det_m2x2 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_663;
for (tmp_663 = 0; tmp_663 < 1; ++tmp_663)
{
switch (tmp_663)
{
case 0 :
{
compvar_t *tmp_664, *tmp_665;
tmp_664 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_666, *tmp_667;
tmp_666 = args[0][0];
tmp_667 = args[0][3];
emit_assign(make_lhs(tmp_664), make_op_rhs(OP_MUL, make_compvar_primary(tmp_666), make_compvar_primary(tmp_667)));
}
tmp_665 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_668, *tmp_669;
tmp_668 = args[0][1];
tmp_669 = args[0][2];
emit_assign(make_lhs(tmp_665), make_op_rhs(OP_MUL, make_compvar_primary(tmp_668), make_compvar_primary(tmp_669)));
}
emit_assign(make_lhs(result_tmps[tmp_663]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_664), make_compvar_primary(tmp_665)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_det_m3x3 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_670;
for (tmp_670 = 0; tmp_670 < 1; ++tmp_670)
{
switch (tmp_670)
{
case 0 :
{
compvar_t *tmp_671, *tmp_672;
tmp_671 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_673, *tmp_674;
tmp_673 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_675, *tmp_676;
tmp_675 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_677, *tmp_678;
tmp_677 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_679, *tmp_680;
tmp_679 = args[0][0];
tmp_680 = args[0][4];
emit_assign(make_lhs(tmp_677), make_op_rhs(OP_MUL, make_compvar_primary(tmp_679), make_compvar_primary(tmp_680)));
}
tmp_678 = args[0][8];
emit_assign(make_lhs(tmp_675), make_op_rhs(OP_MUL, make_compvar_primary(tmp_677), make_compvar_primary(tmp_678)));
}
tmp_676 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_681, *tmp_682;
tmp_681 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_683, *tmp_684;
tmp_683 = args[0][1];
tmp_684 = args[0][5];
emit_assign(make_lhs(tmp_681), make_op_rhs(OP_MUL, make_compvar_primary(tmp_683), make_compvar_primary(tmp_684)));
}
tmp_682 = args[0][6];
emit_assign(make_lhs(tmp_676), make_op_rhs(OP_MUL, make_compvar_primary(tmp_681), make_compvar_primary(tmp_682)));
}
emit_assign(make_lhs(tmp_673), make_op_rhs(OP_ADD, make_compvar_primary(tmp_675), make_compvar_primary(tmp_676)));
}
tmp_674 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_685, *tmp_686;
tmp_685 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_687, *tmp_688;
tmp_687 = args[0][2];
tmp_688 = args[0][3];
emit_assign(make_lhs(tmp_685), make_op_rhs(OP_MUL, make_compvar_primary(tmp_687), make_compvar_primary(tmp_688)));
}
tmp_686 = args[0][7];
emit_assign(make_lhs(tmp_674), make_op_rhs(OP_MUL, make_compvar_primary(tmp_685), make_compvar_primary(tmp_686)));
}
emit_assign(make_lhs(tmp_671), make_op_rhs(OP_ADD, make_compvar_primary(tmp_673), make_compvar_primary(tmp_674)));
}
tmp_672 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_689, *tmp_690;
tmp_689 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_691, *tmp_692;
tmp_691 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_693, *tmp_694;
tmp_693 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_695, *tmp_696;
tmp_695 = args[0][2];
tmp_696 = args[0][4];
emit_assign(make_lhs(tmp_693), make_op_rhs(OP_MUL, make_compvar_primary(tmp_695), make_compvar_primary(tmp_696)));
}
tmp_694 = args[0][6];
emit_assign(make_lhs(tmp_691), make_op_rhs(OP_MUL, make_compvar_primary(tmp_693), make_compvar_primary(tmp_694)));
}
tmp_692 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_697, *tmp_698;
tmp_697 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_699, *tmp_700;
tmp_699 = args[0][0];
tmp_700 = args[0][5];
emit_assign(make_lhs(tmp_697), make_op_rhs(OP_MUL, make_compvar_primary(tmp_699), make_compvar_primary(tmp_700)));
}
tmp_698 = args[0][7];
emit_assign(make_lhs(tmp_692), make_op_rhs(OP_MUL, make_compvar_primary(tmp_697), make_compvar_primary(tmp_698)));
}
emit_assign(make_lhs(tmp_689), make_op_rhs(OP_ADD, make_compvar_primary(tmp_691), make_compvar_primary(tmp_692)));
}
tmp_690 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_701, *tmp_702;
tmp_701 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_703, *tmp_704;
tmp_703 = args[0][1];
tmp_704 = args[0][3];
emit_assign(make_lhs(tmp_701), make_op_rhs(OP_MUL, make_compvar_primary(tmp_703), make_compvar_primary(tmp_704)));
}
tmp_702 = args[0][8];
emit_assign(make_lhs(tmp_690), make_op_rhs(OP_MUL, make_compvar_primary(tmp_701), make_compvar_primary(tmp_702)));
}
emit_assign(make_lhs(tmp_672), make_op_rhs(OP_ADD, make_compvar_primary(tmp_689), make_compvar_primary(tmp_690)));
}
emit_assign(make_lhs(result_tmps[tmp_670]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_671), make_compvar_primary(tmp_672)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_normalize (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_705;

if (arglengths[0] == 1)
{
tmp_705 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_709, *tmp_710;
tmp_709 = args[0][0];
tmp_710 = args[0][0];
emit_assign(make_lhs(tmp_705), make_op_rhs(OP_MUL, make_compvar_primary(tmp_709), make_compvar_primary(tmp_710)));
}

}
else
{
compvar_t *tmp_706, *tmp_707;
int tmp_708;
tmp_705 = compiler_make_temporary(TYPE_INT);
tmp_706 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_711, *tmp_712;
tmp_711 = args[0][0];
tmp_712 = args[0][0];
emit_assign(make_lhs(tmp_706), make_op_rhs(OP_MUL, make_compvar_primary(tmp_711), make_compvar_primary(tmp_712)));
}
tmp_707 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_713, *tmp_714;
tmp_713 = args[0][1];
tmp_714 = args[0][1];
emit_assign(make_lhs(tmp_707), make_op_rhs(OP_MUL, make_compvar_primary(tmp_713), make_compvar_primary(tmp_714)));
}
emit_assign(make_lhs(tmp_705), make_op_rhs(OP_ADD, make_compvar_primary(tmp_706), make_compvar_primary(tmp_707)));
for (tmp_708 = 2; tmp_708 < arglengths[0]; ++tmp_708)
{
tmp_706 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_715, *tmp_716;
tmp_715 = args[0][tmp_708];
tmp_716 = args[0][tmp_708];
emit_assign(make_lhs(tmp_706), make_op_rhs(OP_MUL, make_compvar_primary(tmp_715), make_compvar_primary(tmp_716)));
}
emit_assign(make_lhs(tmp_705), make_op_rhs(OP_ADD, make_compvar_primary(tmp_705), make_compvar_primary(tmp_706)));
}
}

{
compvar_t *tmp_717;
tmp_717 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_718, *tmp_719;
tmp_718 = tmp_705;
tmp_719 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_719), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_717), make_op_rhs(OP_EQ, make_compvar_primary(tmp_718), make_compvar_primary(tmp_719)));
}
start_if_cond(make_compvar_rhs(tmp_717));
{
int tmp_720;
for (tmp_720 = 0; tmp_720 < arglengths[0]; ++tmp_720)
{
emit_assign(make_lhs(result_tmps[tmp_720]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_721;
for (tmp_721 = 0; tmp_721 < arglengths[0]; ++tmp_721)
{
{
compvar_t *tmp_722, *tmp_723;
tmp_722 = args[0][tmp_721];
tmp_723 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_724;
tmp_724 = tmp_705;
emit_assign(make_lhs(tmp_723), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_724)));
}
emit_assign(make_lhs(result_tmps[tmp_721]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_722), make_compvar_primary(tmp_723)));
}
}
}
end_if_cond();
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_725;
for (tmp_725 = 0; tmp_725 < 1; ++tmp_725)
{
switch (tmp_725)
{
case 0 :
{
compvar_t *tmp_726, *tmp_727;
tmp_726 = args[0][0];
tmp_727 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_725]), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_726), make_compvar_primary(tmp_727)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_quat (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_728;
for (tmp_728 = 0; tmp_728 < 1; ++tmp_728)
{
switch (tmp_728)
{
case 0 :
{
compvar_t *tmp_729;
tmp_729 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_730, *tmp_731;
tmp_730 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_732, *tmp_733;
tmp_732 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_734, *tmp_735;
tmp_734 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_736, *tmp_737;
tmp_736 = args[0][0];
tmp_737 = args[0][0];
emit_assign(make_lhs(tmp_734), make_op_rhs(OP_MUL, make_compvar_primary(tmp_736), make_compvar_primary(tmp_737)));
}
tmp_735 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_738, *tmp_739;
tmp_738 = args[0][1];
tmp_739 = args[0][1];
emit_assign(make_lhs(tmp_735), make_op_rhs(OP_MUL, make_compvar_primary(tmp_738), make_compvar_primary(tmp_739)));
}
emit_assign(make_lhs(tmp_732), make_op_rhs(OP_ADD, make_compvar_primary(tmp_734), make_compvar_primary(tmp_735)));
}
tmp_733 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_740, *tmp_741;
tmp_740 = args[0][2];
tmp_741 = args[0][2];
emit_assign(make_lhs(tmp_733), make_op_rhs(OP_MUL, make_compvar_primary(tmp_740), make_compvar_primary(tmp_741)));
}
emit_assign(make_lhs(tmp_730), make_op_rhs(OP_ADD, make_compvar_primary(tmp_732), make_compvar_primary(tmp_733)));
}
tmp_731 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_742, *tmp_743;
tmp_742 = args[0][3];
tmp_743 = args[0][3];
emit_assign(make_lhs(tmp_731), make_op_rhs(OP_MUL, make_compvar_primary(tmp_742), make_compvar_primary(tmp_743)));
}
emit_assign(make_lhs(tmp_729), make_op_rhs(OP_ADD, make_compvar_primary(tmp_730), make_compvar_primary(tmp_731)));
}
emit_assign(make_lhs(result_tmps[tmp_728]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_729)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_cquat (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_744;
for (tmp_744 = 0; tmp_744 < 1; ++tmp_744)
{
switch (tmp_744)
{
case 0 :
{
compvar_t *tmp_745;
tmp_745 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_746, *tmp_747;
tmp_746 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_748, *tmp_749;
tmp_748 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_750, *tmp_751;
tmp_750 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_752, *tmp_753;
tmp_752 = args[0][0];
tmp_753 = args[0][0];
emit_assign(make_lhs(tmp_750), make_op_rhs(OP_MUL, make_compvar_primary(tmp_752), make_compvar_primary(tmp_753)));
}
tmp_751 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_754, *tmp_755;
tmp_754 = args[0][1];
tmp_755 = args[0][1];
emit_assign(make_lhs(tmp_751), make_op_rhs(OP_MUL, make_compvar_primary(tmp_754), make_compvar_primary(tmp_755)));
}
emit_assign(make_lhs(tmp_748), make_op_rhs(OP_ADD, make_compvar_primary(tmp_750), make_compvar_primary(tmp_751)));
}
tmp_749 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_756, *tmp_757;
tmp_756 = args[0][2];
tmp_757 = args[0][2];
emit_assign(make_lhs(tmp_749), make_op_rhs(OP_MUL, make_compvar_primary(tmp_756), make_compvar_primary(tmp_757)));
}
emit_assign(make_lhs(tmp_746), make_op_rhs(OP_ADD, make_compvar_primary(tmp_748), make_compvar_primary(tmp_749)));
}
tmp_747 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_758, *tmp_759;
tmp_758 = args[0][3];
tmp_759 = args[0][3];
emit_assign(make_lhs(tmp_747), make_op_rhs(OP_MUL, make_compvar_primary(tmp_758), make_compvar_primary(tmp_759)));
}
emit_assign(make_lhs(tmp_745), make_op_rhs(OP_ADD, make_compvar_primary(tmp_746), make_compvar_primary(tmp_747)));
}
emit_assign(make_lhs(result_tmps[tmp_744]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_745)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_hyper (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_760;
for (tmp_760 = 0; tmp_760 < 1; ++tmp_760)
{
switch (tmp_760)
{
case 0 :
{
compvar_t *tmp_761;
tmp_761 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_762, *tmp_763;
tmp_762 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_764, *tmp_765;
tmp_764 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_766, *tmp_767;
tmp_766 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_768, *tmp_769;
tmp_768 = args[0][0];
tmp_769 = args[0][0];
emit_assign(make_lhs(tmp_766), make_op_rhs(OP_MUL, make_compvar_primary(tmp_768), make_compvar_primary(tmp_769)));
}
tmp_767 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_770, *tmp_771;
tmp_770 = args[0][1];
tmp_771 = args[0][1];
emit_assign(make_lhs(tmp_767), make_op_rhs(OP_MUL, make_compvar_primary(tmp_770), make_compvar_primary(tmp_771)));
}
emit_assign(make_lhs(tmp_764), make_op_rhs(OP_ADD, make_compvar_primary(tmp_766), make_compvar_primary(tmp_767)));
}
tmp_765 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_772, *tmp_773;
tmp_772 = args[0][2];
tmp_773 = args[0][2];
emit_assign(make_lhs(tmp_765), make_op_rhs(OP_MUL, make_compvar_primary(tmp_772), make_compvar_primary(tmp_773)));
}
emit_assign(make_lhs(tmp_762), make_op_rhs(OP_ADD, make_compvar_primary(tmp_764), make_compvar_primary(tmp_765)));
}
tmp_763 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_774, *tmp_775;
tmp_774 = args[0][3];
tmp_775 = args[0][3];
emit_assign(make_lhs(tmp_763), make_op_rhs(OP_MUL, make_compvar_primary(tmp_774), make_compvar_primary(tmp_775)));
}
emit_assign(make_lhs(tmp_761), make_op_rhs(OP_ADD, make_compvar_primary(tmp_762), make_compvar_primary(tmp_763)));
}
emit_assign(make_lhs(result_tmps[tmp_760]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_761)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_v2 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_776;
for (tmp_776 = 0; tmp_776 < 1; ++tmp_776)
{
switch (tmp_776)
{
case 0 :
{
compvar_t *tmp_777;
tmp_777 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_778, *tmp_779;
tmp_778 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_780, *tmp_781;
tmp_780 = args[0][0];
tmp_781 = args[0][0];
emit_assign(make_lhs(tmp_778), make_op_rhs(OP_MUL, make_compvar_primary(tmp_780), make_compvar_primary(tmp_781)));
}
tmp_779 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_782, *tmp_783;
tmp_782 = args[0][1];
tmp_783 = args[0][1];
emit_assign(make_lhs(tmp_779), make_op_rhs(OP_MUL, make_compvar_primary(tmp_782), make_compvar_primary(tmp_783)));
}
emit_assign(make_lhs(tmp_777), make_op_rhs(OP_ADD, make_compvar_primary(tmp_778), make_compvar_primary(tmp_779)));
}
emit_assign(make_lhs(result_tmps[tmp_776]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_777)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_v3 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_784;
for (tmp_784 = 0; tmp_784 < 1; ++tmp_784)
{
switch (tmp_784)
{
case 0 :
{
compvar_t *tmp_785;
tmp_785 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_786, *tmp_787;
tmp_786 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_788, *tmp_789;
tmp_788 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_790, *tmp_791;
tmp_790 = args[0][0];
tmp_791 = args[0][0];
emit_assign(make_lhs(tmp_788), make_op_rhs(OP_MUL, make_compvar_primary(tmp_790), make_compvar_primary(tmp_791)));
}
tmp_789 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_792, *tmp_793;
tmp_792 = args[0][1];
tmp_793 = args[0][1];
emit_assign(make_lhs(tmp_789), make_op_rhs(OP_MUL, make_compvar_primary(tmp_792), make_compvar_primary(tmp_793)));
}
emit_assign(make_lhs(tmp_786), make_op_rhs(OP_ADD, make_compvar_primary(tmp_788), make_compvar_primary(tmp_789)));
}
tmp_787 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_794, *tmp_795;
tmp_794 = args[0][2];
tmp_795 = args[0][2];
emit_assign(make_lhs(tmp_787), make_op_rhs(OP_MUL, make_compvar_primary(tmp_794), make_compvar_primary(tmp_795)));
}
emit_assign(make_lhs(tmp_785), make_op_rhs(OP_ADD, make_compvar_primary(tmp_786), make_compvar_primary(tmp_787)));
}
emit_assign(make_lhs(result_tmps[tmp_784]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_785)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_796;
for (tmp_796 = 0; tmp_796 < 1; ++tmp_796)
{
{
compvar_t *tmp_797;
tmp_797 = args[0][tmp_796];
emit_assign(make_lhs(result_tmps[tmp_796]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_797)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_798;
for (tmp_798 = 0; tmp_798 < arglengths[0]; ++tmp_798)
{
{
compvar_t *tmp_799;
tmp_799 = args[0][tmp_798];
emit_assign(make_lhs(result_tmps[tmp_798]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_799)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_deg2rad (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_800;
for (tmp_800 = 0; tmp_800 < 1; ++tmp_800)
{
switch (tmp_800)
{
case 0 :
{
compvar_t *tmp_801, *tmp_802;
tmp_801 = args[0][0];
tmp_802 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_802), make_float_const_rhs(0.017453292));
emit_assign(make_lhs(result_tmps[tmp_800]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_801), make_compvar_primary(tmp_802)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rad2deg (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_803;
for (tmp_803 = 0; tmp_803 < 1; ++tmp_803)
{
switch (tmp_803)
{
case 0 :
{
compvar_t *tmp_804, *tmp_805;
tmp_804 = args[0][0];
tmp_805 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_805), make_float_const_rhs(57.29578));
emit_assign(make_lhs(result_tmps[tmp_803]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_804), make_compvar_primary(tmp_805)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sin_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_806;

tmp_806 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_807;
tmp_807 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_808, *tmp_809;
tmp_808 = args[0][0];
tmp_809 = args[0][1];
emit_assign(make_lhs(tmp_807), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_808), make_compvar_primary(tmp_809)));
}
emit_assign(make_lhs(tmp_806), make_op_rhs(OP_C_SIN, make_compvar_primary(tmp_807)));
}

{
int tmp_810;
for (tmp_810 = 0; tmp_810 < 2; ++tmp_810)
{
switch (tmp_810)
{
case 0 :
{
compvar_t *tmp_811;
tmp_811 = tmp_806;
emit_assign(make_lhs(result_tmps[tmp_810]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_811)));
}
break;
case 1 :
{
compvar_t *tmp_812;
tmp_812 = tmp_806;
emit_assign(make_lhs(result_tmps[tmp_810]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_812)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sin (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_813;
for (tmp_813 = 0; tmp_813 < 1; ++tmp_813)
{
switch (tmp_813)
{
case 0 :
{
compvar_t *tmp_814;
tmp_814 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_813]), make_op_rhs(OP_SIN, make_compvar_primary(tmp_814)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cos_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_815;

tmp_815 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_816;
tmp_816 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_817, *tmp_818;
tmp_817 = args[0][0];
tmp_818 = args[0][1];
emit_assign(make_lhs(tmp_816), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_817), make_compvar_primary(tmp_818)));
}
emit_assign(make_lhs(tmp_815), make_op_rhs(OP_C_COS, make_compvar_primary(tmp_816)));
}

{
int tmp_819;
for (tmp_819 = 0; tmp_819 < 2; ++tmp_819)
{
switch (tmp_819)
{
case 0 :
{
compvar_t *tmp_820;
tmp_820 = tmp_815;
emit_assign(make_lhs(result_tmps[tmp_819]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_820)));
}
break;
case 1 :
{
compvar_t *tmp_821;
tmp_821 = tmp_815;
emit_assign(make_lhs(result_tmps[tmp_819]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_821)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cos (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_822;
for (tmp_822 = 0; tmp_822 < 1; ++tmp_822)
{
switch (tmp_822)
{
case 0 :
{
compvar_t *tmp_823;
tmp_823 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_822]), make_op_rhs(OP_COS, make_compvar_primary(tmp_823)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tan_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_824;

tmp_824 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_825;
tmp_825 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_826, *tmp_827;
tmp_826 = args[0][0];
tmp_827 = args[0][1];
emit_assign(make_lhs(tmp_825), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_826), make_compvar_primary(tmp_827)));
}
emit_assign(make_lhs(tmp_824), make_op_rhs(OP_C_TAN, make_compvar_primary(tmp_825)));
}

{
int tmp_828;
for (tmp_828 = 0; tmp_828 < 2; ++tmp_828)
{
switch (tmp_828)
{
case 0 :
{
compvar_t *tmp_829;
tmp_829 = tmp_824;
emit_assign(make_lhs(result_tmps[tmp_828]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_829)));
}
break;
case 1 :
{
compvar_t *tmp_830;
tmp_830 = tmp_824;
emit_assign(make_lhs(result_tmps[tmp_828]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_830)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tan (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_831;
for (tmp_831 = 0; tmp_831 < 1; ++tmp_831)
{
switch (tmp_831)
{
case 0 :
{
compvar_t *tmp_832;
tmp_832 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_831]), make_op_rhs(OP_TAN, make_compvar_primary(tmp_832)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asin_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_833;

tmp_833 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_834;
tmp_834 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_835, *tmp_836;
tmp_835 = args[0][0];
tmp_836 = args[0][1];
emit_assign(make_lhs(tmp_834), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_835), make_compvar_primary(tmp_836)));
}
emit_assign(make_lhs(tmp_833), make_op_rhs(OP_C_ASIN, make_compvar_primary(tmp_834)));
}

{
int tmp_837;
for (tmp_837 = 0; tmp_837 < 2; ++tmp_837)
{
switch (tmp_837)
{
case 0 :
{
compvar_t *tmp_838;
tmp_838 = tmp_833;
emit_assign(make_lhs(result_tmps[tmp_837]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_838)));
}
break;
case 1 :
{
compvar_t *tmp_839;
tmp_839 = tmp_833;
emit_assign(make_lhs(result_tmps[tmp_837]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_839)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asin (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_840;
tmp_840 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_841, *tmp_842;
tmp_841 = args[0][0];
tmp_842 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_842), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_840), make_op_rhs(OP_LESS, make_compvar_primary(tmp_841), make_compvar_primary(tmp_842)));
}
start_if_cond(make_compvar_rhs(tmp_840));
switch_if_branch();
{
compvar_t *tmp_843, *tmp_844;
tmp_843 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_843), make_int_const_rhs(1));
tmp_844 = args[0][0];
emit_assign(make_lhs(tmp_840), make_op_rhs(OP_LESS, make_compvar_primary(tmp_843), make_compvar_primary(tmp_844)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_840));
{
int tmp_845;
for (tmp_845 = 0; tmp_845 < 1; ++tmp_845)
{
switch (tmp_845)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_845]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_846;
for (tmp_846 = 0; tmp_846 < 1; ++tmp_846)
{
switch (tmp_846)
{
case 0 :
{
compvar_t *tmp_847;
tmp_847 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_846]), make_op_rhs(OP_ASIN, make_compvar_primary(tmp_847)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acos_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_848;

tmp_848 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_849;
tmp_849 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_850, *tmp_851;
tmp_850 = args[0][0];
tmp_851 = args[0][1];
emit_assign(make_lhs(tmp_849), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_850), make_compvar_primary(tmp_851)));
}
emit_assign(make_lhs(tmp_848), make_op_rhs(OP_C_ACOS, make_compvar_primary(tmp_849)));
}

{
int tmp_852;
for (tmp_852 = 0; tmp_852 < 2; ++tmp_852)
{
switch (tmp_852)
{
case 0 :
{
compvar_t *tmp_853;
tmp_853 = tmp_848;
emit_assign(make_lhs(result_tmps[tmp_852]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_853)));
}
break;
case 1 :
{
compvar_t *tmp_854;
tmp_854 = tmp_848;
emit_assign(make_lhs(result_tmps[tmp_852]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_854)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acos (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_855;
tmp_855 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_856, *tmp_857;
tmp_856 = args[0][0];
tmp_857 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_857), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_855), make_op_rhs(OP_LESS, make_compvar_primary(tmp_856), make_compvar_primary(tmp_857)));
}
start_if_cond(make_compvar_rhs(tmp_855));
switch_if_branch();
{
compvar_t *tmp_858, *tmp_859;
tmp_858 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_858), make_int_const_rhs(1));
tmp_859 = args[0][0];
emit_assign(make_lhs(tmp_855), make_op_rhs(OP_LESS, make_compvar_primary(tmp_858), make_compvar_primary(tmp_859)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_855));
{
int tmp_860;
for (tmp_860 = 0; tmp_860 < 1; ++tmp_860)
{
switch (tmp_860)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_860]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_861;
for (tmp_861 = 0; tmp_861 < 1; ++tmp_861)
{
switch (tmp_861)
{
case 0 :
{
compvar_t *tmp_862;
tmp_862 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_861]), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_862)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_863;

tmp_863 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_864;
tmp_864 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_865, *tmp_866;
tmp_865 = args[0][0];
tmp_866 = args[0][1];
emit_assign(make_lhs(tmp_864), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_865), make_compvar_primary(tmp_866)));
}
emit_assign(make_lhs(tmp_863), make_op_rhs(OP_C_ATAN, make_compvar_primary(tmp_864)));
}

{
int tmp_867;
for (tmp_867 = 0; tmp_867 < 2; ++tmp_867)
{
switch (tmp_867)
{
case 0 :
{
compvar_t *tmp_868;
tmp_868 = tmp_863;
emit_assign(make_lhs(result_tmps[tmp_867]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_868)));
}
break;
case 1 :
{
compvar_t *tmp_869;
tmp_869 = tmp_863;
emit_assign(make_lhs(result_tmps[tmp_867]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_869)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_870;
for (tmp_870 = 0; tmp_870 < 1; ++tmp_870)
{
switch (tmp_870)
{
case 0 :
{
compvar_t *tmp_871;
tmp_871 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_870]), make_op_rhs(OP_ATAN, make_compvar_primary(tmp_871)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan2 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_872;
for (tmp_872 = 0; tmp_872 < 1; ++tmp_872)
{
switch (tmp_872)
{
case 0 :
{
compvar_t *tmp_873, *tmp_874;
tmp_873 = args[0][0];
tmp_874 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_872]), make_op_rhs(OP_ATAN2, make_compvar_primary(tmp_873), make_compvar_primary(tmp_874)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_ri_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_875;

tmp_875 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_876, *tmp_877;
tmp_876 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_878, *tmp_879;
tmp_878 = args[0][0];
tmp_879 = args[0][1];
emit_assign(make_lhs(tmp_876), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_878), make_compvar_primary(tmp_879)));
}
tmp_877 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_880, *tmp_881;
tmp_880 = args[1][0];
tmp_881 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_881), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_877), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_880), make_compvar_primary(tmp_881)));
}
emit_assign(make_lhs(tmp_875), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_876), make_compvar_primary(tmp_877)));
}

{
int tmp_882;
for (tmp_882 = 0; tmp_882 < 2; ++tmp_882)
{
switch (tmp_882)
{
case 0 :
{
compvar_t *tmp_883;
tmp_883 = tmp_875;
emit_assign(make_lhs(result_tmps[tmp_882]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_883)));
}
break;
case 1 :
{
compvar_t *tmp_884;
tmp_884 = tmp_875;
emit_assign(make_lhs(result_tmps[tmp_882]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_884)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_885;

tmp_885 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_886, *tmp_887;
tmp_886 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_888, *tmp_889;
tmp_888 = args[0][0];
tmp_889 = args[0][1];
emit_assign(make_lhs(tmp_886), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_888), make_compvar_primary(tmp_889)));
}
tmp_887 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_890, *tmp_891;
tmp_890 = args[1][0];
tmp_891 = args[1][1];
emit_assign(make_lhs(tmp_887), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_890), make_compvar_primary(tmp_891)));
}
emit_assign(make_lhs(tmp_885), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_886), make_compvar_primary(tmp_887)));
}

{
int tmp_892;
for (tmp_892 = 0; tmp_892 < 2; ++tmp_892)
{
switch (tmp_892)
{
case 0 :
{
compvar_t *tmp_893;
tmp_893 = tmp_885;
emit_assign(make_lhs(result_tmps[tmp_892]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_893)));
}
break;
case 1 :
{
compvar_t *tmp_894;
tmp_894 = tmp_885;
emit_assign(make_lhs(result_tmps[tmp_892]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_894)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_1_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_895;

tmp_895 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_896, *tmp_897;
tmp_896 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_898, *tmp_899;
tmp_898 = args[0][0];
tmp_899 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_899), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_896), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_898), make_compvar_primary(tmp_899)));
}
tmp_897 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_900, *tmp_901;
tmp_900 = args[1][0];
tmp_901 = args[1][1];
emit_assign(make_lhs(tmp_897), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_900), make_compvar_primary(tmp_901)));
}
emit_assign(make_lhs(tmp_895), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_896), make_compvar_primary(tmp_897)));
}

{
int tmp_902;
for (tmp_902 = 0; tmp_902 < 2; ++tmp_902)
{
switch (tmp_902)
{
case 0 :
{
compvar_t *tmp_903;
tmp_903 = tmp_895;
emit_assign(make_lhs(result_tmps[tmp_902]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_903)));
}
break;
case 1 :
{
compvar_t *tmp_904;
tmp_904 = tmp_895;
emit_assign(make_lhs(result_tmps[tmp_902]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_904)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_905;
tmp_905 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_906, *tmp_907;
tmp_906 = args[1][0];
tmp_907 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_907), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_905), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_906), make_compvar_primary(tmp_907)));
}
start_if_cond(make_compvar_rhs(tmp_905));
{
compvar_t *tmp_908, *tmp_909;
tmp_908 = args[0][0];
tmp_909 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_909), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_905), make_op_rhs(OP_EQ, make_compvar_primary(tmp_908), make_compvar_primary(tmp_909)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_905));
{
int tmp_910;
for (tmp_910 = 0; tmp_910 < 1; ++tmp_910)
{
switch (tmp_910)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_910]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_911;
for (tmp_911 = 0; tmp_911 < 1; ++tmp_911)
{
switch (tmp_911)
{
case 0 :
{
compvar_t *tmp_912, *tmp_913;
tmp_912 = args[0][0];
tmp_913 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_911]), make_op_rhs(OP_POW, make_compvar_primary(tmp_912), make_compvar_primary(tmp_913)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_s (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_914;
for (tmp_914 = 0; tmp_914 < arglengths[0]; ++tmp_914)
{
{
compvar_t *tmp_915;
tmp_915 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_916, *tmp_917;
tmp_916 = args[1][0];
tmp_917 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_917), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_915), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_916), make_compvar_primary(tmp_917)));
}
start_if_cond(make_compvar_rhs(tmp_915));
{
compvar_t *tmp_918, *tmp_919;
tmp_918 = args[0][tmp_914];
tmp_919 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_919), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_915), make_op_rhs(OP_EQ, make_compvar_primary(tmp_918), make_compvar_primary(tmp_919)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_915));
emit_assign(make_lhs(result_tmps[tmp_914]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_920, *tmp_921;
tmp_920 = args[0][tmp_914];
tmp_921 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_914]), make_op_rhs(OP_POW, make_compvar_primary(tmp_920), make_compvar_primary(tmp_921)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_exp_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_922;

tmp_922 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_923;
tmp_923 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_924, *tmp_925;
tmp_924 = args[0][0];
tmp_925 = args[0][1];
emit_assign(make_lhs(tmp_923), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_924), make_compvar_primary(tmp_925)));
}
emit_assign(make_lhs(tmp_922), make_op_rhs(OP_C_EXP, make_compvar_primary(tmp_923)));
}

{
int tmp_926;
for (tmp_926 = 0; tmp_926 < 2; ++tmp_926)
{
switch (tmp_926)
{
case 0 :
{
compvar_t *tmp_927;
tmp_927 = tmp_922;
emit_assign(make_lhs(result_tmps[tmp_926]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_927)));
}
break;
case 1 :
{
compvar_t *tmp_928;
tmp_928 = tmp_922;
emit_assign(make_lhs(result_tmps[tmp_926]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_928)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_exp_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_929;
for (tmp_929 = 0; tmp_929 < 1; ++tmp_929)
{
switch (tmp_929)
{
case 0 :
{
compvar_t *tmp_930;
tmp_930 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_929]), make_op_rhs(OP_EXP, make_compvar_primary(tmp_930)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_log_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_931;

tmp_931 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_932;
tmp_932 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_933, *tmp_934;
tmp_933 = args[0][0];
tmp_934 = args[0][1];
emit_assign(make_lhs(tmp_932), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_933), make_compvar_primary(tmp_934)));
}
emit_assign(make_lhs(tmp_931), make_op_rhs(OP_C_LOG, make_compvar_primary(tmp_932)));
}

{
int tmp_935;
for (tmp_935 = 0; tmp_935 < 2; ++tmp_935)
{
switch (tmp_935)
{
case 0 :
{
compvar_t *tmp_936;
tmp_936 = tmp_931;
emit_assign(make_lhs(result_tmps[tmp_935]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_936)));
}
break;
case 1 :
{
compvar_t *tmp_937;
tmp_937 = tmp_931;
emit_assign(make_lhs(result_tmps[tmp_935]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_937)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_log_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_938;
tmp_938 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_939, *tmp_940;
tmp_939 = args[0][0];
tmp_940 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_940), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_938), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_939), make_compvar_primary(tmp_940)));
}
start_if_cond(make_compvar_rhs(tmp_938));
{
int tmp_941;
for (tmp_941 = 0; tmp_941 < 1; ++tmp_941)
{
switch (tmp_941)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_941]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_942;
for (tmp_942 = 0; tmp_942 < 1; ++tmp_942)
{
switch (tmp_942)
{
case 0 :
{
compvar_t *tmp_943;
tmp_943 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_942]), make_op_rhs(OP_LOG, make_compvar_primary(tmp_943)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_arg_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_944;
for (tmp_944 = 0; tmp_944 < 1; ++tmp_944)
{
switch (tmp_944)
{
case 0 :
{
compvar_t *tmp_945;
tmp_945 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_946, *tmp_947;
tmp_946 = args[0][0];
tmp_947 = args[0][1];
emit_assign(make_lhs(tmp_945), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_946), make_compvar_primary(tmp_947)));
}
emit_assign(make_lhs(result_tmps[tmp_944]), make_op_rhs(OP_C_ARG, make_compvar_primary(tmp_945)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_conj_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_948;
for (tmp_948 = 0; tmp_948 < 2; ++tmp_948)
{
switch (tmp_948)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_948]), make_compvar_rhs(args[0][0]));
break;
case 1 :
{
compvar_t *tmp_949;
tmp_949 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_948]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_949)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sinh_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_950;

tmp_950 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_951;
tmp_951 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_952, *tmp_953;
tmp_952 = args[0][0];
tmp_953 = args[0][1];
emit_assign(make_lhs(tmp_951), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_952), make_compvar_primary(tmp_953)));
}
emit_assign(make_lhs(tmp_950), make_op_rhs(OP_C_SINH, make_compvar_primary(tmp_951)));
}

{
int tmp_954;
for (tmp_954 = 0; tmp_954 < 2; ++tmp_954)
{
switch (tmp_954)
{
case 0 :
{
compvar_t *tmp_955;
tmp_955 = tmp_950;
emit_assign(make_lhs(result_tmps[tmp_954]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_955)));
}
break;
case 1 :
{
compvar_t *tmp_956;
tmp_956 = tmp_950;
emit_assign(make_lhs(result_tmps[tmp_954]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_956)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sinh_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_957;
for (tmp_957 = 0; tmp_957 < 1; ++tmp_957)
{
switch (tmp_957)
{
case 0 :
{
compvar_t *tmp_958;
tmp_958 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_957]), make_op_rhs(OP_SINH, make_compvar_primary(tmp_958)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cosh_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_959;

tmp_959 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_960;
tmp_960 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_961, *tmp_962;
tmp_961 = args[0][0];
tmp_962 = args[0][1];
emit_assign(make_lhs(tmp_960), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_961), make_compvar_primary(tmp_962)));
}
emit_assign(make_lhs(tmp_959), make_op_rhs(OP_C_COSH, make_compvar_primary(tmp_960)));
}

{
int tmp_963;
for (tmp_963 = 0; tmp_963 < 2; ++tmp_963)
{
switch (tmp_963)
{
case 0 :
{
compvar_t *tmp_964;
tmp_964 = tmp_959;
emit_assign(make_lhs(result_tmps[tmp_963]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_964)));
}
break;
case 1 :
{
compvar_t *tmp_965;
tmp_965 = tmp_959;
emit_assign(make_lhs(result_tmps[tmp_963]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_965)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cosh_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_966;
for (tmp_966 = 0; tmp_966 < 1; ++tmp_966)
{
switch (tmp_966)
{
case 0 :
{
compvar_t *tmp_967;
tmp_967 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_966]), make_op_rhs(OP_COSH, make_compvar_primary(tmp_967)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tanh_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_968;

tmp_968 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_969;
tmp_969 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_970, *tmp_971;
tmp_970 = args[0][0];
tmp_971 = args[0][1];
emit_assign(make_lhs(tmp_969), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_970), make_compvar_primary(tmp_971)));
}
emit_assign(make_lhs(tmp_968), make_op_rhs(OP_C_TANH, make_compvar_primary(tmp_969)));
}

{
int tmp_972;
for (tmp_972 = 0; tmp_972 < 2; ++tmp_972)
{
switch (tmp_972)
{
case 0 :
{
compvar_t *tmp_973;
tmp_973 = tmp_968;
emit_assign(make_lhs(result_tmps[tmp_972]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_973)));
}
break;
case 1 :
{
compvar_t *tmp_974;
tmp_974 = tmp_968;
emit_assign(make_lhs(result_tmps[tmp_972]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_974)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tanh_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_975;
for (tmp_975 = 0; tmp_975 < 1; ++tmp_975)
{
switch (tmp_975)
{
case 0 :
{
compvar_t *tmp_976;
tmp_976 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_975]), make_op_rhs(OP_TANH, make_compvar_primary(tmp_976)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asinh_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_977;

tmp_977 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_978;
tmp_978 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_979, *tmp_980;
tmp_979 = args[0][0];
tmp_980 = args[0][1];
emit_assign(make_lhs(tmp_978), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_979), make_compvar_primary(tmp_980)));
}
emit_assign(make_lhs(tmp_977), make_op_rhs(OP_C_ASINH, make_compvar_primary(tmp_978)));
}

{
int tmp_981;
for (tmp_981 = 0; tmp_981 < 2; ++tmp_981)
{
switch (tmp_981)
{
case 0 :
{
compvar_t *tmp_982;
tmp_982 = tmp_977;
emit_assign(make_lhs(result_tmps[tmp_981]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_982)));
}
break;
case 1 :
{
compvar_t *tmp_983;
tmp_983 = tmp_977;
emit_assign(make_lhs(result_tmps[tmp_981]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_983)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asinh_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_984;
for (tmp_984 = 0; tmp_984 < 1; ++tmp_984)
{
switch (tmp_984)
{
case 0 :
{
compvar_t *tmp_985;
tmp_985 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_984]), make_op_rhs(OP_ASINH, make_compvar_primary(tmp_985)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acosh_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_986;

tmp_986 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_987;
tmp_987 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_988, *tmp_989;
tmp_988 = args[0][0];
tmp_989 = args[0][1];
emit_assign(make_lhs(tmp_987), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_988), make_compvar_primary(tmp_989)));
}
emit_assign(make_lhs(tmp_986), make_op_rhs(OP_C_ACOSH, make_compvar_primary(tmp_987)));
}

{
int tmp_990;
for (tmp_990 = 0; tmp_990 < 2; ++tmp_990)
{
switch (tmp_990)
{
case 0 :
{
compvar_t *tmp_991;
tmp_991 = tmp_986;
emit_assign(make_lhs(result_tmps[tmp_990]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_991)));
}
break;
case 1 :
{
compvar_t *tmp_992;
tmp_992 = tmp_986;
emit_assign(make_lhs(result_tmps[tmp_990]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_992)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acosh_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_993;
for (tmp_993 = 0; tmp_993 < 1; ++tmp_993)
{
switch (tmp_993)
{
case 0 :
{
compvar_t *tmp_994;
tmp_994 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_993]), make_op_rhs(OP_ACOSH, make_compvar_primary(tmp_994)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atanh_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_995;

tmp_995 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_996;
tmp_996 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_997, *tmp_998;
tmp_997 = args[0][0];
tmp_998 = args[0][1];
emit_assign(make_lhs(tmp_996), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_997), make_compvar_primary(tmp_998)));
}
emit_assign(make_lhs(tmp_995), make_op_rhs(OP_C_ATANH, make_compvar_primary(tmp_996)));
}

{
int tmp_999;
for (tmp_999 = 0; tmp_999 < 2; ++tmp_999)
{
switch (tmp_999)
{
case 0 :
{
compvar_t *tmp_1000;
tmp_1000 = tmp_995;
emit_assign(make_lhs(result_tmps[tmp_999]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1000)));
}
break;
case 1 :
{
compvar_t *tmp_1001;
tmp_1001 = tmp_995;
emit_assign(make_lhs(result_tmps[tmp_999]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1001)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atanh_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1002;
for (tmp_1002 = 0; tmp_1002 < 1; ++tmp_1002)
{
switch (tmp_1002)
{
case 0 :
{
compvar_t *tmp_1003;
tmp_1003 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1002]), make_op_rhs(OP_ATANH, make_compvar_primary(tmp_1003)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gamma_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1004;

tmp_1004 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_1005;
tmp_1005 = compiler_make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_1006, *tmp_1007;
tmp_1006 = args[0][0];
tmp_1007 = args[0][1];
emit_assign(make_lhs(tmp_1005), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1006), make_compvar_primary(tmp_1007)));
}
emit_assign(make_lhs(tmp_1004), make_op_rhs(OP_C_GAMMA, make_compvar_primary(tmp_1005)));
}

{
int tmp_1008;
for (tmp_1008 = 0; tmp_1008 < 2; ++tmp_1008)
{
switch (tmp_1008)
{
case 0 :
{
compvar_t *tmp_1009;
tmp_1009 = tmp_1004;
emit_assign(make_lhs(result_tmps[tmp_1008]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1009)));
}
break;
case 1 :
{
compvar_t *tmp_1010;
tmp_1010 = tmp_1004;
emit_assign(make_lhs(result_tmps[tmp_1008]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1010)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gamma_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1011;
tmp_1011 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1012, *tmp_1013;
tmp_1012 = args[0][0];
tmp_1013 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1013), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1011), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1012), make_compvar_primary(tmp_1013)));
}
start_if_cond(make_compvar_rhs(tmp_1011));
{
int tmp_1014;
for (tmp_1014 = 0; tmp_1014 < 1; ++tmp_1014)
{
switch (tmp_1014)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1014]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1015;
for (tmp_1015 = 0; tmp_1015 < 1; ++tmp_1015)
{
switch (tmp_1015)
{
case 0 :
{
compvar_t *tmp_1016;
tmp_1016 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1015]), make_op_rhs(OP_GAMMA, make_compvar_primary(tmp_1016)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_beta_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1017;
tmp_1017 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1018, *tmp_1019;
tmp_1018 = args[0][0];
tmp_1019 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1019), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1017), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1018), make_compvar_primary(tmp_1019)));
}
start_if_cond(make_compvar_rhs(tmp_1017));
switch_if_branch();
{
compvar_t *tmp_1020, *tmp_1021;
tmp_1020 = args[1][0];
tmp_1021 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1021), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1017), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1020), make_compvar_primary(tmp_1021)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1017));
{
int tmp_1022;
for (tmp_1022 = 0; tmp_1022 < 1; ++tmp_1022)
{
switch (tmp_1022)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1022]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1023;
for (tmp_1023 = 0; tmp_1023 < 1; ++tmp_1023)
{
switch (tmp_1023)
{
case 0 :
{
compvar_t *tmp_1024, *tmp_1025;
tmp_1024 = args[0][0];
tmp_1025 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1023]), make_op_rhs(OP_BETA, make_compvar_primary(tmp_1024), make_compvar_primary(tmp_1025)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_kcomp (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1026;
for (tmp_1026 = 0; tmp_1026 < 1; ++tmp_1026)
{
switch (tmp_1026)
{
case 0 :
{
compvar_t *tmp_1027;
tmp_1027 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1026]), make_op_rhs(OP_ELL_INT_K_COMP, make_compvar_primary(tmp_1027)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_ecomp (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1028;
for (tmp_1028 = 0; tmp_1028 < 1; ++tmp_1028)
{
switch (tmp_1028)
{
case 0 :
{
compvar_t *tmp_1029;
tmp_1029 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1028]), make_op_rhs(OP_ELL_INT_E_COMP, make_compvar_primary(tmp_1029)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_f (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1030;
for (tmp_1030 = 0; tmp_1030 < 1; ++tmp_1030)
{
switch (tmp_1030)
{
case 0 :
{
compvar_t *tmp_1031, *tmp_1032;
tmp_1031 = args[0][0];
tmp_1032 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1030]), make_op_rhs(OP_ELL_INT_F, make_compvar_primary(tmp_1031), make_compvar_primary(tmp_1032)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_e (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1033;
for (tmp_1033 = 0; tmp_1033 < 1; ++tmp_1033)
{
switch (tmp_1033)
{
case 0 :
{
compvar_t *tmp_1034, *tmp_1035;
tmp_1034 = args[0][0];
tmp_1035 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1033]), make_op_rhs(OP_ELL_INT_E, make_compvar_primary(tmp_1034), make_compvar_primary(tmp_1035)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_p (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1036;
for (tmp_1036 = 0; tmp_1036 < 1; ++tmp_1036)
{
switch (tmp_1036)
{
case 0 :
{
compvar_t *tmp_1037, *tmp_1038, *tmp_1039;
tmp_1037 = args[0][0];
tmp_1038 = args[1][0];
tmp_1039 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1036]), make_op_rhs(OP_ELL_INT_P, make_compvar_primary(tmp_1037), make_compvar_primary(tmp_1038), make_compvar_primary(tmp_1039)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_d (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1040;
for (tmp_1040 = 0; tmp_1040 < 1; ++tmp_1040)
{
switch (tmp_1040)
{
case 0 :
{
compvar_t *tmp_1041, *tmp_1042, *tmp_1043;
tmp_1041 = args[0][0];
tmp_1042 = args[1][0];
tmp_1043 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1040]), make_op_rhs(OP_ELL_INT_D, make_compvar_primary(tmp_1041), make_compvar_primary(tmp_1042), make_compvar_primary(tmp_1043)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rc (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1044;
for (tmp_1044 = 0; tmp_1044 < 1; ++tmp_1044)
{
switch (tmp_1044)
{
case 0 :
{
compvar_t *tmp_1045, *tmp_1046;
tmp_1045 = args[0][0];
tmp_1046 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1044]), make_op_rhs(OP_ELL_INT_RC, make_compvar_primary(tmp_1045), make_compvar_primary(tmp_1046)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rd (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1047;
for (tmp_1047 = 0; tmp_1047 < 1; ++tmp_1047)
{
switch (tmp_1047)
{
case 0 :
{
compvar_t *tmp_1048, *tmp_1049, *tmp_1050;
tmp_1048 = args[0][0];
tmp_1049 = args[1][0];
tmp_1050 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1047]), make_op_rhs(OP_ELL_INT_RD, make_compvar_primary(tmp_1048), make_compvar_primary(tmp_1049), make_compvar_primary(tmp_1050)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rf (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1051;
for (tmp_1051 = 0; tmp_1051 < 1; ++tmp_1051)
{
switch (tmp_1051)
{
case 0 :
{
compvar_t *tmp_1052, *tmp_1053, *tmp_1054;
tmp_1052 = args[0][0];
tmp_1053 = args[1][0];
tmp_1054 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1051]), make_op_rhs(OP_ELL_INT_RF, make_compvar_primary(tmp_1052), make_compvar_primary(tmp_1053), make_compvar_primary(tmp_1054)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rj (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1055;
for (tmp_1055 = 0; tmp_1055 < 1; ++tmp_1055)
{
switch (tmp_1055)
{
case 0 :
{
compvar_t *tmp_1056, *tmp_1057, *tmp_1058, *tmp_1059;
tmp_1056 = args[0][0];
tmp_1057 = args[1][0];
tmp_1058 = args[2][0];
tmp_1059 = args[3][0];
emit_assign(make_lhs(result_tmps[tmp_1055]), make_op_rhs(OP_ELL_INT_RJ, make_compvar_primary(tmp_1056), make_compvar_primary(tmp_1057), make_compvar_primary(tmp_1058), make_compvar_primary(tmp_1059)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_sn_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1060;

tmp_1060 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1061, *tmp_1062;
tmp_1061 = args[0][0];
tmp_1062 = args[1][0];
emit_assign(make_lhs(tmp_1060), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1061), make_compvar_primary(tmp_1062)));
}

{
int tmp_1063;
for (tmp_1063 = 0; tmp_1063 < 1; ++tmp_1063)
{
switch (tmp_1063)
{
case 0 :
{
compvar_t *tmp_1064, *tmp_1065;
tmp_1064 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1064), make_int_const_rhs(0));
tmp_1065 = tmp_1060;
emit_assign(make_lhs(result_tmps[tmp_1063]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1064), make_compvar_primary(tmp_1065)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_cn_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1066;

tmp_1066 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1067, *tmp_1068;
tmp_1067 = args[0][0];
tmp_1068 = args[1][0];
emit_assign(make_lhs(tmp_1066), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1067), make_compvar_primary(tmp_1068)));
}

{
int tmp_1069;
for (tmp_1069 = 0; tmp_1069 < 1; ++tmp_1069)
{
switch (tmp_1069)
{
case 0 :
{
compvar_t *tmp_1070, *tmp_1071;
tmp_1070 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1070), make_int_const_rhs(1));
tmp_1071 = tmp_1066;
emit_assign(make_lhs(result_tmps[tmp_1069]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1070), make_compvar_primary(tmp_1071)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_dn_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1072;

tmp_1072 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1073, *tmp_1074;
tmp_1073 = args[0][0];
tmp_1074 = args[1][0];
emit_assign(make_lhs(tmp_1072), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1073), make_compvar_primary(tmp_1074)));
}

{
int tmp_1075;
for (tmp_1075 = 0; tmp_1075 < 1; ++tmp_1075)
{
switch (tmp_1075)
{
case 0 :
{
compvar_t *tmp_1076, *tmp_1077;
tmp_1076 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1076), make_int_const_rhs(2));
tmp_1077 = tmp_1072;
emit_assign(make_lhs(result_tmps[tmp_1075]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1076), make_compvar_primary(tmp_1077)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_sn_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1078;
compvar_t *tmp_1081;

tmp_1078 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1079, *tmp_1080;
tmp_1079 = args[0][0];
tmp_1080 = args[1][0];
emit_assign(make_lhs(tmp_1078), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1079), make_compvar_primary(tmp_1080)));
}

tmp_1081 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1082, *tmp_1083;
tmp_1082 = args[0][1];
tmp_1083 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1084, *tmp_1085;
tmp_1084 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1084), make_int_const_rhs(1));
tmp_1085 = args[1][0];
emit_assign(make_lhs(tmp_1083), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1084), make_compvar_primary(tmp_1085)));
}
emit_assign(make_lhs(tmp_1081), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1082), make_compvar_primary(tmp_1083)));
}

{
compvar_t *tmp_1086;
compvar_t *tmp_1089;
compvar_t *tmp_1092;
compvar_t *tmp_1095;
compvar_t *tmp_1098;
compvar_t *tmp_1101;

tmp_1086 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1087, *tmp_1088;
tmp_1087 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1087), make_int_const_rhs(0));
tmp_1088 = tmp_1078;
emit_assign(make_lhs(tmp_1086), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1087), make_compvar_primary(tmp_1088)));
}

tmp_1089 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1090, *tmp_1091;
tmp_1090 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1090), make_int_const_rhs(1));
tmp_1091 = tmp_1078;
emit_assign(make_lhs(tmp_1089), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1090), make_compvar_primary(tmp_1091)));
}

tmp_1092 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1093, *tmp_1094;
tmp_1093 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1093), make_int_const_rhs(2));
tmp_1094 = tmp_1078;
emit_assign(make_lhs(tmp_1092), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1093), make_compvar_primary(tmp_1094)));
}

tmp_1095 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1096, *tmp_1097;
tmp_1096 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1096), make_int_const_rhs(0));
tmp_1097 = tmp_1081;
emit_assign(make_lhs(tmp_1095), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1096), make_compvar_primary(tmp_1097)));
}

tmp_1098 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1099, *tmp_1100;
tmp_1099 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1099), make_int_const_rhs(1));
tmp_1100 = tmp_1081;
emit_assign(make_lhs(tmp_1098), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1099), make_compvar_primary(tmp_1100)));
}

tmp_1101 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1102, *tmp_1103;
tmp_1102 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1102), make_int_const_rhs(2));
tmp_1103 = tmp_1081;
emit_assign(make_lhs(tmp_1101), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1102), make_compvar_primary(tmp_1103)));
}

{
compvar_t *tmp_1104;

tmp_1104 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1105, *tmp_1106;
tmp_1105 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1107, *tmp_1108;
tmp_1107 = tmp_1098;
tmp_1108 = tmp_1098;
emit_assign(make_lhs(tmp_1105), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1107), make_compvar_primary(tmp_1108)));
}
tmp_1106 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1109, *tmp_1110;
tmp_1109 = args[1][0];
tmp_1110 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1111, *tmp_1112;
tmp_1111 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1113, *tmp_1114;
tmp_1113 = tmp_1086;
tmp_1114 = tmp_1086;
emit_assign(make_lhs(tmp_1111), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1113), make_compvar_primary(tmp_1114)));
}
tmp_1112 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1115, *tmp_1116;
tmp_1115 = tmp_1095;
tmp_1116 = tmp_1095;
emit_assign(make_lhs(tmp_1112), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1115), make_compvar_primary(tmp_1116)));
}
emit_assign(make_lhs(tmp_1110), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1111), make_compvar_primary(tmp_1112)));
}
emit_assign(make_lhs(tmp_1106), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1109), make_compvar_primary(tmp_1110)));
}
emit_assign(make_lhs(tmp_1104), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1105), make_compvar_primary(tmp_1106)));
}

{
compvar_t *tmp_1117, *tmp_1118;
tmp_1117 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1119, *tmp_1120;
tmp_1119 = tmp_1086;
tmp_1120 = tmp_1101;
emit_assign(make_lhs(tmp_1117), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1119), make_compvar_primary(tmp_1120)));
}
tmp_1118 = tmp_1104;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1117), make_compvar_primary(tmp_1118)));
}
{
compvar_t *tmp_1121, *tmp_1122;
tmp_1121 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1123, *tmp_1124;
tmp_1123 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1125, *tmp_1126;
tmp_1125 = tmp_1089;
tmp_1126 = tmp_1092;
emit_assign(make_lhs(tmp_1123), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1125), make_compvar_primary(tmp_1126)));
}
tmp_1124 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1127, *tmp_1128;
tmp_1127 = tmp_1095;
tmp_1128 = tmp_1098;
emit_assign(make_lhs(tmp_1124), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1127), make_compvar_primary(tmp_1128)));
}
emit_assign(make_lhs(tmp_1121), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1123), make_compvar_primary(tmp_1124)));
}
tmp_1122 = tmp_1104;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1121), make_compvar_primary(tmp_1122)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_cn_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1129;
compvar_t *tmp_1132;

tmp_1129 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1130, *tmp_1131;
tmp_1130 = args[0][0];
tmp_1131 = args[1][0];
emit_assign(make_lhs(tmp_1129), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1130), make_compvar_primary(tmp_1131)));
}

tmp_1132 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1133, *tmp_1134;
tmp_1133 = args[0][1];
tmp_1134 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1135, *tmp_1136;
tmp_1135 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1135), make_int_const_rhs(1));
tmp_1136 = args[1][0];
emit_assign(make_lhs(tmp_1134), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1135), make_compvar_primary(tmp_1136)));
}
emit_assign(make_lhs(tmp_1132), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1133), make_compvar_primary(tmp_1134)));
}

{
compvar_t *tmp_1137;
compvar_t *tmp_1140;
compvar_t *tmp_1143;
compvar_t *tmp_1146;
compvar_t *tmp_1149;
compvar_t *tmp_1152;

tmp_1137 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1138, *tmp_1139;
tmp_1138 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1138), make_int_const_rhs(0));
tmp_1139 = tmp_1129;
emit_assign(make_lhs(tmp_1137), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1138), make_compvar_primary(tmp_1139)));
}

tmp_1140 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1141, *tmp_1142;
tmp_1141 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1141), make_int_const_rhs(1));
tmp_1142 = tmp_1129;
emit_assign(make_lhs(tmp_1140), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1141), make_compvar_primary(tmp_1142)));
}

tmp_1143 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1144, *tmp_1145;
tmp_1144 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1144), make_int_const_rhs(2));
tmp_1145 = tmp_1129;
emit_assign(make_lhs(tmp_1143), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1144), make_compvar_primary(tmp_1145)));
}

tmp_1146 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1147, *tmp_1148;
tmp_1147 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1147), make_int_const_rhs(0));
tmp_1148 = tmp_1132;
emit_assign(make_lhs(tmp_1146), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1147), make_compvar_primary(tmp_1148)));
}

tmp_1149 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1150, *tmp_1151;
tmp_1150 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1150), make_int_const_rhs(1));
tmp_1151 = tmp_1132;
emit_assign(make_lhs(tmp_1149), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1150), make_compvar_primary(tmp_1151)));
}

tmp_1152 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1153, *tmp_1154;
tmp_1153 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1153), make_int_const_rhs(2));
tmp_1154 = tmp_1132;
emit_assign(make_lhs(tmp_1152), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1153), make_compvar_primary(tmp_1154)));
}

{
compvar_t *tmp_1155;

tmp_1155 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1156, *tmp_1157;
tmp_1156 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1158, *tmp_1159;
tmp_1158 = tmp_1149;
tmp_1159 = tmp_1149;
emit_assign(make_lhs(tmp_1156), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1158), make_compvar_primary(tmp_1159)));
}
tmp_1157 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1160, *tmp_1161;
tmp_1160 = args[1][0];
tmp_1161 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1162, *tmp_1163;
tmp_1162 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1164, *tmp_1165;
tmp_1164 = tmp_1137;
tmp_1165 = tmp_1137;
emit_assign(make_lhs(tmp_1162), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1164), make_compvar_primary(tmp_1165)));
}
tmp_1163 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1166, *tmp_1167;
tmp_1166 = tmp_1146;
tmp_1167 = tmp_1146;
emit_assign(make_lhs(tmp_1163), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1166), make_compvar_primary(tmp_1167)));
}
emit_assign(make_lhs(tmp_1161), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1162), make_compvar_primary(tmp_1163)));
}
emit_assign(make_lhs(tmp_1157), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1160), make_compvar_primary(tmp_1161)));
}
emit_assign(make_lhs(tmp_1155), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1156), make_compvar_primary(tmp_1157)));
}

{
compvar_t *tmp_1168, *tmp_1169;
tmp_1168 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1170, *tmp_1171;
tmp_1170 = tmp_1140;
tmp_1171 = tmp_1149;
emit_assign(make_lhs(tmp_1168), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1170), make_compvar_primary(tmp_1171)));
}
tmp_1169 = tmp_1155;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1168), make_compvar_primary(tmp_1169)));
}
{
compvar_t *tmp_1172, *tmp_1173;
tmp_1172 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1174;
tmp_1174 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1175, *tmp_1176;
tmp_1175 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1177, *tmp_1178;
tmp_1177 = tmp_1137;
tmp_1178 = tmp_1143;
emit_assign(make_lhs(tmp_1175), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1177), make_compvar_primary(tmp_1178)));
}
tmp_1176 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1179, *tmp_1180;
tmp_1179 = tmp_1146;
tmp_1180 = tmp_1152;
emit_assign(make_lhs(tmp_1176), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1179), make_compvar_primary(tmp_1180)));
}
emit_assign(make_lhs(tmp_1174), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1175), make_compvar_primary(tmp_1176)));
}
emit_assign(make_lhs(tmp_1172), make_op_rhs(OP_NEG, make_compvar_primary(tmp_1174)));
}
tmp_1173 = tmp_1155;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1172), make_compvar_primary(tmp_1173)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_dn_ri (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1181;
compvar_t *tmp_1184;

tmp_1181 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1182, *tmp_1183;
tmp_1182 = args[0][0];
tmp_1183 = args[1][0];
emit_assign(make_lhs(tmp_1181), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1182), make_compvar_primary(tmp_1183)));
}

tmp_1184 = compiler_make_temporary(TYPE_V3);
{
compvar_t *tmp_1185, *tmp_1186;
tmp_1185 = args[0][1];
tmp_1186 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1187, *tmp_1188;
tmp_1187 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1187), make_int_const_rhs(1));
tmp_1188 = args[1][0];
emit_assign(make_lhs(tmp_1186), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1187), make_compvar_primary(tmp_1188)));
}
emit_assign(make_lhs(tmp_1184), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1185), make_compvar_primary(tmp_1186)));
}

{
compvar_t *tmp_1189;
compvar_t *tmp_1192;
compvar_t *tmp_1195;
compvar_t *tmp_1198;
compvar_t *tmp_1201;
compvar_t *tmp_1204;

tmp_1189 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1190, *tmp_1191;
tmp_1190 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1190), make_int_const_rhs(0));
tmp_1191 = tmp_1181;
emit_assign(make_lhs(tmp_1189), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1190), make_compvar_primary(tmp_1191)));
}

tmp_1192 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1193, *tmp_1194;
tmp_1193 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1193), make_int_const_rhs(1));
tmp_1194 = tmp_1181;
emit_assign(make_lhs(tmp_1192), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1193), make_compvar_primary(tmp_1194)));
}

tmp_1195 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1196, *tmp_1197;
tmp_1196 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1196), make_int_const_rhs(2));
tmp_1197 = tmp_1181;
emit_assign(make_lhs(tmp_1195), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1196), make_compvar_primary(tmp_1197)));
}

tmp_1198 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1199, *tmp_1200;
tmp_1199 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1199), make_int_const_rhs(0));
tmp_1200 = tmp_1184;
emit_assign(make_lhs(tmp_1198), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1199), make_compvar_primary(tmp_1200)));
}

tmp_1201 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1202, *tmp_1203;
tmp_1202 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1202), make_int_const_rhs(1));
tmp_1203 = tmp_1184;
emit_assign(make_lhs(tmp_1201), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1202), make_compvar_primary(tmp_1203)));
}

tmp_1204 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1205, *tmp_1206;
tmp_1205 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1205), make_int_const_rhs(2));
tmp_1206 = tmp_1184;
emit_assign(make_lhs(tmp_1204), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1205), make_compvar_primary(tmp_1206)));
}

{
compvar_t *tmp_1207;

tmp_1207 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1208, *tmp_1209;
tmp_1208 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1210, *tmp_1211;
tmp_1210 = tmp_1201;
tmp_1211 = tmp_1201;
emit_assign(make_lhs(tmp_1208), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1210), make_compvar_primary(tmp_1211)));
}
tmp_1209 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1212, *tmp_1213;
tmp_1212 = args[1][0];
tmp_1213 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1214, *tmp_1215;
tmp_1214 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1216, *tmp_1217;
tmp_1216 = tmp_1189;
tmp_1217 = tmp_1189;
emit_assign(make_lhs(tmp_1214), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1216), make_compvar_primary(tmp_1217)));
}
tmp_1215 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1218, *tmp_1219;
tmp_1218 = tmp_1198;
tmp_1219 = tmp_1198;
emit_assign(make_lhs(tmp_1215), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1218), make_compvar_primary(tmp_1219)));
}
emit_assign(make_lhs(tmp_1213), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1214), make_compvar_primary(tmp_1215)));
}
emit_assign(make_lhs(tmp_1209), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1212), make_compvar_primary(tmp_1213)));
}
emit_assign(make_lhs(tmp_1207), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1208), make_compvar_primary(tmp_1209)));
}

{
compvar_t *tmp_1220, *tmp_1221;
tmp_1220 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1222, *tmp_1223;
tmp_1222 = tmp_1201;
tmp_1223 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1224, *tmp_1225;
tmp_1224 = tmp_1195;
tmp_1225 = tmp_1204;
emit_assign(make_lhs(tmp_1223), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1224), make_compvar_primary(tmp_1225)));
}
emit_assign(make_lhs(tmp_1220), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1222), make_compvar_primary(tmp_1223)));
}
tmp_1221 = tmp_1207;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1220), make_compvar_primary(tmp_1221)));
}
{
compvar_t *tmp_1226, *tmp_1227;
tmp_1226 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1228, *tmp_1229;
tmp_1228 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1230, *tmp_1231;
tmp_1230 = tmp_1189;
tmp_1231 = tmp_1198;
emit_assign(make_lhs(tmp_1228), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1230), make_compvar_primary(tmp_1231)));
}
tmp_1229 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1232, *tmp_1233;
tmp_1232 = args[1][0];
tmp_1233 = tmp_1192;
emit_assign(make_lhs(tmp_1229), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1232), make_compvar_primary(tmp_1233)));
}
emit_assign(make_lhs(tmp_1226), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1228), make_compvar_primary(tmp_1229)));
}
tmp_1227 = tmp_1207;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1226), make_compvar_primary(tmp_1227)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_floor (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1234;
for (tmp_1234 = 0; tmp_1234 < 1; ++tmp_1234)
{
switch (tmp_1234)
{
case 0 :
{
compvar_t *tmp_1235;
tmp_1235 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1234]), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1235)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ceil (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1236;
for (tmp_1236 = 0; tmp_1236 < 1; ++tmp_1236)
{
switch (tmp_1236)
{
case 0 :
{
compvar_t *tmp_1237;
tmp_1237 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1236]), make_op_rhs(OP_CEIL, make_compvar_primary(tmp_1237)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sign_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1238;
for (tmp_1238 = 0; tmp_1238 < arglengths[0]; ++tmp_1238)
{
{
compvar_t *tmp_1239;
tmp_1239 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1240, *tmp_1241;
tmp_1240 = args[0][tmp_1238];
tmp_1241 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1241), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1239), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1240), make_compvar_primary(tmp_1241)));
}
start_if_cond(make_compvar_rhs(tmp_1239));
emit_assign(make_lhs(result_tmps[tmp_1238]), make_int_const_rhs(-1));
switch_if_branch();
{
compvar_t *tmp_1242;
tmp_1242 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1243, *tmp_1244;
tmp_1243 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1243), make_int_const_rhs(0));
tmp_1244 = args[0][tmp_1238];
emit_assign(make_lhs(tmp_1242), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1243), make_compvar_primary(tmp_1244)));
}
start_if_cond(make_compvar_rhs(tmp_1242));
emit_assign(make_lhs(result_tmps[tmp_1238]), make_int_const_rhs(1));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1238]), make_int_const_rhs(0));
end_if_cond();
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_min_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1245;
for (tmp_1245 = 0; tmp_1245 < arglengths[0]; ++tmp_1245)
{
{
compvar_t *tmp_1246;
tmp_1246 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1247, *tmp_1248;
tmp_1247 = args[0][tmp_1245];
tmp_1248 = args[1][tmp_1245];
emit_assign(make_lhs(tmp_1246), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1247), make_compvar_primary(tmp_1248)));
}
start_if_cond(make_compvar_rhs(tmp_1246));
emit_assign(make_lhs(result_tmps[tmp_1245]), make_compvar_rhs(args[0][tmp_1245]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1245]), make_compvar_rhs(args[1][tmp_1245]));
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_max_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1249;
for (tmp_1249 = 0; tmp_1249 < arglengths[0]; ++tmp_1249)
{
{
compvar_t *tmp_1250;
tmp_1250 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1251, *tmp_1252;
tmp_1251 = args[0][tmp_1249];
tmp_1252 = args[1][tmp_1249];
emit_assign(make_lhs(tmp_1250), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1251), make_compvar_primary(tmp_1252)));
}
start_if_cond(make_compvar_rhs(tmp_1250));
emit_assign(make_lhs(result_tmps[tmp_1249]), make_compvar_rhs(args[1][tmp_1249]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1249]), make_compvar_rhs(args[0][tmp_1249]));
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_clamp (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1253;
for (tmp_1253 = 0; tmp_1253 < arglengths[0]; ++tmp_1253)
{
{
compvar_t *tmp_1254;
tmp_1254 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1255, *tmp_1256;
tmp_1255 = args[0][tmp_1253];
tmp_1256 = args[1][tmp_1253];
emit_assign(make_lhs(tmp_1254), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1255), make_compvar_primary(tmp_1256)));
}
start_if_cond(make_compvar_rhs(tmp_1254));
emit_assign(make_lhs(result_tmps[tmp_1253]), make_compvar_rhs(args[1][tmp_1253]));
switch_if_branch();
{
compvar_t *tmp_1257;
tmp_1257 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1258, *tmp_1259;
tmp_1258 = args[2][tmp_1253];
tmp_1259 = args[0][tmp_1253];
emit_assign(make_lhs(tmp_1257), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1258), make_compvar_primary(tmp_1259)));
}
start_if_cond(make_compvar_rhs(tmp_1257));
emit_assign(make_lhs(result_tmps[tmp_1253]), make_compvar_rhs(args[2][tmp_1253]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1253]), make_compvar_rhs(args[0][tmp_1253]));
end_if_cond();
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lerp_1 (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[1]];
int i;
for (i = 0; i < arglengths[1]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1260;

tmp_1260 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1261, *tmp_1262;
tmp_1261 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1261), make_int_const_rhs(1));
tmp_1262 = args[0][0];
emit_assign(make_lhs(tmp_1260), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1261), make_compvar_primary(tmp_1262)));
}

{
int tmp_1263;
for (tmp_1263 = 0; tmp_1263 < arglengths[1]; ++tmp_1263)
{
{
compvar_t *tmp_1264, *tmp_1265;
tmp_1264 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1266, *tmp_1267;
tmp_1266 = tmp_1260;
tmp_1267 = args[1][tmp_1263];
emit_assign(make_lhs(tmp_1264), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1266), make_compvar_primary(tmp_1267)));
}
tmp_1265 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1268, *tmp_1269;
tmp_1268 = args[0][0];
tmp_1269 = args[2][tmp_1263];
emit_assign(make_lhs(tmp_1265), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1268), make_compvar_primary(tmp_1269)));
}
emit_assign(make_lhs(result_tmps[tmp_1263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1264), make_compvar_primary(tmp_1265)));
}
}
}
}
for (i = 0; i < arglengths[1]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lerp_n (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1270;
for (tmp_1270 = 0; tmp_1270 < arglengths[1]; ++tmp_1270)
{
{
compvar_t *tmp_1271, *tmp_1272;
tmp_1271 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1273, *tmp_1274;
tmp_1273 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1275, *tmp_1276;
tmp_1275 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1275), make_int_const_rhs(1));
tmp_1276 = args[0][tmp_1270];
emit_assign(make_lhs(tmp_1273), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1275), make_compvar_primary(tmp_1276)));
}
tmp_1274 = args[1][tmp_1270];
emit_assign(make_lhs(tmp_1271), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1273), make_compvar_primary(tmp_1274)));
}
tmp_1272 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1277, *tmp_1278;
tmp_1277 = args[0][tmp_1270];
tmp_1278 = args[2][tmp_1270];
emit_assign(make_lhs(tmp_1272), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1277), make_compvar_primary(tmp_1278)));
}
emit_assign(make_lhs(result_tmps[tmp_1270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1271), make_compvar_primary(tmp_1272)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_scale (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1279;
for (tmp_1279 = 0; tmp_1279 < arglengths[0]; ++tmp_1279)
{
{
compvar_t *tmp_1280;

tmp_1280 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1281, *tmp_1282;
tmp_1281 = args[2][tmp_1279];
tmp_1282 = args[1][tmp_1279];
emit_assign(make_lhs(tmp_1280), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1281), make_compvar_primary(tmp_1282)));
}

{
compvar_t *tmp_1283;
tmp_1283 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1284, *tmp_1285;
tmp_1284 = tmp_1280;
tmp_1285 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1285), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1283), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1284), make_compvar_primary(tmp_1285)));
}
start_if_cond(make_compvar_rhs(tmp_1283));
emit_assign(make_lhs(result_tmps[tmp_1279]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1286, *tmp_1287;
tmp_1286 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1288, *tmp_1289;
tmp_1288 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1290, *tmp_1291;
tmp_1290 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1292, *tmp_1293;
tmp_1292 = args[0][tmp_1279];
tmp_1293 = args[1][tmp_1279];
emit_assign(make_lhs(tmp_1290), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1292), make_compvar_primary(tmp_1293)));
}
tmp_1291 = tmp_1280;
emit_assign(make_lhs(tmp_1288), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1290), make_compvar_primary(tmp_1291)));
}
tmp_1289 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1294, *tmp_1295;
tmp_1294 = args[4][tmp_1279];
tmp_1295 = args[3][tmp_1279];
emit_assign(make_lhs(tmp_1289), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1294), make_compvar_primary(tmp_1295)));
}
emit_assign(make_lhs(tmp_1286), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1288), make_compvar_primary(tmp_1289)));
}
tmp_1287 = args[3][tmp_1279];
emit_assign(make_lhs(result_tmps[tmp_1279]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1286), make_compvar_primary(tmp_1287)));
}
end_if_cond();
}
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_not (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1296;
tmp_1296 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1297, *tmp_1298;
tmp_1297 = args[0][0];
tmp_1298 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1298), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1296), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1297), make_compvar_primary(tmp_1298)));
}
start_if_cond(make_compvar_rhs(tmp_1296));
{
int tmp_1299;
for (tmp_1299 = 0; tmp_1299 < 1; ++tmp_1299)
{
switch (tmp_1299)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1299]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1300;
for (tmp_1300 = 0; tmp_1300 < 1; ++tmp_1300)
{
switch (tmp_1300)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1300]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_or (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1301;
tmp_1301 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1302, *tmp_1303;
tmp_1302 = args[0][0];
tmp_1303 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1303), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1301), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1302), make_compvar_primary(tmp_1303)));
}
start_if_cond(make_compvar_rhs(tmp_1301));
{
compvar_t *tmp_1304, *tmp_1305;
tmp_1304 = args[1][0];
tmp_1305 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1305), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1301), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1304), make_compvar_primary(tmp_1305)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1301));
{
int tmp_1306;
for (tmp_1306 = 0; tmp_1306 < 1; ++tmp_1306)
{
switch (tmp_1306)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1306]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1307;
for (tmp_1307 = 0; tmp_1307 < 1; ++tmp_1307)
{
switch (tmp_1307)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1307]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_and (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1308;
tmp_1308 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1309, *tmp_1310;
tmp_1309 = args[0][0];
tmp_1310 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1310), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1308), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1309), make_compvar_primary(tmp_1310)));
}
start_if_cond(make_compvar_rhs(tmp_1308));
switch_if_branch();
{
compvar_t *tmp_1311, *tmp_1312;
tmp_1311 = args[1][0];
tmp_1312 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1312), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1308), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1311), make_compvar_primary(tmp_1312)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1308));
{
int tmp_1313;
for (tmp_1313 = 0; tmp_1313 < 1; ++tmp_1313)
{
switch (tmp_1313)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1313]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1314;
for (tmp_1314 = 0; tmp_1314 < 1; ++tmp_1314)
{
switch (tmp_1314)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1314]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_xor (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1315;
tmp_1315 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1316, *tmp_1317;
tmp_1316 = args[0][0];
tmp_1317 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1317), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1315), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1316), make_compvar_primary(tmp_1317)));
}
emit_assign(make_lhs(tmp_1315), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1315)));
start_if_cond(make_compvar_rhs(tmp_1315));
{
compvar_t *tmp_1318, *tmp_1319;
tmp_1318 = args[1][0];
tmp_1319 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1319), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1315), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1318), make_compvar_primary(tmp_1319)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1315));
switch_if_branch();
{
compvar_t *tmp_1320, *tmp_1321;
tmp_1320 = args[1][0];
tmp_1321 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1321), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1315), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1320), make_compvar_primary(tmp_1321)));
}
emit_assign(make_lhs(tmp_1315), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1315)));
start_if_cond(make_compvar_rhs(tmp_1315));
{
compvar_t *tmp_1322, *tmp_1323;
tmp_1322 = args[0][0];
tmp_1323 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1323), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1315), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1322), make_compvar_primary(tmp_1323)));
}
switch_if_branch();
end_if_cond();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1315));
{
int tmp_1324;
for (tmp_1324 = 0; tmp_1324 < 1; ++tmp_1324)
{
switch (tmp_1324)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1324]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1325;
for (tmp_1325 = 0; tmp_1325 < 1; ++tmp_1325)
{
switch (tmp_1325)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1325]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_equal (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1326;
for (tmp_1326 = 0; tmp_1326 < 1; ++tmp_1326)
{
switch (tmp_1326)
{
case 0 :
{
compvar_t *tmp_1327, *tmp_1328;
tmp_1327 = args[0][0];
tmp_1328 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1326]), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1327), make_compvar_primary(tmp_1328)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_less (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1329;
for (tmp_1329 = 0; tmp_1329 < 1; ++tmp_1329)
{
switch (tmp_1329)
{
case 0 :
{
compvar_t *tmp_1330, *tmp_1331;
tmp_1330 = args[0][0];
tmp_1331 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1329]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1330), make_compvar_primary(tmp_1331)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_greater (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1332;
for (tmp_1332 = 0; tmp_1332 < 1; ++tmp_1332)
{
switch (tmp_1332)
{
case 0 :
{
compvar_t *tmp_1333, *tmp_1334;
tmp_1333 = args[1][0];
tmp_1334 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1332]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1333), make_compvar_primary(tmp_1334)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lessequal (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1335;
for (tmp_1335 = 0; tmp_1335 < 1; ++tmp_1335)
{
switch (tmp_1335)
{
case 0 :
{
compvar_t *tmp_1336, *tmp_1337;
tmp_1336 = args[0][0];
tmp_1337 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1335]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1336), make_compvar_primary(tmp_1337)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_greaterequal (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1338;
for (tmp_1338 = 0; tmp_1338 < 1; ++tmp_1338)
{
switch (tmp_1338)
{
case 0 :
{
compvar_t *tmp_1339, *tmp_1340;
tmp_1339 = args[1][0];
tmp_1340 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1338]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1339), make_compvar_primary(tmp_1340)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_notequal (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1341;
for (tmp_1341 = 0; tmp_1341 < 1; ++tmp_1341)
{
switch (tmp_1341)
{
case 0 :
{
compvar_t *tmp_1342;
tmp_1342 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1343, *tmp_1344;
tmp_1343 = args[0][0];
tmp_1344 = args[1][0];
emit_assign(make_lhs(tmp_1342), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1343), make_compvar_primary(tmp_1344)));
}
emit_assign(make_lhs(result_tmps[tmp_1341]), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1342)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_inintv (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1345;
tmp_1345 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1346, *tmp_1347;
tmp_1346 = args[1][0];
tmp_1347 = args[0][0];
emit_assign(make_lhs(tmp_1345), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1346), make_compvar_primary(tmp_1347)));
}
start_if_cond(make_compvar_rhs(tmp_1345));
{
compvar_t *tmp_1348, *tmp_1349;
tmp_1348 = args[0][0];
tmp_1349 = args[2][0];
emit_assign(make_lhs(tmp_1345), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1348), make_compvar_primary(tmp_1349)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1345));
{
int tmp_1350;
for (tmp_1350 = 0; tmp_1350 < 1; ++tmp_1350)
{
switch (tmp_1350)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1350]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1351;
for (tmp_1351 = 0; tmp_1351 < 1; ++tmp_1351)
{
switch (tmp_1351)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1351]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_apply_curve (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1352;
for (tmp_1352 = 0; tmp_1352 < 1; ++tmp_1352)
{
switch (tmp_1352)
{
case 0 :
{
compvar_t *tmp_1353, *tmp_1354;
tmp_1353 = args[0][0];
tmp_1354 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1352]), make_op_rhs(OP_APPLY_CURVE, make_compvar_primary(tmp_1353), make_compvar_primary(tmp_1354)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_apply_gradient (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1355;

tmp_1355 = compiler_make_temporary(TYPE_TUPLE);
{
compvar_t *tmp_1356, *tmp_1357;
tmp_1356 = args[0][0];
tmp_1357 = args[1][0];
emit_assign(make_lhs(tmp_1355), make_op_rhs(OP_APPLY_GRADIENT, make_compvar_primary(tmp_1356), make_compvar_primary(tmp_1357)));
}

{
int tmp_1358;
for (tmp_1358 = 0; tmp_1358 < 4; ++tmp_1358)
{
switch (tmp_1358)
{
case 0 :
{
compvar_t *tmp_1359, *tmp_1360;
tmp_1359 = tmp_1355;
tmp_1360 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1360), make_int_const_rhs(0));
emit_assign(make_lhs(result_tmps[tmp_1358]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1359), make_compvar_primary(tmp_1360)));
}
break;
case 1 :
{
compvar_t *tmp_1361, *tmp_1362;
tmp_1361 = tmp_1355;
tmp_1362 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1362), make_int_const_rhs(1));
emit_assign(make_lhs(result_tmps[tmp_1358]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1361), make_compvar_primary(tmp_1362)));
}
break;
case 2 :
{
compvar_t *tmp_1363, *tmp_1364;
tmp_1363 = tmp_1355;
tmp_1364 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1364), make_int_const_rhs(2));
emit_assign(make_lhs(result_tmps[tmp_1358]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1363), make_compvar_primary(tmp_1364)));
}
break;
case 3 :
{
compvar_t *tmp_1365, *tmp_1366;
tmp_1365 = tmp_1355;
tmp_1366 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1366), make_int_const_rhs(3));
emit_assign(make_lhs(result_tmps[tmp_1358]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1365), make_compvar_primary(tmp_1366)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_origvalxy (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1367;

tmp_1367 = compiler_make_temporary(TYPE_TUPLE);
{
compvar_t *tmp_1368, *tmp_1369, *tmp_1370, *tmp_1371;
tmp_1368 = args[0][0];
tmp_1369 = args[0][1];
tmp_1370 = args[2][0];
tmp_1371 = args[1][0];
emit_assign(make_lhs(tmp_1367), make_op_rhs(OP_ORIG_VAL, make_compvar_primary(tmp_1368), make_compvar_primary(tmp_1369), make_compvar_primary(tmp_1370), make_compvar_primary(tmp_1371)));
}

{
int tmp_1372;
for (tmp_1372 = 0; tmp_1372 < 4; ++tmp_1372)
{
switch (tmp_1372)
{
case 0 :
{
compvar_t *tmp_1373, *tmp_1374;
tmp_1373 = tmp_1367;
tmp_1374 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1374), make_int_const_rhs(0));
emit_assign(make_lhs(result_tmps[tmp_1372]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1373), make_compvar_primary(tmp_1374)));
}
break;
case 1 :
{
compvar_t *tmp_1375, *tmp_1376;
tmp_1375 = tmp_1367;
tmp_1376 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1376), make_int_const_rhs(1));
emit_assign(make_lhs(result_tmps[tmp_1372]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1375), make_compvar_primary(tmp_1376)));
}
break;
case 2 :
{
compvar_t *tmp_1377, *tmp_1378;
tmp_1377 = tmp_1367;
tmp_1378 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1378), make_int_const_rhs(2));
emit_assign(make_lhs(result_tmps[tmp_1372]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1377), make_compvar_primary(tmp_1378)));
}
break;
case 3 :
{
compvar_t *tmp_1379, *tmp_1380;
tmp_1379 = tmp_1367;
tmp_1380 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1380), make_int_const_rhs(3));
emit_assign(make_lhs(result_tmps[tmp_1372]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1379), make_compvar_primary(tmp_1380)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_render (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1381;
for (tmp_1381 = 0; tmp_1381 < 1; ++tmp_1381)
{
switch (tmp_1381)
{
case 0 :
{
compvar_t *tmp_1382, *tmp_1383, *tmp_1384;
tmp_1382 = args[0][0];
tmp_1383 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1383), make_value_rhs(get_internal_value(filter, "__renderPixelW", TRUE)));
tmp_1384 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1384), make_value_rhs(get_internal_value(filter, "__renderPixelH", TRUE)));
emit_assign(make_lhs(result_tmps[tmp_1381]), make_op_rhs(OP_RENDER, make_compvar_primary(tmp_1382), make_compvar_primary(tmp_1383), make_compvar_primary(tmp_1384)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pixelsize (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1385;
for (tmp_1385 = 0; tmp_1385 < 2; ++tmp_1385)
{
switch (tmp_1385)
{
case 0 :
{
compvar_t *tmp_1386;
tmp_1386 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1385]), make_op_rhs(OP_IMAGE_PIXEL_WIDTH, make_compvar_primary(tmp_1386)));
}
break;
case 1 :
{
compvar_t *tmp_1387;
tmp_1387 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1385]), make_op_rhs(OP_IMAGE_PIXEL_HEIGHT, make_compvar_primary(tmp_1387)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_red (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1388;
for (tmp_1388 = 0; tmp_1388 < 1; ++tmp_1388)
{
switch (tmp_1388)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1388]), make_compvar_rhs(args[0][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_green (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1389;
for (tmp_1389 = 0; tmp_1389 < 1; ++tmp_1389)
{
switch (tmp_1389)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1389]), make_compvar_rhs(args[0][1]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_blue (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1390;
for (tmp_1390 = 0; tmp_1390 < 1; ++tmp_1390)
{
switch (tmp_1390)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1390]), make_compvar_rhs(args[0][2]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_alpha (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1391;
for (tmp_1391 = 0; tmp_1391 < 1; ++tmp_1391)
{
switch (tmp_1391)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1391]), make_compvar_rhs(args[0][3]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gray (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1392;
for (tmp_1392 = 0; tmp_1392 < 1; ++tmp_1392)
{
switch (tmp_1392)
{
case 0 :
{
compvar_t *tmp_1393, *tmp_1394;
tmp_1393 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1395, *tmp_1396;
tmp_1395 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1397, *tmp_1398;
tmp_1397 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1397), make_float_const_rhs(0.299));
tmp_1398 = args[0][0];
emit_assign(make_lhs(tmp_1395), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1397), make_compvar_primary(tmp_1398)));
}
tmp_1396 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1399, *tmp_1400;
tmp_1399 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1399), make_float_const_rhs(0.587));
tmp_1400 = args[0][1];
emit_assign(make_lhs(tmp_1396), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1399), make_compvar_primary(tmp_1400)));
}
emit_assign(make_lhs(tmp_1393), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1395), make_compvar_primary(tmp_1396)));
}
tmp_1394 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1401, *tmp_1402;
tmp_1401 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1401), make_float_const_rhs(0.114));
tmp_1402 = args[0][2];
emit_assign(make_lhs(tmp_1394), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1401), make_compvar_primary(tmp_1402)));
}
emit_assign(make_lhs(result_tmps[tmp_1392]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1393), make_compvar_primary(tmp_1394)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rgbcolor (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1403;
for (tmp_1403 = 0; tmp_1403 < 4; ++tmp_1403)
{
switch (tmp_1403)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1403]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1403]), make_compvar_rhs(args[1][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1403]), make_compvar_rhs(args[2][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1403]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rgbacolor (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1404;
for (tmp_1404 = 0; tmp_1404 < 4; ++tmp_1404)
{
switch (tmp_1404)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1404]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1404]), make_compvar_rhs(args[1][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1404]), make_compvar_rhs(args[2][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1404]), make_compvar_rhs(args[3][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_graycolor (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1405;
for (tmp_1405 = 0; tmp_1405 < 4; ++tmp_1405)
{
switch (tmp_1405)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1405]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1405]), make_compvar_rhs(args[0][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1405]), make_compvar_rhs(args[0][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1405]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_grayacolor (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1406;
for (tmp_1406 = 0; tmp_1406 < 4; ++tmp_1406)
{
switch (tmp_1406)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1406]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1406]), make_compvar_rhs(args[0][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1406]), make_compvar_rhs(args[0][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1406]), make_compvar_rhs(args[1][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tohsva (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1407;
compvar_t *tmp_1412;
compvar_t *tmp_1417;

tmp_1407 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1408, *tmp_1409;
tmp_1408 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1408), make_int_const_rhs(0));
tmp_1409 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1410, *tmp_1411;
tmp_1410 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1410), make_int_const_rhs(1));
tmp_1411 = args[0][0];
emit_assign(make_lhs(tmp_1409), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1410), make_compvar_primary(tmp_1411)));
}
emit_assign(make_lhs(tmp_1407), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1408), make_compvar_primary(tmp_1409)));
}

tmp_1412 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1413, *tmp_1414;
tmp_1413 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1413), make_int_const_rhs(0));
tmp_1414 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1415, *tmp_1416;
tmp_1415 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1415), make_int_const_rhs(1));
tmp_1416 = args[0][1];
emit_assign(make_lhs(tmp_1414), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1415), make_compvar_primary(tmp_1416)));
}
emit_assign(make_lhs(tmp_1412), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1413), make_compvar_primary(tmp_1414)));
}

tmp_1417 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1418, *tmp_1419;
tmp_1418 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1418), make_int_const_rhs(0));
tmp_1419 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1420, *tmp_1421;
tmp_1420 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1420), make_int_const_rhs(1));
tmp_1421 = args[0][2];
emit_assign(make_lhs(tmp_1419), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1420), make_compvar_primary(tmp_1421)));
}
emit_assign(make_lhs(tmp_1417), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1418), make_compvar_primary(tmp_1419)));
}

{
compvar_t *tmp_1422, *tmp_1423;
tmp_1422 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1422), make_int_const_rhs(0));
tmp_1423 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1424, *tmp_1425;
tmp_1424 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1424), make_int_const_rhs(1));
tmp_1425 = args[0][3];
emit_assign(make_lhs(tmp_1423), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1424), make_compvar_primary(tmp_1425)));
}
emit_assign(make_lhs(result_tmps[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1422), make_compvar_primary(tmp_1423)));
}
{
compvar_t *tmp_1426;
compvar_t *tmp_1431;

tmp_1426 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1427, *tmp_1428;
tmp_1427 = tmp_1407;
tmp_1428 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1429, *tmp_1430;
tmp_1429 = tmp_1412;
tmp_1430 = tmp_1417;
emit_assign(make_lhs(tmp_1428), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1429), make_compvar_primary(tmp_1430)));
}
emit_assign(make_lhs(tmp_1426), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1427), make_compvar_primary(tmp_1428)));
}

tmp_1431 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1432, *tmp_1433;
tmp_1432 = tmp_1407;
tmp_1433 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1434, *tmp_1435;
tmp_1434 = tmp_1412;
tmp_1435 = tmp_1417;
emit_assign(make_lhs(tmp_1433), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1434), make_compvar_primary(tmp_1435)));
}
emit_assign(make_lhs(tmp_1431), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1432), make_compvar_primary(tmp_1433)));
}

emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1426));
{
compvar_t *tmp_1436;
tmp_1436 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1437, *tmp_1438;
tmp_1437 = tmp_1426;
tmp_1438 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1438), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1436), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1437), make_compvar_primary(tmp_1438)));
}
start_if_cond(make_compvar_rhs(tmp_1436));
emit_assign(make_lhs(result_tmps[0]), make_int_const_rhs(0));
emit_assign(make_lhs(result_tmps[1]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1439;
compvar_t *tmp_1442;

tmp_1439 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1440, *tmp_1441;
tmp_1440 = tmp_1426;
tmp_1441 = tmp_1431;
emit_assign(make_lhs(tmp_1439), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1440), make_compvar_primary(tmp_1441)));
}

tmp_1442 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1442), make_int_const_rhs(0));

{
compvar_t *tmp_1443, *tmp_1444;
tmp_1443 = tmp_1439;
tmp_1444 = tmp_1426;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1443), make_compvar_primary(tmp_1444)));
}
{
compvar_t *tmp_1445;
tmp_1445 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1446, *tmp_1447;
tmp_1446 = tmp_1407;
tmp_1447 = tmp_1426;
emit_assign(make_lhs(tmp_1445), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1446), make_compvar_primary(tmp_1447)));
}
start_if_cond(make_compvar_rhs(tmp_1445));
{
compvar_t *tmp_1448, *tmp_1449;
tmp_1448 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1450, *tmp_1451;
tmp_1450 = tmp_1412;
tmp_1451 = tmp_1417;
emit_assign(make_lhs(tmp_1448), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1450), make_compvar_primary(tmp_1451)));
}
tmp_1449 = tmp_1439;
emit_assign(make_lhs(tmp_1442), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1448), make_compvar_primary(tmp_1449)));
}
switch_if_branch();
{
compvar_t *tmp_1452;
tmp_1452 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1453, *tmp_1454;
tmp_1453 = tmp_1412;
tmp_1454 = tmp_1426;
emit_assign(make_lhs(tmp_1452), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1453), make_compvar_primary(tmp_1454)));
}
start_if_cond(make_compvar_rhs(tmp_1452));
{
compvar_t *tmp_1455, *tmp_1456;
tmp_1455 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1455), make_int_const_rhs(2));
tmp_1456 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1457, *tmp_1458;
tmp_1457 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1459, *tmp_1460;
tmp_1459 = tmp_1417;
tmp_1460 = tmp_1407;
emit_assign(make_lhs(tmp_1457), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1459), make_compvar_primary(tmp_1460)));
}
tmp_1458 = tmp_1439;
emit_assign(make_lhs(tmp_1456), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1457), make_compvar_primary(tmp_1458)));
}
emit_assign(make_lhs(tmp_1442), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1455), make_compvar_primary(tmp_1456)));
}
switch_if_branch();
{
compvar_t *tmp_1461, *tmp_1462;
tmp_1461 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1461), make_int_const_rhs(4));
tmp_1462 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1463, *tmp_1464;
tmp_1463 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1465, *tmp_1466;
tmp_1465 = tmp_1407;
tmp_1466 = tmp_1412;
emit_assign(make_lhs(tmp_1463), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1465), make_compvar_primary(tmp_1466)));
}
tmp_1464 = tmp_1439;
emit_assign(make_lhs(tmp_1462), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1463), make_compvar_primary(tmp_1464)));
}
emit_assign(make_lhs(tmp_1442), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1461), make_compvar_primary(tmp_1462)));
}
end_if_cond();
}
end_if_cond();
}
{
compvar_t *tmp_1467, *tmp_1468;
tmp_1467 = tmp_1442;
tmp_1468 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1468), make_float_const_rhs(6.0));
emit_assign(make_lhs(tmp_1442), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1467), make_compvar_primary(tmp_1468)));
}
{
compvar_t *tmp_1469;
tmp_1469 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1470, *tmp_1471;
tmp_1470 = tmp_1442;
tmp_1471 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1471), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1469), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1470), make_compvar_primary(tmp_1471)));
}
start_if_cond(make_compvar_rhs(tmp_1469));
{
compvar_t *tmp_1472, *tmp_1473;
tmp_1472 = tmp_1442;
tmp_1473 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1473), make_int_const_rhs(1));
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1472), make_compvar_primary(tmp_1473)));
}
switch_if_branch();
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1442));
end_if_cond();
}
}
end_if_cond();
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_torgba (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1474;
compvar_t *tmp_1479;

tmp_1474 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1475, *tmp_1476;
tmp_1475 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1475), make_int_const_rhs(0));
tmp_1476 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1477, *tmp_1478;
tmp_1477 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1477), make_int_const_rhs(1));
tmp_1478 = args[0][1];
emit_assign(make_lhs(tmp_1476), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1477), make_compvar_primary(tmp_1478)));
}
emit_assign(make_lhs(tmp_1474), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1475), make_compvar_primary(tmp_1476)));
}

tmp_1479 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1480, *tmp_1481;
tmp_1480 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1480), make_int_const_rhs(0));
tmp_1481 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1482, *tmp_1483;
tmp_1482 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1482), make_int_const_rhs(1));
tmp_1483 = args[0][2];
emit_assign(make_lhs(tmp_1481), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1482), make_compvar_primary(tmp_1483)));
}
emit_assign(make_lhs(tmp_1479), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1480), make_compvar_primary(tmp_1481)));
}

{
compvar_t *tmp_1484, *tmp_1485;
tmp_1484 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1484), make_int_const_rhs(0));
tmp_1485 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1486, *tmp_1487;
tmp_1486 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1486), make_int_const_rhs(1));
tmp_1487 = args[0][3];
emit_assign(make_lhs(tmp_1485), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1486), make_compvar_primary(tmp_1487)));
}
emit_assign(make_lhs(result_tmps[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1484), make_compvar_primary(tmp_1485)));
}
{
compvar_t *tmp_1488;
tmp_1488 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1489, *tmp_1490;
tmp_1489 = tmp_1474;
tmp_1490 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1490), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1488), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1489), make_compvar_primary(tmp_1490)));
}
start_if_cond(make_compvar_rhs(tmp_1488));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1479));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1479));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1479));
switch_if_branch();
{
compvar_t *tmp_1491;

tmp_1491 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1492, *tmp_1493;
tmp_1492 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1492), make_int_const_rhs(0));
tmp_1493 = args[0][0];
emit_assign(make_lhs(tmp_1491), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1492), make_compvar_primary(tmp_1493)));
}

{
compvar_t *tmp_1494;
tmp_1494 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1495, *tmp_1496;
tmp_1495 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1495), make_int_const_rhs(1));
tmp_1496 = tmp_1491;
emit_assign(make_lhs(tmp_1494), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1495), make_compvar_primary(tmp_1496)));
}
start_if_cond(make_compvar_rhs(tmp_1494));
emit_assign(make_lhs(tmp_1491), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1497, *tmp_1498;
tmp_1497 = tmp_1491;
tmp_1498 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1498), make_int_const_rhs(6));
emit_assign(make_lhs(tmp_1491), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1497), make_compvar_primary(tmp_1498)));
}
end_if_cond();
}
{
compvar_t *tmp_1499;

tmp_1499 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1500;
tmp_1500 = tmp_1491;
emit_assign(make_lhs(tmp_1499), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1500)));
}

{
compvar_t *tmp_1501;

tmp_1501 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1502, *tmp_1503;
tmp_1502 = tmp_1491;
tmp_1503 = tmp_1499;
emit_assign(make_lhs(tmp_1501), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1502), make_compvar_primary(tmp_1503)));
}

{
compvar_t *tmp_1504;
compvar_t *tmp_1509;
compvar_t *tmp_1516;

tmp_1504 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1505, *tmp_1506;
tmp_1505 = tmp_1479;
tmp_1506 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1507, *tmp_1508;
tmp_1507 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1507), make_int_const_rhs(1));
tmp_1508 = tmp_1474;
emit_assign(make_lhs(tmp_1506), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1507), make_compvar_primary(tmp_1508)));
}
emit_assign(make_lhs(tmp_1504), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1505), make_compvar_primary(tmp_1506)));
}

tmp_1509 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1510, *tmp_1511;
tmp_1510 = tmp_1479;
tmp_1511 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1512, *tmp_1513;
tmp_1512 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1512), make_int_const_rhs(1));
tmp_1513 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1514, *tmp_1515;
tmp_1514 = tmp_1474;
tmp_1515 = tmp_1501;
emit_assign(make_lhs(tmp_1513), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1514), make_compvar_primary(tmp_1515)));
}
emit_assign(make_lhs(tmp_1511), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1512), make_compvar_primary(tmp_1513)));
}
emit_assign(make_lhs(tmp_1509), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1510), make_compvar_primary(tmp_1511)));
}

tmp_1516 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1517, *tmp_1518;
tmp_1517 = tmp_1479;
tmp_1518 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1519, *tmp_1520;
tmp_1519 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1519), make_int_const_rhs(1));
tmp_1520 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1521, *tmp_1522;
tmp_1521 = tmp_1474;
tmp_1522 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1523, *tmp_1524;
tmp_1523 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1523), make_int_const_rhs(1));
tmp_1524 = tmp_1501;
emit_assign(make_lhs(tmp_1522), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1523), make_compvar_primary(tmp_1524)));
}
emit_assign(make_lhs(tmp_1520), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1521), make_compvar_primary(tmp_1522)));
}
emit_assign(make_lhs(tmp_1518), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1519), make_compvar_primary(tmp_1520)));
}
emit_assign(make_lhs(tmp_1516), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1517), make_compvar_primary(tmp_1518)));
}

{
compvar_t *tmp_1525;
tmp_1525 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1526, *tmp_1527;
tmp_1526 = tmp_1499;
tmp_1527 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1527), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1525), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1526), make_compvar_primary(tmp_1527)));
}
start_if_cond(make_compvar_rhs(tmp_1525));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1479));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1516));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1504));
switch_if_branch();
{
compvar_t *tmp_1528;
tmp_1528 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1529, *tmp_1530;
tmp_1529 = tmp_1499;
tmp_1530 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1530), make_int_const_rhs(1));
emit_assign(make_lhs(tmp_1528), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1529), make_compvar_primary(tmp_1530)));
}
start_if_cond(make_compvar_rhs(tmp_1528));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1509));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1479));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1504));
switch_if_branch();
{
compvar_t *tmp_1531;
tmp_1531 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1532, *tmp_1533;
tmp_1532 = tmp_1499;
tmp_1533 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1533), make_int_const_rhs(2));
emit_assign(make_lhs(tmp_1531), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1532), make_compvar_primary(tmp_1533)));
}
start_if_cond(make_compvar_rhs(tmp_1531));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1504));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1479));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1516));
switch_if_branch();
{
compvar_t *tmp_1534;
tmp_1534 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1535, *tmp_1536;
tmp_1535 = tmp_1499;
tmp_1536 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1536), make_int_const_rhs(3));
emit_assign(make_lhs(tmp_1534), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1535), make_compvar_primary(tmp_1536)));
}
start_if_cond(make_compvar_rhs(tmp_1534));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1504));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1509));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1479));
switch_if_branch();
{
compvar_t *tmp_1537;
tmp_1537 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1538, *tmp_1539;
tmp_1538 = tmp_1499;
tmp_1539 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1539), make_int_const_rhs(4));
emit_assign(make_lhs(tmp_1537), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1538), make_compvar_primary(tmp_1539)));
}
start_if_cond(make_compvar_rhs(tmp_1537));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1516));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1504));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1479));
switch_if_branch();
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1479));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1504));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1509));
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
}
}
}
}
end_if_cond();
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_toxy (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1540;
for (tmp_1540 = 0; tmp_1540 < 2; ++tmp_1540)
{
switch (tmp_1540)
{
case 0 :
{
compvar_t *tmp_1541, *tmp_1542;
tmp_1541 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1543;
tmp_1543 = args[0][1];
emit_assign(make_lhs(tmp_1541), make_op_rhs(OP_COS, make_compvar_primary(tmp_1543)));
}
tmp_1542 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1540]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1541), make_compvar_primary(tmp_1542)));
}
break;
case 1 :
{
compvar_t *tmp_1544, *tmp_1545;
tmp_1544 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1546;
tmp_1546 = args[0][1];
emit_assign(make_lhs(tmp_1544), make_op_rhs(OP_SIN, make_compvar_primary(tmp_1546)));
}
tmp_1545 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1540]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1544), make_compvar_primary(tmp_1545)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_toxy_trivial (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1547;
for (tmp_1547 = 0; tmp_1547 < 2; ++tmp_1547)
{
emit_assign(make_lhs(result_tmps[tmp_1547]), make_compvar_rhs(args[0][tmp_1547]));
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tora (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
compvar_t *tmp_1548;

tmp_1548 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1549, *tmp_1550;
tmp_1549 = args[0][0];
tmp_1550 = args[0][1];
emit_assign(make_lhs(tmp_1548), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_1549), make_compvar_primary(tmp_1550)));
}

{
compvar_t *tmp_1551;
tmp_1551 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1552, *tmp_1553;
tmp_1552 = tmp_1548;
tmp_1553 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1553), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1551), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1552), make_compvar_primary(tmp_1553)));
}
start_if_cond(make_compvar_rhs(tmp_1551));
{
int tmp_1554;
for (tmp_1554 = 0; tmp_1554 < 2; ++tmp_1554)
{
switch (tmp_1554)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1554]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1554]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_1555;

tmp_1555 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1556;
tmp_1556 = compiler_make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1557, *tmp_1558;
tmp_1557 = args[0][0];
tmp_1558 = tmp_1548;
emit_assign(make_lhs(tmp_1556), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1557), make_compvar_primary(tmp_1558)));
}
emit_assign(make_lhs(tmp_1555), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_1556)));
}

emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1548));
{
compvar_t *tmp_1559;
tmp_1559 = compiler_make_temporary(TYPE_INT);
{
compvar_t *tmp_1560, *tmp_1561;
tmp_1560 = args[0][1];
tmp_1561 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1561), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1559), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1560), make_compvar_primary(tmp_1561)));
}
start_if_cond(make_compvar_rhs(tmp_1559));
{
compvar_t *tmp_1562, *tmp_1563;
tmp_1562 = compiler_make_temporary(TYPE_NIL);
{
compvar_t *tmp_1564, *tmp_1565;
tmp_1564 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1564), make_int_const_rhs(2));
tmp_1565 = compiler_make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1565), make_float_const_rhs(M_PI));
emit_assign(make_lhs(tmp_1562), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1564), make_compvar_primary(tmp_1565)));
}
tmp_1563 = tmp_1555;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1562), make_compvar_primary(tmp_1563)));
}
switch_if_branch();
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1555));
end_if_cond();
}
}
end_if_cond();
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tora_trivial (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1566;
for (tmp_1566 = 0; tmp_1566 < 2; ++tmp_1566)
{
emit_assign(make_lhs(result_tmps[tmp_1566]), make_compvar_rhs(args[0][tmp_1566]));
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rand (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1567;
for (tmp_1567 = 0; tmp_1567 < 1; ++tmp_1567)
{
switch (tmp_1567)
{
case 0 :
{
compvar_t *tmp_1568, *tmp_1569;
tmp_1568 = args[0][0];
tmp_1569 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1567]), make_op_rhs(OP_RAND, make_compvar_primary(tmp_1568), make_compvar_primary(tmp_1569)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_noise (filter_t *filter, compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = compiler_make_temporary(result[i]->type);
{
int tmp_1570;
for (tmp_1570 = 0; tmp_1570 < 1; ++tmp_1570)
{
switch (tmp_1570)
{
case 0 :
{
compvar_t *tmp_1571, *tmp_1572, *tmp_1573;
tmp_1571 = args[0][0];
tmp_1572 = args[0][1];
tmp_1573 = args[0][2];
emit_assign(make_lhs(result_tmps[tmp_1570]), make_op_rhs(OP_NOISE, make_compvar_primary(tmp_1571), make_compvar_primary(tmp_1572), make_compvar_primary(tmp_1573)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}


void
init_builtins (void)
{
register_overloaded_builtin("print", "((nil 1) (_ _))", gen_print);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (ri 2))", gen_add_ri);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (_ 1))", gen_add_ri_1);
register_overloaded_builtin("__add", "((ri 2) (_ 1) (ri 2))", gen_add_1_ri);
register_overloaded_builtin("__add", "((T 1) (T 1) (T 1))", gen_add_1);
register_overloaded_builtin("__add", "((T L) (T L) (_ 1))", gen_add_s);
register_overloaded_builtin("__add", "((T L) (T L) (T L))", gen_add_n);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (ri 2))", gen_sub_ri);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (_ 1))", gen_sub_ri_1);
register_overloaded_builtin("__sub", "((ri 2) (_ 1) (ri 2))", gen_sub_1_ri);
register_overloaded_builtin("__sub", "((T 1) (T 1) (T 1))", gen_sub_1);
register_overloaded_builtin("__sub", "((T L) (T L) (_ 1))", gen_sub_s);
register_overloaded_builtin("__sub", "((T L) (T L) (T L))", gen_sub_n);
register_overloaded_builtin("__neg", "((T L) (T L))", gen_neg);
register_overloaded_builtin("__mul", "((ri 2) (ri 2) (ri 2))", gen_mul_ri);
register_overloaded_builtin("__mul", "((ri 2) (_ 1) (ri 2))", gen_mul_1_ri);
register_overloaded_builtin("__mul", "((m2x2 4) (m2x2 4) (m2x2 4))", gen_mul_m2x2);
register_overloaded_builtin("__mul", "((m3x3 9) (m3x3 9) (m3x3 9))", gen_mul_m3x3);
register_overloaded_builtin("__mul", "((v2 2) (v2 2) (m2x2 4))", gen_mul_v2m2x2);
register_overloaded_builtin("__mul", "((v3 3) (v3 3) (m3x3 9))", gen_mul_v3m3x3);
register_overloaded_builtin("__mul", "((v2 2) (m2x2 4) (v2 2))", gen_mul_m2x2v2);
register_overloaded_builtin("__mul", "((v3 3) (m3x3 9) (v3 3))", gen_mul_m3x3v3);
register_overloaded_builtin("__mul", "((quat 4) (quat 4) (quat 4))", gen_mul_quat);
register_overloaded_builtin("__mul", "((cquat 4) (cquat 4) (cquat 4))", gen_mul_cquat);
register_overloaded_builtin("__mul", "((hyper 4) (hyper 4) (hyper 4))", gen_mul_hyper);
register_overloaded_builtin("__mul", "((T 1) (T 1) (T 1))", gen_mul_1);
register_overloaded_builtin("__mul", "((T L) (T L) (_ 1))", gen_mul_s);
register_overloaded_builtin("__mul", "((T L) (T L) (T L))", gen_mul_n);
register_overloaded_builtin("__div", "((ri 2) (ri 2) (ri 2))", gen_div_ri);
register_overloaded_builtin("__div", "((ri 2) (T 1) (ri 2))", gen_div_1_ri);
register_overloaded_builtin("__div", "((v2 2) (_ 2) (m2x2 4))", gen_div_v2m2x2);
register_overloaded_builtin("__div", "((v3 3) (_ 3) (m3x3 9))", gen_div_v3m3x3);
register_overloaded_builtin("__div", "((T 1) (T 1) (T 1))", gen_div_1);
register_overloaded_builtin("__div", "((T L) (T L) (_ 1))", gen_div_s);
register_overloaded_builtin("__div", "((T L) (T L) (T L))", gen_div_n);
register_overloaded_builtin("__mod", "((T 1) (T 1) (T 1))", gen_mod_1);
register_overloaded_builtin("__mod", "((T L) (T L) (_ 1))", gen_mod_s);
register_overloaded_builtin("__mod", "((T L) (T L) (T L))", gen_mod_n);
register_overloaded_builtin("pmod", "((T 1) (T 1) (T 1))", gen_pmod);
register_overloaded_builtin("sqrt", "((ri 2) (ri 2))", gen_sqrt_ri);
register_overloaded_builtin("sqrt", "((T 1) (T 1))", gen_sqrt_1);
register_overloaded_builtin("sum", "((nil 1) (T L))", gen_sum);
register_overloaded_builtin("dotp", "((nil 1) (T L) (T L))", gen_dotp);
register_overloaded_builtin("crossp", "((T 3) (T 3) (T 3))", gen_crossp);
register_overloaded_builtin("det", "((nil 1) (m2x2 4))", gen_det_m2x2);
register_overloaded_builtin("det", "((nil 1) (m3x3 9))", gen_det_m3x3);
register_overloaded_builtin("normalize", "((T L) (T L))", gen_normalize);
register_overloaded_builtin("abs", "((nil 1) (ri 2))", gen_abs_ri);
register_overloaded_builtin("abs", "((nil 1) (quat 4))", gen_abs_quat);
register_overloaded_builtin("abs", "((nil 1) (cquat 4))", gen_abs_cquat);
register_overloaded_builtin("abs", "((nil 1) (hyper 4))", gen_abs_hyper);
register_overloaded_builtin("abs", "((nil 1) (v2 2))", gen_abs_v2);
register_overloaded_builtin("abs", "((nil 1) (v3 3))", gen_abs_v3);
register_overloaded_builtin("abs", "((T 1) (T 1))", gen_abs_1);
register_overloaded_builtin("abs", "((T L) (T L))", gen_abs_n);
register_overloaded_builtin("deg2rad", "((nil 1) (_ 1))", gen_deg2rad);
register_overloaded_builtin("rad2deg", "((deg 1) (_ 1))", gen_rad2deg);
register_overloaded_builtin("sin", "((ri 2) (ri 2))", gen_sin_ri);
register_overloaded_builtin("sin", "((T 1) (T 1))", gen_sin);
register_overloaded_builtin("cos", "((ri 2) (ri 2))", gen_cos_ri);
register_overloaded_builtin("cos", "((T 1) (T 1))", gen_cos);
register_overloaded_builtin("tan", "((ri 2) (ri 2))", gen_tan_ri);
register_overloaded_builtin("tan", "((T 1) (T 1))", gen_tan);
register_overloaded_builtin("asin", "((ri 2) (ri 2))", gen_asin_ri);
register_overloaded_builtin("asin", "((T 1) (T 1))", gen_asin);
register_overloaded_builtin("acos", "((ri 2) (ri 2))", gen_acos_ri);
register_overloaded_builtin("acos", "((T 1) (T 1))", gen_acos);
register_overloaded_builtin("atan", "((ri 2) (ri 2))", gen_atan_ri);
register_overloaded_builtin("atan", "((T 1) (T 1))", gen_atan);
register_overloaded_builtin("atan", "((T 1) (T 1) (T 1))", gen_atan2);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (T 1))", gen_pow_ri_1);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (ri 2))", gen_pow_ri);
register_overloaded_builtin("__pow", "((ri 2) (T 1) (ri 2))", gen_pow_1_ri);
register_overloaded_builtin("__pow", "((T 1) (T 1) (T 1))", gen_pow_1);
register_overloaded_builtin("__pow", "((T L) (T L) (_ 1))", gen_pow_s);
register_overloaded_builtin("exp", "((ri 2) (ri 2))", gen_exp_ri);
register_overloaded_builtin("exp", "((T 1) (T 1))", gen_exp_1);
register_overloaded_builtin("log", "((ri 2) (ri 2))", gen_log_ri);
register_overloaded_builtin("log", "((T 1) (T 1))", gen_log_1);
register_overloaded_builtin("arg", "((nil 1) (ri 2))", gen_arg_ri);
register_overloaded_builtin("conj", "((ri 2) (ri 2))", gen_conj_ri);
register_overloaded_builtin("sinh", "((ri 2) (ri 2))", gen_sinh_ri);
register_overloaded_builtin("sinh", "((T 1) (T 1))", gen_sinh_1);
register_overloaded_builtin("cosh", "((ri 2) (ri 2))", gen_cosh_ri);
register_overloaded_builtin("cosh", "((T 1) (T 1))", gen_cosh_1);
register_overloaded_builtin("tanh", "((ri 2) (ri 2))", gen_tanh_ri);
register_overloaded_builtin("tanh", "((T 1) (T 1))", gen_tanh_1);
register_overloaded_builtin("asinh", "((ri 2) (ri 2))", gen_asinh_ri);
register_overloaded_builtin("asinh", "((T 1) (T 1))", gen_asinh_1);
register_overloaded_builtin("acosh", "((ri 2) (ri 2))", gen_acosh_ri);
register_overloaded_builtin("acosh", "((T 1) (T 1))", gen_acosh_1);
register_overloaded_builtin("atanh", "((ri 2) (ri 2))", gen_atanh_ri);
register_overloaded_builtin("atanh", "((T 1) (T 1))", gen_atanh_1);
register_overloaded_builtin("gamma", "((ri 2) (ri 2))", gen_gamma_ri);
register_overloaded_builtin("gamma", "((T 1) (T 1))", gen_gamma_1);
register_overloaded_builtin("beta", "((T 1) (T 1) (T 1))", gen_beta_1);
register_overloaded_builtin("ell_int_Kcomp", "((T 1) (T 1))", gen_ell_int_kcomp);
register_overloaded_builtin("ell_int_Ecomp", "((T 1) (T 1))", gen_ell_int_ecomp);
register_overloaded_builtin("ell_int_F", "((T 1) (T 1) (T 1))", gen_ell_int_f);
register_overloaded_builtin("ell_int_E", "((T 1) (T 1) (T 1))", gen_ell_int_e);
register_overloaded_builtin("ell_int_P", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_p);
register_overloaded_builtin("ell_int_D", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_d);
register_overloaded_builtin("ell_int_RC", "((T 1) (T 1) (T 1))", gen_ell_int_rc);
register_overloaded_builtin("ell_int_RD", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rd);
register_overloaded_builtin("ell_int_RF", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rf);
register_overloaded_builtin("ell_int_RJ", "((T 1) (T 1) (T 1) (T 1) (T 1))", gen_ell_int_rj);
register_overloaded_builtin("ell_jac_sn", "((T 1) (T 1) (T 1))", gen_ell_jac_sn_1);
register_overloaded_builtin("ell_jac_cn", "((T 1) (T 1) (T 1))", gen_ell_jac_cn_1);
register_overloaded_builtin("ell_jac_dn", "((T 1) (T 1) (T 1))", gen_ell_jac_dn_1);
register_overloaded_builtin("ell_jac_sn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_sn_ri);
register_overloaded_builtin("ell_jac_cn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_cn_ri);
register_overloaded_builtin("ell_jac_dn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_dn_ri);
register_overloaded_builtin("floor", "((T 1) (T 1))", gen_floor);
register_overloaded_builtin("ceil", "((T 1) (T 1))", gen_ceil);
register_overloaded_builtin("sign", "((T L) (T L))", gen_sign_n);
register_overloaded_builtin("min", "((T L) (T L) (T L))", gen_min_n);
register_overloaded_builtin("max", "((T L) (T L) (T L))", gen_max_n);
register_overloaded_builtin("clamp", "((T L) (T L) (T L) (T L))", gen_clamp);
register_overloaded_builtin("lerp", "((T L) (_ 1) (T L) (T L))", gen_lerp_1);
register_overloaded_builtin("lerp", "((T L) (T L) (T L) (T L))", gen_lerp_n);
register_overloaded_builtin("scale", "((T L) (T L) (T L) (T L) (T L) (T L))", gen_scale);
register_overloaded_builtin("__not", "((T 1) (T 1))", gen_not);
register_overloaded_builtin("__or", "((T 1) (T 1) (T 1))", gen_or);
register_overloaded_builtin("__and", "((T 1) (T 1) (T 1))", gen_and);
register_overloaded_builtin("__xor", "((T 1) (T 1) (T 1))", gen_xor);
register_overloaded_builtin("__equal", "((T 1) (T 1) (T 1))", gen_equal);
register_overloaded_builtin("__less", "((T 1) (T 1) (T 1))", gen_less);
register_overloaded_builtin("__greater", "((T 1) (T 1) (T 1))", gen_greater);
register_overloaded_builtin("__lessequal", "((T 1) (T 1) (T 1))", gen_lessequal);
register_overloaded_builtin("__greaterequal", "((T 1) (T 1) (T 1))", gen_greaterequal);
register_overloaded_builtin("__notequal", "((T 1) (T 1) (T 1))", gen_notequal);
register_overloaded_builtin("inintv", "((T 1) (T 1) (T 1) (T 1))", gen_inintv);
register_overloaded_builtin("__applyCurve", "((nil 1) (curve 1) (_ 1))", gen_apply_curve);
register_overloaded_builtin("__applyGradient", "((rgba 4) (gradient 1) (_ 1))", gen_apply_gradient);
register_overloaded_builtin("__origVal", "((rgba 4) (xy 2) (nil 1) (image 1))", gen_origvalxy);
register_overloaded_builtin("render", "((image 1) (image 1))", gen_render);
register_overloaded_builtin("pixelSize", "((xy 2) (image 1))", gen_pixelsize);
register_overloaded_builtin("red", "((nil 1) (rgba 4))", gen_red);
register_overloaded_builtin("green", "((nil 1) (rgba 4))", gen_green);
register_overloaded_builtin("blue", "((nil 1) (rgba 4))", gen_blue);
register_overloaded_builtin("alpha", "((nil 1) (rgba 4))", gen_alpha);
register_overloaded_builtin("gray", "((nil 1) (rgba 4))", gen_gray);
register_overloaded_builtin("rgbColor", "((rgba 4) (T 1) (T 1) (T 1))", gen_rgbcolor);
register_overloaded_builtin("rgbaColor", "((rgba 4) (T 1) (T 1) (T 1) (T 1))", gen_rgbacolor);
register_overloaded_builtin("grayColor", "((rgba 4) (T 1))", gen_graycolor);
register_overloaded_builtin("grayaColor", "((rgba 4) (T 1) (T 1))", gen_grayacolor);
register_overloaded_builtin("toHSVA", "((hsva 4) (rgba 4))", gen_tohsva);
register_overloaded_builtin("toRGBA", "((rgba 4) (hsva 4))", gen_torgba);
register_overloaded_builtin("toXY", "((xy 2) (ra 2))", gen_toxy);
register_overloaded_builtin("toXY", "((xy 2) (xy 2))", gen_toxy_trivial);
register_overloaded_builtin("toRA", "((ra 2) (xy 2))", gen_tora);
register_overloaded_builtin("toRA", "((ra 2) (ra 2))", gen_tora_trivial);
register_overloaded_builtin("rand", "((T 1) (T 1) (T 1))", gen_rand);
register_overloaded_builtin("noise", "((nil 1) (_ 3))", gen_noise);
}
