stretched filter util_ident (stretched image in)
    in(xy)
end
