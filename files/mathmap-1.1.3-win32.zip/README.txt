MathMap 1.0.1 for Windows
=========================

This is the official Windows port of the Math Map-1.1.3 plug-in for the GIMP-2.2. In accordance with the GPL, the source code for this package can be found at http://www.complang.tuwien.ac.at/schani/mathmap/, as well as new releases, updates, and references on the Mathmap language.
This package comes with no warranty of any kind, and is in fact a development release, thus, bugs are to be expected.

Installation
============

To install this package in Windows, unzip the archive named "plug-ins" to the GIMP's plug-in directory.  If you're unsure of where this is, either "C:/Program Files/GIMP-2.0/lib/gimp/2.0/plug-ins" or "C:/Documents and Settings/[YOUR USERNAME]/.gimp-2.2/plug-ins" should work.  Now, unzip the archive named "mathmap" to "C:/Documents and Settings/[YOUR USERNAME]/.gimp-2.2/".  After that, it should be installed.  Look for it under Filters>Generic>Mathmap once you're running the GIMP.

If you have any problems, concerns, etc. that you think are specific to this Windows port, I can be contacted at mr.fluffles@gmail.com.

If you are looking to report or comment on anything that has to do with Mathmap in general, and not just the Windows port, the developer of Mathmap, Mark Probst, can be contacted at schani@complang.tuwien.ac.at

Have fun!
