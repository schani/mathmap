filter util_ident (image in)
    in(xy)
end
