filter ident (image in)
  in(xy)
end

filter blur (image in, float dev: 0.01 - 0.5)
  rendered = render(ident(in));
  blurred = gaussian_blur(rendered, dev, dev);
  blurred(xy)
end
