filter completely_random (image in)
  in(xy:[rand(-X,X), rand(-Y,Y)])
end