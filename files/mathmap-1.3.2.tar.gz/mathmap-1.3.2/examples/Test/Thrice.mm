filter thrice (image in)
  in(xy) * 3
end

filter third (image in)
  in(xy) / 3
end

filter thrice_test (image in)
  third(thrice(in), xy)
end