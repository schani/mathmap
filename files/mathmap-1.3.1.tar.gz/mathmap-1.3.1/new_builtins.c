static void
gen_print (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_0;
for (tmp_0 = 0; tmp_0 < arglengths[0]; ++tmp_0)
{
{
compvar_t *tmp_1;
tmp_1 = make_temporary(TYPE_INT);
{
compvar_t *tmp_2;
tmp_2 = args[0][tmp_0];
emit_assign(make_lhs(tmp_1), make_op_rhs(OP_PRINT, make_compvar_primary(tmp_2)));
}
}
}
}
{
compvar_t *tmp_3;
tmp_3 = make_temporary(TYPE_INT);
{
emit_assign(make_lhs(tmp_3), make_op_rhs(OP_NEWLINE));
}
}
{
int tmp_4;
for (tmp_4 = 0; tmp_4 < 1; ++tmp_4)
{
switch (tmp_4)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_4]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_5;
for (tmp_5 = 0; tmp_5 < 2; ++tmp_5)
{
{
compvar_t *tmp_6, *tmp_7;
tmp_6 = args[0][tmp_5];
tmp_7 = args[1][tmp_5];
emit_assign(make_lhs(result_tmps[tmp_5]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_6), make_compvar_primary(tmp_7)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_8;
for (tmp_8 = 0; tmp_8 < 2; ++tmp_8)
{
{
compvar_t *tmp_9, *tmp_10;
tmp_9 = args[0][tmp_8];
switch (tmp_8)
{
case 0 :
tmp_10 = args[1][0];
break;
case 1 :
tmp_10 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_10), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_8]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_9), make_compvar_primary(tmp_10)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_11;
for (tmp_11 = 0; tmp_11 < 2; ++tmp_11)
{
{
compvar_t *tmp_12, *tmp_13;
tmp_12 = args[1][tmp_11];
switch (tmp_11)
{
case 0 :
tmp_13 = args[0][0];
break;
case 1 :
tmp_13 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_13), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_11]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_12), make_compvar_primary(tmp_13)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_14;
for (tmp_14 = 0; tmp_14 < 1; ++tmp_14)
{
{
compvar_t *tmp_15, *tmp_16;
tmp_15 = args[0][tmp_14];
tmp_16 = args[1][tmp_14];
emit_assign(make_lhs(result_tmps[tmp_14]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_15), make_compvar_primary(tmp_16)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_17;
for (tmp_17 = 0; tmp_17 < arglengths[0]; ++tmp_17)
{
{
compvar_t *tmp_18, *tmp_19;
tmp_18 = args[0][tmp_17];
tmp_19 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_17]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_18), make_compvar_primary(tmp_19)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_20;
for (tmp_20 = 0; tmp_20 < arglengths[0]; ++tmp_20)
{
{
compvar_t *tmp_21, *tmp_22;
tmp_21 = args[0][tmp_20];
tmp_22 = args[1][tmp_20];
emit_assign(make_lhs(result_tmps[tmp_20]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_21), make_compvar_primary(tmp_22)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_23;
for (tmp_23 = 0; tmp_23 < 2; ++tmp_23)
{
{
compvar_t *tmp_24, *tmp_25;
tmp_24 = args[0][tmp_23];
tmp_25 = args[1][tmp_23];
emit_assign(make_lhs(result_tmps[tmp_23]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_24), make_compvar_primary(tmp_25)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_26;
for (tmp_26 = 0; tmp_26 < 2; ++tmp_26)
{
{
compvar_t *tmp_27, *tmp_28;
tmp_27 = args[0][tmp_26];
switch (tmp_26)
{
case 0 :
tmp_28 = args[1][0];
break;
case 1 :
tmp_28 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_28), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_26]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_27), make_compvar_primary(tmp_28)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_29;
for (tmp_29 = 0; tmp_29 < 2; ++tmp_29)
{
{
compvar_t *tmp_30, *tmp_31;
switch (tmp_29)
{
case 0 :
tmp_30 = args[0][0];
break;
case 1 :
tmp_30 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_30), make_int_const_rhs(0));
break;
default :
assert(0);
}
tmp_31 = args[1][tmp_29];
emit_assign(make_lhs(result_tmps[tmp_29]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_30), make_compvar_primary(tmp_31)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_32;
for (tmp_32 = 0; tmp_32 < 1; ++tmp_32)
{
{
compvar_t *tmp_33, *tmp_34;
tmp_33 = args[0][tmp_32];
tmp_34 = args[1][tmp_32];
emit_assign(make_lhs(result_tmps[tmp_32]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_33), make_compvar_primary(tmp_34)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_35;
for (tmp_35 = 0; tmp_35 < arglengths[0]; ++tmp_35)
{
{
compvar_t *tmp_36, *tmp_37;
tmp_36 = args[0][tmp_35];
tmp_37 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_35]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_36), make_compvar_primary(tmp_37)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_38;
for (tmp_38 = 0; tmp_38 < arglengths[0]; ++tmp_38)
{
{
compvar_t *tmp_39, *tmp_40;
tmp_39 = args[0][tmp_38];
tmp_40 = args[1][tmp_38];
emit_assign(make_lhs(result_tmps[tmp_38]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_39), make_compvar_primary(tmp_40)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_neg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_41;
for (tmp_41 = 0; tmp_41 < arglengths[0]; ++tmp_41)
{
{
compvar_t *tmp_42;
tmp_42 = args[0][tmp_41];
emit_assign(make_lhs(result_tmps[tmp_41]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_42)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_43;
for (tmp_43 = 0; tmp_43 < 2; ++tmp_43)
{
switch (tmp_43)
{
case 0 :
{
compvar_t *tmp_44, *tmp_45;
tmp_44 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_46, *tmp_47;
tmp_46 = args[0][0];
tmp_47 = args[1][0];
emit_assign(make_lhs(tmp_44), make_op_rhs(OP_MUL, make_compvar_primary(tmp_46), make_compvar_primary(tmp_47)));
}
tmp_45 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_48, *tmp_49;
tmp_48 = args[0][1];
tmp_49 = args[1][1];
emit_assign(make_lhs(tmp_45), make_op_rhs(OP_MUL, make_compvar_primary(tmp_48), make_compvar_primary(tmp_49)));
}
emit_assign(make_lhs(result_tmps[tmp_43]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_44), make_compvar_primary(tmp_45)));
}
break;
case 1 :
{
compvar_t *tmp_50, *tmp_51;
tmp_50 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_52, *tmp_53;
tmp_52 = args[0][0];
tmp_53 = args[1][1];
emit_assign(make_lhs(tmp_50), make_op_rhs(OP_MUL, make_compvar_primary(tmp_52), make_compvar_primary(tmp_53)));
}
tmp_51 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_54, *tmp_55;
tmp_54 = args[1][0];
tmp_55 = args[0][1];
emit_assign(make_lhs(tmp_51), make_op_rhs(OP_MUL, make_compvar_primary(tmp_54), make_compvar_primary(tmp_55)));
}
emit_assign(make_lhs(result_tmps[tmp_43]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_50), make_compvar_primary(tmp_51)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_56;
for (tmp_56 = 0; tmp_56 < 2; ++tmp_56)
{
{
compvar_t *tmp_57, *tmp_58;
tmp_57 = args[0][0];
tmp_58 = args[1][tmp_56];
emit_assign(make_lhs(result_tmps[tmp_56]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_57), make_compvar_primary(tmp_58)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_59;
for (tmp_59 = 0; tmp_59 < 4; ++tmp_59)
{
switch (tmp_59)
{
case 0 :
{
compvar_t *tmp_60, *tmp_61;
tmp_60 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_62, *tmp_63;
tmp_62 = args[0][0];
tmp_63 = args[1][0];
emit_assign(make_lhs(tmp_60), make_op_rhs(OP_MUL, make_compvar_primary(tmp_62), make_compvar_primary(tmp_63)));
}
tmp_61 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_64, *tmp_65;
tmp_64 = args[0][1];
tmp_65 = args[1][2];
emit_assign(make_lhs(tmp_61), make_op_rhs(OP_MUL, make_compvar_primary(tmp_64), make_compvar_primary(tmp_65)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_60), make_compvar_primary(tmp_61)));
}
break;
case 1 :
{
compvar_t *tmp_66, *tmp_67;
tmp_66 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_68, *tmp_69;
tmp_68 = args[0][0];
tmp_69 = args[1][1];
emit_assign(make_lhs(tmp_66), make_op_rhs(OP_MUL, make_compvar_primary(tmp_68), make_compvar_primary(tmp_69)));
}
tmp_67 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_70, *tmp_71;
tmp_70 = args[0][1];
tmp_71 = args[1][3];
emit_assign(make_lhs(tmp_67), make_op_rhs(OP_MUL, make_compvar_primary(tmp_70), make_compvar_primary(tmp_71)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_66), make_compvar_primary(tmp_67)));
}
break;
case 2 :
{
compvar_t *tmp_72, *tmp_73;
tmp_72 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_74, *tmp_75;
tmp_74 = args[0][2];
tmp_75 = args[1][0];
emit_assign(make_lhs(tmp_72), make_op_rhs(OP_MUL, make_compvar_primary(tmp_74), make_compvar_primary(tmp_75)));
}
tmp_73 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_76, *tmp_77;
tmp_76 = args[0][3];
tmp_77 = args[1][2];
emit_assign(make_lhs(tmp_73), make_op_rhs(OP_MUL, make_compvar_primary(tmp_76), make_compvar_primary(tmp_77)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_72), make_compvar_primary(tmp_73)));
}
break;
case 3 :
{
compvar_t *tmp_78, *tmp_79;
tmp_78 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_80, *tmp_81;
tmp_80 = args[0][2];
tmp_81 = args[1][1];
emit_assign(make_lhs(tmp_78), make_op_rhs(OP_MUL, make_compvar_primary(tmp_80), make_compvar_primary(tmp_81)));
}
tmp_79 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_82, *tmp_83;
tmp_82 = args[0][3];
tmp_83 = args[1][3];
emit_assign(make_lhs(tmp_79), make_op_rhs(OP_MUL, make_compvar_primary(tmp_82), make_compvar_primary(tmp_83)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_78), make_compvar_primary(tmp_79)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[9];
int i;
for (i = 0; i < 9; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_84;
for (tmp_84 = 0; tmp_84 < 9; ++tmp_84)
{
switch (tmp_84)
{
case 0 :
{
compvar_t *tmp_85, *tmp_86;
tmp_85 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_87, *tmp_88;
tmp_87 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_89, *tmp_90;
tmp_89 = args[0][0];
tmp_90 = args[1][0];
emit_assign(make_lhs(tmp_87), make_op_rhs(OP_MUL, make_compvar_primary(tmp_89), make_compvar_primary(tmp_90)));
}
tmp_88 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_91, *tmp_92;
tmp_91 = args[0][1];
tmp_92 = args[1][3];
emit_assign(make_lhs(tmp_88), make_op_rhs(OP_MUL, make_compvar_primary(tmp_91), make_compvar_primary(tmp_92)));
}
emit_assign(make_lhs(tmp_85), make_op_rhs(OP_ADD, make_compvar_primary(tmp_87), make_compvar_primary(tmp_88)));
}
tmp_86 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_93, *tmp_94;
tmp_93 = args[0][2];
tmp_94 = args[1][6];
emit_assign(make_lhs(tmp_86), make_op_rhs(OP_MUL, make_compvar_primary(tmp_93), make_compvar_primary(tmp_94)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_85), make_compvar_primary(tmp_86)));
}
break;
case 1 :
{
compvar_t *tmp_95, *tmp_96;
tmp_95 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_97, *tmp_98;
tmp_97 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_99, *tmp_100;
tmp_99 = args[0][0];
tmp_100 = args[1][1];
emit_assign(make_lhs(tmp_97), make_op_rhs(OP_MUL, make_compvar_primary(tmp_99), make_compvar_primary(tmp_100)));
}
tmp_98 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_101, *tmp_102;
tmp_101 = args[0][1];
tmp_102 = args[1][4];
emit_assign(make_lhs(tmp_98), make_op_rhs(OP_MUL, make_compvar_primary(tmp_101), make_compvar_primary(tmp_102)));
}
emit_assign(make_lhs(tmp_95), make_op_rhs(OP_ADD, make_compvar_primary(tmp_97), make_compvar_primary(tmp_98)));
}
tmp_96 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_103, *tmp_104;
tmp_103 = args[0][2];
tmp_104 = args[1][7];
emit_assign(make_lhs(tmp_96), make_op_rhs(OP_MUL, make_compvar_primary(tmp_103), make_compvar_primary(tmp_104)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_95), make_compvar_primary(tmp_96)));
}
break;
case 2 :
{
compvar_t *tmp_105, *tmp_106;
tmp_105 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_107, *tmp_108;
tmp_107 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_109, *tmp_110;
tmp_109 = args[0][0];
tmp_110 = args[1][2];
emit_assign(make_lhs(tmp_107), make_op_rhs(OP_MUL, make_compvar_primary(tmp_109), make_compvar_primary(tmp_110)));
}
tmp_108 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_111, *tmp_112;
tmp_111 = args[0][1];
tmp_112 = args[1][5];
emit_assign(make_lhs(tmp_108), make_op_rhs(OP_MUL, make_compvar_primary(tmp_111), make_compvar_primary(tmp_112)));
}
emit_assign(make_lhs(tmp_105), make_op_rhs(OP_ADD, make_compvar_primary(tmp_107), make_compvar_primary(tmp_108)));
}
tmp_106 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_113, *tmp_114;
tmp_113 = args[0][2];
tmp_114 = args[1][8];
emit_assign(make_lhs(tmp_106), make_op_rhs(OP_MUL, make_compvar_primary(tmp_113), make_compvar_primary(tmp_114)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_105), make_compvar_primary(tmp_106)));
}
break;
case 3 :
{
compvar_t *tmp_115, *tmp_116;
tmp_115 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_117, *tmp_118;
tmp_117 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_119, *tmp_120;
tmp_119 = args[0][3];
tmp_120 = args[1][0];
emit_assign(make_lhs(tmp_117), make_op_rhs(OP_MUL, make_compvar_primary(tmp_119), make_compvar_primary(tmp_120)));
}
tmp_118 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_121, *tmp_122;
tmp_121 = args[0][4];
tmp_122 = args[1][3];
emit_assign(make_lhs(tmp_118), make_op_rhs(OP_MUL, make_compvar_primary(tmp_121), make_compvar_primary(tmp_122)));
}
emit_assign(make_lhs(tmp_115), make_op_rhs(OP_ADD, make_compvar_primary(tmp_117), make_compvar_primary(tmp_118)));
}
tmp_116 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_123, *tmp_124;
tmp_123 = args[0][5];
tmp_124 = args[1][6];
emit_assign(make_lhs(tmp_116), make_op_rhs(OP_MUL, make_compvar_primary(tmp_123), make_compvar_primary(tmp_124)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_115), make_compvar_primary(tmp_116)));
}
break;
case 4 :
{
compvar_t *tmp_125, *tmp_126;
tmp_125 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_127, *tmp_128;
tmp_127 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_129, *tmp_130;
tmp_129 = args[0][3];
tmp_130 = args[1][1];
emit_assign(make_lhs(tmp_127), make_op_rhs(OP_MUL, make_compvar_primary(tmp_129), make_compvar_primary(tmp_130)));
}
tmp_128 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_131, *tmp_132;
tmp_131 = args[0][4];
tmp_132 = args[1][4];
emit_assign(make_lhs(tmp_128), make_op_rhs(OP_MUL, make_compvar_primary(tmp_131), make_compvar_primary(tmp_132)));
}
emit_assign(make_lhs(tmp_125), make_op_rhs(OP_ADD, make_compvar_primary(tmp_127), make_compvar_primary(tmp_128)));
}
tmp_126 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_133, *tmp_134;
tmp_133 = args[0][5];
tmp_134 = args[1][7];
emit_assign(make_lhs(tmp_126), make_op_rhs(OP_MUL, make_compvar_primary(tmp_133), make_compvar_primary(tmp_134)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_125), make_compvar_primary(tmp_126)));
}
break;
case 5 :
{
compvar_t *tmp_135, *tmp_136;
tmp_135 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_137, *tmp_138;
tmp_137 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_139, *tmp_140;
tmp_139 = args[0][3];
tmp_140 = args[1][2];
emit_assign(make_lhs(tmp_137), make_op_rhs(OP_MUL, make_compvar_primary(tmp_139), make_compvar_primary(tmp_140)));
}
tmp_138 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_141, *tmp_142;
tmp_141 = args[0][4];
tmp_142 = args[1][5];
emit_assign(make_lhs(tmp_138), make_op_rhs(OP_MUL, make_compvar_primary(tmp_141), make_compvar_primary(tmp_142)));
}
emit_assign(make_lhs(tmp_135), make_op_rhs(OP_ADD, make_compvar_primary(tmp_137), make_compvar_primary(tmp_138)));
}
tmp_136 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_143, *tmp_144;
tmp_143 = args[0][5];
tmp_144 = args[1][8];
emit_assign(make_lhs(tmp_136), make_op_rhs(OP_MUL, make_compvar_primary(tmp_143), make_compvar_primary(tmp_144)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_135), make_compvar_primary(tmp_136)));
}
break;
case 6 :
{
compvar_t *tmp_145, *tmp_146;
tmp_145 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_147, *tmp_148;
tmp_147 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_149, *tmp_150;
tmp_149 = args[0][6];
tmp_150 = args[1][0];
emit_assign(make_lhs(tmp_147), make_op_rhs(OP_MUL, make_compvar_primary(tmp_149), make_compvar_primary(tmp_150)));
}
tmp_148 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_151, *tmp_152;
tmp_151 = args[0][7];
tmp_152 = args[1][3];
emit_assign(make_lhs(tmp_148), make_op_rhs(OP_MUL, make_compvar_primary(tmp_151), make_compvar_primary(tmp_152)));
}
emit_assign(make_lhs(tmp_145), make_op_rhs(OP_ADD, make_compvar_primary(tmp_147), make_compvar_primary(tmp_148)));
}
tmp_146 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_153, *tmp_154;
tmp_153 = args[0][8];
tmp_154 = args[1][6];
emit_assign(make_lhs(tmp_146), make_op_rhs(OP_MUL, make_compvar_primary(tmp_153), make_compvar_primary(tmp_154)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_145), make_compvar_primary(tmp_146)));
}
break;
case 7 :
{
compvar_t *tmp_155, *tmp_156;
tmp_155 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_157, *tmp_158;
tmp_157 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_159, *tmp_160;
tmp_159 = args[0][6];
tmp_160 = args[1][1];
emit_assign(make_lhs(tmp_157), make_op_rhs(OP_MUL, make_compvar_primary(tmp_159), make_compvar_primary(tmp_160)));
}
tmp_158 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_161, *tmp_162;
tmp_161 = args[0][7];
tmp_162 = args[1][4];
emit_assign(make_lhs(tmp_158), make_op_rhs(OP_MUL, make_compvar_primary(tmp_161), make_compvar_primary(tmp_162)));
}
emit_assign(make_lhs(tmp_155), make_op_rhs(OP_ADD, make_compvar_primary(tmp_157), make_compvar_primary(tmp_158)));
}
tmp_156 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_163, *tmp_164;
tmp_163 = args[0][8];
tmp_164 = args[1][7];
emit_assign(make_lhs(tmp_156), make_op_rhs(OP_MUL, make_compvar_primary(tmp_163), make_compvar_primary(tmp_164)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_155), make_compvar_primary(tmp_156)));
}
break;
case 8 :
{
compvar_t *tmp_165, *tmp_166;
tmp_165 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_167, *tmp_168;
tmp_167 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_169, *tmp_170;
tmp_169 = args[0][6];
tmp_170 = args[1][2];
emit_assign(make_lhs(tmp_167), make_op_rhs(OP_MUL, make_compvar_primary(tmp_169), make_compvar_primary(tmp_170)));
}
tmp_168 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_171, *tmp_172;
tmp_171 = args[0][7];
tmp_172 = args[1][5];
emit_assign(make_lhs(tmp_168), make_op_rhs(OP_MUL, make_compvar_primary(tmp_171), make_compvar_primary(tmp_172)));
}
emit_assign(make_lhs(tmp_165), make_op_rhs(OP_ADD, make_compvar_primary(tmp_167), make_compvar_primary(tmp_168)));
}
tmp_166 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_173, *tmp_174;
tmp_173 = args[0][8];
tmp_174 = args[1][8];
emit_assign(make_lhs(tmp_166), make_op_rhs(OP_MUL, make_compvar_primary(tmp_173), make_compvar_primary(tmp_174)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_165), make_compvar_primary(tmp_166)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 9; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_175;
for (tmp_175 = 0; tmp_175 < 2; ++tmp_175)
{
switch (tmp_175)
{
case 0 :
{
compvar_t *tmp_176, *tmp_177;
tmp_176 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_178, *tmp_179;
tmp_178 = args[0][0];
tmp_179 = args[1][0];
emit_assign(make_lhs(tmp_176), make_op_rhs(OP_MUL, make_compvar_primary(tmp_178), make_compvar_primary(tmp_179)));
}
tmp_177 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_180, *tmp_181;
tmp_180 = args[0][1];
tmp_181 = args[1][2];
emit_assign(make_lhs(tmp_177), make_op_rhs(OP_MUL, make_compvar_primary(tmp_180), make_compvar_primary(tmp_181)));
}
emit_assign(make_lhs(result_tmps[tmp_175]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_176), make_compvar_primary(tmp_177)));
}
break;
case 1 :
{
compvar_t *tmp_182, *tmp_183;
tmp_182 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_184, *tmp_185;
tmp_184 = args[0][0];
tmp_185 = args[1][1];
emit_assign(make_lhs(tmp_182), make_op_rhs(OP_MUL, make_compvar_primary(tmp_184), make_compvar_primary(tmp_185)));
}
tmp_183 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_186, *tmp_187;
tmp_186 = args[0][1];
tmp_187 = args[1][3];
emit_assign(make_lhs(tmp_183), make_op_rhs(OP_MUL, make_compvar_primary(tmp_186), make_compvar_primary(tmp_187)));
}
emit_assign(make_lhs(result_tmps[tmp_175]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_182), make_compvar_primary(tmp_183)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_188;
for (tmp_188 = 0; tmp_188 < 3; ++tmp_188)
{
switch (tmp_188)
{
case 0 :
{
compvar_t *tmp_189, *tmp_190;
tmp_189 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_191, *tmp_192;
tmp_191 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_193, *tmp_194;
tmp_193 = args[0][0];
tmp_194 = args[1][0];
emit_assign(make_lhs(tmp_191), make_op_rhs(OP_MUL, make_compvar_primary(tmp_193), make_compvar_primary(tmp_194)));
}
tmp_192 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_195, *tmp_196;
tmp_195 = args[0][1];
tmp_196 = args[1][3];
emit_assign(make_lhs(tmp_192), make_op_rhs(OP_MUL, make_compvar_primary(tmp_195), make_compvar_primary(tmp_196)));
}
emit_assign(make_lhs(tmp_189), make_op_rhs(OP_ADD, make_compvar_primary(tmp_191), make_compvar_primary(tmp_192)));
}
tmp_190 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_197, *tmp_198;
tmp_197 = args[0][2];
tmp_198 = args[1][6];
emit_assign(make_lhs(tmp_190), make_op_rhs(OP_MUL, make_compvar_primary(tmp_197), make_compvar_primary(tmp_198)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_189), make_compvar_primary(tmp_190)));
}
break;
case 1 :
{
compvar_t *tmp_199, *tmp_200;
tmp_199 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_201, *tmp_202;
tmp_201 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_203, *tmp_204;
tmp_203 = args[0][0];
tmp_204 = args[1][1];
emit_assign(make_lhs(tmp_201), make_op_rhs(OP_MUL, make_compvar_primary(tmp_203), make_compvar_primary(tmp_204)));
}
tmp_202 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_205, *tmp_206;
tmp_205 = args[0][1];
tmp_206 = args[1][4];
emit_assign(make_lhs(tmp_202), make_op_rhs(OP_MUL, make_compvar_primary(tmp_205), make_compvar_primary(tmp_206)));
}
emit_assign(make_lhs(tmp_199), make_op_rhs(OP_ADD, make_compvar_primary(tmp_201), make_compvar_primary(tmp_202)));
}
tmp_200 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_207, *tmp_208;
tmp_207 = args[0][2];
tmp_208 = args[1][7];
emit_assign(make_lhs(tmp_200), make_op_rhs(OP_MUL, make_compvar_primary(tmp_207), make_compvar_primary(tmp_208)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_199), make_compvar_primary(tmp_200)));
}
break;
case 2 :
{
compvar_t *tmp_209, *tmp_210;
tmp_209 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_211, *tmp_212;
tmp_211 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_213, *tmp_214;
tmp_213 = args[0][0];
tmp_214 = args[1][2];
emit_assign(make_lhs(tmp_211), make_op_rhs(OP_MUL, make_compvar_primary(tmp_213), make_compvar_primary(tmp_214)));
}
tmp_212 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_215, *tmp_216;
tmp_215 = args[0][1];
tmp_216 = args[1][5];
emit_assign(make_lhs(tmp_212), make_op_rhs(OP_MUL, make_compvar_primary(tmp_215), make_compvar_primary(tmp_216)));
}
emit_assign(make_lhs(tmp_209), make_op_rhs(OP_ADD, make_compvar_primary(tmp_211), make_compvar_primary(tmp_212)));
}
tmp_210 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_217, *tmp_218;
tmp_217 = args[0][2];
tmp_218 = args[1][8];
emit_assign(make_lhs(tmp_210), make_op_rhs(OP_MUL, make_compvar_primary(tmp_217), make_compvar_primary(tmp_218)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_209), make_compvar_primary(tmp_210)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m2x2v2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_219;
for (tmp_219 = 0; tmp_219 < 2; ++tmp_219)
{
switch (tmp_219)
{
case 0 :
{
compvar_t *tmp_220, *tmp_221;
tmp_220 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_222, *tmp_223;
tmp_222 = args[0][0];
tmp_223 = args[1][0];
emit_assign(make_lhs(tmp_220), make_op_rhs(OP_MUL, make_compvar_primary(tmp_222), make_compvar_primary(tmp_223)));
}
tmp_221 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_224, *tmp_225;
tmp_224 = args[0][1];
tmp_225 = args[1][1];
emit_assign(make_lhs(tmp_221), make_op_rhs(OP_MUL, make_compvar_primary(tmp_224), make_compvar_primary(tmp_225)));
}
emit_assign(make_lhs(result_tmps[tmp_219]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_220), make_compvar_primary(tmp_221)));
}
break;
case 1 :
{
compvar_t *tmp_226, *tmp_227;
tmp_226 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_228, *tmp_229;
tmp_228 = args[0][2];
tmp_229 = args[1][0];
emit_assign(make_lhs(tmp_226), make_op_rhs(OP_MUL, make_compvar_primary(tmp_228), make_compvar_primary(tmp_229)));
}
tmp_227 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_230, *tmp_231;
tmp_230 = args[0][3];
tmp_231 = args[1][1];
emit_assign(make_lhs(tmp_227), make_op_rhs(OP_MUL, make_compvar_primary(tmp_230), make_compvar_primary(tmp_231)));
}
emit_assign(make_lhs(result_tmps[tmp_219]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_226), make_compvar_primary(tmp_227)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m3x3v3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_232;
for (tmp_232 = 0; tmp_232 < 3; ++tmp_232)
{
switch (tmp_232)
{
case 0 :
{
compvar_t *tmp_233, *tmp_234;
tmp_233 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_235, *tmp_236;
tmp_235 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_237, *tmp_238;
tmp_237 = args[0][0];
tmp_238 = args[1][0];
emit_assign(make_lhs(tmp_235), make_op_rhs(OP_MUL, make_compvar_primary(tmp_237), make_compvar_primary(tmp_238)));
}
tmp_236 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_239, *tmp_240;
tmp_239 = args[0][1];
tmp_240 = args[1][1];
emit_assign(make_lhs(tmp_236), make_op_rhs(OP_MUL, make_compvar_primary(tmp_239), make_compvar_primary(tmp_240)));
}
emit_assign(make_lhs(tmp_233), make_op_rhs(OP_ADD, make_compvar_primary(tmp_235), make_compvar_primary(tmp_236)));
}
tmp_234 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_241, *tmp_242;
tmp_241 = args[0][2];
tmp_242 = args[1][2];
emit_assign(make_lhs(tmp_234), make_op_rhs(OP_MUL, make_compvar_primary(tmp_241), make_compvar_primary(tmp_242)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_233), make_compvar_primary(tmp_234)));
}
break;
case 1 :
{
compvar_t *tmp_243, *tmp_244;
tmp_243 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_245, *tmp_246;
tmp_245 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_247, *tmp_248;
tmp_247 = args[0][3];
tmp_248 = args[1][0];
emit_assign(make_lhs(tmp_245), make_op_rhs(OP_MUL, make_compvar_primary(tmp_247), make_compvar_primary(tmp_248)));
}
tmp_246 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_249, *tmp_250;
tmp_249 = args[0][4];
tmp_250 = args[1][1];
emit_assign(make_lhs(tmp_246), make_op_rhs(OP_MUL, make_compvar_primary(tmp_249), make_compvar_primary(tmp_250)));
}
emit_assign(make_lhs(tmp_243), make_op_rhs(OP_ADD, make_compvar_primary(tmp_245), make_compvar_primary(tmp_246)));
}
tmp_244 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_251, *tmp_252;
tmp_251 = args[0][5];
tmp_252 = args[1][2];
emit_assign(make_lhs(tmp_244), make_op_rhs(OP_MUL, make_compvar_primary(tmp_251), make_compvar_primary(tmp_252)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_243), make_compvar_primary(tmp_244)));
}
break;
case 2 :
{
compvar_t *tmp_253, *tmp_254;
tmp_253 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_255, *tmp_256;
tmp_255 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_257, *tmp_258;
tmp_257 = args[0][6];
tmp_258 = args[1][0];
emit_assign(make_lhs(tmp_255), make_op_rhs(OP_MUL, make_compvar_primary(tmp_257), make_compvar_primary(tmp_258)));
}
tmp_256 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_259, *tmp_260;
tmp_259 = args[0][7];
tmp_260 = args[1][1];
emit_assign(make_lhs(tmp_256), make_op_rhs(OP_MUL, make_compvar_primary(tmp_259), make_compvar_primary(tmp_260)));
}
emit_assign(make_lhs(tmp_253), make_op_rhs(OP_ADD, make_compvar_primary(tmp_255), make_compvar_primary(tmp_256)));
}
tmp_254 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_261, *tmp_262;
tmp_261 = args[0][8];
tmp_262 = args[1][2];
emit_assign(make_lhs(tmp_254), make_op_rhs(OP_MUL, make_compvar_primary(tmp_261), make_compvar_primary(tmp_262)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_253), make_compvar_primary(tmp_254)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_quat (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_263;
for (tmp_263 = 0; tmp_263 < 4; ++tmp_263)
{
switch (tmp_263)
{
case 0 :
{
compvar_t *tmp_264, *tmp_265;
tmp_264 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_266, *tmp_267;
tmp_266 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_268, *tmp_269;
tmp_268 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_270, *tmp_271;
tmp_270 = args[0][0];
tmp_271 = args[1][0];
emit_assign(make_lhs(tmp_268), make_op_rhs(OP_MUL, make_compvar_primary(tmp_270), make_compvar_primary(tmp_271)));
}
tmp_269 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_272;
tmp_272 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_273, *tmp_274;
tmp_273 = args[0][1];
tmp_274 = args[1][1];
emit_assign(make_lhs(tmp_272), make_op_rhs(OP_MUL, make_compvar_primary(tmp_273), make_compvar_primary(tmp_274)));
}
emit_assign(make_lhs(tmp_269), make_op_rhs(OP_NEG, make_compvar_primary(tmp_272)));
}
emit_assign(make_lhs(tmp_266), make_op_rhs(OP_ADD, make_compvar_primary(tmp_268), make_compvar_primary(tmp_269)));
}
tmp_267 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_275;
tmp_275 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_276, *tmp_277;
tmp_276 = args[0][2];
tmp_277 = args[1][2];
emit_assign(make_lhs(tmp_275), make_op_rhs(OP_MUL, make_compvar_primary(tmp_276), make_compvar_primary(tmp_277)));
}
emit_assign(make_lhs(tmp_267), make_op_rhs(OP_NEG, make_compvar_primary(tmp_275)));
}
emit_assign(make_lhs(tmp_264), make_op_rhs(OP_ADD, make_compvar_primary(tmp_266), make_compvar_primary(tmp_267)));
}
tmp_265 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_278;
tmp_278 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_279, *tmp_280;
tmp_279 = args[0][3];
tmp_280 = args[1][3];
emit_assign(make_lhs(tmp_278), make_op_rhs(OP_MUL, make_compvar_primary(tmp_279), make_compvar_primary(tmp_280)));
}
emit_assign(make_lhs(tmp_265), make_op_rhs(OP_NEG, make_compvar_primary(tmp_278)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_264), make_compvar_primary(tmp_265)));
}
break;
case 1 :
{
compvar_t *tmp_281, *tmp_282;
tmp_281 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_283, *tmp_284;
tmp_283 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_285, *tmp_286;
tmp_285 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_287, *tmp_288;
tmp_287 = args[0][0];
tmp_288 = args[1][1];
emit_assign(make_lhs(tmp_285), make_op_rhs(OP_MUL, make_compvar_primary(tmp_287), make_compvar_primary(tmp_288)));
}
tmp_286 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_289, *tmp_290;
tmp_289 = args[0][1];
tmp_290 = args[1][0];
emit_assign(make_lhs(tmp_286), make_op_rhs(OP_MUL, make_compvar_primary(tmp_289), make_compvar_primary(tmp_290)));
}
emit_assign(make_lhs(tmp_283), make_op_rhs(OP_ADD, make_compvar_primary(tmp_285), make_compvar_primary(tmp_286)));
}
tmp_284 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_291, *tmp_292;
tmp_291 = args[0][2];
tmp_292 = args[1][3];
emit_assign(make_lhs(tmp_284), make_op_rhs(OP_MUL, make_compvar_primary(tmp_291), make_compvar_primary(tmp_292)));
}
emit_assign(make_lhs(tmp_281), make_op_rhs(OP_ADD, make_compvar_primary(tmp_283), make_compvar_primary(tmp_284)));
}
tmp_282 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_293;
tmp_293 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_294, *tmp_295;
tmp_294 = args[0][3];
tmp_295 = args[1][2];
emit_assign(make_lhs(tmp_293), make_op_rhs(OP_MUL, make_compvar_primary(tmp_294), make_compvar_primary(tmp_295)));
}
emit_assign(make_lhs(tmp_282), make_op_rhs(OP_NEG, make_compvar_primary(tmp_293)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_281), make_compvar_primary(tmp_282)));
}
break;
case 2 :
{
compvar_t *tmp_296, *tmp_297;
tmp_296 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_298, *tmp_299;
tmp_298 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_300, *tmp_301;
tmp_300 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_302, *tmp_303;
tmp_302 = args[0][0];
tmp_303 = args[1][2];
emit_assign(make_lhs(tmp_300), make_op_rhs(OP_MUL, make_compvar_primary(tmp_302), make_compvar_primary(tmp_303)));
}
tmp_301 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_304, *tmp_305;
tmp_304 = args[0][2];
tmp_305 = args[1][0];
emit_assign(make_lhs(tmp_301), make_op_rhs(OP_MUL, make_compvar_primary(tmp_304), make_compvar_primary(tmp_305)));
}
emit_assign(make_lhs(tmp_298), make_op_rhs(OP_ADD, make_compvar_primary(tmp_300), make_compvar_primary(tmp_301)));
}
tmp_299 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_306;
tmp_306 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_307, *tmp_308;
tmp_307 = args[0][1];
tmp_308 = args[1][3];
emit_assign(make_lhs(tmp_306), make_op_rhs(OP_MUL, make_compvar_primary(tmp_307), make_compvar_primary(tmp_308)));
}
emit_assign(make_lhs(tmp_299), make_op_rhs(OP_NEG, make_compvar_primary(tmp_306)));
}
emit_assign(make_lhs(tmp_296), make_op_rhs(OP_ADD, make_compvar_primary(tmp_298), make_compvar_primary(tmp_299)));
}
tmp_297 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_309, *tmp_310;
tmp_309 = args[0][3];
tmp_310 = args[1][1];
emit_assign(make_lhs(tmp_297), make_op_rhs(OP_MUL, make_compvar_primary(tmp_309), make_compvar_primary(tmp_310)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_296), make_compvar_primary(tmp_297)));
}
break;
case 3 :
{
compvar_t *tmp_311, *tmp_312;
tmp_311 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_313, *tmp_314;
tmp_313 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_315, *tmp_316;
tmp_315 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_317, *tmp_318;
tmp_317 = args[0][0];
tmp_318 = args[1][3];
emit_assign(make_lhs(tmp_315), make_op_rhs(OP_MUL, make_compvar_primary(tmp_317), make_compvar_primary(tmp_318)));
}
tmp_316 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_319, *tmp_320;
tmp_319 = args[0][3];
tmp_320 = args[1][0];
emit_assign(make_lhs(tmp_316), make_op_rhs(OP_MUL, make_compvar_primary(tmp_319), make_compvar_primary(tmp_320)));
}
emit_assign(make_lhs(tmp_313), make_op_rhs(OP_ADD, make_compvar_primary(tmp_315), make_compvar_primary(tmp_316)));
}
tmp_314 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_321, *tmp_322;
tmp_321 = args[0][1];
tmp_322 = args[1][2];
emit_assign(make_lhs(tmp_314), make_op_rhs(OP_MUL, make_compvar_primary(tmp_321), make_compvar_primary(tmp_322)));
}
emit_assign(make_lhs(tmp_311), make_op_rhs(OP_ADD, make_compvar_primary(tmp_313), make_compvar_primary(tmp_314)));
}
tmp_312 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_323;
tmp_323 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_324, *tmp_325;
tmp_324 = args[0][2];
tmp_325 = args[1][1];
emit_assign(make_lhs(tmp_323), make_op_rhs(OP_MUL, make_compvar_primary(tmp_324), make_compvar_primary(tmp_325)));
}
emit_assign(make_lhs(tmp_312), make_op_rhs(OP_NEG, make_compvar_primary(tmp_323)));
}
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_311), make_compvar_primary(tmp_312)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_cquat (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_326;
for (tmp_326 = 0; tmp_326 < 4; ++tmp_326)
{
switch (tmp_326)
{
case 0 :
{
compvar_t *tmp_327, *tmp_328;
tmp_327 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_329, *tmp_330;
tmp_329 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_331, *tmp_332;
tmp_331 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_333, *tmp_334;
tmp_333 = args[0][0];
tmp_334 = args[1][0];
emit_assign(make_lhs(tmp_331), make_op_rhs(OP_MUL, make_compvar_primary(tmp_333), make_compvar_primary(tmp_334)));
}
tmp_332 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_335;
tmp_335 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_336, *tmp_337;
tmp_336 = args[0][1];
tmp_337 = args[1][1];
emit_assign(make_lhs(tmp_335), make_op_rhs(OP_MUL, make_compvar_primary(tmp_336), make_compvar_primary(tmp_337)));
}
emit_assign(make_lhs(tmp_332), make_op_rhs(OP_NEG, make_compvar_primary(tmp_335)));
}
emit_assign(make_lhs(tmp_329), make_op_rhs(OP_ADD, make_compvar_primary(tmp_331), make_compvar_primary(tmp_332)));
}
tmp_330 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_338, *tmp_339;
tmp_338 = args[0][2];
tmp_339 = args[1][2];
emit_assign(make_lhs(tmp_330), make_op_rhs(OP_MUL, make_compvar_primary(tmp_338), make_compvar_primary(tmp_339)));
}
emit_assign(make_lhs(tmp_327), make_op_rhs(OP_ADD, make_compvar_primary(tmp_329), make_compvar_primary(tmp_330)));
}
tmp_328 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_340, *tmp_341;
tmp_340 = args[0][3];
tmp_341 = args[1][3];
emit_assign(make_lhs(tmp_328), make_op_rhs(OP_MUL, make_compvar_primary(tmp_340), make_compvar_primary(tmp_341)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_327), make_compvar_primary(tmp_328)));
}
break;
case 1 :
{
compvar_t *tmp_342, *tmp_343;
tmp_342 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_344, *tmp_345;
tmp_344 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_346, *tmp_347;
tmp_346 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_348, *tmp_349;
tmp_348 = args[0][0];
tmp_349 = args[1][1];
emit_assign(make_lhs(tmp_346), make_op_rhs(OP_MUL, make_compvar_primary(tmp_348), make_compvar_primary(tmp_349)));
}
tmp_347 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_350, *tmp_351;
tmp_350 = args[0][1];
tmp_351 = args[1][0];
emit_assign(make_lhs(tmp_347), make_op_rhs(OP_MUL, make_compvar_primary(tmp_350), make_compvar_primary(tmp_351)));
}
emit_assign(make_lhs(tmp_344), make_op_rhs(OP_ADD, make_compvar_primary(tmp_346), make_compvar_primary(tmp_347)));
}
tmp_345 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_352, *tmp_353;
tmp_352 = args[0][2];
tmp_353 = args[1][3];
emit_assign(make_lhs(tmp_345), make_op_rhs(OP_MUL, make_compvar_primary(tmp_352), make_compvar_primary(tmp_353)));
}
emit_assign(make_lhs(tmp_342), make_op_rhs(OP_ADD, make_compvar_primary(tmp_344), make_compvar_primary(tmp_345)));
}
tmp_343 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_354, *tmp_355;
tmp_354 = args[0][3];
tmp_355 = args[1][2];
emit_assign(make_lhs(tmp_343), make_op_rhs(OP_MUL, make_compvar_primary(tmp_354), make_compvar_primary(tmp_355)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_342), make_compvar_primary(tmp_343)));
}
break;
case 2 :
{
compvar_t *tmp_356, *tmp_357;
tmp_356 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_358, *tmp_359;
tmp_358 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_360, *tmp_361;
tmp_360 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_362, *tmp_363;
tmp_362 = args[0][0];
tmp_363 = args[1][2];
emit_assign(make_lhs(tmp_360), make_op_rhs(OP_MUL, make_compvar_primary(tmp_362), make_compvar_primary(tmp_363)));
}
tmp_361 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_364, *tmp_365;
tmp_364 = args[0][2];
tmp_365 = args[1][0];
emit_assign(make_lhs(tmp_361), make_op_rhs(OP_MUL, make_compvar_primary(tmp_364), make_compvar_primary(tmp_365)));
}
emit_assign(make_lhs(tmp_358), make_op_rhs(OP_ADD, make_compvar_primary(tmp_360), make_compvar_primary(tmp_361)));
}
tmp_359 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_366;
tmp_366 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_367, *tmp_368;
tmp_367 = args[0][1];
tmp_368 = args[1][3];
emit_assign(make_lhs(tmp_366), make_op_rhs(OP_MUL, make_compvar_primary(tmp_367), make_compvar_primary(tmp_368)));
}
emit_assign(make_lhs(tmp_359), make_op_rhs(OP_NEG, make_compvar_primary(tmp_366)));
}
emit_assign(make_lhs(tmp_356), make_op_rhs(OP_ADD, make_compvar_primary(tmp_358), make_compvar_primary(tmp_359)));
}
tmp_357 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_369;
tmp_369 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_370, *tmp_371;
tmp_370 = args[0][3];
tmp_371 = args[1][1];
emit_assign(make_lhs(tmp_369), make_op_rhs(OP_MUL, make_compvar_primary(tmp_370), make_compvar_primary(tmp_371)));
}
emit_assign(make_lhs(tmp_357), make_op_rhs(OP_NEG, make_compvar_primary(tmp_369)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_356), make_compvar_primary(tmp_357)));
}
break;
case 3 :
{
compvar_t *tmp_372, *tmp_373;
tmp_372 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_374, *tmp_375;
tmp_374 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_376, *tmp_377;
tmp_376 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_378, *tmp_379;
tmp_378 = args[0][0];
tmp_379 = args[1][3];
emit_assign(make_lhs(tmp_376), make_op_rhs(OP_MUL, make_compvar_primary(tmp_378), make_compvar_primary(tmp_379)));
}
tmp_377 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_380, *tmp_381;
tmp_380 = args[0][3];
tmp_381 = args[1][0];
emit_assign(make_lhs(tmp_377), make_op_rhs(OP_MUL, make_compvar_primary(tmp_380), make_compvar_primary(tmp_381)));
}
emit_assign(make_lhs(tmp_374), make_op_rhs(OP_ADD, make_compvar_primary(tmp_376), make_compvar_primary(tmp_377)));
}
tmp_375 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_382;
tmp_382 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_383, *tmp_384;
tmp_383 = args[0][1];
tmp_384 = args[1][2];
emit_assign(make_lhs(tmp_382), make_op_rhs(OP_MUL, make_compvar_primary(tmp_383), make_compvar_primary(tmp_384)));
}
emit_assign(make_lhs(tmp_375), make_op_rhs(OP_NEG, make_compvar_primary(tmp_382)));
}
emit_assign(make_lhs(tmp_372), make_op_rhs(OP_ADD, make_compvar_primary(tmp_374), make_compvar_primary(tmp_375)));
}
tmp_373 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_385;
tmp_385 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_386, *tmp_387;
tmp_386 = args[0][2];
tmp_387 = args[1][1];
emit_assign(make_lhs(tmp_385), make_op_rhs(OP_MUL, make_compvar_primary(tmp_386), make_compvar_primary(tmp_387)));
}
emit_assign(make_lhs(tmp_373), make_op_rhs(OP_NEG, make_compvar_primary(tmp_385)));
}
emit_assign(make_lhs(result_tmps[tmp_326]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_372), make_compvar_primary(tmp_373)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_hyper (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_388;
for (tmp_388 = 0; tmp_388 < 4; ++tmp_388)
{
switch (tmp_388)
{
case 0 :
{
compvar_t *tmp_389, *tmp_390;
tmp_389 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_391, *tmp_392;
tmp_391 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_393, *tmp_394;
tmp_393 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_395, *tmp_396;
tmp_395 = args[0][0];
tmp_396 = args[1][0];
emit_assign(make_lhs(tmp_393), make_op_rhs(OP_MUL, make_compvar_primary(tmp_395), make_compvar_primary(tmp_396)));
}
tmp_394 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_397;
tmp_397 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_398, *tmp_399;
tmp_398 = args[0][1];
tmp_399 = args[1][1];
emit_assign(make_lhs(tmp_397), make_op_rhs(OP_MUL, make_compvar_primary(tmp_398), make_compvar_primary(tmp_399)));
}
emit_assign(make_lhs(tmp_394), make_op_rhs(OP_NEG, make_compvar_primary(tmp_397)));
}
emit_assign(make_lhs(tmp_391), make_op_rhs(OP_ADD, make_compvar_primary(tmp_393), make_compvar_primary(tmp_394)));
}
tmp_392 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_400;
tmp_400 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_401, *tmp_402;
tmp_401 = args[0][2];
tmp_402 = args[1][2];
emit_assign(make_lhs(tmp_400), make_op_rhs(OP_MUL, make_compvar_primary(tmp_401), make_compvar_primary(tmp_402)));
}
emit_assign(make_lhs(tmp_392), make_op_rhs(OP_NEG, make_compvar_primary(tmp_400)));
}
emit_assign(make_lhs(tmp_389), make_op_rhs(OP_ADD, make_compvar_primary(tmp_391), make_compvar_primary(tmp_392)));
}
tmp_390 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_403, *tmp_404;
tmp_403 = args[0][3];
tmp_404 = args[1][3];
emit_assign(make_lhs(tmp_390), make_op_rhs(OP_MUL, make_compvar_primary(tmp_403), make_compvar_primary(tmp_404)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_389), make_compvar_primary(tmp_390)));
}
break;
case 1 :
{
compvar_t *tmp_405, *tmp_406;
tmp_405 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_407, *tmp_408;
tmp_407 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_409, *tmp_410;
tmp_409 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_411, *tmp_412;
tmp_411 = args[0][0];
tmp_412 = args[1][1];
emit_assign(make_lhs(tmp_409), make_op_rhs(OP_MUL, make_compvar_primary(tmp_411), make_compvar_primary(tmp_412)));
}
tmp_410 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_413, *tmp_414;
tmp_413 = args[0][1];
tmp_414 = args[1][0];
emit_assign(make_lhs(tmp_410), make_op_rhs(OP_MUL, make_compvar_primary(tmp_413), make_compvar_primary(tmp_414)));
}
emit_assign(make_lhs(tmp_407), make_op_rhs(OP_ADD, make_compvar_primary(tmp_409), make_compvar_primary(tmp_410)));
}
tmp_408 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_415;
tmp_415 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_416, *tmp_417;
tmp_416 = args[0][2];
tmp_417 = args[1][3];
emit_assign(make_lhs(tmp_415), make_op_rhs(OP_MUL, make_compvar_primary(tmp_416), make_compvar_primary(tmp_417)));
}
emit_assign(make_lhs(tmp_408), make_op_rhs(OP_NEG, make_compvar_primary(tmp_415)));
}
emit_assign(make_lhs(tmp_405), make_op_rhs(OP_ADD, make_compvar_primary(tmp_407), make_compvar_primary(tmp_408)));
}
tmp_406 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_418;
tmp_418 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_419, *tmp_420;
tmp_419 = args[0][3];
tmp_420 = args[1][2];
emit_assign(make_lhs(tmp_418), make_op_rhs(OP_MUL, make_compvar_primary(tmp_419), make_compvar_primary(tmp_420)));
}
emit_assign(make_lhs(tmp_406), make_op_rhs(OP_NEG, make_compvar_primary(tmp_418)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_405), make_compvar_primary(tmp_406)));
}
break;
case 2 :
{
compvar_t *tmp_421, *tmp_422;
tmp_421 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_423, *tmp_424;
tmp_423 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_425, *tmp_426;
tmp_425 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_427, *tmp_428;
tmp_427 = args[0][0];
tmp_428 = args[1][2];
emit_assign(make_lhs(tmp_425), make_op_rhs(OP_MUL, make_compvar_primary(tmp_427), make_compvar_primary(tmp_428)));
}
tmp_426 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_429, *tmp_430;
tmp_429 = args[0][2];
tmp_430 = args[1][0];
emit_assign(make_lhs(tmp_426), make_op_rhs(OP_MUL, make_compvar_primary(tmp_429), make_compvar_primary(tmp_430)));
}
emit_assign(make_lhs(tmp_423), make_op_rhs(OP_ADD, make_compvar_primary(tmp_425), make_compvar_primary(tmp_426)));
}
tmp_424 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_431;
tmp_431 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_432, *tmp_433;
tmp_432 = args[0][1];
tmp_433 = args[1][3];
emit_assign(make_lhs(tmp_431), make_op_rhs(OP_MUL, make_compvar_primary(tmp_432), make_compvar_primary(tmp_433)));
}
emit_assign(make_lhs(tmp_424), make_op_rhs(OP_NEG, make_compvar_primary(tmp_431)));
}
emit_assign(make_lhs(tmp_421), make_op_rhs(OP_ADD, make_compvar_primary(tmp_423), make_compvar_primary(tmp_424)));
}
tmp_422 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_434;
tmp_434 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_435, *tmp_436;
tmp_435 = args[0][3];
tmp_436 = args[1][1];
emit_assign(make_lhs(tmp_434), make_op_rhs(OP_MUL, make_compvar_primary(tmp_435), make_compvar_primary(tmp_436)));
}
emit_assign(make_lhs(tmp_422), make_op_rhs(OP_NEG, make_compvar_primary(tmp_434)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_421), make_compvar_primary(tmp_422)));
}
break;
case 3 :
{
compvar_t *tmp_437, *tmp_438;
tmp_437 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_439, *tmp_440;
tmp_439 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_441, *tmp_442;
tmp_441 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_443, *tmp_444;
tmp_443 = args[0][0];
tmp_444 = args[1][3];
emit_assign(make_lhs(tmp_441), make_op_rhs(OP_MUL, make_compvar_primary(tmp_443), make_compvar_primary(tmp_444)));
}
tmp_442 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_445, *tmp_446;
tmp_445 = args[0][3];
tmp_446 = args[1][0];
emit_assign(make_lhs(tmp_442), make_op_rhs(OP_MUL, make_compvar_primary(tmp_445), make_compvar_primary(tmp_446)));
}
emit_assign(make_lhs(tmp_439), make_op_rhs(OP_ADD, make_compvar_primary(tmp_441), make_compvar_primary(tmp_442)));
}
tmp_440 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_447, *tmp_448;
tmp_447 = args[0][1];
tmp_448 = args[1][2];
emit_assign(make_lhs(tmp_440), make_op_rhs(OP_MUL, make_compvar_primary(tmp_447), make_compvar_primary(tmp_448)));
}
emit_assign(make_lhs(tmp_437), make_op_rhs(OP_ADD, make_compvar_primary(tmp_439), make_compvar_primary(tmp_440)));
}
tmp_438 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_449, *tmp_450;
tmp_449 = args[0][2];
tmp_450 = args[1][1];
emit_assign(make_lhs(tmp_438), make_op_rhs(OP_MUL, make_compvar_primary(tmp_449), make_compvar_primary(tmp_450)));
}
emit_assign(make_lhs(result_tmps[tmp_388]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_437), make_compvar_primary(tmp_438)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_451;
for (tmp_451 = 0; tmp_451 < 1; ++tmp_451)
{
switch (tmp_451)
{
case 0 :
{
compvar_t *tmp_452, *tmp_453;
tmp_452 = args[0][0];
tmp_453 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_451]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_452), make_compvar_primary(tmp_453)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_454;
for (tmp_454 = 0; tmp_454 < arglengths[0]; ++tmp_454)
{
{
compvar_t *tmp_455, *tmp_456;
tmp_455 = args[0][tmp_454];
tmp_456 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_454]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_455), make_compvar_primary(tmp_456)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_457;
for (tmp_457 = 0; tmp_457 < arglengths[0]; ++tmp_457)
{
{
compvar_t *tmp_458, *tmp_459;
tmp_458 = args[0][tmp_457];
tmp_459 = args[1][tmp_457];
emit_assign(make_lhs(result_tmps[tmp_457]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_458), make_compvar_primary(tmp_459)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_460;
tmp_460 = make_temporary(TYPE_INT);
{
compvar_t *tmp_461, *tmp_462;
tmp_461 = args[1][0];
tmp_462 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_462), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_460), make_op_rhs(OP_EQ, make_compvar_primary(tmp_461), make_compvar_primary(tmp_462)));
}
start_if_cond(make_compvar_rhs(tmp_460));
{
compvar_t *tmp_463, *tmp_464;
tmp_463 = args[1][1];
tmp_464 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_464), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_460), make_op_rhs(OP_EQ, make_compvar_primary(tmp_463), make_compvar_primary(tmp_464)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_460));
{
int tmp_465;
for (tmp_465 = 0; tmp_465 < 2; ++tmp_465)
{
switch (tmp_465)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_465]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_465]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_466;

if (2 == 1)
{
tmp_466 = make_temporary(TYPE_INT);
{
compvar_t *tmp_470, *tmp_471;
tmp_470 = args[1][0];
tmp_471 = args[1][0];
emit_assign(make_lhs(tmp_466), make_op_rhs(OP_MUL, make_compvar_primary(tmp_470), make_compvar_primary(tmp_471)));
}

}
else
{
compvar_t *tmp_467, *tmp_468;
int tmp_469;
tmp_466 = make_temporary(TYPE_INT);
tmp_467 = make_temporary(TYPE_INT);
{
compvar_t *tmp_472, *tmp_473;
tmp_472 = args[1][0];
tmp_473 = args[1][0];
emit_assign(make_lhs(tmp_467), make_op_rhs(OP_MUL, make_compvar_primary(tmp_472), make_compvar_primary(tmp_473)));
}
tmp_468 = make_temporary(TYPE_INT);
{
compvar_t *tmp_474, *tmp_475;
tmp_474 = args[1][1];
tmp_475 = args[1][1];
emit_assign(make_lhs(tmp_468), make_op_rhs(OP_MUL, make_compvar_primary(tmp_474), make_compvar_primary(tmp_475)));
}
emit_assign(make_lhs(tmp_466), make_op_rhs(OP_ADD, make_compvar_primary(tmp_467), make_compvar_primary(tmp_468)));
for (tmp_469 = 2; tmp_469 < 2; ++tmp_469)
{
tmp_467 = make_temporary(TYPE_INT);
{
compvar_t *tmp_476, *tmp_477;
tmp_476 = args[1][tmp_469];
tmp_477 = args[1][tmp_469];
emit_assign(make_lhs(tmp_467), make_op_rhs(OP_MUL, make_compvar_primary(tmp_476), make_compvar_primary(tmp_477)));
}
emit_assign(make_lhs(tmp_466), make_op_rhs(OP_ADD, make_compvar_primary(tmp_466), make_compvar_primary(tmp_467)));
}
}

{
int tmp_478;
for (tmp_478 = 0; tmp_478 < 2; ++tmp_478)
{
switch (tmp_478)
{
case 0 :
{
compvar_t *tmp_479, *tmp_480;
if (2 == 1)
{
tmp_479 = make_temporary(TYPE_INT);
{
compvar_t *tmp_484, *tmp_485;
tmp_484 = args[0][0];
tmp_485 = args[1][0];
emit_assign(make_lhs(tmp_479), make_op_rhs(OP_MUL, make_compvar_primary(tmp_484), make_compvar_primary(tmp_485)));
}

}
else
{
compvar_t *tmp_481, *tmp_482;
int tmp_483;
tmp_479 = make_temporary(TYPE_INT);
tmp_481 = make_temporary(TYPE_INT);
{
compvar_t *tmp_486, *tmp_487;
tmp_486 = args[0][0];
tmp_487 = args[1][0];
emit_assign(make_lhs(tmp_481), make_op_rhs(OP_MUL, make_compvar_primary(tmp_486), make_compvar_primary(tmp_487)));
}
tmp_482 = make_temporary(TYPE_INT);
{
compvar_t *tmp_488, *tmp_489;
tmp_488 = args[0][1];
tmp_489 = args[1][1];
emit_assign(make_lhs(tmp_482), make_op_rhs(OP_MUL, make_compvar_primary(tmp_488), make_compvar_primary(tmp_489)));
}
emit_assign(make_lhs(tmp_479), make_op_rhs(OP_ADD, make_compvar_primary(tmp_481), make_compvar_primary(tmp_482)));
for (tmp_483 = 2; tmp_483 < 2; ++tmp_483)
{
tmp_481 = make_temporary(TYPE_INT);
{
compvar_t *tmp_490, *tmp_491;
tmp_490 = args[0][tmp_483];
tmp_491 = args[1][tmp_483];
emit_assign(make_lhs(tmp_481), make_op_rhs(OP_MUL, make_compvar_primary(tmp_490), make_compvar_primary(tmp_491)));
}
emit_assign(make_lhs(tmp_479), make_op_rhs(OP_ADD, make_compvar_primary(tmp_479), make_compvar_primary(tmp_481)));
}
}
tmp_480 = tmp_466;
emit_assign(make_lhs(result_tmps[tmp_478]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_479), make_compvar_primary(tmp_480)));
}
break;
case 1 :
{
compvar_t *tmp_492, *tmp_493;
tmp_492 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_494, *tmp_495;
tmp_494 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_496, *tmp_497;
tmp_496 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_498;
tmp_498 = args[0][0];
emit_assign(make_lhs(tmp_496), make_op_rhs(OP_NEG, make_compvar_primary(tmp_498)));
}
tmp_497 = args[1][1];
emit_assign(make_lhs(tmp_494), make_op_rhs(OP_MUL, make_compvar_primary(tmp_496), make_compvar_primary(tmp_497)));
}
tmp_495 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_499, *tmp_500;
tmp_499 = args[1][0];
tmp_500 = args[0][1];
emit_assign(make_lhs(tmp_495), make_op_rhs(OP_MUL, make_compvar_primary(tmp_499), make_compvar_primary(tmp_500)));
}
emit_assign(make_lhs(tmp_492), make_op_rhs(OP_ADD, make_compvar_primary(tmp_494), make_compvar_primary(tmp_495)));
}
tmp_493 = tmp_466;
emit_assign(make_lhs(result_tmps[tmp_478]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_492), make_compvar_primary(tmp_493)));
}
break;
default :
assert(0);
}
}
}
}
end_if_cond();
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_501;

if (2 == 1)
{
tmp_501 = make_temporary(TYPE_INT);
{
compvar_t *tmp_505, *tmp_506;
tmp_505 = args[1][0];
tmp_506 = args[1][0];
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_MUL, make_compvar_primary(tmp_505), make_compvar_primary(tmp_506)));
}

}
else
{
compvar_t *tmp_502, *tmp_503;
int tmp_504;
tmp_501 = make_temporary(TYPE_INT);
tmp_502 = make_temporary(TYPE_INT);
{
compvar_t *tmp_507, *tmp_508;
tmp_507 = args[1][0];
tmp_508 = args[1][0];
emit_assign(make_lhs(tmp_502), make_op_rhs(OP_MUL, make_compvar_primary(tmp_507), make_compvar_primary(tmp_508)));
}
tmp_503 = make_temporary(TYPE_INT);
{
compvar_t *tmp_509, *tmp_510;
tmp_509 = args[1][1];
tmp_510 = args[1][1];
emit_assign(make_lhs(tmp_503), make_op_rhs(OP_MUL, make_compvar_primary(tmp_509), make_compvar_primary(tmp_510)));
}
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_ADD, make_compvar_primary(tmp_502), make_compvar_primary(tmp_503)));
for (tmp_504 = 2; tmp_504 < 2; ++tmp_504)
{
tmp_502 = make_temporary(TYPE_INT);
{
compvar_t *tmp_511, *tmp_512;
tmp_511 = args[1][tmp_504];
tmp_512 = args[1][tmp_504];
emit_assign(make_lhs(tmp_502), make_op_rhs(OP_MUL, make_compvar_primary(tmp_511), make_compvar_primary(tmp_512)));
}
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_ADD, make_compvar_primary(tmp_501), make_compvar_primary(tmp_502)));
}
}

{
compvar_t *tmp_513;
tmp_513 = make_temporary(TYPE_INT);
{
compvar_t *tmp_514, *tmp_515;
tmp_514 = tmp_501;
tmp_515 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_515), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_513), make_op_rhs(OP_EQ, make_compvar_primary(tmp_514), make_compvar_primary(tmp_515)));
}
start_if_cond(make_compvar_rhs(tmp_513));
{
int tmp_516;
for (tmp_516 = 0; tmp_516 < 2; ++tmp_516)
{
switch (tmp_516)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_516]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_516]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_517;
for (tmp_517 = 0; tmp_517 < 2; ++tmp_517)
{
switch (tmp_517)
{
case 0 :
{
compvar_t *tmp_518, *tmp_519;
tmp_518 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_520, *tmp_521;
tmp_520 = args[0][0];
tmp_521 = args[1][0];
emit_assign(make_lhs(tmp_518), make_op_rhs(OP_MUL, make_compvar_primary(tmp_520), make_compvar_primary(tmp_521)));
}
tmp_519 = tmp_501;
emit_assign(make_lhs(result_tmps[tmp_517]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_518), make_compvar_primary(tmp_519)));
}
break;
case 1 :
{
compvar_t *tmp_522;
tmp_522 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_523, *tmp_524;
tmp_523 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_525, *tmp_526;
tmp_525 = args[0][0];
tmp_526 = args[1][1];
emit_assign(make_lhs(tmp_523), make_op_rhs(OP_MUL, make_compvar_primary(tmp_525), make_compvar_primary(tmp_526)));
}
tmp_524 = tmp_501;
emit_assign(make_lhs(tmp_522), make_op_rhs(OP_DIV, make_compvar_primary(tmp_523), make_compvar_primary(tmp_524)));
}
emit_assign(make_lhs(result_tmps[tmp_517]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_522)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_527;
compvar_t *tmp_532;

tmp_527 = make_temporary(TYPE_M2X2);
{
compvar_t *tmp_528, *tmp_529, *tmp_530, *tmp_531;
tmp_528 = args[1][0];
tmp_529 = args[1][1];
tmp_530 = args[1][2];
tmp_531 = args[1][3];
emit_assign(make_lhs(tmp_527), make_op_rhs(OP_MAKE_M2X2, make_compvar_primary(tmp_528), make_compvar_primary(tmp_529), make_compvar_primary(tmp_530), make_compvar_primary(tmp_531)));
}

tmp_532 = make_temporary(TYPE_V2);
{
compvar_t *tmp_533, *tmp_534;
tmp_533 = args[0][0];
tmp_534 = args[0][1];
emit_assign(make_lhs(tmp_532), make_op_rhs(OP_MAKE_V2, make_compvar_primary(tmp_533), make_compvar_primary(tmp_534)));
}

{
compvar_t *tmp_535;

tmp_535 = make_temporary(TYPE_V2);
{
compvar_t *tmp_536, *tmp_537;
tmp_536 = tmp_527;
tmp_537 = tmp_532;
emit_assign(make_lhs(tmp_535), make_op_rhs(OP_SOLVE_LINEAR_2, make_compvar_primary(tmp_536), make_compvar_primary(tmp_537)));
}

{
int tmp_538;
for (tmp_538 = 0; tmp_538 < 2; ++tmp_538)
{
switch (tmp_538)
{
case 0 :
{
compvar_t *tmp_539, *tmp_540;
tmp_539 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_539), make_int_const_rhs(0));
tmp_540 = tmp_535;
emit_assign(make_lhs(result_tmps[tmp_538]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_539), make_compvar_primary(tmp_540)));
}
break;
case 1 :
{
compvar_t *tmp_541, *tmp_542;
tmp_541 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_541), make_int_const_rhs(1));
tmp_542 = tmp_535;
emit_assign(make_lhs(result_tmps[tmp_538]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_541), make_compvar_primary(tmp_542)));
}
break;
default :
assert(0);
}
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_543;
compvar_t *tmp_553;

tmp_543 = make_temporary(TYPE_GSL_MATRIX);
{
compvar_t *tmp_544, *tmp_545, *tmp_546, *tmp_547, *tmp_548, *tmp_549, *tmp_550, *tmp_551, *tmp_552;
tmp_544 = args[1][0];
tmp_545 = args[1][1];
tmp_546 = args[1][2];
tmp_547 = args[1][3];
tmp_548 = args[1][4];
tmp_549 = args[1][5];
tmp_550 = args[1][6];
tmp_551 = args[1][7];
tmp_552 = args[1][8];
emit_assign(make_lhs(tmp_543), make_op_rhs(OP_MAKE_M3X3, make_compvar_primary(tmp_544), make_compvar_primary(tmp_545), make_compvar_primary(tmp_546), make_compvar_primary(tmp_547), make_compvar_primary(tmp_548), make_compvar_primary(tmp_549), make_compvar_primary(tmp_550), make_compvar_primary(tmp_551), make_compvar_primary(tmp_552)));
}

tmp_553 = make_temporary(TYPE_V3);
{
compvar_t *tmp_554, *tmp_555, *tmp_556;
tmp_554 = args[0][0];
tmp_555 = args[0][1];
tmp_556 = args[0][2];
emit_assign(make_lhs(tmp_553), make_op_rhs(OP_MAKE_V3, make_compvar_primary(tmp_554), make_compvar_primary(tmp_555), make_compvar_primary(tmp_556)));
}

{
compvar_t *tmp_557;

tmp_557 = make_temporary(TYPE_V3);
{
compvar_t *tmp_558, *tmp_559;
tmp_558 = tmp_543;
tmp_559 = tmp_553;
emit_assign(make_lhs(tmp_557), make_op_rhs(OP_SOLVE_LINEAR_3, make_compvar_primary(tmp_558), make_compvar_primary(tmp_559)));
}

{
int tmp_560;
for (tmp_560 = 0; tmp_560 < 3; ++tmp_560)
{
switch (tmp_560)
{
case 0 :
{
compvar_t *tmp_561, *tmp_562;
tmp_561 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_561), make_int_const_rhs(0));
tmp_562 = tmp_557;
emit_assign(make_lhs(result_tmps[tmp_560]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_561), make_compvar_primary(tmp_562)));
}
break;
case 1 :
{
compvar_t *tmp_563, *tmp_564;
tmp_563 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_563), make_int_const_rhs(1));
tmp_564 = tmp_557;
emit_assign(make_lhs(result_tmps[tmp_560]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_563), make_compvar_primary(tmp_564)));
}
break;
case 2 :
{
compvar_t *tmp_565, *tmp_566;
tmp_565 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_565), make_int_const_rhs(2));
tmp_566 = tmp_557;
emit_assign(make_lhs(result_tmps[tmp_560]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_565), make_compvar_primary(tmp_566)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_567;
tmp_567 = make_temporary(TYPE_INT);
{
compvar_t *tmp_568;
tmp_568 = tmp_543;
emit_assign(make_lhs(tmp_567), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_568)));
}
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_569;
tmp_569 = make_temporary(TYPE_INT);
{
compvar_t *tmp_570, *tmp_571;
tmp_570 = args[1][0];
tmp_571 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_571), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_569), make_op_rhs(OP_EQ, make_compvar_primary(tmp_570), make_compvar_primary(tmp_571)));
}
start_if_cond(make_compvar_rhs(tmp_569));
{
int tmp_572;
for (tmp_572 = 0; tmp_572 < 1; ++tmp_572)
{
switch (tmp_572)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_572]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_573;
for (tmp_573 = 0; tmp_573 < 1; ++tmp_573)
{
{
compvar_t *tmp_574, *tmp_575;
tmp_574 = args[0][tmp_573];
tmp_575 = args[1][tmp_573];
emit_assign(make_lhs(result_tmps[tmp_573]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_574), make_compvar_primary(tmp_575)));
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_576;
tmp_576 = make_temporary(TYPE_INT);
{
compvar_t *tmp_577, *tmp_578;
tmp_577 = args[1][0];
tmp_578 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_578), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_576), make_op_rhs(OP_EQ, make_compvar_primary(tmp_577), make_compvar_primary(tmp_578)));
}
start_if_cond(make_compvar_rhs(tmp_576));
{
int tmp_579;
for (tmp_579 = 0; tmp_579 < arglengths[0]; ++tmp_579)
{
emit_assign(make_lhs(result_tmps[tmp_579]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_580;
for (tmp_580 = 0; tmp_580 < arglengths[0]; ++tmp_580)
{
{
compvar_t *tmp_581, *tmp_582;
tmp_581 = args[0][tmp_580];
tmp_582 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_580]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_581), make_compvar_primary(tmp_582)));
}
}
}
end_if_cond();
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_583;
for (tmp_583 = 0; tmp_583 < arglengths[1]; ++tmp_583)
{
{
compvar_t *tmp_584;
tmp_584 = make_temporary(TYPE_INT);
{
compvar_t *tmp_585, *tmp_586;
tmp_585 = args[1][tmp_583];
tmp_586 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_586), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_584), make_op_rhs(OP_EQ, make_compvar_primary(tmp_585), make_compvar_primary(tmp_586)));
}
start_if_cond(make_compvar_rhs(tmp_584));
emit_assign(make_lhs(result_tmps[tmp_583]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_587, *tmp_588;
tmp_587 = args[0][tmp_583];
tmp_588 = args[1][tmp_583];
emit_assign(make_lhs(result_tmps[tmp_583]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_587), make_compvar_primary(tmp_588)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_589;
tmp_589 = make_temporary(TYPE_INT);
{
compvar_t *tmp_590, *tmp_591;
tmp_590 = args[1][0];
tmp_591 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_591), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_589), make_op_rhs(OP_EQ, make_compvar_primary(tmp_590), make_compvar_primary(tmp_591)));
}
start_if_cond(make_compvar_rhs(tmp_589));
{
int tmp_592;
for (tmp_592 = 0; tmp_592 < 1; ++tmp_592)
{
switch (tmp_592)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_592]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_593;
for (tmp_593 = 0; tmp_593 < 1; ++tmp_593)
{
{
compvar_t *tmp_594, *tmp_595;
tmp_594 = args[0][tmp_593];
tmp_595 = args[1][tmp_593];
emit_assign(make_lhs(result_tmps[tmp_593]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_594), make_compvar_primary(tmp_595)));
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_596;
tmp_596 = make_temporary(TYPE_INT);
{
compvar_t *tmp_597, *tmp_598;
tmp_597 = args[1][0];
tmp_598 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_598), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_596), make_op_rhs(OP_EQ, make_compvar_primary(tmp_597), make_compvar_primary(tmp_598)));
}
start_if_cond(make_compvar_rhs(tmp_596));
{
int tmp_599;
for (tmp_599 = 0; tmp_599 < arglengths[0]; ++tmp_599)
{
emit_assign(make_lhs(result_tmps[tmp_599]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_600;
for (tmp_600 = 0; tmp_600 < arglengths[0]; ++tmp_600)
{
{
compvar_t *tmp_601, *tmp_602;
tmp_601 = args[0][tmp_600];
tmp_602 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_600]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_601), make_compvar_primary(tmp_602)));
}
}
}
end_if_cond();
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_603;
for (tmp_603 = 0; tmp_603 < arglengths[1]; ++tmp_603)
{
{
compvar_t *tmp_604;
tmp_604 = make_temporary(TYPE_INT);
{
compvar_t *tmp_605, *tmp_606;
tmp_605 = args[1][tmp_603];
tmp_606 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_606), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_604), make_op_rhs(OP_EQ, make_compvar_primary(tmp_605), make_compvar_primary(tmp_606)));
}
start_if_cond(make_compvar_rhs(tmp_604));
emit_assign(make_lhs(result_tmps[tmp_603]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_607, *tmp_608;
tmp_607 = args[0][tmp_603];
tmp_608 = args[1][tmp_603];
emit_assign(make_lhs(result_tmps[tmp_603]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_607), make_compvar_primary(tmp_608)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pmod (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_609;

tmp_609 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_610, *tmp_611;
tmp_610 = args[0][0];
tmp_611 = args[1][0];
emit_assign(make_lhs(tmp_609), make_op_rhs(OP_MOD, make_compvar_primary(tmp_610), make_compvar_primary(tmp_611)));
}

{
compvar_t *tmp_612;
tmp_612 = make_temporary(TYPE_INT);
{
compvar_t *tmp_613, *tmp_614;
tmp_613 = args[0][0];
tmp_614 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_614), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_612), make_op_rhs(OP_LESS, make_compvar_primary(tmp_613), make_compvar_primary(tmp_614)));
}
start_if_cond(make_compvar_rhs(tmp_612));
{
int tmp_615;
for (tmp_615 = 0; tmp_615 < 1; ++tmp_615)
{
switch (tmp_615)
{
case 0 :
{
compvar_t *tmp_616, *tmp_617;
tmp_616 = tmp_609;
tmp_617 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_615]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_616), make_compvar_primary(tmp_617)));
}
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_618;
for (tmp_618 = 0; tmp_618 < 1; ++tmp_618)
{
switch (tmp_618)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_618]), make_compvar_rhs(tmp_609));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sqrt_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_619;

tmp_619 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_620;
tmp_620 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_621, *tmp_622;
tmp_621 = args[0][0];
tmp_622 = args[0][1];
emit_assign(make_lhs(tmp_620), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_621), make_compvar_primary(tmp_622)));
}
emit_assign(make_lhs(tmp_619), make_op_rhs(OP_C_SQRT, make_compvar_primary(tmp_620)));
}

{
int tmp_623;
for (tmp_623 = 0; tmp_623 < 2; ++tmp_623)
{
switch (tmp_623)
{
case 0 :
{
compvar_t *tmp_624;
tmp_624 = tmp_619;
emit_assign(make_lhs(result_tmps[tmp_623]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_624)));
}
break;
case 1 :
{
compvar_t *tmp_625;
tmp_625 = tmp_619;
emit_assign(make_lhs(result_tmps[tmp_623]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_625)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sqrt_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_626;
for (tmp_626 = 0; tmp_626 < 1; ++tmp_626)
{
switch (tmp_626)
{
case 0 :
{
compvar_t *tmp_627;
tmp_627 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_626]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_627)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sum (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_628;
for (tmp_628 = 0; tmp_628 < 1; ++tmp_628)
{
switch (tmp_628)
{
case 0 :
if (arglengths[0] == 1)
{
emit_assign(make_lhs(result_tmps[tmp_628]), make_compvar_rhs(args[0][0]));

}
else
{
compvar_t *tmp_629, *tmp_630;
int tmp_631;
tmp_629 = args[0][0];
tmp_630 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_628]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_629), make_compvar_primary(tmp_630)));
for (tmp_631 = 2; tmp_631 < arglengths[0]; ++tmp_631)
{
tmp_629 = args[0][tmp_631];
emit_assign(make_lhs(result_tmps[tmp_628]), make_op_rhs(OP_ADD, make_compvar_primary(result_tmps[tmp_628]), make_compvar_primary(tmp_629)));
}
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_dotp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_632;
for (tmp_632 = 0; tmp_632 < 1; ++tmp_632)
{
switch (tmp_632)
{
case 0 :
if (arglengths[0] == 1)
{
{
compvar_t *tmp_636, *tmp_637;
tmp_636 = args[0][0];
tmp_637 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_632]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_636), make_compvar_primary(tmp_637)));
}

}
else
{
compvar_t *tmp_633, *tmp_634;
int tmp_635;
tmp_633 = make_temporary(TYPE_INT);
{
compvar_t *tmp_638, *tmp_639;
tmp_638 = args[0][0];
tmp_639 = args[1][0];
emit_assign(make_lhs(tmp_633), make_op_rhs(OP_MUL, make_compvar_primary(tmp_638), make_compvar_primary(tmp_639)));
}
tmp_634 = make_temporary(TYPE_INT);
{
compvar_t *tmp_640, *tmp_641;
tmp_640 = args[0][1];
tmp_641 = args[1][1];
emit_assign(make_lhs(tmp_634), make_op_rhs(OP_MUL, make_compvar_primary(tmp_640), make_compvar_primary(tmp_641)));
}
emit_assign(make_lhs(result_tmps[tmp_632]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_633), make_compvar_primary(tmp_634)));
for (tmp_635 = 2; tmp_635 < arglengths[0]; ++tmp_635)
{
tmp_633 = make_temporary(TYPE_INT);
{
compvar_t *tmp_642, *tmp_643;
tmp_642 = args[0][tmp_635];
tmp_643 = args[1][tmp_635];
emit_assign(make_lhs(tmp_633), make_op_rhs(OP_MUL, make_compvar_primary(tmp_642), make_compvar_primary(tmp_643)));
}
emit_assign(make_lhs(result_tmps[tmp_632]), make_op_rhs(OP_ADD, make_compvar_primary(result_tmps[tmp_632]), make_compvar_primary(tmp_633)));
}
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_crossp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_644;
for (tmp_644 = 0; tmp_644 < 3; ++tmp_644)
{
switch (tmp_644)
{
case 0 :
{
compvar_t *tmp_645, *tmp_646;
tmp_645 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_647, *tmp_648;
tmp_647 = args[0][1];
tmp_648 = args[1][2];
emit_assign(make_lhs(tmp_645), make_op_rhs(OP_MUL, make_compvar_primary(tmp_647), make_compvar_primary(tmp_648)));
}
tmp_646 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_649, *tmp_650;
tmp_649 = args[0][2];
tmp_650 = args[1][1];
emit_assign(make_lhs(tmp_646), make_op_rhs(OP_MUL, make_compvar_primary(tmp_649), make_compvar_primary(tmp_650)));
}
emit_assign(make_lhs(result_tmps[tmp_644]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_645), make_compvar_primary(tmp_646)));
}
break;
case 1 :
{
compvar_t *tmp_651, *tmp_652;
tmp_651 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_653, *tmp_654;
tmp_653 = args[0][2];
tmp_654 = args[1][0];
emit_assign(make_lhs(tmp_651), make_op_rhs(OP_MUL, make_compvar_primary(tmp_653), make_compvar_primary(tmp_654)));
}
tmp_652 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_655, *tmp_656;
tmp_655 = args[0][0];
tmp_656 = args[1][2];
emit_assign(make_lhs(tmp_652), make_op_rhs(OP_MUL, make_compvar_primary(tmp_655), make_compvar_primary(tmp_656)));
}
emit_assign(make_lhs(result_tmps[tmp_644]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_651), make_compvar_primary(tmp_652)));
}
break;
case 2 :
{
compvar_t *tmp_657, *tmp_658;
tmp_657 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_659, *tmp_660;
tmp_659 = args[0][0];
tmp_660 = args[1][1];
emit_assign(make_lhs(tmp_657), make_op_rhs(OP_MUL, make_compvar_primary(tmp_659), make_compvar_primary(tmp_660)));
}
tmp_658 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_661, *tmp_662;
tmp_661 = args[0][1];
tmp_662 = args[1][0];
emit_assign(make_lhs(tmp_658), make_op_rhs(OP_MUL, make_compvar_primary(tmp_661), make_compvar_primary(tmp_662)));
}
emit_assign(make_lhs(result_tmps[tmp_644]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_657), make_compvar_primary(tmp_658)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_det_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_663;
for (tmp_663 = 0; tmp_663 < 1; ++tmp_663)
{
switch (tmp_663)
{
case 0 :
{
compvar_t *tmp_664, *tmp_665;
tmp_664 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_666, *tmp_667;
tmp_666 = args[0][0];
tmp_667 = args[0][3];
emit_assign(make_lhs(tmp_664), make_op_rhs(OP_MUL, make_compvar_primary(tmp_666), make_compvar_primary(tmp_667)));
}
tmp_665 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_668, *tmp_669;
tmp_668 = args[0][1];
tmp_669 = args[0][2];
emit_assign(make_lhs(tmp_665), make_op_rhs(OP_MUL, make_compvar_primary(tmp_668), make_compvar_primary(tmp_669)));
}
emit_assign(make_lhs(result_tmps[tmp_663]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_664), make_compvar_primary(tmp_665)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_det_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_670;
for (tmp_670 = 0; tmp_670 < 1; ++tmp_670)
{
switch (tmp_670)
{
case 0 :
{
compvar_t *tmp_671, *tmp_672;
tmp_671 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_673, *tmp_674;
tmp_673 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_675, *tmp_676;
tmp_675 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_677, *tmp_678;
tmp_677 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_679, *tmp_680;
tmp_679 = args[0][0];
tmp_680 = args[0][4];
emit_assign(make_lhs(tmp_677), make_op_rhs(OP_MUL, make_compvar_primary(tmp_679), make_compvar_primary(tmp_680)));
}
tmp_678 = args[0][8];
emit_assign(make_lhs(tmp_675), make_op_rhs(OP_MUL, make_compvar_primary(tmp_677), make_compvar_primary(tmp_678)));
}
tmp_676 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_681, *tmp_682;
tmp_681 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_683, *tmp_684;
tmp_683 = args[0][1];
tmp_684 = args[0][5];
emit_assign(make_lhs(tmp_681), make_op_rhs(OP_MUL, make_compvar_primary(tmp_683), make_compvar_primary(tmp_684)));
}
tmp_682 = args[0][6];
emit_assign(make_lhs(tmp_676), make_op_rhs(OP_MUL, make_compvar_primary(tmp_681), make_compvar_primary(tmp_682)));
}
emit_assign(make_lhs(tmp_673), make_op_rhs(OP_ADD, make_compvar_primary(tmp_675), make_compvar_primary(tmp_676)));
}
tmp_674 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_685, *tmp_686;
tmp_685 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_687, *tmp_688;
tmp_687 = args[0][2];
tmp_688 = args[0][3];
emit_assign(make_lhs(tmp_685), make_op_rhs(OP_MUL, make_compvar_primary(tmp_687), make_compvar_primary(tmp_688)));
}
tmp_686 = args[0][7];
emit_assign(make_lhs(tmp_674), make_op_rhs(OP_MUL, make_compvar_primary(tmp_685), make_compvar_primary(tmp_686)));
}
emit_assign(make_lhs(tmp_671), make_op_rhs(OP_ADD, make_compvar_primary(tmp_673), make_compvar_primary(tmp_674)));
}
tmp_672 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_689, *tmp_690;
tmp_689 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_691, *tmp_692;
tmp_691 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_693, *tmp_694;
tmp_693 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_695, *tmp_696;
tmp_695 = args[0][2];
tmp_696 = args[0][4];
emit_assign(make_lhs(tmp_693), make_op_rhs(OP_MUL, make_compvar_primary(tmp_695), make_compvar_primary(tmp_696)));
}
tmp_694 = args[0][6];
emit_assign(make_lhs(tmp_691), make_op_rhs(OP_MUL, make_compvar_primary(tmp_693), make_compvar_primary(tmp_694)));
}
tmp_692 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_697, *tmp_698;
tmp_697 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_699, *tmp_700;
tmp_699 = args[0][0];
tmp_700 = args[0][5];
emit_assign(make_lhs(tmp_697), make_op_rhs(OP_MUL, make_compvar_primary(tmp_699), make_compvar_primary(tmp_700)));
}
tmp_698 = args[0][7];
emit_assign(make_lhs(tmp_692), make_op_rhs(OP_MUL, make_compvar_primary(tmp_697), make_compvar_primary(tmp_698)));
}
emit_assign(make_lhs(tmp_689), make_op_rhs(OP_ADD, make_compvar_primary(tmp_691), make_compvar_primary(tmp_692)));
}
tmp_690 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_701, *tmp_702;
tmp_701 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_703, *tmp_704;
tmp_703 = args[0][1];
tmp_704 = args[0][3];
emit_assign(make_lhs(tmp_701), make_op_rhs(OP_MUL, make_compvar_primary(tmp_703), make_compvar_primary(tmp_704)));
}
tmp_702 = args[0][8];
emit_assign(make_lhs(tmp_690), make_op_rhs(OP_MUL, make_compvar_primary(tmp_701), make_compvar_primary(tmp_702)));
}
emit_assign(make_lhs(tmp_672), make_op_rhs(OP_ADD, make_compvar_primary(tmp_689), make_compvar_primary(tmp_690)));
}
emit_assign(make_lhs(result_tmps[tmp_670]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_671), make_compvar_primary(tmp_672)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_normalize (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_705;

if (arglengths[0] == 1)
{
tmp_705 = make_temporary(TYPE_INT);
{
compvar_t *tmp_709, *tmp_710;
tmp_709 = args[0][0];
tmp_710 = args[0][0];
emit_assign(make_lhs(tmp_705), make_op_rhs(OP_MUL, make_compvar_primary(tmp_709), make_compvar_primary(tmp_710)));
}

}
else
{
compvar_t *tmp_706, *tmp_707;
int tmp_708;
tmp_705 = make_temporary(TYPE_INT);
tmp_706 = make_temporary(TYPE_INT);
{
compvar_t *tmp_711, *tmp_712;
tmp_711 = args[0][0];
tmp_712 = args[0][0];
emit_assign(make_lhs(tmp_706), make_op_rhs(OP_MUL, make_compvar_primary(tmp_711), make_compvar_primary(tmp_712)));
}
tmp_707 = make_temporary(TYPE_INT);
{
compvar_t *tmp_713, *tmp_714;
tmp_713 = args[0][1];
tmp_714 = args[0][1];
emit_assign(make_lhs(tmp_707), make_op_rhs(OP_MUL, make_compvar_primary(tmp_713), make_compvar_primary(tmp_714)));
}
emit_assign(make_lhs(tmp_705), make_op_rhs(OP_ADD, make_compvar_primary(tmp_706), make_compvar_primary(tmp_707)));
for (tmp_708 = 2; tmp_708 < arglengths[0]; ++tmp_708)
{
tmp_706 = make_temporary(TYPE_INT);
{
compvar_t *tmp_715, *tmp_716;
tmp_715 = args[0][tmp_708];
tmp_716 = args[0][tmp_708];
emit_assign(make_lhs(tmp_706), make_op_rhs(OP_MUL, make_compvar_primary(tmp_715), make_compvar_primary(tmp_716)));
}
emit_assign(make_lhs(tmp_705), make_op_rhs(OP_ADD, make_compvar_primary(tmp_705), make_compvar_primary(tmp_706)));
}
}

{
compvar_t *tmp_717;
tmp_717 = make_temporary(TYPE_INT);
{
compvar_t *tmp_718, *tmp_719;
tmp_718 = tmp_705;
tmp_719 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_719), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_717), make_op_rhs(OP_EQ, make_compvar_primary(tmp_718), make_compvar_primary(tmp_719)));
}
start_if_cond(make_compvar_rhs(tmp_717));
{
int tmp_720;
for (tmp_720 = 0; tmp_720 < arglengths[0]; ++tmp_720)
{
emit_assign(make_lhs(result_tmps[tmp_720]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_721;
for (tmp_721 = 0; tmp_721 < arglengths[0]; ++tmp_721)
{
{
compvar_t *tmp_722, *tmp_723;
tmp_722 = args[0][tmp_721];
tmp_723 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_724;
tmp_724 = tmp_705;
emit_assign(make_lhs(tmp_723), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_724)));
}
emit_assign(make_lhs(result_tmps[tmp_721]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_722), make_compvar_primary(tmp_723)));
}
}
}
end_if_cond();
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_725;
for (tmp_725 = 0; tmp_725 < 1; ++tmp_725)
{
switch (tmp_725)
{
case 0 :
{
compvar_t *tmp_726, *tmp_727;
tmp_726 = args[0][0];
tmp_727 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_725]), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_726), make_compvar_primary(tmp_727)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_quat (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_728;
for (tmp_728 = 0; tmp_728 < 1; ++tmp_728)
{
switch (tmp_728)
{
case 0 :
{
compvar_t *tmp_729;
tmp_729 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_730, *tmp_731;
tmp_730 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_732, *tmp_733;
tmp_732 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_734, *tmp_735;
tmp_734 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_736, *tmp_737;
tmp_736 = args[0][0];
tmp_737 = args[0][0];
emit_assign(make_lhs(tmp_734), make_op_rhs(OP_MUL, make_compvar_primary(tmp_736), make_compvar_primary(tmp_737)));
}
tmp_735 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_738, *tmp_739;
tmp_738 = args[0][1];
tmp_739 = args[0][1];
emit_assign(make_lhs(tmp_735), make_op_rhs(OP_MUL, make_compvar_primary(tmp_738), make_compvar_primary(tmp_739)));
}
emit_assign(make_lhs(tmp_732), make_op_rhs(OP_ADD, make_compvar_primary(tmp_734), make_compvar_primary(tmp_735)));
}
tmp_733 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_740, *tmp_741;
tmp_740 = args[0][2];
tmp_741 = args[0][2];
emit_assign(make_lhs(tmp_733), make_op_rhs(OP_MUL, make_compvar_primary(tmp_740), make_compvar_primary(tmp_741)));
}
emit_assign(make_lhs(tmp_730), make_op_rhs(OP_ADD, make_compvar_primary(tmp_732), make_compvar_primary(tmp_733)));
}
tmp_731 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_742, *tmp_743;
tmp_742 = args[0][3];
tmp_743 = args[0][3];
emit_assign(make_lhs(tmp_731), make_op_rhs(OP_MUL, make_compvar_primary(tmp_742), make_compvar_primary(tmp_743)));
}
emit_assign(make_lhs(tmp_729), make_op_rhs(OP_ADD, make_compvar_primary(tmp_730), make_compvar_primary(tmp_731)));
}
emit_assign(make_lhs(result_tmps[tmp_728]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_729)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_cquat (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_744;
for (tmp_744 = 0; tmp_744 < 1; ++tmp_744)
{
switch (tmp_744)
{
case 0 :
{
compvar_t *tmp_745;
tmp_745 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_746, *tmp_747;
tmp_746 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_748, *tmp_749;
tmp_748 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_750, *tmp_751;
tmp_750 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_752, *tmp_753;
tmp_752 = args[0][0];
tmp_753 = args[0][0];
emit_assign(make_lhs(tmp_750), make_op_rhs(OP_MUL, make_compvar_primary(tmp_752), make_compvar_primary(tmp_753)));
}
tmp_751 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_754, *tmp_755;
tmp_754 = args[0][1];
tmp_755 = args[0][1];
emit_assign(make_lhs(tmp_751), make_op_rhs(OP_MUL, make_compvar_primary(tmp_754), make_compvar_primary(tmp_755)));
}
emit_assign(make_lhs(tmp_748), make_op_rhs(OP_ADD, make_compvar_primary(tmp_750), make_compvar_primary(tmp_751)));
}
tmp_749 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_756, *tmp_757;
tmp_756 = args[0][2];
tmp_757 = args[0][2];
emit_assign(make_lhs(tmp_749), make_op_rhs(OP_MUL, make_compvar_primary(tmp_756), make_compvar_primary(tmp_757)));
}
emit_assign(make_lhs(tmp_746), make_op_rhs(OP_ADD, make_compvar_primary(tmp_748), make_compvar_primary(tmp_749)));
}
tmp_747 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_758, *tmp_759;
tmp_758 = args[0][3];
tmp_759 = args[0][3];
emit_assign(make_lhs(tmp_747), make_op_rhs(OP_MUL, make_compvar_primary(tmp_758), make_compvar_primary(tmp_759)));
}
emit_assign(make_lhs(tmp_745), make_op_rhs(OP_ADD, make_compvar_primary(tmp_746), make_compvar_primary(tmp_747)));
}
emit_assign(make_lhs(result_tmps[tmp_744]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_745)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_hyper (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_760;
for (tmp_760 = 0; tmp_760 < 1; ++tmp_760)
{
switch (tmp_760)
{
case 0 :
{
compvar_t *tmp_761;
tmp_761 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_762, *tmp_763;
tmp_762 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_764, *tmp_765;
tmp_764 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_766, *tmp_767;
tmp_766 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_768, *tmp_769;
tmp_768 = args[0][0];
tmp_769 = args[0][0];
emit_assign(make_lhs(tmp_766), make_op_rhs(OP_MUL, make_compvar_primary(tmp_768), make_compvar_primary(tmp_769)));
}
tmp_767 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_770, *tmp_771;
tmp_770 = args[0][1];
tmp_771 = args[0][1];
emit_assign(make_lhs(tmp_767), make_op_rhs(OP_MUL, make_compvar_primary(tmp_770), make_compvar_primary(tmp_771)));
}
emit_assign(make_lhs(tmp_764), make_op_rhs(OP_ADD, make_compvar_primary(tmp_766), make_compvar_primary(tmp_767)));
}
tmp_765 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_772, *tmp_773;
tmp_772 = args[0][2];
tmp_773 = args[0][2];
emit_assign(make_lhs(tmp_765), make_op_rhs(OP_MUL, make_compvar_primary(tmp_772), make_compvar_primary(tmp_773)));
}
emit_assign(make_lhs(tmp_762), make_op_rhs(OP_ADD, make_compvar_primary(tmp_764), make_compvar_primary(tmp_765)));
}
tmp_763 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_774, *tmp_775;
tmp_774 = args[0][3];
tmp_775 = args[0][3];
emit_assign(make_lhs(tmp_763), make_op_rhs(OP_MUL, make_compvar_primary(tmp_774), make_compvar_primary(tmp_775)));
}
emit_assign(make_lhs(tmp_761), make_op_rhs(OP_ADD, make_compvar_primary(tmp_762), make_compvar_primary(tmp_763)));
}
emit_assign(make_lhs(result_tmps[tmp_760]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_761)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_776;
for (tmp_776 = 0; tmp_776 < 1; ++tmp_776)
{
{
compvar_t *tmp_777;
tmp_777 = args[0][tmp_776];
emit_assign(make_lhs(result_tmps[tmp_776]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_777)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_778;
for (tmp_778 = 0; tmp_778 < arglengths[0]; ++tmp_778)
{
{
compvar_t *tmp_779;
tmp_779 = args[0][tmp_778];
emit_assign(make_lhs(result_tmps[tmp_778]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_779)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_deg2rad (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_780;
for (tmp_780 = 0; tmp_780 < 1; ++tmp_780)
{
switch (tmp_780)
{
case 0 :
{
compvar_t *tmp_781, *tmp_782;
tmp_781 = args[0][0];
tmp_782 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_782), make_float_const_rhs(0.017453292));
emit_assign(make_lhs(result_tmps[tmp_780]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_781), make_compvar_primary(tmp_782)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rad2deg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_783;
for (tmp_783 = 0; tmp_783 < 1; ++tmp_783)
{
switch (tmp_783)
{
case 0 :
{
compvar_t *tmp_784, *tmp_785;
tmp_784 = args[0][0];
tmp_785 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_785), make_float_const_rhs(57.29578));
emit_assign(make_lhs(result_tmps[tmp_783]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_784), make_compvar_primary(tmp_785)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_786;

tmp_786 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_787;
tmp_787 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_788, *tmp_789;
tmp_788 = args[0][0];
tmp_789 = args[0][1];
emit_assign(make_lhs(tmp_787), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_788), make_compvar_primary(tmp_789)));
}
emit_assign(make_lhs(tmp_786), make_op_rhs(OP_C_SIN, make_compvar_primary(tmp_787)));
}

{
int tmp_790;
for (tmp_790 = 0; tmp_790 < 2; ++tmp_790)
{
switch (tmp_790)
{
case 0 :
{
compvar_t *tmp_791;
tmp_791 = tmp_786;
emit_assign(make_lhs(result_tmps[tmp_790]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_791)));
}
break;
case 1 :
{
compvar_t *tmp_792;
tmp_792 = tmp_786;
emit_assign(make_lhs(result_tmps[tmp_790]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_792)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_793;
for (tmp_793 = 0; tmp_793 < 1; ++tmp_793)
{
switch (tmp_793)
{
case 0 :
{
compvar_t *tmp_794;
tmp_794 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_793]), make_op_rhs(OP_SIN, make_compvar_primary(tmp_794)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_795;

tmp_795 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_796;
tmp_796 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_797, *tmp_798;
tmp_797 = args[0][0];
tmp_798 = args[0][1];
emit_assign(make_lhs(tmp_796), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_797), make_compvar_primary(tmp_798)));
}
emit_assign(make_lhs(tmp_795), make_op_rhs(OP_C_COS, make_compvar_primary(tmp_796)));
}

{
int tmp_799;
for (tmp_799 = 0; tmp_799 < 2; ++tmp_799)
{
switch (tmp_799)
{
case 0 :
{
compvar_t *tmp_800;
tmp_800 = tmp_795;
emit_assign(make_lhs(result_tmps[tmp_799]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_800)));
}
break;
case 1 :
{
compvar_t *tmp_801;
tmp_801 = tmp_795;
emit_assign(make_lhs(result_tmps[tmp_799]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_801)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_802;
for (tmp_802 = 0; tmp_802 < 1; ++tmp_802)
{
switch (tmp_802)
{
case 0 :
{
compvar_t *tmp_803;
tmp_803 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_802]), make_op_rhs(OP_COS, make_compvar_primary(tmp_803)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_804;

tmp_804 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_805;
tmp_805 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_806, *tmp_807;
tmp_806 = args[0][0];
tmp_807 = args[0][1];
emit_assign(make_lhs(tmp_805), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_806), make_compvar_primary(tmp_807)));
}
emit_assign(make_lhs(tmp_804), make_op_rhs(OP_C_TAN, make_compvar_primary(tmp_805)));
}

{
int tmp_808;
for (tmp_808 = 0; tmp_808 < 2; ++tmp_808)
{
switch (tmp_808)
{
case 0 :
{
compvar_t *tmp_809;
tmp_809 = tmp_804;
emit_assign(make_lhs(result_tmps[tmp_808]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_809)));
}
break;
case 1 :
{
compvar_t *tmp_810;
tmp_810 = tmp_804;
emit_assign(make_lhs(result_tmps[tmp_808]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_810)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_811;
for (tmp_811 = 0; tmp_811 < 1; ++tmp_811)
{
switch (tmp_811)
{
case 0 :
{
compvar_t *tmp_812;
tmp_812 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_811]), make_op_rhs(OP_TAN, make_compvar_primary(tmp_812)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_813;

tmp_813 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_814;
tmp_814 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_815, *tmp_816;
tmp_815 = args[0][0];
tmp_816 = args[0][1];
emit_assign(make_lhs(tmp_814), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_815), make_compvar_primary(tmp_816)));
}
emit_assign(make_lhs(tmp_813), make_op_rhs(OP_C_ASIN, make_compvar_primary(tmp_814)));
}

{
int tmp_817;
for (tmp_817 = 0; tmp_817 < 2; ++tmp_817)
{
switch (tmp_817)
{
case 0 :
{
compvar_t *tmp_818;
tmp_818 = tmp_813;
emit_assign(make_lhs(result_tmps[tmp_817]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_818)));
}
break;
case 1 :
{
compvar_t *tmp_819;
tmp_819 = tmp_813;
emit_assign(make_lhs(result_tmps[tmp_817]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_819)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_820;
tmp_820 = make_temporary(TYPE_INT);
{
compvar_t *tmp_821, *tmp_822;
tmp_821 = args[0][0];
tmp_822 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_822), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_820), make_op_rhs(OP_LESS, make_compvar_primary(tmp_821), make_compvar_primary(tmp_822)));
}
start_if_cond(make_compvar_rhs(tmp_820));
switch_if_branch();
{
compvar_t *tmp_823, *tmp_824;
tmp_823 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_823), make_int_const_rhs(1));
tmp_824 = args[0][0];
emit_assign(make_lhs(tmp_820), make_op_rhs(OP_LESS, make_compvar_primary(tmp_823), make_compvar_primary(tmp_824)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_820));
{
int tmp_825;
for (tmp_825 = 0; tmp_825 < 1; ++tmp_825)
{
switch (tmp_825)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_825]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_826;
for (tmp_826 = 0; tmp_826 < 1; ++tmp_826)
{
switch (tmp_826)
{
case 0 :
{
compvar_t *tmp_827;
tmp_827 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_826]), make_op_rhs(OP_ASIN, make_compvar_primary(tmp_827)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_828;

tmp_828 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_829;
tmp_829 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_830, *tmp_831;
tmp_830 = args[0][0];
tmp_831 = args[0][1];
emit_assign(make_lhs(tmp_829), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_830), make_compvar_primary(tmp_831)));
}
emit_assign(make_lhs(tmp_828), make_op_rhs(OP_C_ACOS, make_compvar_primary(tmp_829)));
}

{
int tmp_832;
for (tmp_832 = 0; tmp_832 < 2; ++tmp_832)
{
switch (tmp_832)
{
case 0 :
{
compvar_t *tmp_833;
tmp_833 = tmp_828;
emit_assign(make_lhs(result_tmps[tmp_832]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_833)));
}
break;
case 1 :
{
compvar_t *tmp_834;
tmp_834 = tmp_828;
emit_assign(make_lhs(result_tmps[tmp_832]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_834)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_835;
tmp_835 = make_temporary(TYPE_INT);
{
compvar_t *tmp_836, *tmp_837;
tmp_836 = args[0][0];
tmp_837 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_837), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_835), make_op_rhs(OP_LESS, make_compvar_primary(tmp_836), make_compvar_primary(tmp_837)));
}
start_if_cond(make_compvar_rhs(tmp_835));
switch_if_branch();
{
compvar_t *tmp_838, *tmp_839;
tmp_838 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_838), make_int_const_rhs(1));
tmp_839 = args[0][0];
emit_assign(make_lhs(tmp_835), make_op_rhs(OP_LESS, make_compvar_primary(tmp_838), make_compvar_primary(tmp_839)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_835));
{
int tmp_840;
for (tmp_840 = 0; tmp_840 < 1; ++tmp_840)
{
switch (tmp_840)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_840]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_841;
for (tmp_841 = 0; tmp_841 < 1; ++tmp_841)
{
switch (tmp_841)
{
case 0 :
{
compvar_t *tmp_842;
tmp_842 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_841]), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_842)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_843;

tmp_843 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_844;
tmp_844 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_845, *tmp_846;
tmp_845 = args[0][0];
tmp_846 = args[0][1];
emit_assign(make_lhs(tmp_844), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_845), make_compvar_primary(tmp_846)));
}
emit_assign(make_lhs(tmp_843), make_op_rhs(OP_C_ATAN, make_compvar_primary(tmp_844)));
}

{
int tmp_847;
for (tmp_847 = 0; tmp_847 < 2; ++tmp_847)
{
switch (tmp_847)
{
case 0 :
{
compvar_t *tmp_848;
tmp_848 = tmp_843;
emit_assign(make_lhs(result_tmps[tmp_847]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_848)));
}
break;
case 1 :
{
compvar_t *tmp_849;
tmp_849 = tmp_843;
emit_assign(make_lhs(result_tmps[tmp_847]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_849)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_850;
for (tmp_850 = 0; tmp_850 < 1; ++tmp_850)
{
switch (tmp_850)
{
case 0 :
{
compvar_t *tmp_851;
tmp_851 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_850]), make_op_rhs(OP_ATAN, make_compvar_primary(tmp_851)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_852;
for (tmp_852 = 0; tmp_852 < 1; ++tmp_852)
{
switch (tmp_852)
{
case 0 :
{
compvar_t *tmp_853, *tmp_854;
tmp_853 = args[0][0];
tmp_854 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_852]), make_op_rhs(OP_ATAN2, make_compvar_primary(tmp_853), make_compvar_primary(tmp_854)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_855;

tmp_855 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_856, *tmp_857;
tmp_856 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_858, *tmp_859;
tmp_858 = args[0][0];
tmp_859 = args[0][1];
emit_assign(make_lhs(tmp_856), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_858), make_compvar_primary(tmp_859)));
}
tmp_857 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_860, *tmp_861;
tmp_860 = args[1][0];
tmp_861 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_861), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_857), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_860), make_compvar_primary(tmp_861)));
}
emit_assign(make_lhs(tmp_855), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_856), make_compvar_primary(tmp_857)));
}

{
int tmp_862;
for (tmp_862 = 0; tmp_862 < 2; ++tmp_862)
{
switch (tmp_862)
{
case 0 :
{
compvar_t *tmp_863;
tmp_863 = tmp_855;
emit_assign(make_lhs(result_tmps[tmp_862]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_863)));
}
break;
case 1 :
{
compvar_t *tmp_864;
tmp_864 = tmp_855;
emit_assign(make_lhs(result_tmps[tmp_862]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_864)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_865;

tmp_865 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_866, *tmp_867;
tmp_866 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_868, *tmp_869;
tmp_868 = args[0][0];
tmp_869 = args[0][1];
emit_assign(make_lhs(tmp_866), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_868), make_compvar_primary(tmp_869)));
}
tmp_867 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_870, *tmp_871;
tmp_870 = args[1][0];
tmp_871 = args[1][1];
emit_assign(make_lhs(tmp_867), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_870), make_compvar_primary(tmp_871)));
}
emit_assign(make_lhs(tmp_865), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_866), make_compvar_primary(tmp_867)));
}

{
int tmp_872;
for (tmp_872 = 0; tmp_872 < 2; ++tmp_872)
{
switch (tmp_872)
{
case 0 :
{
compvar_t *tmp_873;
tmp_873 = tmp_865;
emit_assign(make_lhs(result_tmps[tmp_872]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_873)));
}
break;
case 1 :
{
compvar_t *tmp_874;
tmp_874 = tmp_865;
emit_assign(make_lhs(result_tmps[tmp_872]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_874)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_875;

tmp_875 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_876, *tmp_877;
tmp_876 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_878, *tmp_879;
tmp_878 = args[0][0];
tmp_879 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_879), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_876), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_878), make_compvar_primary(tmp_879)));
}
tmp_877 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_880, *tmp_881;
tmp_880 = args[1][0];
tmp_881 = args[1][1];
emit_assign(make_lhs(tmp_877), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_880), make_compvar_primary(tmp_881)));
}
emit_assign(make_lhs(tmp_875), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_876), make_compvar_primary(tmp_877)));
}

{
int tmp_882;
for (tmp_882 = 0; tmp_882 < 2; ++tmp_882)
{
switch (tmp_882)
{
case 0 :
{
compvar_t *tmp_883;
tmp_883 = tmp_875;
emit_assign(make_lhs(result_tmps[tmp_882]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_883)));
}
break;
case 1 :
{
compvar_t *tmp_884;
tmp_884 = tmp_875;
emit_assign(make_lhs(result_tmps[tmp_882]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_884)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_885;
tmp_885 = make_temporary(TYPE_INT);
{
compvar_t *tmp_886, *tmp_887;
tmp_886 = args[1][0];
tmp_887 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_887), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_885), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_886), make_compvar_primary(tmp_887)));
}
start_if_cond(make_compvar_rhs(tmp_885));
{
compvar_t *tmp_888, *tmp_889;
tmp_888 = args[0][0];
tmp_889 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_889), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_885), make_op_rhs(OP_EQ, make_compvar_primary(tmp_888), make_compvar_primary(tmp_889)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_885));
{
int tmp_890;
for (tmp_890 = 0; tmp_890 < 1; ++tmp_890)
{
switch (tmp_890)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_890]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_891;
for (tmp_891 = 0; tmp_891 < 1; ++tmp_891)
{
switch (tmp_891)
{
case 0 :
{
compvar_t *tmp_892, *tmp_893;
tmp_892 = args[0][0];
tmp_893 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_891]), make_op_rhs(OP_POW, make_compvar_primary(tmp_892), make_compvar_primary(tmp_893)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_894;
for (tmp_894 = 0; tmp_894 < arglengths[0]; ++tmp_894)
{
{
compvar_t *tmp_895;
tmp_895 = make_temporary(TYPE_INT);
{
compvar_t *tmp_896, *tmp_897;
tmp_896 = args[1][0];
tmp_897 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_897), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_895), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_896), make_compvar_primary(tmp_897)));
}
start_if_cond(make_compvar_rhs(tmp_895));
{
compvar_t *tmp_898, *tmp_899;
tmp_898 = args[0][tmp_894];
tmp_899 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_899), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_895), make_op_rhs(OP_EQ, make_compvar_primary(tmp_898), make_compvar_primary(tmp_899)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_895));
emit_assign(make_lhs(result_tmps[tmp_894]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_900, *tmp_901;
tmp_900 = args[0][tmp_894];
tmp_901 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_894]), make_op_rhs(OP_POW, make_compvar_primary(tmp_900), make_compvar_primary(tmp_901)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_exp_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_902;

tmp_902 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_903;
tmp_903 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_904, *tmp_905;
tmp_904 = args[0][0];
tmp_905 = args[0][1];
emit_assign(make_lhs(tmp_903), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_904), make_compvar_primary(tmp_905)));
}
emit_assign(make_lhs(tmp_902), make_op_rhs(OP_C_EXP, make_compvar_primary(tmp_903)));
}

{
int tmp_906;
for (tmp_906 = 0; tmp_906 < 2; ++tmp_906)
{
switch (tmp_906)
{
case 0 :
{
compvar_t *tmp_907;
tmp_907 = tmp_902;
emit_assign(make_lhs(result_tmps[tmp_906]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_907)));
}
break;
case 1 :
{
compvar_t *tmp_908;
tmp_908 = tmp_902;
emit_assign(make_lhs(result_tmps[tmp_906]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_908)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_exp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_909;
for (tmp_909 = 0; tmp_909 < 1; ++tmp_909)
{
switch (tmp_909)
{
case 0 :
{
compvar_t *tmp_910;
tmp_910 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_909]), make_op_rhs(OP_EXP, make_compvar_primary(tmp_910)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_log_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_911;

tmp_911 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_912;
tmp_912 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_913, *tmp_914;
tmp_913 = args[0][0];
tmp_914 = args[0][1];
emit_assign(make_lhs(tmp_912), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_913), make_compvar_primary(tmp_914)));
}
emit_assign(make_lhs(tmp_911), make_op_rhs(OP_C_LOG, make_compvar_primary(tmp_912)));
}

{
int tmp_915;
for (tmp_915 = 0; tmp_915 < 2; ++tmp_915)
{
switch (tmp_915)
{
case 0 :
{
compvar_t *tmp_916;
tmp_916 = tmp_911;
emit_assign(make_lhs(result_tmps[tmp_915]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_916)));
}
break;
case 1 :
{
compvar_t *tmp_917;
tmp_917 = tmp_911;
emit_assign(make_lhs(result_tmps[tmp_915]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_917)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_log_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_918;
tmp_918 = make_temporary(TYPE_INT);
{
compvar_t *tmp_919, *tmp_920;
tmp_919 = args[0][0];
tmp_920 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_920), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_918), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_919), make_compvar_primary(tmp_920)));
}
start_if_cond(make_compvar_rhs(tmp_918));
{
int tmp_921;
for (tmp_921 = 0; tmp_921 < 1; ++tmp_921)
{
switch (tmp_921)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_921]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_922;
for (tmp_922 = 0; tmp_922 < 1; ++tmp_922)
{
switch (tmp_922)
{
case 0 :
{
compvar_t *tmp_923;
tmp_923 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_922]), make_op_rhs(OP_LOG, make_compvar_primary(tmp_923)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_arg_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_924;
for (tmp_924 = 0; tmp_924 < 1; ++tmp_924)
{
switch (tmp_924)
{
case 0 :
{
compvar_t *tmp_925;
tmp_925 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_926, *tmp_927;
tmp_926 = args[0][0];
tmp_927 = args[0][1];
emit_assign(make_lhs(tmp_925), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_926), make_compvar_primary(tmp_927)));
}
emit_assign(make_lhs(result_tmps[tmp_924]), make_op_rhs(OP_C_ARG, make_compvar_primary(tmp_925)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_conj_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_928;
for (tmp_928 = 0; tmp_928 < 2; ++tmp_928)
{
switch (tmp_928)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_928]), make_compvar_rhs(args[0][0]));
break;
case 1 :
{
compvar_t *tmp_929;
tmp_929 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_928]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_929)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_930;

tmp_930 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_931;
tmp_931 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_932, *tmp_933;
tmp_932 = args[0][0];
tmp_933 = args[0][1];
emit_assign(make_lhs(tmp_931), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_932), make_compvar_primary(tmp_933)));
}
emit_assign(make_lhs(tmp_930), make_op_rhs(OP_C_SINH, make_compvar_primary(tmp_931)));
}

{
int tmp_934;
for (tmp_934 = 0; tmp_934 < 2; ++tmp_934)
{
switch (tmp_934)
{
case 0 :
{
compvar_t *tmp_935;
tmp_935 = tmp_930;
emit_assign(make_lhs(result_tmps[tmp_934]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_935)));
}
break;
case 1 :
{
compvar_t *tmp_936;
tmp_936 = tmp_930;
emit_assign(make_lhs(result_tmps[tmp_934]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_936)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_937;
for (tmp_937 = 0; tmp_937 < 1; ++tmp_937)
{
switch (tmp_937)
{
case 0 :
{
compvar_t *tmp_938;
tmp_938 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_937]), make_op_rhs(OP_SINH, make_compvar_primary(tmp_938)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_939;

tmp_939 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_940;
tmp_940 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_941, *tmp_942;
tmp_941 = args[0][0];
tmp_942 = args[0][1];
emit_assign(make_lhs(tmp_940), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_941), make_compvar_primary(tmp_942)));
}
emit_assign(make_lhs(tmp_939), make_op_rhs(OP_C_COSH, make_compvar_primary(tmp_940)));
}

{
int tmp_943;
for (tmp_943 = 0; tmp_943 < 2; ++tmp_943)
{
switch (tmp_943)
{
case 0 :
{
compvar_t *tmp_944;
tmp_944 = tmp_939;
emit_assign(make_lhs(result_tmps[tmp_943]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_944)));
}
break;
case 1 :
{
compvar_t *tmp_945;
tmp_945 = tmp_939;
emit_assign(make_lhs(result_tmps[tmp_943]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_945)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_946;
for (tmp_946 = 0; tmp_946 < 1; ++tmp_946)
{
switch (tmp_946)
{
case 0 :
{
compvar_t *tmp_947;
tmp_947 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_946]), make_op_rhs(OP_COSH, make_compvar_primary(tmp_947)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_948;

tmp_948 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_949;
tmp_949 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_950, *tmp_951;
tmp_950 = args[0][0];
tmp_951 = args[0][1];
emit_assign(make_lhs(tmp_949), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_950), make_compvar_primary(tmp_951)));
}
emit_assign(make_lhs(tmp_948), make_op_rhs(OP_C_TANH, make_compvar_primary(tmp_949)));
}

{
int tmp_952;
for (tmp_952 = 0; tmp_952 < 2; ++tmp_952)
{
switch (tmp_952)
{
case 0 :
{
compvar_t *tmp_953;
tmp_953 = tmp_948;
emit_assign(make_lhs(result_tmps[tmp_952]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_953)));
}
break;
case 1 :
{
compvar_t *tmp_954;
tmp_954 = tmp_948;
emit_assign(make_lhs(result_tmps[tmp_952]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_954)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_955;
for (tmp_955 = 0; tmp_955 < 1; ++tmp_955)
{
switch (tmp_955)
{
case 0 :
{
compvar_t *tmp_956;
tmp_956 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_955]), make_op_rhs(OP_TANH, make_compvar_primary(tmp_956)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_957;

tmp_957 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_958;
tmp_958 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_959, *tmp_960;
tmp_959 = args[0][0];
tmp_960 = args[0][1];
emit_assign(make_lhs(tmp_958), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_959), make_compvar_primary(tmp_960)));
}
emit_assign(make_lhs(tmp_957), make_op_rhs(OP_C_ASINH, make_compvar_primary(tmp_958)));
}

{
int tmp_961;
for (tmp_961 = 0; tmp_961 < 2; ++tmp_961)
{
switch (tmp_961)
{
case 0 :
{
compvar_t *tmp_962;
tmp_962 = tmp_957;
emit_assign(make_lhs(result_tmps[tmp_961]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_962)));
}
break;
case 1 :
{
compvar_t *tmp_963;
tmp_963 = tmp_957;
emit_assign(make_lhs(result_tmps[tmp_961]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_963)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_964;
for (tmp_964 = 0; tmp_964 < 1; ++tmp_964)
{
switch (tmp_964)
{
case 0 :
{
compvar_t *tmp_965;
tmp_965 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_964]), make_op_rhs(OP_ASINH, make_compvar_primary(tmp_965)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_966;

tmp_966 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_967;
tmp_967 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_968, *tmp_969;
tmp_968 = args[0][0];
tmp_969 = args[0][1];
emit_assign(make_lhs(tmp_967), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_968), make_compvar_primary(tmp_969)));
}
emit_assign(make_lhs(tmp_966), make_op_rhs(OP_C_ACOSH, make_compvar_primary(tmp_967)));
}

{
int tmp_970;
for (tmp_970 = 0; tmp_970 < 2; ++tmp_970)
{
switch (tmp_970)
{
case 0 :
{
compvar_t *tmp_971;
tmp_971 = tmp_966;
emit_assign(make_lhs(result_tmps[tmp_970]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_971)));
}
break;
case 1 :
{
compvar_t *tmp_972;
tmp_972 = tmp_966;
emit_assign(make_lhs(result_tmps[tmp_970]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_972)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_973;
for (tmp_973 = 0; tmp_973 < 1; ++tmp_973)
{
switch (tmp_973)
{
case 0 :
{
compvar_t *tmp_974;
tmp_974 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_973]), make_op_rhs(OP_ACOSH, make_compvar_primary(tmp_974)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_975;

tmp_975 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_976;
tmp_976 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_977, *tmp_978;
tmp_977 = args[0][0];
tmp_978 = args[0][1];
emit_assign(make_lhs(tmp_976), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_977), make_compvar_primary(tmp_978)));
}
emit_assign(make_lhs(tmp_975), make_op_rhs(OP_C_ATANH, make_compvar_primary(tmp_976)));
}

{
int tmp_979;
for (tmp_979 = 0; tmp_979 < 2; ++tmp_979)
{
switch (tmp_979)
{
case 0 :
{
compvar_t *tmp_980;
tmp_980 = tmp_975;
emit_assign(make_lhs(result_tmps[tmp_979]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_980)));
}
break;
case 1 :
{
compvar_t *tmp_981;
tmp_981 = tmp_975;
emit_assign(make_lhs(result_tmps[tmp_979]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_981)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_982;
for (tmp_982 = 0; tmp_982 < 1; ++tmp_982)
{
switch (tmp_982)
{
case 0 :
{
compvar_t *tmp_983;
tmp_983 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_982]), make_op_rhs(OP_ATANH, make_compvar_primary(tmp_983)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gamma_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_984;

tmp_984 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_985;
tmp_985 = make_temporary(TYPE_COMPLEX);
{
compvar_t *tmp_986, *tmp_987;
tmp_986 = args[0][0];
tmp_987 = args[0][1];
emit_assign(make_lhs(tmp_985), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_986), make_compvar_primary(tmp_987)));
}
emit_assign(make_lhs(tmp_984), make_op_rhs(OP_C_GAMMA, make_compvar_primary(tmp_985)));
}

{
int tmp_988;
for (tmp_988 = 0; tmp_988 < 2; ++tmp_988)
{
switch (tmp_988)
{
case 0 :
{
compvar_t *tmp_989;
tmp_989 = tmp_984;
emit_assign(make_lhs(result_tmps[tmp_988]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_989)));
}
break;
case 1 :
{
compvar_t *tmp_990;
tmp_990 = tmp_984;
emit_assign(make_lhs(result_tmps[tmp_988]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_990)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gamma_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_991;
tmp_991 = make_temporary(TYPE_INT);
{
compvar_t *tmp_992, *tmp_993;
tmp_992 = args[0][0];
tmp_993 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_993), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_991), make_op_rhs(OP_LESS, make_compvar_primary(tmp_992), make_compvar_primary(tmp_993)));
}
start_if_cond(make_compvar_rhs(tmp_991));
{
int tmp_994;
for (tmp_994 = 0; tmp_994 < 1; ++tmp_994)
{
switch (tmp_994)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_994]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_995;
for (tmp_995 = 0; tmp_995 < 1; ++tmp_995)
{
switch (tmp_995)
{
case 0 :
{
compvar_t *tmp_996;
tmp_996 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_995]), make_op_rhs(OP_GAMMA, make_compvar_primary(tmp_996)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_beta_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_997;
tmp_997 = make_temporary(TYPE_INT);
{
compvar_t *tmp_998, *tmp_999;
tmp_998 = args[0][0];
tmp_999 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_999), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_997), make_op_rhs(OP_LESS, make_compvar_primary(tmp_998), make_compvar_primary(tmp_999)));
}
start_if_cond(make_compvar_rhs(tmp_997));
switch_if_branch();
{
compvar_t *tmp_1000, *tmp_1001;
tmp_1000 = args[1][0];
tmp_1001 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1001), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_997), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1000), make_compvar_primary(tmp_1001)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_997));
{
int tmp_1002;
for (tmp_1002 = 0; tmp_1002 < 1; ++tmp_1002)
{
switch (tmp_1002)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1002]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1003;
for (tmp_1003 = 0; tmp_1003 < 1; ++tmp_1003)
{
switch (tmp_1003)
{
case 0 :
{
compvar_t *tmp_1004, *tmp_1005;
tmp_1004 = args[0][0];
tmp_1005 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1003]), make_op_rhs(OP_BETA, make_compvar_primary(tmp_1004), make_compvar_primary(tmp_1005)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_kcomp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1006;
for (tmp_1006 = 0; tmp_1006 < 1; ++tmp_1006)
{
switch (tmp_1006)
{
case 0 :
{
compvar_t *tmp_1007;
tmp_1007 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1006]), make_op_rhs(OP_ELL_INT_K_COMP, make_compvar_primary(tmp_1007)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_ecomp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1008;
for (tmp_1008 = 0; tmp_1008 < 1; ++tmp_1008)
{
switch (tmp_1008)
{
case 0 :
{
compvar_t *tmp_1009;
tmp_1009 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1008]), make_op_rhs(OP_ELL_INT_E_COMP, make_compvar_primary(tmp_1009)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_f (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1010;
for (tmp_1010 = 0; tmp_1010 < 1; ++tmp_1010)
{
switch (tmp_1010)
{
case 0 :
{
compvar_t *tmp_1011, *tmp_1012;
tmp_1011 = args[0][0];
tmp_1012 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1010]), make_op_rhs(OP_ELL_INT_F, make_compvar_primary(tmp_1011), make_compvar_primary(tmp_1012)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_e (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1013;
for (tmp_1013 = 0; tmp_1013 < 1; ++tmp_1013)
{
switch (tmp_1013)
{
case 0 :
{
compvar_t *tmp_1014, *tmp_1015;
tmp_1014 = args[0][0];
tmp_1015 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1013]), make_op_rhs(OP_ELL_INT_E, make_compvar_primary(tmp_1014), make_compvar_primary(tmp_1015)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_p (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1016;
for (tmp_1016 = 0; tmp_1016 < 1; ++tmp_1016)
{
switch (tmp_1016)
{
case 0 :
{
compvar_t *tmp_1017, *tmp_1018, *tmp_1019;
tmp_1017 = args[0][0];
tmp_1018 = args[1][0];
tmp_1019 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1016]), make_op_rhs(OP_ELL_INT_P, make_compvar_primary(tmp_1017), make_compvar_primary(tmp_1018), make_compvar_primary(tmp_1019)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_d (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1020;
for (tmp_1020 = 0; tmp_1020 < 1; ++tmp_1020)
{
switch (tmp_1020)
{
case 0 :
{
compvar_t *tmp_1021, *tmp_1022, *tmp_1023;
tmp_1021 = args[0][0];
tmp_1022 = args[1][0];
tmp_1023 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1020]), make_op_rhs(OP_ELL_INT_D, make_compvar_primary(tmp_1021), make_compvar_primary(tmp_1022), make_compvar_primary(tmp_1023)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rc (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1024;
for (tmp_1024 = 0; tmp_1024 < 1; ++tmp_1024)
{
switch (tmp_1024)
{
case 0 :
{
compvar_t *tmp_1025, *tmp_1026;
tmp_1025 = args[0][0];
tmp_1026 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1024]), make_op_rhs(OP_ELL_INT_RC, make_compvar_primary(tmp_1025), make_compvar_primary(tmp_1026)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rd (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1027;
for (tmp_1027 = 0; tmp_1027 < 1; ++tmp_1027)
{
switch (tmp_1027)
{
case 0 :
{
compvar_t *tmp_1028, *tmp_1029, *tmp_1030;
tmp_1028 = args[0][0];
tmp_1029 = args[1][0];
tmp_1030 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1027]), make_op_rhs(OP_ELL_INT_RD, make_compvar_primary(tmp_1028), make_compvar_primary(tmp_1029), make_compvar_primary(tmp_1030)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rf (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1031;
for (tmp_1031 = 0; tmp_1031 < 1; ++tmp_1031)
{
switch (tmp_1031)
{
case 0 :
{
compvar_t *tmp_1032, *tmp_1033, *tmp_1034;
tmp_1032 = args[0][0];
tmp_1033 = args[1][0];
tmp_1034 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_1031]), make_op_rhs(OP_ELL_INT_RF, make_compvar_primary(tmp_1032), make_compvar_primary(tmp_1033), make_compvar_primary(tmp_1034)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rj (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1035;
for (tmp_1035 = 0; tmp_1035 < 1; ++tmp_1035)
{
switch (tmp_1035)
{
case 0 :
{
compvar_t *tmp_1036, *tmp_1037, *tmp_1038, *tmp_1039;
tmp_1036 = args[0][0];
tmp_1037 = args[1][0];
tmp_1038 = args[2][0];
tmp_1039 = args[3][0];
emit_assign(make_lhs(result_tmps[tmp_1035]), make_op_rhs(OP_ELL_INT_RJ, make_compvar_primary(tmp_1036), make_compvar_primary(tmp_1037), make_compvar_primary(tmp_1038), make_compvar_primary(tmp_1039)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_sn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1040;

tmp_1040 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1041, *tmp_1042;
tmp_1041 = args[0][0];
tmp_1042 = args[1][0];
emit_assign(make_lhs(tmp_1040), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1041), make_compvar_primary(tmp_1042)));
}

{
int tmp_1043;
for (tmp_1043 = 0; tmp_1043 < 1; ++tmp_1043)
{
switch (tmp_1043)
{
case 0 :
{
compvar_t *tmp_1044, *tmp_1045;
tmp_1044 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1044), make_int_const_rhs(0));
tmp_1045 = tmp_1040;
emit_assign(make_lhs(result_tmps[tmp_1043]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1044), make_compvar_primary(tmp_1045)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_cn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1046;

tmp_1046 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1047, *tmp_1048;
tmp_1047 = args[0][0];
tmp_1048 = args[1][0];
emit_assign(make_lhs(tmp_1046), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1047), make_compvar_primary(tmp_1048)));
}

{
int tmp_1049;
for (tmp_1049 = 0; tmp_1049 < 1; ++tmp_1049)
{
switch (tmp_1049)
{
case 0 :
{
compvar_t *tmp_1050, *tmp_1051;
tmp_1050 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1050), make_int_const_rhs(1));
tmp_1051 = tmp_1046;
emit_assign(make_lhs(result_tmps[tmp_1049]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1050), make_compvar_primary(tmp_1051)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_dn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1052;

tmp_1052 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1053, *tmp_1054;
tmp_1053 = args[0][0];
tmp_1054 = args[1][0];
emit_assign(make_lhs(tmp_1052), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1053), make_compvar_primary(tmp_1054)));
}

{
int tmp_1055;
for (tmp_1055 = 0; tmp_1055 < 1; ++tmp_1055)
{
switch (tmp_1055)
{
case 0 :
{
compvar_t *tmp_1056, *tmp_1057;
tmp_1056 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1056), make_int_const_rhs(2));
tmp_1057 = tmp_1052;
emit_assign(make_lhs(result_tmps[tmp_1055]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1056), make_compvar_primary(tmp_1057)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_sn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1058;
compvar_t *tmp_1061;

tmp_1058 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1059, *tmp_1060;
tmp_1059 = args[0][0];
tmp_1060 = args[1][0];
emit_assign(make_lhs(tmp_1058), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1059), make_compvar_primary(tmp_1060)));
}

tmp_1061 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1062, *tmp_1063;
tmp_1062 = args[0][1];
tmp_1063 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1064, *tmp_1065;
tmp_1064 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1064), make_int_const_rhs(1));
tmp_1065 = args[1][0];
emit_assign(make_lhs(tmp_1063), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1064), make_compvar_primary(tmp_1065)));
}
emit_assign(make_lhs(tmp_1061), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1062), make_compvar_primary(tmp_1063)));
}

{
compvar_t *tmp_1066;
compvar_t *tmp_1069;
compvar_t *tmp_1072;
compvar_t *tmp_1075;
compvar_t *tmp_1078;
compvar_t *tmp_1081;

tmp_1066 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1067, *tmp_1068;
tmp_1067 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1067), make_int_const_rhs(0));
tmp_1068 = tmp_1058;
emit_assign(make_lhs(tmp_1066), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1067), make_compvar_primary(tmp_1068)));
}

tmp_1069 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1070, *tmp_1071;
tmp_1070 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1070), make_int_const_rhs(1));
tmp_1071 = tmp_1058;
emit_assign(make_lhs(tmp_1069), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1070), make_compvar_primary(tmp_1071)));
}

tmp_1072 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1073, *tmp_1074;
tmp_1073 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1073), make_int_const_rhs(2));
tmp_1074 = tmp_1058;
emit_assign(make_lhs(tmp_1072), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1073), make_compvar_primary(tmp_1074)));
}

tmp_1075 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1076, *tmp_1077;
tmp_1076 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1076), make_int_const_rhs(0));
tmp_1077 = tmp_1061;
emit_assign(make_lhs(tmp_1075), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1076), make_compvar_primary(tmp_1077)));
}

tmp_1078 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1079, *tmp_1080;
tmp_1079 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1079), make_int_const_rhs(1));
tmp_1080 = tmp_1061;
emit_assign(make_lhs(tmp_1078), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1079), make_compvar_primary(tmp_1080)));
}

tmp_1081 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1082, *tmp_1083;
tmp_1082 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1082), make_int_const_rhs(2));
tmp_1083 = tmp_1061;
emit_assign(make_lhs(tmp_1081), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1082), make_compvar_primary(tmp_1083)));
}

{
compvar_t *tmp_1084;

tmp_1084 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1085, *tmp_1086;
tmp_1085 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1087, *tmp_1088;
tmp_1087 = tmp_1078;
tmp_1088 = tmp_1078;
emit_assign(make_lhs(tmp_1085), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1087), make_compvar_primary(tmp_1088)));
}
tmp_1086 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1089, *tmp_1090;
tmp_1089 = args[1][0];
tmp_1090 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1091, *tmp_1092;
tmp_1091 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1093, *tmp_1094;
tmp_1093 = tmp_1066;
tmp_1094 = tmp_1066;
emit_assign(make_lhs(tmp_1091), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1093), make_compvar_primary(tmp_1094)));
}
tmp_1092 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1095, *tmp_1096;
tmp_1095 = tmp_1075;
tmp_1096 = tmp_1075;
emit_assign(make_lhs(tmp_1092), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1095), make_compvar_primary(tmp_1096)));
}
emit_assign(make_lhs(tmp_1090), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1091), make_compvar_primary(tmp_1092)));
}
emit_assign(make_lhs(tmp_1086), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1089), make_compvar_primary(tmp_1090)));
}
emit_assign(make_lhs(tmp_1084), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1085), make_compvar_primary(tmp_1086)));
}

{
compvar_t *tmp_1097, *tmp_1098;
tmp_1097 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1099, *tmp_1100;
tmp_1099 = tmp_1066;
tmp_1100 = tmp_1081;
emit_assign(make_lhs(tmp_1097), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1099), make_compvar_primary(tmp_1100)));
}
tmp_1098 = tmp_1084;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1097), make_compvar_primary(tmp_1098)));
}
{
compvar_t *tmp_1101, *tmp_1102;
tmp_1101 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1103, *tmp_1104;
tmp_1103 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1105, *tmp_1106;
tmp_1105 = tmp_1069;
tmp_1106 = tmp_1072;
emit_assign(make_lhs(tmp_1103), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1105), make_compvar_primary(tmp_1106)));
}
tmp_1104 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1107, *tmp_1108;
tmp_1107 = tmp_1075;
tmp_1108 = tmp_1078;
emit_assign(make_lhs(tmp_1104), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1107), make_compvar_primary(tmp_1108)));
}
emit_assign(make_lhs(tmp_1101), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1103), make_compvar_primary(tmp_1104)));
}
tmp_1102 = tmp_1084;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1101), make_compvar_primary(tmp_1102)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_cn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1109;
compvar_t *tmp_1112;

tmp_1109 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1110, *tmp_1111;
tmp_1110 = args[0][0];
tmp_1111 = args[1][0];
emit_assign(make_lhs(tmp_1109), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1110), make_compvar_primary(tmp_1111)));
}

tmp_1112 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1113, *tmp_1114;
tmp_1113 = args[0][1];
tmp_1114 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1115, *tmp_1116;
tmp_1115 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1115), make_int_const_rhs(1));
tmp_1116 = args[1][0];
emit_assign(make_lhs(tmp_1114), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1115), make_compvar_primary(tmp_1116)));
}
emit_assign(make_lhs(tmp_1112), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1113), make_compvar_primary(tmp_1114)));
}

{
compvar_t *tmp_1117;
compvar_t *tmp_1120;
compvar_t *tmp_1123;
compvar_t *tmp_1126;
compvar_t *tmp_1129;
compvar_t *tmp_1132;

tmp_1117 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1118, *tmp_1119;
tmp_1118 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1118), make_int_const_rhs(0));
tmp_1119 = tmp_1109;
emit_assign(make_lhs(tmp_1117), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1118), make_compvar_primary(tmp_1119)));
}

tmp_1120 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1121, *tmp_1122;
tmp_1121 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1121), make_int_const_rhs(1));
tmp_1122 = tmp_1109;
emit_assign(make_lhs(tmp_1120), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1121), make_compvar_primary(tmp_1122)));
}

tmp_1123 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1124, *tmp_1125;
tmp_1124 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1124), make_int_const_rhs(2));
tmp_1125 = tmp_1109;
emit_assign(make_lhs(tmp_1123), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1124), make_compvar_primary(tmp_1125)));
}

tmp_1126 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1127, *tmp_1128;
tmp_1127 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1127), make_int_const_rhs(0));
tmp_1128 = tmp_1112;
emit_assign(make_lhs(tmp_1126), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1127), make_compvar_primary(tmp_1128)));
}

tmp_1129 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1130, *tmp_1131;
tmp_1130 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1130), make_int_const_rhs(1));
tmp_1131 = tmp_1112;
emit_assign(make_lhs(tmp_1129), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1130), make_compvar_primary(tmp_1131)));
}

tmp_1132 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1133, *tmp_1134;
tmp_1133 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1133), make_int_const_rhs(2));
tmp_1134 = tmp_1112;
emit_assign(make_lhs(tmp_1132), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1133), make_compvar_primary(tmp_1134)));
}

{
compvar_t *tmp_1135;

tmp_1135 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1136, *tmp_1137;
tmp_1136 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1138, *tmp_1139;
tmp_1138 = tmp_1129;
tmp_1139 = tmp_1129;
emit_assign(make_lhs(tmp_1136), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1138), make_compvar_primary(tmp_1139)));
}
tmp_1137 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1140, *tmp_1141;
tmp_1140 = args[1][0];
tmp_1141 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1142, *tmp_1143;
tmp_1142 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1144, *tmp_1145;
tmp_1144 = tmp_1117;
tmp_1145 = tmp_1117;
emit_assign(make_lhs(tmp_1142), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1144), make_compvar_primary(tmp_1145)));
}
tmp_1143 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1146, *tmp_1147;
tmp_1146 = tmp_1126;
tmp_1147 = tmp_1126;
emit_assign(make_lhs(tmp_1143), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1146), make_compvar_primary(tmp_1147)));
}
emit_assign(make_lhs(tmp_1141), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1142), make_compvar_primary(tmp_1143)));
}
emit_assign(make_lhs(tmp_1137), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1140), make_compvar_primary(tmp_1141)));
}
emit_assign(make_lhs(tmp_1135), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1136), make_compvar_primary(tmp_1137)));
}

{
compvar_t *tmp_1148, *tmp_1149;
tmp_1148 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1150, *tmp_1151;
tmp_1150 = tmp_1120;
tmp_1151 = tmp_1129;
emit_assign(make_lhs(tmp_1148), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1150), make_compvar_primary(tmp_1151)));
}
tmp_1149 = tmp_1135;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1148), make_compvar_primary(tmp_1149)));
}
{
compvar_t *tmp_1152, *tmp_1153;
tmp_1152 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1154;
tmp_1154 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1155, *tmp_1156;
tmp_1155 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1157, *tmp_1158;
tmp_1157 = tmp_1117;
tmp_1158 = tmp_1123;
emit_assign(make_lhs(tmp_1155), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1157), make_compvar_primary(tmp_1158)));
}
tmp_1156 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1159, *tmp_1160;
tmp_1159 = tmp_1126;
tmp_1160 = tmp_1132;
emit_assign(make_lhs(tmp_1156), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1159), make_compvar_primary(tmp_1160)));
}
emit_assign(make_lhs(tmp_1154), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1155), make_compvar_primary(tmp_1156)));
}
emit_assign(make_lhs(tmp_1152), make_op_rhs(OP_NEG, make_compvar_primary(tmp_1154)));
}
tmp_1153 = tmp_1135;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1152), make_compvar_primary(tmp_1153)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_dn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1161;
compvar_t *tmp_1164;

tmp_1161 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1162, *tmp_1163;
tmp_1162 = args[0][0];
tmp_1163 = args[1][0];
emit_assign(make_lhs(tmp_1161), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1162), make_compvar_primary(tmp_1163)));
}

tmp_1164 = make_temporary(TYPE_V3);
{
compvar_t *tmp_1165, *tmp_1166;
tmp_1165 = args[0][1];
tmp_1166 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1167, *tmp_1168;
tmp_1167 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1167), make_int_const_rhs(1));
tmp_1168 = args[1][0];
emit_assign(make_lhs(tmp_1166), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1167), make_compvar_primary(tmp_1168)));
}
emit_assign(make_lhs(tmp_1164), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_1165), make_compvar_primary(tmp_1166)));
}

{
compvar_t *tmp_1169;
compvar_t *tmp_1172;
compvar_t *tmp_1175;
compvar_t *tmp_1178;
compvar_t *tmp_1181;
compvar_t *tmp_1184;

tmp_1169 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1170, *tmp_1171;
tmp_1170 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1170), make_int_const_rhs(0));
tmp_1171 = tmp_1161;
emit_assign(make_lhs(tmp_1169), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1170), make_compvar_primary(tmp_1171)));
}

tmp_1172 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1173, *tmp_1174;
tmp_1173 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1173), make_int_const_rhs(1));
tmp_1174 = tmp_1161;
emit_assign(make_lhs(tmp_1172), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1173), make_compvar_primary(tmp_1174)));
}

tmp_1175 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1176, *tmp_1177;
tmp_1176 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1176), make_int_const_rhs(2));
tmp_1177 = tmp_1161;
emit_assign(make_lhs(tmp_1175), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1176), make_compvar_primary(tmp_1177)));
}

tmp_1178 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1179, *tmp_1180;
tmp_1179 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1179), make_int_const_rhs(0));
tmp_1180 = tmp_1164;
emit_assign(make_lhs(tmp_1178), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1179), make_compvar_primary(tmp_1180)));
}

tmp_1181 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1182, *tmp_1183;
tmp_1182 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1182), make_int_const_rhs(1));
tmp_1183 = tmp_1164;
emit_assign(make_lhs(tmp_1181), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1182), make_compvar_primary(tmp_1183)));
}

tmp_1184 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1185, *tmp_1186;
tmp_1185 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1185), make_int_const_rhs(2));
tmp_1186 = tmp_1164;
emit_assign(make_lhs(tmp_1184), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1185), make_compvar_primary(tmp_1186)));
}

{
compvar_t *tmp_1187;

tmp_1187 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1188, *tmp_1189;
tmp_1188 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1190, *tmp_1191;
tmp_1190 = tmp_1181;
tmp_1191 = tmp_1181;
emit_assign(make_lhs(tmp_1188), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1190), make_compvar_primary(tmp_1191)));
}
tmp_1189 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1192, *tmp_1193;
tmp_1192 = args[1][0];
tmp_1193 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1194, *tmp_1195;
tmp_1194 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1196, *tmp_1197;
tmp_1196 = tmp_1169;
tmp_1197 = tmp_1169;
emit_assign(make_lhs(tmp_1194), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1196), make_compvar_primary(tmp_1197)));
}
tmp_1195 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1198, *tmp_1199;
tmp_1198 = tmp_1178;
tmp_1199 = tmp_1178;
emit_assign(make_lhs(tmp_1195), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1198), make_compvar_primary(tmp_1199)));
}
emit_assign(make_lhs(tmp_1193), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1194), make_compvar_primary(tmp_1195)));
}
emit_assign(make_lhs(tmp_1189), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1192), make_compvar_primary(tmp_1193)));
}
emit_assign(make_lhs(tmp_1187), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1188), make_compvar_primary(tmp_1189)));
}

{
compvar_t *tmp_1200, *tmp_1201;
tmp_1200 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1202, *tmp_1203;
tmp_1202 = tmp_1181;
tmp_1203 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1204, *tmp_1205;
tmp_1204 = tmp_1175;
tmp_1205 = tmp_1184;
emit_assign(make_lhs(tmp_1203), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1204), make_compvar_primary(tmp_1205)));
}
emit_assign(make_lhs(tmp_1200), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1202), make_compvar_primary(tmp_1203)));
}
tmp_1201 = tmp_1187;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1200), make_compvar_primary(tmp_1201)));
}
{
compvar_t *tmp_1206, *tmp_1207;
tmp_1206 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1208, *tmp_1209;
tmp_1208 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1210, *tmp_1211;
tmp_1210 = tmp_1169;
tmp_1211 = tmp_1178;
emit_assign(make_lhs(tmp_1208), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1210), make_compvar_primary(tmp_1211)));
}
tmp_1209 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1212, *tmp_1213;
tmp_1212 = args[1][0];
tmp_1213 = tmp_1172;
emit_assign(make_lhs(tmp_1209), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1212), make_compvar_primary(tmp_1213)));
}
emit_assign(make_lhs(tmp_1206), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1208), make_compvar_primary(tmp_1209)));
}
tmp_1207 = tmp_1187;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1206), make_compvar_primary(tmp_1207)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_floor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1214;
for (tmp_1214 = 0; tmp_1214 < 1; ++tmp_1214)
{
switch (tmp_1214)
{
case 0 :
{
compvar_t *tmp_1215;
tmp_1215 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1214]), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1215)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ceil (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1216;
for (tmp_1216 = 0; tmp_1216 < 1; ++tmp_1216)
{
switch (tmp_1216)
{
case 0 :
{
compvar_t *tmp_1217;
tmp_1217 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1216]), make_op_rhs(OP_CEIL, make_compvar_primary(tmp_1217)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sign_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1218;
for (tmp_1218 = 0; tmp_1218 < arglengths[0]; ++tmp_1218)
{
{
compvar_t *tmp_1219;
tmp_1219 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1220, *tmp_1221;
tmp_1220 = args[0][tmp_1218];
tmp_1221 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1221), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1219), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1220), make_compvar_primary(tmp_1221)));
}
start_if_cond(make_compvar_rhs(tmp_1219));
emit_assign(make_lhs(result_tmps[tmp_1218]), make_int_const_rhs(-1));
switch_if_branch();
{
compvar_t *tmp_1222;
tmp_1222 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1223, *tmp_1224;
tmp_1223 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1223), make_int_const_rhs(0));
tmp_1224 = args[0][tmp_1218];
emit_assign(make_lhs(tmp_1222), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1223), make_compvar_primary(tmp_1224)));
}
start_if_cond(make_compvar_rhs(tmp_1222));
emit_assign(make_lhs(result_tmps[tmp_1218]), make_int_const_rhs(1));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1218]), make_int_const_rhs(0));
end_if_cond();
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_min_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1225;
for (tmp_1225 = 0; tmp_1225 < arglengths[0]; ++tmp_1225)
{
{
compvar_t *tmp_1226;
tmp_1226 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1227, *tmp_1228;
tmp_1227 = args[0][tmp_1225];
tmp_1228 = args[1][tmp_1225];
emit_assign(make_lhs(tmp_1226), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1227), make_compvar_primary(tmp_1228)));
}
start_if_cond(make_compvar_rhs(tmp_1226));
emit_assign(make_lhs(result_tmps[tmp_1225]), make_compvar_rhs(args[0][tmp_1225]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1225]), make_compvar_rhs(args[1][tmp_1225]));
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_max_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1229;
for (tmp_1229 = 0; tmp_1229 < arglengths[0]; ++tmp_1229)
{
{
compvar_t *tmp_1230;
tmp_1230 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1231, *tmp_1232;
tmp_1231 = args[0][tmp_1229];
tmp_1232 = args[1][tmp_1229];
emit_assign(make_lhs(tmp_1230), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1231), make_compvar_primary(tmp_1232)));
}
start_if_cond(make_compvar_rhs(tmp_1230));
emit_assign(make_lhs(result_tmps[tmp_1229]), make_compvar_rhs(args[1][tmp_1229]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1229]), make_compvar_rhs(args[0][tmp_1229]));
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_clamp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1233;
for (tmp_1233 = 0; tmp_1233 < arglengths[0]; ++tmp_1233)
{
{
compvar_t *tmp_1234;
tmp_1234 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1235, *tmp_1236;
tmp_1235 = args[0][tmp_1233];
tmp_1236 = args[1][tmp_1233];
emit_assign(make_lhs(tmp_1234), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1235), make_compvar_primary(tmp_1236)));
}
start_if_cond(make_compvar_rhs(tmp_1234));
emit_assign(make_lhs(result_tmps[tmp_1233]), make_compvar_rhs(args[1][tmp_1233]));
switch_if_branch();
{
compvar_t *tmp_1237;
tmp_1237 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1238, *tmp_1239;
tmp_1238 = args[2][tmp_1233];
tmp_1239 = args[0][tmp_1233];
emit_assign(make_lhs(tmp_1237), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1238), make_compvar_primary(tmp_1239)));
}
start_if_cond(make_compvar_rhs(tmp_1237));
emit_assign(make_lhs(result_tmps[tmp_1233]), make_compvar_rhs(args[2][tmp_1233]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_1233]), make_compvar_rhs(args[0][tmp_1233]));
end_if_cond();
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lerp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[1]];
int i;
for (i = 0; i < arglengths[1]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1240;

tmp_1240 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1241, *tmp_1242;
tmp_1241 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1241), make_int_const_rhs(1));
tmp_1242 = args[0][0];
emit_assign(make_lhs(tmp_1240), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1241), make_compvar_primary(tmp_1242)));
}

{
int tmp_1243;
for (tmp_1243 = 0; tmp_1243 < arglengths[1]; ++tmp_1243)
{
{
compvar_t *tmp_1244, *tmp_1245;
tmp_1244 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1246, *tmp_1247;
tmp_1246 = tmp_1240;
tmp_1247 = args[1][tmp_1243];
emit_assign(make_lhs(tmp_1244), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1246), make_compvar_primary(tmp_1247)));
}
tmp_1245 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1248, *tmp_1249;
tmp_1248 = args[0][0];
tmp_1249 = args[2][tmp_1243];
emit_assign(make_lhs(tmp_1245), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1248), make_compvar_primary(tmp_1249)));
}
emit_assign(make_lhs(result_tmps[tmp_1243]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1244), make_compvar_primary(tmp_1245)));
}
}
}
}
for (i = 0; i < arglengths[1]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lerp_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1250;
for (tmp_1250 = 0; tmp_1250 < arglengths[1]; ++tmp_1250)
{
{
compvar_t *tmp_1251, *tmp_1252;
tmp_1251 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1253, *tmp_1254;
tmp_1253 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1255, *tmp_1256;
tmp_1255 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1255), make_int_const_rhs(1));
tmp_1256 = args[0][tmp_1250];
emit_assign(make_lhs(tmp_1253), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1255), make_compvar_primary(tmp_1256)));
}
tmp_1254 = args[1][tmp_1250];
emit_assign(make_lhs(tmp_1251), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1253), make_compvar_primary(tmp_1254)));
}
tmp_1252 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1257, *tmp_1258;
tmp_1257 = args[0][tmp_1250];
tmp_1258 = args[2][tmp_1250];
emit_assign(make_lhs(tmp_1252), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1257), make_compvar_primary(tmp_1258)));
}
emit_assign(make_lhs(result_tmps[tmp_1250]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1251), make_compvar_primary(tmp_1252)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_scale (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1259;
for (tmp_1259 = 0; tmp_1259 < arglengths[0]; ++tmp_1259)
{
{
compvar_t *tmp_1260;

tmp_1260 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1261, *tmp_1262;
tmp_1261 = args[2][tmp_1259];
tmp_1262 = args[1][tmp_1259];
emit_assign(make_lhs(tmp_1260), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1261), make_compvar_primary(tmp_1262)));
}

{
compvar_t *tmp_1263;
tmp_1263 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1264, *tmp_1265;
tmp_1264 = tmp_1260;
tmp_1265 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1265), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1263), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1264), make_compvar_primary(tmp_1265)));
}
start_if_cond(make_compvar_rhs(tmp_1263));
emit_assign(make_lhs(result_tmps[tmp_1259]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1266, *tmp_1267;
tmp_1266 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1268, *tmp_1269;
tmp_1268 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1270, *tmp_1271;
tmp_1270 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1272, *tmp_1273;
tmp_1272 = args[0][tmp_1259];
tmp_1273 = args[1][tmp_1259];
emit_assign(make_lhs(tmp_1270), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1272), make_compvar_primary(tmp_1273)));
}
tmp_1271 = tmp_1260;
emit_assign(make_lhs(tmp_1268), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1270), make_compvar_primary(tmp_1271)));
}
tmp_1269 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1274, *tmp_1275;
tmp_1274 = args[4][tmp_1259];
tmp_1275 = args[3][tmp_1259];
emit_assign(make_lhs(tmp_1269), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1274), make_compvar_primary(tmp_1275)));
}
emit_assign(make_lhs(tmp_1266), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1268), make_compvar_primary(tmp_1269)));
}
tmp_1267 = args[3][tmp_1259];
emit_assign(make_lhs(result_tmps[tmp_1259]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1266), make_compvar_primary(tmp_1267)));
}
end_if_cond();
}
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_not (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1276;
tmp_1276 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1277, *tmp_1278;
tmp_1277 = args[0][0];
tmp_1278 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1278), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1276), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1277), make_compvar_primary(tmp_1278)));
}
start_if_cond(make_compvar_rhs(tmp_1276));
{
int tmp_1279;
for (tmp_1279 = 0; tmp_1279 < 1; ++tmp_1279)
{
switch (tmp_1279)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1279]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1280;
for (tmp_1280 = 0; tmp_1280 < 1; ++tmp_1280)
{
switch (tmp_1280)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1280]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_or (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1281;
tmp_1281 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1282, *tmp_1283;
tmp_1282 = args[0][0];
tmp_1283 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1283), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1281), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1282), make_compvar_primary(tmp_1283)));
}
start_if_cond(make_compvar_rhs(tmp_1281));
{
compvar_t *tmp_1284, *tmp_1285;
tmp_1284 = args[1][0];
tmp_1285 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1285), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1281), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1284), make_compvar_primary(tmp_1285)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1281));
{
int tmp_1286;
for (tmp_1286 = 0; tmp_1286 < 1; ++tmp_1286)
{
switch (tmp_1286)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1286]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1287;
for (tmp_1287 = 0; tmp_1287 < 1; ++tmp_1287)
{
switch (tmp_1287)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1287]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_and (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1288;
tmp_1288 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1289, *tmp_1290;
tmp_1289 = args[0][0];
tmp_1290 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1290), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1288), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1289), make_compvar_primary(tmp_1290)));
}
start_if_cond(make_compvar_rhs(tmp_1288));
switch_if_branch();
{
compvar_t *tmp_1291, *tmp_1292;
tmp_1291 = args[1][0];
tmp_1292 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1292), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1288), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1291), make_compvar_primary(tmp_1292)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1288));
{
int tmp_1293;
for (tmp_1293 = 0; tmp_1293 < 1; ++tmp_1293)
{
switch (tmp_1293)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1293]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1294;
for (tmp_1294 = 0; tmp_1294 < 1; ++tmp_1294)
{
switch (tmp_1294)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1294]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_xor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1295;
tmp_1295 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1296, *tmp_1297;
tmp_1296 = args[0][0];
tmp_1297 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1297), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1295), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1296), make_compvar_primary(tmp_1297)));
}
emit_assign(make_lhs(tmp_1295), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1295)));
start_if_cond(make_compvar_rhs(tmp_1295));
{
compvar_t *tmp_1298, *tmp_1299;
tmp_1298 = args[1][0];
tmp_1299 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1299), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1295), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1298), make_compvar_primary(tmp_1299)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1295));
switch_if_branch();
{
compvar_t *tmp_1300, *tmp_1301;
tmp_1300 = args[1][0];
tmp_1301 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1301), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1295), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1300), make_compvar_primary(tmp_1301)));
}
emit_assign(make_lhs(tmp_1295), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1295)));
start_if_cond(make_compvar_rhs(tmp_1295));
{
compvar_t *tmp_1302, *tmp_1303;
tmp_1302 = args[0][0];
tmp_1303 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1303), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1295), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1302), make_compvar_primary(tmp_1303)));
}
switch_if_branch();
end_if_cond();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1295));
{
int tmp_1304;
for (tmp_1304 = 0; tmp_1304 < 1; ++tmp_1304)
{
switch (tmp_1304)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1304]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1305;
for (tmp_1305 = 0; tmp_1305 < 1; ++tmp_1305)
{
switch (tmp_1305)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1305]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_equal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1306;
for (tmp_1306 = 0; tmp_1306 < 1; ++tmp_1306)
{
switch (tmp_1306)
{
case 0 :
{
compvar_t *tmp_1307, *tmp_1308;
tmp_1307 = args[0][0];
tmp_1308 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1306]), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1307), make_compvar_primary(tmp_1308)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_less (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1309;
for (tmp_1309 = 0; tmp_1309 < 1; ++tmp_1309)
{
switch (tmp_1309)
{
case 0 :
{
compvar_t *tmp_1310, *tmp_1311;
tmp_1310 = args[0][0];
tmp_1311 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1309]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1310), make_compvar_primary(tmp_1311)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_greater (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1312;
for (tmp_1312 = 0; tmp_1312 < 1; ++tmp_1312)
{
switch (tmp_1312)
{
case 0 :
{
compvar_t *tmp_1313, *tmp_1314;
tmp_1313 = args[1][0];
tmp_1314 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1312]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1313), make_compvar_primary(tmp_1314)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lessequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1315;
for (tmp_1315 = 0; tmp_1315 < 1; ++tmp_1315)
{
switch (tmp_1315)
{
case 0 :
{
compvar_t *tmp_1316, *tmp_1317;
tmp_1316 = args[0][0];
tmp_1317 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1315]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1316), make_compvar_primary(tmp_1317)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_greaterequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1318;
for (tmp_1318 = 0; tmp_1318 < 1; ++tmp_1318)
{
switch (tmp_1318)
{
case 0 :
{
compvar_t *tmp_1319, *tmp_1320;
tmp_1319 = args[1][0];
tmp_1320 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1318]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1319), make_compvar_primary(tmp_1320)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_notequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1321;
for (tmp_1321 = 0; tmp_1321 < 1; ++tmp_1321)
{
switch (tmp_1321)
{
case 0 :
{
compvar_t *tmp_1322;
tmp_1322 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1323, *tmp_1324;
tmp_1323 = args[0][0];
tmp_1324 = args[1][0];
emit_assign(make_lhs(tmp_1322), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1323), make_compvar_primary(tmp_1324)));
}
emit_assign(make_lhs(result_tmps[tmp_1321]), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1322)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_inintv (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1325;
tmp_1325 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1326, *tmp_1327;
tmp_1326 = args[1][0];
tmp_1327 = args[0][0];
emit_assign(make_lhs(tmp_1325), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1326), make_compvar_primary(tmp_1327)));
}
start_if_cond(make_compvar_rhs(tmp_1325));
{
compvar_t *tmp_1328, *tmp_1329;
tmp_1328 = args[0][0];
tmp_1329 = args[2][0];
emit_assign(make_lhs(tmp_1325), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1328), make_compvar_primary(tmp_1329)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1325));
{
int tmp_1330;
for (tmp_1330 = 0; tmp_1330 < 1; ++tmp_1330)
{
switch (tmp_1330)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1330]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1331;
for (tmp_1331 = 0; tmp_1331 < 1; ++tmp_1331)
{
switch (tmp_1331)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1331]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_origvalxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1332;

tmp_1332 = make_temporary(TYPE_TUPLE);
{
compvar_t *tmp_1333, *tmp_1334, *tmp_1335, *tmp_1336;
tmp_1333 = args[0][0];
tmp_1334 = args[0][1];
tmp_1335 = args[2][0];
tmp_1336 = args[1][0];
emit_assign(make_lhs(tmp_1332), make_op_rhs(OP_ORIG_VAL, make_compvar_primary(tmp_1333), make_compvar_primary(tmp_1334), make_compvar_primary(tmp_1335), make_compvar_primary(tmp_1336)));
}

{
int tmp_1337;
for (tmp_1337 = 0; tmp_1337 < 4; ++tmp_1337)
{
switch (tmp_1337)
{
case 0 :
{
compvar_t *tmp_1338, *tmp_1339;
tmp_1338 = tmp_1332;
tmp_1339 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1339), make_int_const_rhs(0));
emit_assign(make_lhs(result_tmps[tmp_1337]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1338), make_compvar_primary(tmp_1339)));
}
break;
case 1 :
{
compvar_t *tmp_1340, *tmp_1341;
tmp_1340 = tmp_1332;
tmp_1341 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1341), make_int_const_rhs(1));
emit_assign(make_lhs(result_tmps[tmp_1337]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1340), make_compvar_primary(tmp_1341)));
}
break;
case 2 :
{
compvar_t *tmp_1342, *tmp_1343;
tmp_1342 = tmp_1332;
tmp_1343 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1343), make_int_const_rhs(2));
emit_assign(make_lhs(result_tmps[tmp_1337]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1342), make_compvar_primary(tmp_1343)));
}
break;
case 3 :
{
compvar_t *tmp_1344, *tmp_1345;
tmp_1344 = tmp_1332;
tmp_1345 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1345), make_int_const_rhs(3));
emit_assign(make_lhs(result_tmps[tmp_1337]), make_op_rhs(OP_TUPLE_NTH, make_compvar_primary(tmp_1344), make_compvar_primary(tmp_1345)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_red (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1346;
for (tmp_1346 = 0; tmp_1346 < 1; ++tmp_1346)
{
switch (tmp_1346)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1346]), make_compvar_rhs(args[0][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_green (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1347;
for (tmp_1347 = 0; tmp_1347 < 1; ++tmp_1347)
{
switch (tmp_1347)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1347]), make_compvar_rhs(args[0][1]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_blue (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1348;
for (tmp_1348 = 0; tmp_1348 < 1; ++tmp_1348)
{
switch (tmp_1348)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1348]), make_compvar_rhs(args[0][2]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_alpha (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1349;
for (tmp_1349 = 0; tmp_1349 < 1; ++tmp_1349)
{
switch (tmp_1349)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1349]), make_compvar_rhs(args[0][3]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gray (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1350;
for (tmp_1350 = 0; tmp_1350 < 1; ++tmp_1350)
{
switch (tmp_1350)
{
case 0 :
{
compvar_t *tmp_1351, *tmp_1352;
tmp_1351 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1353, *tmp_1354;
tmp_1353 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1355, *tmp_1356;
tmp_1355 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1355), make_float_const_rhs(0.299));
tmp_1356 = args[0][0];
emit_assign(make_lhs(tmp_1353), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1355), make_compvar_primary(tmp_1356)));
}
tmp_1354 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1357, *tmp_1358;
tmp_1357 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1357), make_float_const_rhs(0.587));
tmp_1358 = args[0][1];
emit_assign(make_lhs(tmp_1354), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1357), make_compvar_primary(tmp_1358)));
}
emit_assign(make_lhs(tmp_1351), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1353), make_compvar_primary(tmp_1354)));
}
tmp_1352 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1359, *tmp_1360;
tmp_1359 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1359), make_float_const_rhs(0.114));
tmp_1360 = args[0][2];
emit_assign(make_lhs(tmp_1352), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1359), make_compvar_primary(tmp_1360)));
}
emit_assign(make_lhs(result_tmps[tmp_1350]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1351), make_compvar_primary(tmp_1352)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rgbcolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1361;
for (tmp_1361 = 0; tmp_1361 < 4; ++tmp_1361)
{
switch (tmp_1361)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1361]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1361]), make_compvar_rhs(args[1][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1361]), make_compvar_rhs(args[2][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1361]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rgbacolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1362;
for (tmp_1362 = 0; tmp_1362 < 4; ++tmp_1362)
{
switch (tmp_1362)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1362]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1362]), make_compvar_rhs(args[1][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1362]), make_compvar_rhs(args[2][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1362]), make_compvar_rhs(args[3][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_graycolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1363;
for (tmp_1363 = 0; tmp_1363 < 4; ++tmp_1363)
{
switch (tmp_1363)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1363]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1363]), make_compvar_rhs(args[0][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1363]), make_compvar_rhs(args[0][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1363]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_grayacolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1364;
for (tmp_1364 = 0; tmp_1364 < 4; ++tmp_1364)
{
switch (tmp_1364)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1364]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1364]), make_compvar_rhs(args[0][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1364]), make_compvar_rhs(args[0][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1364]), make_compvar_rhs(args[1][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tohsva (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1365;
compvar_t *tmp_1370;
compvar_t *tmp_1375;

tmp_1365 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1366, *tmp_1367;
tmp_1366 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1366), make_int_const_rhs(0));
tmp_1367 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1368, *tmp_1369;
tmp_1368 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1368), make_int_const_rhs(1));
tmp_1369 = args[0][0];
emit_assign(make_lhs(tmp_1367), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1368), make_compvar_primary(tmp_1369)));
}
emit_assign(make_lhs(tmp_1365), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1366), make_compvar_primary(tmp_1367)));
}

tmp_1370 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1371, *tmp_1372;
tmp_1371 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1371), make_int_const_rhs(0));
tmp_1372 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1373, *tmp_1374;
tmp_1373 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1373), make_int_const_rhs(1));
tmp_1374 = args[0][1];
emit_assign(make_lhs(tmp_1372), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1373), make_compvar_primary(tmp_1374)));
}
emit_assign(make_lhs(tmp_1370), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1371), make_compvar_primary(tmp_1372)));
}

tmp_1375 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1376, *tmp_1377;
tmp_1376 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1376), make_int_const_rhs(0));
tmp_1377 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1378, *tmp_1379;
tmp_1378 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1378), make_int_const_rhs(1));
tmp_1379 = args[0][2];
emit_assign(make_lhs(tmp_1377), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1378), make_compvar_primary(tmp_1379)));
}
emit_assign(make_lhs(tmp_1375), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1376), make_compvar_primary(tmp_1377)));
}

{
compvar_t *tmp_1380, *tmp_1381;
tmp_1380 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1380), make_int_const_rhs(0));
tmp_1381 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1382, *tmp_1383;
tmp_1382 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1382), make_int_const_rhs(1));
tmp_1383 = args[0][3];
emit_assign(make_lhs(tmp_1381), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1382), make_compvar_primary(tmp_1383)));
}
emit_assign(make_lhs(result_tmps[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1380), make_compvar_primary(tmp_1381)));
}
{
compvar_t *tmp_1384;
compvar_t *tmp_1389;

tmp_1384 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1385, *tmp_1386;
tmp_1385 = tmp_1365;
tmp_1386 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1387, *tmp_1388;
tmp_1387 = tmp_1370;
tmp_1388 = tmp_1375;
emit_assign(make_lhs(tmp_1386), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1387), make_compvar_primary(tmp_1388)));
}
emit_assign(make_lhs(tmp_1384), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1385), make_compvar_primary(tmp_1386)));
}

tmp_1389 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1390, *tmp_1391;
tmp_1390 = tmp_1365;
tmp_1391 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1392, *tmp_1393;
tmp_1392 = tmp_1370;
tmp_1393 = tmp_1375;
emit_assign(make_lhs(tmp_1391), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1392), make_compvar_primary(tmp_1393)));
}
emit_assign(make_lhs(tmp_1389), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1390), make_compvar_primary(tmp_1391)));
}

emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1384));
{
compvar_t *tmp_1394;
tmp_1394 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1395, *tmp_1396;
tmp_1395 = tmp_1384;
tmp_1396 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1396), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1394), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1395), make_compvar_primary(tmp_1396)));
}
start_if_cond(make_compvar_rhs(tmp_1394));
emit_assign(make_lhs(result_tmps[0]), make_int_const_rhs(0));
emit_assign(make_lhs(result_tmps[1]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1397;
compvar_t *tmp_1400;

tmp_1397 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1398, *tmp_1399;
tmp_1398 = tmp_1384;
tmp_1399 = tmp_1389;
emit_assign(make_lhs(tmp_1397), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1398), make_compvar_primary(tmp_1399)));
}

tmp_1400 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1400), make_int_const_rhs(0));

{
compvar_t *tmp_1401, *tmp_1402;
tmp_1401 = tmp_1397;
tmp_1402 = tmp_1384;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1401), make_compvar_primary(tmp_1402)));
}
{
compvar_t *tmp_1403;
tmp_1403 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1404, *tmp_1405;
tmp_1404 = tmp_1365;
tmp_1405 = tmp_1384;
emit_assign(make_lhs(tmp_1403), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1404), make_compvar_primary(tmp_1405)));
}
start_if_cond(make_compvar_rhs(tmp_1403));
{
compvar_t *tmp_1406, *tmp_1407;
tmp_1406 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1408, *tmp_1409;
tmp_1408 = tmp_1370;
tmp_1409 = tmp_1375;
emit_assign(make_lhs(tmp_1406), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1408), make_compvar_primary(tmp_1409)));
}
tmp_1407 = tmp_1397;
emit_assign(make_lhs(tmp_1400), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1406), make_compvar_primary(tmp_1407)));
}
switch_if_branch();
{
compvar_t *tmp_1410;
tmp_1410 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1411, *tmp_1412;
tmp_1411 = tmp_1370;
tmp_1412 = tmp_1384;
emit_assign(make_lhs(tmp_1410), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1411), make_compvar_primary(tmp_1412)));
}
start_if_cond(make_compvar_rhs(tmp_1410));
{
compvar_t *tmp_1413, *tmp_1414;
tmp_1413 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1413), make_int_const_rhs(2));
tmp_1414 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1415, *tmp_1416;
tmp_1415 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1417, *tmp_1418;
tmp_1417 = tmp_1375;
tmp_1418 = tmp_1365;
emit_assign(make_lhs(tmp_1415), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1417), make_compvar_primary(tmp_1418)));
}
tmp_1416 = tmp_1397;
emit_assign(make_lhs(tmp_1414), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1415), make_compvar_primary(tmp_1416)));
}
emit_assign(make_lhs(tmp_1400), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1413), make_compvar_primary(tmp_1414)));
}
switch_if_branch();
{
compvar_t *tmp_1419, *tmp_1420;
tmp_1419 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1419), make_int_const_rhs(4));
tmp_1420 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1421, *tmp_1422;
tmp_1421 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1423, *tmp_1424;
tmp_1423 = tmp_1365;
tmp_1424 = tmp_1370;
emit_assign(make_lhs(tmp_1421), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1423), make_compvar_primary(tmp_1424)));
}
tmp_1422 = tmp_1397;
emit_assign(make_lhs(tmp_1420), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1421), make_compvar_primary(tmp_1422)));
}
emit_assign(make_lhs(tmp_1400), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1419), make_compvar_primary(tmp_1420)));
}
end_if_cond();
}
end_if_cond();
}
{
compvar_t *tmp_1425, *tmp_1426;
tmp_1425 = tmp_1400;
tmp_1426 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1426), make_float_const_rhs(6.0));
emit_assign(make_lhs(tmp_1400), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1425), make_compvar_primary(tmp_1426)));
}
{
compvar_t *tmp_1427;
tmp_1427 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1428, *tmp_1429;
tmp_1428 = tmp_1400;
tmp_1429 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1429), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1427), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1428), make_compvar_primary(tmp_1429)));
}
start_if_cond(make_compvar_rhs(tmp_1427));
{
compvar_t *tmp_1430, *tmp_1431;
tmp_1430 = tmp_1400;
tmp_1431 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1431), make_int_const_rhs(1));
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1430), make_compvar_primary(tmp_1431)));
}
switch_if_branch();
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1400));
end_if_cond();
}
}
end_if_cond();
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_torgba (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1432;
compvar_t *tmp_1437;

tmp_1432 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1433, *tmp_1434;
tmp_1433 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1433), make_int_const_rhs(0));
tmp_1434 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1435, *tmp_1436;
tmp_1435 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1435), make_int_const_rhs(1));
tmp_1436 = args[0][1];
emit_assign(make_lhs(tmp_1434), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1435), make_compvar_primary(tmp_1436)));
}
emit_assign(make_lhs(tmp_1432), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1433), make_compvar_primary(tmp_1434)));
}

tmp_1437 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1438, *tmp_1439;
tmp_1438 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1438), make_int_const_rhs(0));
tmp_1439 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1440, *tmp_1441;
tmp_1440 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1440), make_int_const_rhs(1));
tmp_1441 = args[0][2];
emit_assign(make_lhs(tmp_1439), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1440), make_compvar_primary(tmp_1441)));
}
emit_assign(make_lhs(tmp_1437), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1438), make_compvar_primary(tmp_1439)));
}

{
compvar_t *tmp_1442, *tmp_1443;
tmp_1442 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1442), make_int_const_rhs(0));
tmp_1443 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1444, *tmp_1445;
tmp_1444 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1444), make_int_const_rhs(1));
tmp_1445 = args[0][3];
emit_assign(make_lhs(tmp_1443), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1444), make_compvar_primary(tmp_1445)));
}
emit_assign(make_lhs(result_tmps[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1442), make_compvar_primary(tmp_1443)));
}
{
compvar_t *tmp_1446;
tmp_1446 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1447, *tmp_1448;
tmp_1447 = tmp_1432;
tmp_1448 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1448), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1446), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1447), make_compvar_primary(tmp_1448)));
}
start_if_cond(make_compvar_rhs(tmp_1446));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1437));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1437));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1437));
switch_if_branch();
{
compvar_t *tmp_1449;

tmp_1449 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1450, *tmp_1451;
tmp_1450 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1450), make_int_const_rhs(0));
tmp_1451 = args[0][0];
emit_assign(make_lhs(tmp_1449), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1450), make_compvar_primary(tmp_1451)));
}

{
compvar_t *tmp_1452;
tmp_1452 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1453, *tmp_1454;
tmp_1453 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1453), make_int_const_rhs(1));
tmp_1454 = tmp_1449;
emit_assign(make_lhs(tmp_1452), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1453), make_compvar_primary(tmp_1454)));
}
start_if_cond(make_compvar_rhs(tmp_1452));
emit_assign(make_lhs(tmp_1449), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1455, *tmp_1456;
tmp_1455 = tmp_1449;
tmp_1456 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1456), make_int_const_rhs(6));
emit_assign(make_lhs(tmp_1449), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1455), make_compvar_primary(tmp_1456)));
}
end_if_cond();
}
{
compvar_t *tmp_1457;

tmp_1457 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1458;
tmp_1458 = tmp_1449;
emit_assign(make_lhs(tmp_1457), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1458)));
}

{
compvar_t *tmp_1459;

tmp_1459 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1460, *tmp_1461;
tmp_1460 = tmp_1449;
tmp_1461 = tmp_1457;
emit_assign(make_lhs(tmp_1459), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1460), make_compvar_primary(tmp_1461)));
}

{
compvar_t *tmp_1462;
compvar_t *tmp_1467;
compvar_t *tmp_1474;

tmp_1462 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1463, *tmp_1464;
tmp_1463 = tmp_1437;
tmp_1464 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1465, *tmp_1466;
tmp_1465 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1465), make_int_const_rhs(1));
tmp_1466 = tmp_1432;
emit_assign(make_lhs(tmp_1464), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1465), make_compvar_primary(tmp_1466)));
}
emit_assign(make_lhs(tmp_1462), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1463), make_compvar_primary(tmp_1464)));
}

tmp_1467 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1468, *tmp_1469;
tmp_1468 = tmp_1437;
tmp_1469 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1470, *tmp_1471;
tmp_1470 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1470), make_int_const_rhs(1));
tmp_1471 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1472, *tmp_1473;
tmp_1472 = tmp_1432;
tmp_1473 = tmp_1459;
emit_assign(make_lhs(tmp_1471), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1472), make_compvar_primary(tmp_1473)));
}
emit_assign(make_lhs(tmp_1469), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1470), make_compvar_primary(tmp_1471)));
}
emit_assign(make_lhs(tmp_1467), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1468), make_compvar_primary(tmp_1469)));
}

tmp_1474 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1475, *tmp_1476;
tmp_1475 = tmp_1437;
tmp_1476 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1477, *tmp_1478;
tmp_1477 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1477), make_int_const_rhs(1));
tmp_1478 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1479, *tmp_1480;
tmp_1479 = tmp_1432;
tmp_1480 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1481, *tmp_1482;
tmp_1481 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1481), make_int_const_rhs(1));
tmp_1482 = tmp_1459;
emit_assign(make_lhs(tmp_1480), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1481), make_compvar_primary(tmp_1482)));
}
emit_assign(make_lhs(tmp_1478), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1479), make_compvar_primary(tmp_1480)));
}
emit_assign(make_lhs(tmp_1476), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1477), make_compvar_primary(tmp_1478)));
}
emit_assign(make_lhs(tmp_1474), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1475), make_compvar_primary(tmp_1476)));
}

{
compvar_t *tmp_1483;
tmp_1483 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1484, *tmp_1485;
tmp_1484 = tmp_1457;
tmp_1485 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1485), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1483), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1484), make_compvar_primary(tmp_1485)));
}
start_if_cond(make_compvar_rhs(tmp_1483));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1437));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1474));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1462));
switch_if_branch();
{
compvar_t *tmp_1486;
tmp_1486 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1487, *tmp_1488;
tmp_1487 = tmp_1457;
tmp_1488 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1488), make_int_const_rhs(1));
emit_assign(make_lhs(tmp_1486), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1487), make_compvar_primary(tmp_1488)));
}
start_if_cond(make_compvar_rhs(tmp_1486));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1467));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1437));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1462));
switch_if_branch();
{
compvar_t *tmp_1489;
tmp_1489 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1490, *tmp_1491;
tmp_1490 = tmp_1457;
tmp_1491 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1491), make_int_const_rhs(2));
emit_assign(make_lhs(tmp_1489), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1490), make_compvar_primary(tmp_1491)));
}
start_if_cond(make_compvar_rhs(tmp_1489));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1462));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1437));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1474));
switch_if_branch();
{
compvar_t *tmp_1492;
tmp_1492 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1493, *tmp_1494;
tmp_1493 = tmp_1457;
tmp_1494 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1494), make_int_const_rhs(3));
emit_assign(make_lhs(tmp_1492), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1493), make_compvar_primary(tmp_1494)));
}
start_if_cond(make_compvar_rhs(tmp_1492));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1462));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1467));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1437));
switch_if_branch();
{
compvar_t *tmp_1495;
tmp_1495 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1496, *tmp_1497;
tmp_1496 = tmp_1457;
tmp_1497 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1497), make_int_const_rhs(4));
emit_assign(make_lhs(tmp_1495), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1496), make_compvar_primary(tmp_1497)));
}
start_if_cond(make_compvar_rhs(tmp_1495));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1474));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1462));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1437));
switch_if_branch();
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1437));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1462));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1467));
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
}
}
}
}
end_if_cond();
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_toxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1498;
for (tmp_1498 = 0; tmp_1498 < 2; ++tmp_1498)
{
switch (tmp_1498)
{
case 0 :
{
compvar_t *tmp_1499, *tmp_1500;
tmp_1499 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1501;
tmp_1501 = args[0][1];
emit_assign(make_lhs(tmp_1499), make_op_rhs(OP_COS, make_compvar_primary(tmp_1501)));
}
tmp_1500 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1498]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1499), make_compvar_primary(tmp_1500)));
}
break;
case 1 :
{
compvar_t *tmp_1502, *tmp_1503;
tmp_1502 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1504;
tmp_1504 = args[0][1];
emit_assign(make_lhs(tmp_1502), make_op_rhs(OP_SIN, make_compvar_primary(tmp_1504)));
}
tmp_1503 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1498]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1502), make_compvar_primary(tmp_1503)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_toxy_trivial (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1505;
for (tmp_1505 = 0; tmp_1505 < 2; ++tmp_1505)
{
emit_assign(make_lhs(result_tmps[tmp_1505]), make_compvar_rhs(args[0][tmp_1505]));
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tora (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1506;

tmp_1506 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1507, *tmp_1508;
tmp_1507 = args[0][0];
tmp_1508 = args[0][1];
emit_assign(make_lhs(tmp_1506), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_1507), make_compvar_primary(tmp_1508)));
}

{
compvar_t *tmp_1509;
tmp_1509 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1510, *tmp_1511;
tmp_1510 = tmp_1506;
tmp_1511 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1511), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1509), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1510), make_compvar_primary(tmp_1511)));
}
start_if_cond(make_compvar_rhs(tmp_1509));
{
int tmp_1512;
for (tmp_1512 = 0; tmp_1512 < 2; ++tmp_1512)
{
switch (tmp_1512)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1512]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1512]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_1513;

tmp_1513 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1514;
tmp_1514 = make_temporary(TYPE_FLOAT);
{
compvar_t *tmp_1515, *tmp_1516;
tmp_1515 = args[0][0];
tmp_1516 = tmp_1506;
emit_assign(make_lhs(tmp_1514), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1515), make_compvar_primary(tmp_1516)));
}
emit_assign(make_lhs(tmp_1513), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_1514)));
}

emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1506));
{
compvar_t *tmp_1517;
tmp_1517 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1518, *tmp_1519;
tmp_1518 = args[0][1];
tmp_1519 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1519), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1517), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1518), make_compvar_primary(tmp_1519)));
}
start_if_cond(make_compvar_rhs(tmp_1517));
{
compvar_t *tmp_1520, *tmp_1521;
tmp_1520 = make_temporary(TYPE_NIL);
{
compvar_t *tmp_1522, *tmp_1523;
tmp_1522 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1522), make_int_const_rhs(2));
tmp_1523 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1523), make_float_const_rhs(M_PI));
emit_assign(make_lhs(tmp_1520), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1522), make_compvar_primary(tmp_1523)));
}
tmp_1521 = tmp_1513;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1520), make_compvar_primary(tmp_1521)));
}
switch_if_branch();
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1513));
end_if_cond();
}
}
end_if_cond();
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tora_trivial (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1524;
for (tmp_1524 = 0; tmp_1524 < 2; ++tmp_1524)
{
emit_assign(make_lhs(result_tmps[tmp_1524]), make_compvar_rhs(args[0][tmp_1524]));
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rand (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1525;
for (tmp_1525 = 0; tmp_1525 < 1; ++tmp_1525)
{
switch (tmp_1525)
{
case 0 :
{
compvar_t *tmp_1526, *tmp_1527;
tmp_1526 = args[0][0];
tmp_1527 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1525]), make_op_rhs(OP_RAND, make_compvar_primary(tmp_1526), make_compvar_primary(tmp_1527)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_noise (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1528;
for (tmp_1528 = 0; tmp_1528 < 1; ++tmp_1528)
{
switch (tmp_1528)
{
case 0 :
{
compvar_t *tmp_1529, *tmp_1530, *tmp_1531;
tmp_1529 = args[0][0];
tmp_1530 = args[0][1];
tmp_1531 = args[0][2];
emit_assign(make_lhs(result_tmps[tmp_1528]), make_op_rhs(OP_NOISE, make_compvar_primary(tmp_1529), make_compvar_primary(tmp_1530), make_compvar_primary(tmp_1531)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}


void
init_builtins (void)
{
register_overloaded_builtin("print", "((nil 1) (_ _))", gen_print);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (ri 2))", gen_add_ri);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (_ 1))", gen_add_ri_1);
register_overloaded_builtin("__add", "((ri 2) (_ 1) (ri 2))", gen_add_1_ri);
register_overloaded_builtin("__add", "((T 1) (T 1) (T 1))", gen_add_1);
register_overloaded_builtin("__add", "((T L) (T L) (_ 1))", gen_add_s);
register_overloaded_builtin("__add", "((T L) (T L) (T L))", gen_add_n);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (ri 2))", gen_sub_ri);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (_ 1))", gen_sub_ri_1);
register_overloaded_builtin("__sub", "((ri 2) (_ 1) (ri 2))", gen_sub_1_ri);
register_overloaded_builtin("__sub", "((T 1) (T 1) (T 1))", gen_sub_1);
register_overloaded_builtin("__sub", "((T L) (T L) (_ 1))", gen_sub_s);
register_overloaded_builtin("__sub", "((T L) (T L) (T L))", gen_sub_n);
register_overloaded_builtin("__neg", "((T L) (T L))", gen_neg);
register_overloaded_builtin("__mul", "((ri 2) (ri 2) (ri 2))", gen_mul_ri);
register_overloaded_builtin("__mul", "((ri 2) (_ 1) (ri 2))", gen_mul_1_ri);
register_overloaded_builtin("__mul", "((m2x2 4) (m2x2 4) (m2x2 4))", gen_mul_m2x2);
register_overloaded_builtin("__mul", "((m3x3 9) (m3x3 9) (m3x3 9))", gen_mul_m3x3);
register_overloaded_builtin("__mul", "((v2 2) (v2 2) (m2x2 4))", gen_mul_v2m2x2);
register_overloaded_builtin("__mul", "((v3 3) (v3 3) (m3x3 9))", gen_mul_v3m3x3);
register_overloaded_builtin("__mul", "((v2 2) (m2x2 4) (v2 2))", gen_mul_m2x2v2);
register_overloaded_builtin("__mul", "((v3 3) (m3x3 9) (v3 3))", gen_mul_m3x3v3);
register_overloaded_builtin("__mul", "((quat 4) (quat 4) (quat 4))", gen_mul_quat);
register_overloaded_builtin("__mul", "((cquat 4) (cquat 4) (cquat 4))", gen_mul_cquat);
register_overloaded_builtin("__mul", "((hyper 4) (hyper 4) (hyper 4))", gen_mul_hyper);
register_overloaded_builtin("__mul", "((T 1) (T 1) (T 1))", gen_mul_1);
register_overloaded_builtin("__mul", "((T L) (T L) (_ 1))", gen_mul_s);
register_overloaded_builtin("__mul", "((T L) (T L) (T L))", gen_mul_n);
register_overloaded_builtin("__div", "((ri 2) (ri 2) (ri 2))", gen_div_ri);
register_overloaded_builtin("__div", "((ri 2) (T 1) (ri 2))", gen_div_1_ri);
register_overloaded_builtin("__div", "((v2 2) (_ 2) (m2x2 4))", gen_div_v2m2x2);
register_overloaded_builtin("__div", "((v3 3) (_ 3) (m3x3 9))", gen_div_v3m3x3);
register_overloaded_builtin("__div", "((T 1) (T 1) (T 1))", gen_div_1);
register_overloaded_builtin("__div", "((T L) (T L) (_ 1))", gen_div_s);
register_overloaded_builtin("__div", "((T L) (T L) (T L))", gen_div_n);
register_overloaded_builtin("__mod", "((T 1) (T 1) (T 1))", gen_mod_1);
register_overloaded_builtin("__mod", "((T L) (T L) (_ 1))", gen_mod_s);
register_overloaded_builtin("__mod", "((T L) (T L) (T L))", gen_mod_n);
register_overloaded_builtin("pmod", "((T 1) (T 1) (T 1))", gen_pmod);
register_overloaded_builtin("sqrt", "((ri 2) (ri 2))", gen_sqrt_ri);
register_overloaded_builtin("sqrt", "((T 1) (T 1))", gen_sqrt_1);
register_overloaded_builtin("sum", "((T 1) (T L))", gen_sum);
register_overloaded_builtin("dotp", "((nil 1) (T L) (T L))", gen_dotp);
register_overloaded_builtin("crossp", "((T 3) (T 3) (T 3))", gen_crossp);
register_overloaded_builtin("det", "((nil 1) (m2x2 4))", gen_det_m2x2);
register_overloaded_builtin("det", "((nil 1) (m3x3 9))", gen_det_m3x3);
register_overloaded_builtin("normalize", "((T L) (T L))", gen_normalize);
register_overloaded_builtin("abs", "((nil 1) (ri 2))", gen_abs_ri);
register_overloaded_builtin("abs", "((nil 1) (quat 4))", gen_abs_quat);
register_overloaded_builtin("abs", "((nil 1) (cquat 4))", gen_abs_cquat);
register_overloaded_builtin("abs", "((nil 1) (hyper 4))", gen_abs_hyper);
register_overloaded_builtin("abs", "((T 1) (T 1))", gen_abs_1);
register_overloaded_builtin("abs", "((T L) (T L))", gen_abs_n);
register_overloaded_builtin("deg2rad", "((nil 1) (_ 1))", gen_deg2rad);
register_overloaded_builtin("rad2deg", "((deg 1) (_ 1))", gen_rad2deg);
register_overloaded_builtin("sin", "((ri 2) (ri 2))", gen_sin_ri);
register_overloaded_builtin("sin", "((T 1) (T 1))", gen_sin);
register_overloaded_builtin("cos", "((ri 2) (ri 2))", gen_cos_ri);
register_overloaded_builtin("cos", "((T 1) (T 1))", gen_cos);
register_overloaded_builtin("tan", "((ri 2) (ri 2))", gen_tan_ri);
register_overloaded_builtin("tan", "((T 1) (T 1))", gen_tan);
register_overloaded_builtin("asin", "((ri 2) (ri 2))", gen_asin_ri);
register_overloaded_builtin("asin", "((T 1) (T 1))", gen_asin);
register_overloaded_builtin("acos", "((ri 2) (ri 2))", gen_acos_ri);
register_overloaded_builtin("acos", "((T 1) (T 1))", gen_acos);
register_overloaded_builtin("atan", "((ri 2) (ri 2))", gen_atan_ri);
register_overloaded_builtin("atan", "((T 1) (T 1))", gen_atan);
register_overloaded_builtin("atan", "((T 1) (T 1) (T 1))", gen_atan2);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (T 1))", gen_pow_ri_1);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (ri 2))", gen_pow_ri);
register_overloaded_builtin("__pow", "((ri 2) (T 1) (ri 2))", gen_pow_1_ri);
register_overloaded_builtin("__pow", "((T 1) (T 1) (T 1))", gen_pow_1);
register_overloaded_builtin("__pow", "((T L) (T L) (_ 1))", gen_pow_s);
register_overloaded_builtin("exp", "((ri 2) (ri 2))", gen_exp_ri);
register_overloaded_builtin("exp", "((T 1) (T 1))", gen_exp_1);
register_overloaded_builtin("log", "((ri 2) (ri 2))", gen_log_ri);
register_overloaded_builtin("log", "((T 1) (T 1))", gen_log_1);
register_overloaded_builtin("arg", "((nil 1) (ri 2))", gen_arg_ri);
register_overloaded_builtin("conj", "((ri 2) (ri 2))", gen_conj_ri);
register_overloaded_builtin("sinh", "((ri 2) (ri 2))", gen_sinh_ri);
register_overloaded_builtin("sinh", "((T 1) (T 1))", gen_sinh_1);
register_overloaded_builtin("cosh", "((ri 2) (ri 2))", gen_cosh_ri);
register_overloaded_builtin("cosh", "((T 1) (T 1))", gen_cosh_1);
register_overloaded_builtin("tanh", "((ri 2) (ri 2))", gen_tanh_ri);
register_overloaded_builtin("tanh", "((T 1) (T 1))", gen_tanh_1);
register_overloaded_builtin("asinh", "((ri 2) (ri 2))", gen_asinh_ri);
register_overloaded_builtin("asinh", "((T 1) (T 1))", gen_asinh_1);
register_overloaded_builtin("acosh", "((ri 2) (ri 2))", gen_acosh_ri);
register_overloaded_builtin("acosh", "((T 1) (T 1))", gen_acosh_1);
register_overloaded_builtin("atanh", "((ri 2) (ri 2))", gen_atanh_ri);
register_overloaded_builtin("atanh", "((T 1) (T 1))", gen_atanh_1);
register_overloaded_builtin("gamma", "((ri 2) (ri 2))", gen_gamma_ri);
register_overloaded_builtin("gamma", "((T 1) (T 1))", gen_gamma_1);
register_overloaded_builtin("beta", "((T 1) (T 1) (T 1))", gen_beta_1);
register_overloaded_builtin("ell_int_Kcomp", "((T 1) (T 1))", gen_ell_int_kcomp);
register_overloaded_builtin("ell_int_Ecomp", "((T 1) (T 1))", gen_ell_int_ecomp);
register_overloaded_builtin("ell_int_F", "((T 1) (T 1) (T 1))", gen_ell_int_f);
register_overloaded_builtin("ell_int_E", "((T 1) (T 1) (T 1))", gen_ell_int_e);
register_overloaded_builtin("ell_int_P", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_p);
register_overloaded_builtin("ell_int_D", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_d);
register_overloaded_builtin("ell_int_RC", "((T 1) (T 1) (T 1))", gen_ell_int_rc);
register_overloaded_builtin("ell_int_RD", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rd);
register_overloaded_builtin("ell_int_RF", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rf);
register_overloaded_builtin("ell_int_RJ", "((T 1) (T 1) (T 1) (T 1) (T 1))", gen_ell_int_rj);
register_overloaded_builtin("ell_jac_sn", "((T 1) (T 1) (T 1))", gen_ell_jac_sn_1);
register_overloaded_builtin("ell_jac_cn", "((T 1) (T 1) (T 1))", gen_ell_jac_cn_1);
register_overloaded_builtin("ell_jac_dn", "((T 1) (T 1) (T 1))", gen_ell_jac_dn_1);
register_overloaded_builtin("ell_jac_sn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_sn_ri);
register_overloaded_builtin("ell_jac_cn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_cn_ri);
register_overloaded_builtin("ell_jac_dn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_dn_ri);
register_overloaded_builtin("floor", "((T 1) (T 1))", gen_floor);
register_overloaded_builtin("ceil", "((T 1) (T 1))", gen_ceil);
register_overloaded_builtin("sign", "((T L) (T L))", gen_sign_n);
register_overloaded_builtin("min", "((T L) (T L) (T L))", gen_min_n);
register_overloaded_builtin("max", "((T L) (T L) (T L))", gen_max_n);
register_overloaded_builtin("clamp", "((T L) (T L) (T L) (T L))", gen_clamp);
register_overloaded_builtin("lerp", "((T L) (_ 1) (T L) (T L))", gen_lerp_1);
register_overloaded_builtin("lerp", "((T L) (T L) (T L) (T L))", gen_lerp_n);
register_overloaded_builtin("scale", "((T L) (T L) (T L) (T L) (T L) (T L))", gen_scale);
register_overloaded_builtin("__not", "((T 1) (T 1))", gen_not);
register_overloaded_builtin("__or", "((T 1) (T 1) (T 1))", gen_or);
register_overloaded_builtin("__and", "((T 1) (T 1) (T 1))", gen_and);
register_overloaded_builtin("__xor", "((T 1) (T 1) (T 1))", gen_xor);
register_overloaded_builtin("__equal", "((T 1) (T 1) (T 1))", gen_equal);
register_overloaded_builtin("__less", "((T 1) (T 1) (T 1))", gen_less);
register_overloaded_builtin("__greater", "((T 1) (T 1) (T 1))", gen_greater);
register_overloaded_builtin("__lessequal", "((T 1) (T 1) (T 1))", gen_lessequal);
register_overloaded_builtin("__greaterequal", "((T 1) (T 1) (T 1))", gen_greaterequal);
register_overloaded_builtin("__notequal", "((T 1) (T 1) (T 1))", gen_notequal);
register_overloaded_builtin("inintv", "((T 1) (T 1) (T 1) (T 1))", gen_inintv);
register_overloaded_builtin("__origVal", "((rgba 4) (xy 2) (nil 1) (image 1))", gen_origvalxy);
register_overloaded_builtin("red", "((nil 1) (rgba 4))", gen_red);
register_overloaded_builtin("green", "((nil 1) (rgba 4))", gen_green);
register_overloaded_builtin("blue", "((nil 1) (rgba 4))", gen_blue);
register_overloaded_builtin("alpha", "((nil 1) (rgba 4))", gen_alpha);
register_overloaded_builtin("gray", "((nil 1) (rgba 4))", gen_gray);
register_overloaded_builtin("rgbColor", "((rgba 4) (T 1) (T 1) (T 1))", gen_rgbcolor);
register_overloaded_builtin("rgbaColor", "((rgba 4) (T 1) (T 1) (T 1) (T 1))", gen_rgbacolor);
register_overloaded_builtin("grayColor", "((rgba 4) (T 1))", gen_graycolor);
register_overloaded_builtin("grayaColor", "((rgba 4) (T 1) (T 1))", gen_grayacolor);
register_overloaded_builtin("toHSVA", "((hsva 4) (rgba 4))", gen_tohsva);
register_overloaded_builtin("toRGBA", "((rgba 4) (hsva 4))", gen_torgba);
register_overloaded_builtin("toXY", "((xy 2) (ra 2))", gen_toxy);
register_overloaded_builtin("toXY", "((xy 2) (xy 2))", gen_toxy_trivial);
register_overloaded_builtin("toRA", "((ra 2) (xy 2))", gen_tora);
register_overloaded_builtin("toRA", "((ra 2) (ra 2))", gen_tora_trivial);
register_overloaded_builtin("rand", "((T 1) (T 1) (T 1))", gen_rand);
register_overloaded_builtin("noise", "((nil 1) (_ 3))", gen_noise);
}
