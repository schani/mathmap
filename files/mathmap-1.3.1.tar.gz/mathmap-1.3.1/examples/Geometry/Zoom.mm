filter geom_zoom (image in, float factor: 0-10 (1))
  in(xy * factor)
end
