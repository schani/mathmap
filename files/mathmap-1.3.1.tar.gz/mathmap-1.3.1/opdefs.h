#define OP_NOP 0
#define OP_INT_TO_FLOAT 1
#define OP_FLOAT_TO_INT 2
#define OP_INT_TO_COMPLEX 3
#define OP_FLOAT_TO_COMPLEX 4
#define OP_ADD 5
#define OP_SUB 6
#define OP_NEG 7
#define OP_MUL 8
#define OP_DIV 9
#define OP_MOD 10
#define OP_ABS 11
#define OP_MIN 12
#define OP_MAX 13
#define OP_SQRT 14
#define OP_HYPOT 15
#define OP_SIN 16
#define OP_COS 17
#define OP_TAN 18
#define OP_ASIN 19
#define OP_ACOS 20
#define OP_ATAN 21
#define OP_ATAN2 22
#define OP_POW 23
#define OP_EXP 24
#define OP_LOG 25
#define OP_SINH 26
#define OP_COSH 27
#define OP_TANH 28
#define OP_ASINH 29
#define OP_ACOSH 30
#define OP_ATANH 31
#define OP_GAMMA 32
#define OP_BETA 33
#define OP_FLOOR 34
#define OP_CEIL 35
#define OP_EQ 36
#define OP_LESS 37
#define OP_LESS_INT 38
#define OP_LEQ 39
#define OP_NOT 40
#define OP_PRINT 41
#define OP_NEWLINE 42
#define OP_START_DEBUG_TUPLE 43
#define OP_SET_DEBUG_TUPLE_DATA 44
#define OP_ORIG_VAL 45
#define OP_RED 46
#define OP_GREEN 47
#define OP_BLUE 48
#define OP_ALPHA 49
#define OP_TUPLE_NTH 50
#define OP_COMPLEX 51
#define OP_C_REAL 52
#define OP_C_IMAG 53
#define OP_C_SQRT 54
#define OP_C_SIN 55
#define OP_C_COS 56
#define OP_C_TAN 57
#define OP_C_ASIN 58
#define OP_C_ACOS 59
#define OP_C_ATAN 60
#define OP_C_POW 61
#define OP_C_EXP 62
#define OP_C_LOG 63
#define OP_C_ARG 64
#define OP_C_SINH 65
#define OP_C_COSH 66
#define OP_C_TANH 67
#define OP_C_ASINH 68
#define OP_C_ACOSH 69
#define OP_C_ATANH 70
#define OP_C_GAMMA 71
#define OP_ELL_INT_K_COMP 72
#define OP_ELL_INT_E_COMP 73
#define OP_ELL_INT_F 74
#define OP_ELL_INT_E 75
#define OP_ELL_INT_P 76
#define OP_ELL_INT_D 77
#define OP_ELL_INT_RC 78
#define OP_ELL_INT_RD 79
#define OP_ELL_INT_RF 80
#define OP_ELL_INT_RJ 81
#define OP_ELL_JAC 82
#define OP_MAKE_M2X2 83
#define OP_MAKE_M3X3 84
#define OP_FREE_MATRIX 85
#define OP_MAKE_V2 86
#define OP_MAKE_V3 87
#define OP_V2_NTH 88
#define OP_V3_NTH 89
#define OP_SOLVE_LINEAR_2 90
#define OP_SOLVE_LINEAR_3 91
#define OP_SOLVE_POLY_2 92
#define OP_SOLVE_POLY_3 93
#define OP_NOISE 94
#define OP_RAND 95
#define OP_USERVAL_INT 96
#define OP_USERVAL_FLOAT 97
#define OP_USERVAL_BOOL 98
#define OP_USERVAL_CURVE 99
#define OP_USERVAL_COLOR 100
#define OP_USERVAL_GRADIENT 101
#define OP_USERVAL_IMAGE 102
#define OP_OUTPUT_TUPLE 103

#define NUM_OPS 104

static void
init_ops (void)
{
    init_op(OP_NOP, "NOP", 0, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_INT_TO_FLOAT, "INT2FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_INT);
    init_op(OP_FLOAT_TO_INT, "FLOAT2INT", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT);
    init_op(OP_INT_TO_COMPLEX, "INT2COMPLEX", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_INT);
    init_op(OP_FLOAT_TO_COMPLEX, "FLOAT2COMPLEX", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_FLOAT);
    init_op(OP_ADD, "ADD", 2, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_SUB, "SUB", 2, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_NEG, "NEG", 1, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_MUL, "MUL", 2, TYPE_PROP_MAX, TYPE_NIL, 1, 1);
    init_op(OP_DIV, "DIV", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_MOD, "MOD", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ABS, "fabs", 1, TYPE_PROP_MAX_FLOAT, TYPE_NIL, 1, 1);
    init_op(OP_MIN, "MIN", 2, TYPE_PROP_MAX_FLOAT, TYPE_NIL, 1, 1);
    init_op(OP_MAX, "MAX", 2, TYPE_PROP_MAX_FLOAT, TYPE_NIL, 1, 1);
    init_op(OP_SQRT, "sqrt", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_HYPOT, "hypot", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_SIN, "sin", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_COS, "cos", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_TAN, "tan", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ASIN, "asin", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ACOS, "acos", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ATAN, "atan", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ATAN2, "atan2", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_POW, "pow", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_EXP, "exp", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_LOG, "log", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_SINH, "sinh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_COSH, "cosh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_TANH, "tanh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ASINH, "asinh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ACOSH, "acosh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ATANH, "atanh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_GAMMA, "GAMMA", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_BETA, "gsl_sf_beta", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_FLOOR, "floor", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT);
    init_op(OP_CEIL, "ceil", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT);
    init_op(OP_EQ, "EQ", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LESS, "LESS", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_LESS_INT, "LESS", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_INT, TYPE_INT);
    init_op(OP_LEQ, "LEQ", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_NOT, "NOT", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1, TYPE_INT);
    init_op(OP_PRINT, "PRINT_FLOAT", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_FLOAT);
    init_op(OP_NEWLINE, "NEWLINE", 0, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_START_DEBUG_TUPLE, "START_DEBUG_TUPLE", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_INT);
    init_op(OP_SET_DEBUG_TUPLE_DATA, "SET_DEBUG_TUPLE_DATA", 2, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_INT, TYPE_FLOAT);
    init_op(OP_ORIG_VAL, "ORIG_VAL", 4, TYPE_PROP_CONST, TYPE_TUPLE, 1, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_IMAGE, TYPE_FLOAT);
    init_op(OP_RED, "RED_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_GREEN, "GREEN_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_BLUE, "BLUE_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_ALPHA, "ALPHA_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_COLOR);
    init_op(OP_TUPLE_NTH, "TUPLE_NTH", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_TUPLE, TYPE_INT);
    init_op(OP_COMPLEX, "COMPLEX", 2, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_C_REAL, "crealf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_IMAG, "cimagf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_SQRT, "csqrtf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_SIN, "csinf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_COS, "ccosf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_TAN, "ctanf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ASIN, "casinf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ACOS, "cacosf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ATAN, "catanf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_POW, "cpowf", 2, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX, TYPE_COMPLEX);
    init_op(OP_C_EXP, "cexpf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_LOG, "clogf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ARG, "cargf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_SINH, "csinhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_COSH, "ccoshf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_TANH, "ctanhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ASINH, "casinhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ACOSH, "cacoshf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_ATANH, "catanhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_C_GAMMA, "cgamma", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1, TYPE_COMPLEX);
    init_op(OP_ELL_INT_K_COMP, "ELL_INT_K_COMP", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ELL_INT_E_COMP, "ELL_INT_E_COMP", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT);
    init_op(OP_ELL_INT_F, "ELL_INT_F", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_E, "ELL_INT_E", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_P, "ELL_INT_P", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_D, "ELL_INT_D", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RC, "ELL_INT_RC", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RD, "ELL_INT_RD", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RF, "ELL_INT_RF", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_INT_RJ, "ELL_INT_RJ", 4, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_ELL_JAC, "ELL_JAC", 2, TYPE_PROP_CONST, TYPE_V3, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_MAKE_M2X2, "MAKE_M2X2", 4, TYPE_PROP_CONST, TYPE_M2X2, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_MAKE_M3X3, "MAKE_M3X3", 9, TYPE_PROP_CONST, TYPE_GSL_MATRIX, 0, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_FREE_MATRIX, "FREE_MATRIX", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_GSL_MATRIX);
    init_op(OP_MAKE_V2, "MAKE_V2", 2, TYPE_PROP_CONST, TYPE_V2, 1, 1, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_MAKE_V3, "MAKE_V3", 3, TYPE_PROP_CONST, TYPE_V3, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_V2_NTH, "VECTOR_NTH", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_INT, TYPE_V2);
    init_op(OP_V3_NTH, "VECTOR_NTH", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_INT, TYPE_V3);
    init_op(OP_SOLVE_LINEAR_2, "SOLVE_LINEAR_2", 2, TYPE_PROP_CONST, TYPE_V2, 0, 0, TYPE_M2X2, TYPE_V2);
    init_op(OP_SOLVE_LINEAR_3, "SOLVE_LINEAR_3", 2, TYPE_PROP_CONST, TYPE_V3, 0, 0, TYPE_GSL_MATRIX, TYPE_V3);
    init_op(OP_SOLVE_POLY_2, "SOLVE_POLY_2", 3, TYPE_PROP_CONST, TYPE_V2, 0, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_SOLVE_POLY_3, "SOLVE_POLY_3", 4, TYPE_PROP_CONST, TYPE_V3, 0, 0, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_NOISE, "noise", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1, TYPE_FLOAT, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_RAND, "RAND", 2, TYPE_PROP_CONST, TYPE_FLOAT, 0, 0, TYPE_FLOAT, TYPE_FLOAT);
    init_op(OP_USERVAL_INT, "USERVAL_INT_ACCESS", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_FLOAT, "USERVAL_FLOAT_ACCESS", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_BOOL, "USERVAL_BOOL_ACCESS", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_CURVE, "USERVAL_CURVE_ACCESS", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0, TYPE_INT, TYPE_FLOAT);
    init_op(OP_USERVAL_COLOR, "USERVAL_COLOR_ACCESS", 1, TYPE_PROP_CONST, TYPE_COLOR, 1, 0, TYPE_INT);
    init_op(OP_USERVAL_GRADIENT, "USERVAL_GRADIENT_ACCESS", 2, TYPE_PROP_CONST, TYPE_COLOR, 1, 0, TYPE_INT, TYPE_FLOAT);
    init_op(OP_USERVAL_IMAGE, "USERVAL_IMAGE_ACCESS", 1, TYPE_PROP_CONST, TYPE_IMAGE, 1, 0, TYPE_INT);
    init_op(OP_OUTPUT_TUPLE, "OUTPUT_TUPLE", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0, TYPE_TUPLE);
}

static primary_t
fold_rhs (rhs_t *rhs)
{
assert(rhs_is_foldable(rhs));
switch(rhs->v.op.op->index)
{
case OP_NOP :
return make_int_const_primary(NOP());
case OP_INT_TO_FLOAT :
return make_float_const_primary(INT2FLOAT(OP_CONST_INT_VAL(0)));
case OP_FLOAT_TO_INT :
return make_int_const_primary(FLOAT2INT(OP_CONST_FLOAT_VAL(0)));
case OP_INT_TO_COMPLEX :
return make_complex_const_primary(INT2COMPLEX(OP_CONST_INT_VAL(0)));
case OP_FLOAT_TO_COMPLEX :
return make_complex_const_primary(FLOAT2COMPLEX(OP_CONST_FLOAT_VAL(0)));
case OP_ADD :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(ADD((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.constant.int_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.constant.float_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SUB :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(SUB((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.constant.int_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.constant.float_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_NEG :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
return make_int_const_primary(NEG((int)rhs->v.op.args[0].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(NEG((float)rhs->v.op.args[0].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(NEG((complex float)rhs->v.op.args[0].v.constant.complex_value));
default : assert(0); break;
}
case OP_MUL :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(MUL((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.constant.int_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.constant.float_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.float_value));
case TYPE_COMPLEX :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.constant.complex_value, (complex float)rhs->v.op.args[1].v.constant.complex_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_DIV :
return make_float_const_primary(DIV(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_MOD :
return make_float_const_primary(MOD(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ABS :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
return make_int_const_primary(fabs((int)rhs->v.op.args[0].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(fabs((float)rhs->v.op.args[0].v.constant.float_value));
default : assert(0); break;
}
case OP_MIN :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(MIN((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_MAX :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_int_const_primary(MAX((int)rhs->v.op.args[0].v.constant.int_value, (int)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.constant.int_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.int_value));
case TYPE_FLOAT :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.constant.float_value, (float)rhs->v.op.args[1].v.constant.float_value));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SQRT :
return make_float_const_primary(sqrt(OP_CONST_FLOAT_VAL(0)));
case OP_HYPOT :
return make_float_const_primary(hypot(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_SIN :
return make_float_const_primary(sin(OP_CONST_FLOAT_VAL(0)));
case OP_COS :
return make_float_const_primary(cos(OP_CONST_FLOAT_VAL(0)));
case OP_TAN :
return make_float_const_primary(tan(OP_CONST_FLOAT_VAL(0)));
case OP_ASIN :
return make_float_const_primary(asin(OP_CONST_FLOAT_VAL(0)));
case OP_ACOS :
return make_float_const_primary(acos(OP_CONST_FLOAT_VAL(0)));
case OP_ATAN :
return make_float_const_primary(atan(OP_CONST_FLOAT_VAL(0)));
case OP_ATAN2 :
return make_float_const_primary(atan2(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_POW :
return make_float_const_primary(pow(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_EXP :
return make_float_const_primary(exp(OP_CONST_FLOAT_VAL(0)));
case OP_LOG :
return make_float_const_primary(log(OP_CONST_FLOAT_VAL(0)));
case OP_SINH :
return make_float_const_primary(sinh(OP_CONST_FLOAT_VAL(0)));
case OP_COSH :
return make_float_const_primary(cosh(OP_CONST_FLOAT_VAL(0)));
case OP_TANH :
return make_float_const_primary(tanh(OP_CONST_FLOAT_VAL(0)));
case OP_ASINH :
return make_float_const_primary(asinh(OP_CONST_FLOAT_VAL(0)));
case OP_ACOSH :
return make_float_const_primary(acosh(OP_CONST_FLOAT_VAL(0)));
case OP_ATANH :
return make_float_const_primary(atanh(OP_CONST_FLOAT_VAL(0)));
case OP_GAMMA :
return make_float_const_primary(GAMMA(OP_CONST_FLOAT_VAL(0)));
case OP_BETA :
return make_float_const_primary(gsl_sf_beta(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_FLOOR :
return make_int_const_primary(floor(OP_CONST_FLOAT_VAL(0)));
case OP_CEIL :
return make_int_const_primary(ceil(OP_CONST_FLOAT_VAL(0)));
case OP_EQ :
return make_int_const_primary(EQ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_LESS :
return make_int_const_primary(LESS(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_LESS_INT :
return make_int_const_primary(LESS(OP_CONST_INT_VAL(0), OP_CONST_INT_VAL(1)));
case OP_LEQ :
return make_int_const_primary(LEQ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_NOT :
return make_int_const_primary(NOT(OP_CONST_INT_VAL(0)));
case OP_COMPLEX :
return make_complex_const_primary(COMPLEX(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_C_REAL :
return make_float_const_primary(crealf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_IMAG :
return make_float_const_primary(cimagf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_SQRT :
return make_complex_const_primary(csqrtf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_SIN :
return make_complex_const_primary(csinf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_COS :
return make_complex_const_primary(ccosf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_TAN :
return make_complex_const_primary(ctanf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ASIN :
return make_complex_const_primary(casinf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ACOS :
return make_complex_const_primary(cacosf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ATAN :
return make_complex_const_primary(catanf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_POW :
return make_complex_const_primary(cpowf(OP_CONST_COMPLEX_VAL(0), OP_CONST_COMPLEX_VAL(1)));
case OP_C_EXP :
return make_complex_const_primary(cexpf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_LOG :
return make_complex_const_primary(clogf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ARG :
return make_float_const_primary(cargf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_SINH :
return make_complex_const_primary(csinhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_COSH :
return make_complex_const_primary(ccoshf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_TANH :
return make_complex_const_primary(ctanhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ASINH :
return make_complex_const_primary(casinhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ACOSH :
return make_complex_const_primary(cacoshf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_ATANH :
return make_complex_const_primary(catanhf(OP_CONST_COMPLEX_VAL(0)));
case OP_C_GAMMA :
return make_complex_const_primary(cgamma(OP_CONST_COMPLEX_VAL(0)));
case OP_ELL_INT_K_COMP :
return make_float_const_primary(ELL_INT_K_COMP(OP_CONST_FLOAT_VAL(0)));
case OP_ELL_INT_E_COMP :
return make_float_const_primary(ELL_INT_E_COMP(OP_CONST_FLOAT_VAL(0)));
case OP_ELL_INT_F :
return make_float_const_primary(ELL_INT_F(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ELL_INT_E :
return make_float_const_primary(ELL_INT_E(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ELL_INT_P :
return make_float_const_primary(ELL_INT_P(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_D :
return make_float_const_primary(ELL_INT_D(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_RC :
return make_float_const_primary(ELL_INT_RC(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ELL_INT_RD :
return make_float_const_primary(ELL_INT_RD(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_RF :
return make_float_const_primary(ELL_INT_RF(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_ELL_INT_RJ :
return make_float_const_primary(ELL_INT_RJ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3)));
case OP_ELL_JAC :
return make_v3_const_primary(ELL_JAC(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_MAKE_M2X2 :
return make_m2x2_const_primary(MAKE_M2X2(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3)));
case OP_MAKE_V2 :
return make_v2_const_primary(MAKE_V2(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_MAKE_V3 :
return make_v3_const_primary(MAKE_V3(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_NOISE :
return make_float_const_primary(noise(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
default : assert(0);
}
}
static void
builtin_op_nop (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = NOP();
}
static void
builtin_op_int_to_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = INT2FLOAT(BUILTIN_INT_ARG(1));
}
static void
builtin_op_float_to_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = FLOAT2INT(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_int_to_complex (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = INT2COMPLEX(BUILTIN_INT_ARG(1));
}
static void
builtin_op_float_to_complex (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = FLOAT2COMPLEX(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_add_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = ADD(BUILTIN_INT_ARG(1), BUILTIN_INT_ARG(2));
}
static void
builtin_op_add_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ADD(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_add_complex (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = ADD(BUILTIN_COMPLEX_ARG(1), BUILTIN_COMPLEX_ARG(2));
}
static void
builtin_op_sub_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = SUB(BUILTIN_INT_ARG(1), BUILTIN_INT_ARG(2));
}
static void
builtin_op_sub_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = SUB(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_sub_complex (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = SUB(BUILTIN_COMPLEX_ARG(1), BUILTIN_COMPLEX_ARG(2));
}
static void
builtin_op_neg_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = NEG(BUILTIN_INT_ARG(1));
}
static void
builtin_op_neg_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = NEG(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_neg_complex (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = NEG(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_mul_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = MUL(BUILTIN_INT_ARG(1), BUILTIN_INT_ARG(2));
}
static void
builtin_op_mul_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = MUL(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_mul_complex (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = MUL(BUILTIN_COMPLEX_ARG(1), BUILTIN_COMPLEX_ARG(2));
}
static void
builtin_op_div (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = DIV(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_mod (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = MOD(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_abs_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = fabs(BUILTIN_INT_ARG(1));
}
static void
builtin_op_abs_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = fabs(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_min_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = MIN(BUILTIN_INT_ARG(1), BUILTIN_INT_ARG(2));
}
static void
builtin_op_min_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = MIN(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_max_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = MAX(BUILTIN_INT_ARG(1), BUILTIN_INT_ARG(2));
}
static void
builtin_op_max_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = MAX(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_sqrt (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = sqrt(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_hypot (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = hypot(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_sin (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = sin(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_cos (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = cos(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_tan (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = tan(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_asin (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = asin(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_acos (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = acos(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_atan (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = atan(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_atan2 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = atan2(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_pow (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = pow(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_exp (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = exp(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_log (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = log(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_sinh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = sinh(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_cosh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = cosh(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_tanh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = tanh(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_asinh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = asinh(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_acosh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = acosh(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_atanh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = atanh(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_gamma (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = GAMMA(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_beta (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = gsl_sf_beta(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_floor (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = floor(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_ceil (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = ceil(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_eq (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = EQ(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_less (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = LESS(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_less_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = LESS(BUILTIN_INT_ARG(1), BUILTIN_INT_ARG(2));
}
static void
builtin_op_leq (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = LEQ(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_not (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = NOT(BUILTIN_INT_ARG(1));
}
static void
builtin_op_print (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = PRINT_FLOAT(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_newline (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = NEWLINE();
}
static void
builtin_op_start_debug_tuple (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = START_DEBUG_TUPLE(BUILTIN_INT_ARG(1));
}
static void
builtin_op_set_debug_tuple_data (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = SET_DEBUG_TUPLE_DATA(BUILTIN_INT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_orig_val (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_TUPLE_ARG(0) = ORIG_VAL_INTERPRETER(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_IMAGE_ARG(3), BUILTIN_FLOAT_ARG(4));
}
static void
builtin_op_red (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = RED_FLOAT(BUILTIN_COLOR_ARG(1));
}
static void
builtin_op_green (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = GREEN_FLOAT(BUILTIN_COLOR_ARG(1));
}
static void
builtin_op_blue (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = BLUE_FLOAT(BUILTIN_COLOR_ARG(1));
}
static void
builtin_op_alpha (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ALPHA_FLOAT(BUILTIN_COLOR_ARG(1));
}
static void
builtin_op_tuple_nth (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = TUPLE_NTH(BUILTIN_TUPLE_ARG(1), BUILTIN_INT_ARG(2));
}
static void
builtin_op_complex (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = COMPLEX(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_c_real (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = crealf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_imag (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = cimagf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_sqrt (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = csqrtf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_sin (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = csinf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_cos (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = ccosf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_tan (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = ctanf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_asin (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = casinf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_acos (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = cacosf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_atan (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = catanf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_pow (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = cpowf(BUILTIN_COMPLEX_ARG(1), BUILTIN_COMPLEX_ARG(2));
}
static void
builtin_op_c_exp (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = cexpf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_log (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = clogf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_arg (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = cargf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_sinh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = csinhf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_cosh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = ccoshf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_tanh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = ctanhf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_asinh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = casinhf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_acosh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = cacoshf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_atanh (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = catanhf(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_c_gamma (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COMPLEX_ARG(0) = cgamma(BUILTIN_COMPLEX_ARG(1));
}
static void
builtin_op_ell_int_k_comp (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_K_COMP(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_ell_int_e_comp (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_E_COMP(BUILTIN_FLOAT_ARG(1));
}
static void
builtin_op_ell_int_f (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_F(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_ell_int_e (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_E(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_ell_int_p (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_P(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3));
}
static void
builtin_op_ell_int_d (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_D(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3));
}
static void
builtin_op_ell_int_rc (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_RC(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_ell_int_rd (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_RD(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3));
}
static void
builtin_op_ell_int_rf (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_RF(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3));
}
static void
builtin_op_ell_int_rj (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = ELL_INT_RJ(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3), BUILTIN_FLOAT_ARG(4));
}
static void
builtin_op_ell_jac (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_V3_ARG(0) = ELL_JAC(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_make_m2x2 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_M2X2_ARG(0) = MAKE_M2X2(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3), BUILTIN_FLOAT_ARG(4));
}
static void
builtin_op_make_m3x3 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_GSL_MATRIX_ARG(0) = MAKE_M3X3(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3), BUILTIN_FLOAT_ARG(4), BUILTIN_FLOAT_ARG(5), BUILTIN_FLOAT_ARG(6), BUILTIN_FLOAT_ARG(7), BUILTIN_FLOAT_ARG(8), BUILTIN_FLOAT_ARG(9));
}
static void
builtin_op_free_matrix (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = FREE_MATRIX(BUILTIN_GSL_MATRIX_ARG(1));
}
static void
builtin_op_make_v2 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_V2_ARG(0) = MAKE_V2(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_make_v3 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_V3_ARG(0) = MAKE_V3(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3));
}
static void
builtin_op_v2_nth (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = VECTOR_NTH(BUILTIN_INT_ARG(1), BUILTIN_V2_ARG(2));
}
static void
builtin_op_v3_nth (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = VECTOR_NTH(BUILTIN_INT_ARG(1), BUILTIN_V3_ARG(2));
}
static void
builtin_op_solve_linear_2 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_V2_ARG(0) = SOLVE_LINEAR_2(BUILTIN_M2X2_ARG(1), BUILTIN_V2_ARG(2));
}
static void
builtin_op_solve_linear_3 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_V3_ARG(0) = SOLVE_LINEAR_3(BUILTIN_GSL_MATRIX_ARG(1), BUILTIN_V3_ARG(2));
}
static void
builtin_op_solve_poly_2 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_V2_ARG(0) = SOLVE_POLY_2(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3));
}
static void
builtin_op_solve_poly_3 (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_V3_ARG(0) = SOLVE_POLY_3(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3), BUILTIN_FLOAT_ARG(4));
}
static void
builtin_op_noise (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = noise(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2), BUILTIN_FLOAT_ARG(3));
}
static void
builtin_op_rand (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = RAND(BUILTIN_FLOAT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_userval_int (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = USERVAL_INT_ACCESS(BUILTIN_INT_ARG(1));
}
static void
builtin_op_userval_float (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = USERVAL_FLOAT_ACCESS(BUILTIN_INT_ARG(1));
}
static void
builtin_op_userval_bool (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = USERVAL_BOOL_ACCESS(BUILTIN_INT_ARG(1));
}
static void
builtin_op_userval_curve (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_FLOAT_ARG(0) = USERVAL_CURVE_ACCESS(BUILTIN_INT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_userval_color (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COLOR_ARG(0) = USERVAL_COLOR_ACCESS(BUILTIN_INT_ARG(1));
}
static void
builtin_op_userval_gradient (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_COLOR_ARG(0) = USERVAL_GRADIENT_ACCESS(BUILTIN_INT_ARG(1), BUILTIN_FLOAT_ARG(2));
}
static void
builtin_op_userval_image (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_IMAGE_ARG(0) = USERVAL_IMAGE_ACCESS(BUILTIN_INT_ARG(1));
}
static void
builtin_op_output_tuple (mathmap_invocation_t *invocation, int *arg_indexes)
{
BUILTIN_INT_ARG(0) = OUTPUT_TUPLE_INTERPRETER(BUILTIN_TUPLE_ARG(1));
}
static builtin_func_t
get_builtin (rhs_t *rhs)
{
switch (rhs->v.op.op->index)
{
case OP_NOP :
return builtin_op_nop;
case OP_INT_TO_FLOAT :
return builtin_op_int_to_float;
case OP_FLOAT_TO_INT :
return builtin_op_float_to_int;
case OP_INT_TO_COMPLEX :
return builtin_op_int_to_complex;
case OP_FLOAT_TO_COMPLEX :
return builtin_op_float_to_complex;
case OP_ADD :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_add_int;
case TYPE_FLOAT :
return builtin_op_add_float;
case TYPE_COMPLEX :
return builtin_op_add_complex;
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_add_float;
case TYPE_FLOAT :
return builtin_op_add_float;
case TYPE_COMPLEX :
return builtin_op_add_complex;
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_add_complex;
case TYPE_FLOAT :
return builtin_op_add_complex;
case TYPE_COMPLEX :
return builtin_op_add_complex;
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SUB :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_sub_int;
case TYPE_FLOAT :
return builtin_op_sub_float;
case TYPE_COMPLEX :
return builtin_op_sub_complex;
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_sub_float;
case TYPE_FLOAT :
return builtin_op_sub_float;
case TYPE_COMPLEX :
return builtin_op_sub_complex;
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_sub_complex;
case TYPE_FLOAT :
return builtin_op_sub_complex;
case TYPE_COMPLEX :
return builtin_op_sub_complex;
default : assert(0); break;
}
default : assert(0); break;
}
case OP_NEG :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
return builtin_op_neg_int;
case TYPE_FLOAT :
return builtin_op_neg_float;
case TYPE_COMPLEX :
return builtin_op_neg_complex;
default : assert(0); break;
}
case OP_MUL :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_mul_int;
case TYPE_FLOAT :
return builtin_op_mul_float;
case TYPE_COMPLEX :
return builtin_op_mul_complex;
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_mul_float;
case TYPE_FLOAT :
return builtin_op_mul_float;
case TYPE_COMPLEX :
return builtin_op_mul_complex;
default : assert(0); break;
}
case TYPE_COMPLEX :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_mul_complex;
case TYPE_FLOAT :
return builtin_op_mul_complex;
case TYPE_COMPLEX :
return builtin_op_mul_complex;
default : assert(0); break;
}
default : assert(0); break;
}
case OP_DIV :
return builtin_op_div;
case OP_MOD :
return builtin_op_mod;
case OP_ABS :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
return builtin_op_abs_int;
case TYPE_FLOAT :
return builtin_op_abs_float;
default : assert(0); break;
}
case OP_MIN :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_min_int;
case TYPE_FLOAT :
return builtin_op_min_float;
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_min_float;
case TYPE_FLOAT :
return builtin_op_min_float;
default : assert(0); break;
}
default : assert(0); break;
}
case OP_MAX :
switch (primary_type(&rhs->v.op.args[0])) {
case TYPE_INT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_max_int;
case TYPE_FLOAT :
return builtin_op_max_float;
default : assert(0); break;
}
case TYPE_FLOAT :
switch (primary_type(&rhs->v.op.args[1])) {
case TYPE_INT :
return builtin_op_max_float;
case TYPE_FLOAT :
return builtin_op_max_float;
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SQRT :
return builtin_op_sqrt;
case OP_HYPOT :
return builtin_op_hypot;
case OP_SIN :
return builtin_op_sin;
case OP_COS :
return builtin_op_cos;
case OP_TAN :
return builtin_op_tan;
case OP_ASIN :
return builtin_op_asin;
case OP_ACOS :
return builtin_op_acos;
case OP_ATAN :
return builtin_op_atan;
case OP_ATAN2 :
return builtin_op_atan2;
case OP_POW :
return builtin_op_pow;
case OP_EXP :
return builtin_op_exp;
case OP_LOG :
return builtin_op_log;
case OP_SINH :
return builtin_op_sinh;
case OP_COSH :
return builtin_op_cosh;
case OP_TANH :
return builtin_op_tanh;
case OP_ASINH :
return builtin_op_asinh;
case OP_ACOSH :
return builtin_op_acosh;
case OP_ATANH :
return builtin_op_atanh;
case OP_GAMMA :
return builtin_op_gamma;
case OP_BETA :
return builtin_op_beta;
case OP_FLOOR :
return builtin_op_floor;
case OP_CEIL :
return builtin_op_ceil;
case OP_EQ :
return builtin_op_eq;
case OP_LESS :
return builtin_op_less;
case OP_LESS_INT :
return builtin_op_less_int;
case OP_LEQ :
return builtin_op_leq;
case OP_NOT :
return builtin_op_not;
case OP_PRINT :
return builtin_op_print;
case OP_NEWLINE :
return builtin_op_newline;
case OP_START_DEBUG_TUPLE :
return builtin_op_start_debug_tuple;
case OP_SET_DEBUG_TUPLE_DATA :
return builtin_op_set_debug_tuple_data;
case OP_ORIG_VAL :
return builtin_op_orig_val;
case OP_RED :
return builtin_op_red;
case OP_GREEN :
return builtin_op_green;
case OP_BLUE :
return builtin_op_blue;
case OP_ALPHA :
return builtin_op_alpha;
case OP_TUPLE_NTH :
return builtin_op_tuple_nth;
case OP_COMPLEX :
return builtin_op_complex;
case OP_C_REAL :
return builtin_op_c_real;
case OP_C_IMAG :
return builtin_op_c_imag;
case OP_C_SQRT :
return builtin_op_c_sqrt;
case OP_C_SIN :
return builtin_op_c_sin;
case OP_C_COS :
return builtin_op_c_cos;
case OP_C_TAN :
return builtin_op_c_tan;
case OP_C_ASIN :
return builtin_op_c_asin;
case OP_C_ACOS :
return builtin_op_c_acos;
case OP_C_ATAN :
return builtin_op_c_atan;
case OP_C_POW :
return builtin_op_c_pow;
case OP_C_EXP :
return builtin_op_c_exp;
case OP_C_LOG :
return builtin_op_c_log;
case OP_C_ARG :
return builtin_op_c_arg;
case OP_C_SINH :
return builtin_op_c_sinh;
case OP_C_COSH :
return builtin_op_c_cosh;
case OP_C_TANH :
return builtin_op_c_tanh;
case OP_C_ASINH :
return builtin_op_c_asinh;
case OP_C_ACOSH :
return builtin_op_c_acosh;
case OP_C_ATANH :
return builtin_op_c_atanh;
case OP_C_GAMMA :
return builtin_op_c_gamma;
case OP_ELL_INT_K_COMP :
return builtin_op_ell_int_k_comp;
case OP_ELL_INT_E_COMP :
return builtin_op_ell_int_e_comp;
case OP_ELL_INT_F :
return builtin_op_ell_int_f;
case OP_ELL_INT_E :
return builtin_op_ell_int_e;
case OP_ELL_INT_P :
return builtin_op_ell_int_p;
case OP_ELL_INT_D :
return builtin_op_ell_int_d;
case OP_ELL_INT_RC :
return builtin_op_ell_int_rc;
case OP_ELL_INT_RD :
return builtin_op_ell_int_rd;
case OP_ELL_INT_RF :
return builtin_op_ell_int_rf;
case OP_ELL_INT_RJ :
return builtin_op_ell_int_rj;
case OP_ELL_JAC :
return builtin_op_ell_jac;
case OP_MAKE_M2X2 :
return builtin_op_make_m2x2;
case OP_MAKE_M3X3 :
return builtin_op_make_m3x3;
case OP_FREE_MATRIX :
return builtin_op_free_matrix;
case OP_MAKE_V2 :
return builtin_op_make_v2;
case OP_MAKE_V3 :
return builtin_op_make_v3;
case OP_V2_NTH :
return builtin_op_v2_nth;
case OP_V3_NTH :
return builtin_op_v3_nth;
case OP_SOLVE_LINEAR_2 :
return builtin_op_solve_linear_2;
case OP_SOLVE_LINEAR_3 :
return builtin_op_solve_linear_3;
case OP_SOLVE_POLY_2 :
return builtin_op_solve_poly_2;
case OP_SOLVE_POLY_3 :
return builtin_op_solve_poly_3;
case OP_NOISE :
return builtin_op_noise;
case OP_RAND :
return builtin_op_rand;
case OP_USERVAL_INT :
return builtin_op_userval_int;
case OP_USERVAL_FLOAT :
return builtin_op_userval_float;
case OP_USERVAL_BOOL :
return builtin_op_userval_bool;
case OP_USERVAL_CURVE :
return builtin_op_userval_curve;
case OP_USERVAL_COLOR :
return builtin_op_userval_color;
case OP_USERVAL_GRADIENT :
return builtin_op_userval_gradient;
case OP_USERVAL_IMAGE :
return builtin_op_userval_image;
case OP_OUTPUT_TUPLE :
return builtin_op_output_tuple;
default : assert(0);
}
}
