MathMap for Windows - Test Release
==================================

MathMap for Windows requires that you have GIMP 2.6 installed.  You
can download it here:

  http://www.gimp.org/windows/

After you have started GIMP at least once, you should have a folder
with the name `.gimp-2.6' in your home folder, i.e. something like

  C:\Documents and Settings\Your Name\.gimp-2.6

Copy all the files (.exe and .dll's) in `plug-ins' into the sub-folder
of the same name of the `.gimp-2.6' folder.  Copy the `mathmap' folder
into the `.gimp-2.6' folder.

The next time you start GIMP, MathMap should be accessible from
Filters->Generic->MathMap->MathMap.

-- 
Mark Probst
mark.probst@gmail.com
