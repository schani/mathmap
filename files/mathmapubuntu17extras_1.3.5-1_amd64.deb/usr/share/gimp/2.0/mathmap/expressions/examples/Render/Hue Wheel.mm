#Hue Wheel Nevit Dilmen 2009
#Draws a Color Wheel
filter Hue_Wheel ()
  toRGBA(hsva:[a/(2*pi), 1, 1, 1])
end 