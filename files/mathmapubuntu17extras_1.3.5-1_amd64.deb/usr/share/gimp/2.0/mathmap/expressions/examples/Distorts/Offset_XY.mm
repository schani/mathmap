stretchedfilter simple_int (stretched image in ,float offset_X: -1-1 (0),float offset_Y: -1-1 (0))u=x+offset_X;v=y+offset_Y;in(xy:[u,v])end
