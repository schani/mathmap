stretched filter util_visualize_fft (stretched image in, bool ignore_alpha (1))
  visualize_fft(in, ignore_alpha, xy)
end
