stretched filter util_render (stretched image in)
    rendered = render(in);
    rendered(xy)
end
