#Time Rotate Nevit Dilmen 2009
#Rotates image with "t"
filter rotate_time (image in)
in(ra + ra:[0, 2*pi*t])
end 