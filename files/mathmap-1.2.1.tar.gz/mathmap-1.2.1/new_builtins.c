static void
gen_print (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_0;
for (tmp_0 = 0; tmp_0 < arglengths[0]; ++tmp_0)
{
{
compvar_t *tmp_1;
tmp_1 = make_temporary(TYPE_INT);
{
compvar_t *tmp_2;
tmp_2 = args[0][tmp_0];
emit_assign(make_lhs(tmp_1), make_op_rhs(OP_PRINT, make_compvar_primary(tmp_2)));
}
}
}
}
{
compvar_t *tmp_3;
tmp_3 = make_temporary(TYPE_INT);
{
emit_assign(make_lhs(tmp_3), make_op_rhs(OP_NEWLINE));
}
}
{
int tmp_4;
for (tmp_4 = 0; tmp_4 < 1; ++tmp_4)
{
switch (tmp_4)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_4]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_5;
for (tmp_5 = 0; tmp_5 < 2; ++tmp_5)
{
{
compvar_t *tmp_6, *tmp_7;
tmp_6 = args[0][tmp_5];
tmp_7 = args[1][tmp_5];
emit_assign(make_lhs(result_tmps[tmp_5]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_6), make_compvar_primary(tmp_7)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_8;
for (tmp_8 = 0; tmp_8 < 2; ++tmp_8)
{
{
compvar_t *tmp_9, *tmp_10;
tmp_9 = args[0][tmp_8];
switch (tmp_8)
{
case 0 :
tmp_10 = args[1][0];
break;
case 1 :
tmp_10 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_10), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_8]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_9), make_compvar_primary(tmp_10)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_11;
for (tmp_11 = 0; tmp_11 < 2; ++tmp_11)
{
{
compvar_t *tmp_12, *tmp_13;
tmp_12 = args[1][tmp_11];
switch (tmp_11)
{
case 0 :
tmp_13 = args[0][0];
break;
case 1 :
tmp_13 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_13), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_11]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_12), make_compvar_primary(tmp_13)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_14;
for (tmp_14 = 0; tmp_14 < 1; ++tmp_14)
{
{
compvar_t *tmp_15, *tmp_16;
tmp_15 = args[0][tmp_14];
tmp_16 = args[1][tmp_14];
emit_assign(make_lhs(result_tmps[tmp_14]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_15), make_compvar_primary(tmp_16)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_17;
for (tmp_17 = 0; tmp_17 < arglengths[0]; ++tmp_17)
{
{
compvar_t *tmp_18, *tmp_19;
tmp_18 = args[0][tmp_17];
tmp_19 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_17]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_18), make_compvar_primary(tmp_19)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_add_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_20;
for (tmp_20 = 0; tmp_20 < arglengths[0]; ++tmp_20)
{
{
compvar_t *tmp_21, *tmp_22;
tmp_21 = args[0][tmp_20];
tmp_22 = args[1][tmp_20];
emit_assign(make_lhs(result_tmps[tmp_20]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_21), make_compvar_primary(tmp_22)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_23;
for (tmp_23 = 0; tmp_23 < 2; ++tmp_23)
{
{
compvar_t *tmp_24, *tmp_25;
tmp_24 = args[0][tmp_23];
tmp_25 = args[1][tmp_23];
emit_assign(make_lhs(result_tmps[tmp_23]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_24), make_compvar_primary(tmp_25)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_26;
for (tmp_26 = 0; tmp_26 < 2; ++tmp_26)
{
{
compvar_t *tmp_27, *tmp_28;
tmp_27 = args[0][tmp_26];
switch (tmp_26)
{
case 0 :
tmp_28 = args[1][0];
break;
case 1 :
tmp_28 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_28), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result_tmps[tmp_26]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_27), make_compvar_primary(tmp_28)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_29;
for (tmp_29 = 0; tmp_29 < 2; ++tmp_29)
{
{
compvar_t *tmp_30, *tmp_31;
switch (tmp_29)
{
case 0 :
tmp_30 = args[0][0];
break;
case 1 :
tmp_30 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_30), make_int_const_rhs(0));
break;
default :
assert(0);
}
tmp_31 = args[1][tmp_29];
emit_assign(make_lhs(result_tmps[tmp_29]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_30), make_compvar_primary(tmp_31)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_32;
for (tmp_32 = 0; tmp_32 < 1; ++tmp_32)
{
{
compvar_t *tmp_33, *tmp_34;
tmp_33 = args[0][tmp_32];
tmp_34 = args[1][tmp_32];
emit_assign(make_lhs(result_tmps[tmp_32]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_33), make_compvar_primary(tmp_34)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_35;
for (tmp_35 = 0; tmp_35 < arglengths[0]; ++tmp_35)
{
{
compvar_t *tmp_36, *tmp_37;
tmp_36 = args[0][tmp_35];
tmp_37 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_35]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_36), make_compvar_primary(tmp_37)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sub_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_38;
for (tmp_38 = 0; tmp_38 < arglengths[0]; ++tmp_38)
{
{
compvar_t *tmp_39, *tmp_40;
tmp_39 = args[0][tmp_38];
tmp_40 = args[1][tmp_38];
emit_assign(make_lhs(result_tmps[tmp_38]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_39), make_compvar_primary(tmp_40)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_neg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_41;
for (tmp_41 = 0; tmp_41 < arglengths[0]; ++tmp_41)
{
{
compvar_t *tmp_42;
tmp_42 = args[0][tmp_41];
emit_assign(make_lhs(result_tmps[tmp_41]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_42)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_43;
for (tmp_43 = 0; tmp_43 < 2; ++tmp_43)
{
switch (tmp_43)
{
case 0 :
{
compvar_t *tmp_44, *tmp_45;
tmp_44 = make_temporary(TYPE_INT);
{
compvar_t *tmp_46, *tmp_47;
tmp_46 = args[0][0];
tmp_47 = args[1][0];
emit_assign(make_lhs(tmp_44), make_op_rhs(OP_MUL, make_compvar_primary(tmp_46), make_compvar_primary(tmp_47)));
}
tmp_45 = make_temporary(TYPE_INT);
{
compvar_t *tmp_48, *tmp_49;
tmp_48 = args[0][1];
tmp_49 = args[1][1];
emit_assign(make_lhs(tmp_45), make_op_rhs(OP_MUL, make_compvar_primary(tmp_48), make_compvar_primary(tmp_49)));
}
emit_assign(make_lhs(result_tmps[tmp_43]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_44), make_compvar_primary(tmp_45)));
}
break;
case 1 :
{
compvar_t *tmp_50, *tmp_51;
tmp_50 = make_temporary(TYPE_INT);
{
compvar_t *tmp_52, *tmp_53;
tmp_52 = args[0][0];
tmp_53 = args[1][1];
emit_assign(make_lhs(tmp_50), make_op_rhs(OP_MUL, make_compvar_primary(tmp_52), make_compvar_primary(tmp_53)));
}
tmp_51 = make_temporary(TYPE_INT);
{
compvar_t *tmp_54, *tmp_55;
tmp_54 = args[1][0];
tmp_55 = args[0][1];
emit_assign(make_lhs(tmp_51), make_op_rhs(OP_MUL, make_compvar_primary(tmp_54), make_compvar_primary(tmp_55)));
}
emit_assign(make_lhs(result_tmps[tmp_43]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_50), make_compvar_primary(tmp_51)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_56;
for (tmp_56 = 0; tmp_56 < 2; ++tmp_56)
{
{
compvar_t *tmp_57, *tmp_58;
tmp_57 = args[0][0];
tmp_58 = args[1][tmp_56];
emit_assign(make_lhs(result_tmps[tmp_56]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_57), make_compvar_primary(tmp_58)));
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_59;
for (tmp_59 = 0; tmp_59 < 4; ++tmp_59)
{
switch (tmp_59)
{
case 0 :
{
compvar_t *tmp_60, *tmp_61;
tmp_60 = make_temporary(TYPE_INT);
{
compvar_t *tmp_62, *tmp_63;
tmp_62 = args[0][0];
tmp_63 = args[1][0];
emit_assign(make_lhs(tmp_60), make_op_rhs(OP_MUL, make_compvar_primary(tmp_62), make_compvar_primary(tmp_63)));
}
tmp_61 = make_temporary(TYPE_INT);
{
compvar_t *tmp_64, *tmp_65;
tmp_64 = args[0][1];
tmp_65 = args[1][2];
emit_assign(make_lhs(tmp_61), make_op_rhs(OP_MUL, make_compvar_primary(tmp_64), make_compvar_primary(tmp_65)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_60), make_compvar_primary(tmp_61)));
}
break;
case 1 :
{
compvar_t *tmp_66, *tmp_67;
tmp_66 = make_temporary(TYPE_INT);
{
compvar_t *tmp_68, *tmp_69;
tmp_68 = args[0][0];
tmp_69 = args[1][1];
emit_assign(make_lhs(tmp_66), make_op_rhs(OP_MUL, make_compvar_primary(tmp_68), make_compvar_primary(tmp_69)));
}
tmp_67 = make_temporary(TYPE_INT);
{
compvar_t *tmp_70, *tmp_71;
tmp_70 = args[0][1];
tmp_71 = args[1][3];
emit_assign(make_lhs(tmp_67), make_op_rhs(OP_MUL, make_compvar_primary(tmp_70), make_compvar_primary(tmp_71)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_66), make_compvar_primary(tmp_67)));
}
break;
case 2 :
{
compvar_t *tmp_72, *tmp_73;
tmp_72 = make_temporary(TYPE_INT);
{
compvar_t *tmp_74, *tmp_75;
tmp_74 = args[0][2];
tmp_75 = args[1][0];
emit_assign(make_lhs(tmp_72), make_op_rhs(OP_MUL, make_compvar_primary(tmp_74), make_compvar_primary(tmp_75)));
}
tmp_73 = make_temporary(TYPE_INT);
{
compvar_t *tmp_76, *tmp_77;
tmp_76 = args[0][3];
tmp_77 = args[1][2];
emit_assign(make_lhs(tmp_73), make_op_rhs(OP_MUL, make_compvar_primary(tmp_76), make_compvar_primary(tmp_77)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_72), make_compvar_primary(tmp_73)));
}
break;
case 3 :
{
compvar_t *tmp_78, *tmp_79;
tmp_78 = make_temporary(TYPE_INT);
{
compvar_t *tmp_80, *tmp_81;
tmp_80 = args[0][2];
tmp_81 = args[1][1];
emit_assign(make_lhs(tmp_78), make_op_rhs(OP_MUL, make_compvar_primary(tmp_80), make_compvar_primary(tmp_81)));
}
tmp_79 = make_temporary(TYPE_INT);
{
compvar_t *tmp_82, *tmp_83;
tmp_82 = args[0][3];
tmp_83 = args[1][3];
emit_assign(make_lhs(tmp_79), make_op_rhs(OP_MUL, make_compvar_primary(tmp_82), make_compvar_primary(tmp_83)));
}
emit_assign(make_lhs(result_tmps[tmp_59]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_78), make_compvar_primary(tmp_79)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[9];
int i;
for (i = 0; i < 9; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_84;
for (tmp_84 = 0; tmp_84 < 9; ++tmp_84)
{
switch (tmp_84)
{
case 0 :
{
compvar_t *tmp_85, *tmp_86;
tmp_85 = make_temporary(TYPE_INT);
{
compvar_t *tmp_87, *tmp_88;
tmp_87 = make_temporary(TYPE_INT);
{
compvar_t *tmp_89, *tmp_90;
tmp_89 = args[0][0];
tmp_90 = args[1][0];
emit_assign(make_lhs(tmp_87), make_op_rhs(OP_MUL, make_compvar_primary(tmp_89), make_compvar_primary(tmp_90)));
}
tmp_88 = make_temporary(TYPE_INT);
{
compvar_t *tmp_91, *tmp_92;
tmp_91 = args[0][1];
tmp_92 = args[1][3];
emit_assign(make_lhs(tmp_88), make_op_rhs(OP_MUL, make_compvar_primary(tmp_91), make_compvar_primary(tmp_92)));
}
emit_assign(make_lhs(tmp_85), make_op_rhs(OP_ADD, make_compvar_primary(tmp_87), make_compvar_primary(tmp_88)));
}
tmp_86 = make_temporary(TYPE_INT);
{
compvar_t *tmp_93, *tmp_94;
tmp_93 = args[0][2];
tmp_94 = args[1][6];
emit_assign(make_lhs(tmp_86), make_op_rhs(OP_MUL, make_compvar_primary(tmp_93), make_compvar_primary(tmp_94)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_85), make_compvar_primary(tmp_86)));
}
break;
case 1 :
{
compvar_t *tmp_95, *tmp_96;
tmp_95 = make_temporary(TYPE_INT);
{
compvar_t *tmp_97, *tmp_98;
tmp_97 = make_temporary(TYPE_INT);
{
compvar_t *tmp_99, *tmp_100;
tmp_99 = args[0][0];
tmp_100 = args[1][1];
emit_assign(make_lhs(tmp_97), make_op_rhs(OP_MUL, make_compvar_primary(tmp_99), make_compvar_primary(tmp_100)));
}
tmp_98 = make_temporary(TYPE_INT);
{
compvar_t *tmp_101, *tmp_102;
tmp_101 = args[0][1];
tmp_102 = args[1][4];
emit_assign(make_lhs(tmp_98), make_op_rhs(OP_MUL, make_compvar_primary(tmp_101), make_compvar_primary(tmp_102)));
}
emit_assign(make_lhs(tmp_95), make_op_rhs(OP_ADD, make_compvar_primary(tmp_97), make_compvar_primary(tmp_98)));
}
tmp_96 = make_temporary(TYPE_INT);
{
compvar_t *tmp_103, *tmp_104;
tmp_103 = args[0][2];
tmp_104 = args[1][7];
emit_assign(make_lhs(tmp_96), make_op_rhs(OP_MUL, make_compvar_primary(tmp_103), make_compvar_primary(tmp_104)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_95), make_compvar_primary(tmp_96)));
}
break;
case 2 :
{
compvar_t *tmp_105, *tmp_106;
tmp_105 = make_temporary(TYPE_INT);
{
compvar_t *tmp_107, *tmp_108;
tmp_107 = make_temporary(TYPE_INT);
{
compvar_t *tmp_109, *tmp_110;
tmp_109 = args[0][0];
tmp_110 = args[1][2];
emit_assign(make_lhs(tmp_107), make_op_rhs(OP_MUL, make_compvar_primary(tmp_109), make_compvar_primary(tmp_110)));
}
tmp_108 = make_temporary(TYPE_INT);
{
compvar_t *tmp_111, *tmp_112;
tmp_111 = args[0][1];
tmp_112 = args[1][5];
emit_assign(make_lhs(tmp_108), make_op_rhs(OP_MUL, make_compvar_primary(tmp_111), make_compvar_primary(tmp_112)));
}
emit_assign(make_lhs(tmp_105), make_op_rhs(OP_ADD, make_compvar_primary(tmp_107), make_compvar_primary(tmp_108)));
}
tmp_106 = make_temporary(TYPE_INT);
{
compvar_t *tmp_113, *tmp_114;
tmp_113 = args[0][2];
tmp_114 = args[1][8];
emit_assign(make_lhs(tmp_106), make_op_rhs(OP_MUL, make_compvar_primary(tmp_113), make_compvar_primary(tmp_114)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_105), make_compvar_primary(tmp_106)));
}
break;
case 3 :
{
compvar_t *tmp_115, *tmp_116;
tmp_115 = make_temporary(TYPE_INT);
{
compvar_t *tmp_117, *tmp_118;
tmp_117 = make_temporary(TYPE_INT);
{
compvar_t *tmp_119, *tmp_120;
tmp_119 = args[0][3];
tmp_120 = args[1][0];
emit_assign(make_lhs(tmp_117), make_op_rhs(OP_MUL, make_compvar_primary(tmp_119), make_compvar_primary(tmp_120)));
}
tmp_118 = make_temporary(TYPE_INT);
{
compvar_t *tmp_121, *tmp_122;
tmp_121 = args[0][4];
tmp_122 = args[1][3];
emit_assign(make_lhs(tmp_118), make_op_rhs(OP_MUL, make_compvar_primary(tmp_121), make_compvar_primary(tmp_122)));
}
emit_assign(make_lhs(tmp_115), make_op_rhs(OP_ADD, make_compvar_primary(tmp_117), make_compvar_primary(tmp_118)));
}
tmp_116 = make_temporary(TYPE_INT);
{
compvar_t *tmp_123, *tmp_124;
tmp_123 = args[0][5];
tmp_124 = args[1][6];
emit_assign(make_lhs(tmp_116), make_op_rhs(OP_MUL, make_compvar_primary(tmp_123), make_compvar_primary(tmp_124)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_115), make_compvar_primary(tmp_116)));
}
break;
case 4 :
{
compvar_t *tmp_125, *tmp_126;
tmp_125 = make_temporary(TYPE_INT);
{
compvar_t *tmp_127, *tmp_128;
tmp_127 = make_temporary(TYPE_INT);
{
compvar_t *tmp_129, *tmp_130;
tmp_129 = args[0][3];
tmp_130 = args[1][1];
emit_assign(make_lhs(tmp_127), make_op_rhs(OP_MUL, make_compvar_primary(tmp_129), make_compvar_primary(tmp_130)));
}
tmp_128 = make_temporary(TYPE_INT);
{
compvar_t *tmp_131, *tmp_132;
tmp_131 = args[0][4];
tmp_132 = args[1][4];
emit_assign(make_lhs(tmp_128), make_op_rhs(OP_MUL, make_compvar_primary(tmp_131), make_compvar_primary(tmp_132)));
}
emit_assign(make_lhs(tmp_125), make_op_rhs(OP_ADD, make_compvar_primary(tmp_127), make_compvar_primary(tmp_128)));
}
tmp_126 = make_temporary(TYPE_INT);
{
compvar_t *tmp_133, *tmp_134;
tmp_133 = args[0][5];
tmp_134 = args[1][7];
emit_assign(make_lhs(tmp_126), make_op_rhs(OP_MUL, make_compvar_primary(tmp_133), make_compvar_primary(tmp_134)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_125), make_compvar_primary(tmp_126)));
}
break;
case 5 :
{
compvar_t *tmp_135, *tmp_136;
tmp_135 = make_temporary(TYPE_INT);
{
compvar_t *tmp_137, *tmp_138;
tmp_137 = make_temporary(TYPE_INT);
{
compvar_t *tmp_139, *tmp_140;
tmp_139 = args[0][3];
tmp_140 = args[1][2];
emit_assign(make_lhs(tmp_137), make_op_rhs(OP_MUL, make_compvar_primary(tmp_139), make_compvar_primary(tmp_140)));
}
tmp_138 = make_temporary(TYPE_INT);
{
compvar_t *tmp_141, *tmp_142;
tmp_141 = args[0][4];
tmp_142 = args[1][5];
emit_assign(make_lhs(tmp_138), make_op_rhs(OP_MUL, make_compvar_primary(tmp_141), make_compvar_primary(tmp_142)));
}
emit_assign(make_lhs(tmp_135), make_op_rhs(OP_ADD, make_compvar_primary(tmp_137), make_compvar_primary(tmp_138)));
}
tmp_136 = make_temporary(TYPE_INT);
{
compvar_t *tmp_143, *tmp_144;
tmp_143 = args[0][5];
tmp_144 = args[1][8];
emit_assign(make_lhs(tmp_136), make_op_rhs(OP_MUL, make_compvar_primary(tmp_143), make_compvar_primary(tmp_144)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_135), make_compvar_primary(tmp_136)));
}
break;
case 6 :
{
compvar_t *tmp_145, *tmp_146;
tmp_145 = make_temporary(TYPE_INT);
{
compvar_t *tmp_147, *tmp_148;
tmp_147 = make_temporary(TYPE_INT);
{
compvar_t *tmp_149, *tmp_150;
tmp_149 = args[0][6];
tmp_150 = args[1][0];
emit_assign(make_lhs(tmp_147), make_op_rhs(OP_MUL, make_compvar_primary(tmp_149), make_compvar_primary(tmp_150)));
}
tmp_148 = make_temporary(TYPE_INT);
{
compvar_t *tmp_151, *tmp_152;
tmp_151 = args[0][7];
tmp_152 = args[1][3];
emit_assign(make_lhs(tmp_148), make_op_rhs(OP_MUL, make_compvar_primary(tmp_151), make_compvar_primary(tmp_152)));
}
emit_assign(make_lhs(tmp_145), make_op_rhs(OP_ADD, make_compvar_primary(tmp_147), make_compvar_primary(tmp_148)));
}
tmp_146 = make_temporary(TYPE_INT);
{
compvar_t *tmp_153, *tmp_154;
tmp_153 = args[0][8];
tmp_154 = args[1][6];
emit_assign(make_lhs(tmp_146), make_op_rhs(OP_MUL, make_compvar_primary(tmp_153), make_compvar_primary(tmp_154)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_145), make_compvar_primary(tmp_146)));
}
break;
case 7 :
{
compvar_t *tmp_155, *tmp_156;
tmp_155 = make_temporary(TYPE_INT);
{
compvar_t *tmp_157, *tmp_158;
tmp_157 = make_temporary(TYPE_INT);
{
compvar_t *tmp_159, *tmp_160;
tmp_159 = args[0][6];
tmp_160 = args[1][1];
emit_assign(make_lhs(tmp_157), make_op_rhs(OP_MUL, make_compvar_primary(tmp_159), make_compvar_primary(tmp_160)));
}
tmp_158 = make_temporary(TYPE_INT);
{
compvar_t *tmp_161, *tmp_162;
tmp_161 = args[0][7];
tmp_162 = args[1][4];
emit_assign(make_lhs(tmp_158), make_op_rhs(OP_MUL, make_compvar_primary(tmp_161), make_compvar_primary(tmp_162)));
}
emit_assign(make_lhs(tmp_155), make_op_rhs(OP_ADD, make_compvar_primary(tmp_157), make_compvar_primary(tmp_158)));
}
tmp_156 = make_temporary(TYPE_INT);
{
compvar_t *tmp_163, *tmp_164;
tmp_163 = args[0][8];
tmp_164 = args[1][7];
emit_assign(make_lhs(tmp_156), make_op_rhs(OP_MUL, make_compvar_primary(tmp_163), make_compvar_primary(tmp_164)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_155), make_compvar_primary(tmp_156)));
}
break;
case 8 :
{
compvar_t *tmp_165, *tmp_166;
tmp_165 = make_temporary(TYPE_INT);
{
compvar_t *tmp_167, *tmp_168;
tmp_167 = make_temporary(TYPE_INT);
{
compvar_t *tmp_169, *tmp_170;
tmp_169 = args[0][6];
tmp_170 = args[1][2];
emit_assign(make_lhs(tmp_167), make_op_rhs(OP_MUL, make_compvar_primary(tmp_169), make_compvar_primary(tmp_170)));
}
tmp_168 = make_temporary(TYPE_INT);
{
compvar_t *tmp_171, *tmp_172;
tmp_171 = args[0][7];
tmp_172 = args[1][5];
emit_assign(make_lhs(tmp_168), make_op_rhs(OP_MUL, make_compvar_primary(tmp_171), make_compvar_primary(tmp_172)));
}
emit_assign(make_lhs(tmp_165), make_op_rhs(OP_ADD, make_compvar_primary(tmp_167), make_compvar_primary(tmp_168)));
}
tmp_166 = make_temporary(TYPE_INT);
{
compvar_t *tmp_173, *tmp_174;
tmp_173 = args[0][8];
tmp_174 = args[1][8];
emit_assign(make_lhs(tmp_166), make_op_rhs(OP_MUL, make_compvar_primary(tmp_173), make_compvar_primary(tmp_174)));
}
emit_assign(make_lhs(result_tmps[tmp_84]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_165), make_compvar_primary(tmp_166)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 9; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_175;
for (tmp_175 = 0; tmp_175 < 2; ++tmp_175)
{
switch (tmp_175)
{
case 0 :
{
compvar_t *tmp_176, *tmp_177;
tmp_176 = make_temporary(TYPE_INT);
{
compvar_t *tmp_178, *tmp_179;
tmp_178 = args[0][0];
tmp_179 = args[1][0];
emit_assign(make_lhs(tmp_176), make_op_rhs(OP_MUL, make_compvar_primary(tmp_178), make_compvar_primary(tmp_179)));
}
tmp_177 = make_temporary(TYPE_INT);
{
compvar_t *tmp_180, *tmp_181;
tmp_180 = args[0][1];
tmp_181 = args[1][2];
emit_assign(make_lhs(tmp_177), make_op_rhs(OP_MUL, make_compvar_primary(tmp_180), make_compvar_primary(tmp_181)));
}
emit_assign(make_lhs(result_tmps[tmp_175]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_176), make_compvar_primary(tmp_177)));
}
break;
case 1 :
{
compvar_t *tmp_182, *tmp_183;
tmp_182 = make_temporary(TYPE_INT);
{
compvar_t *tmp_184, *tmp_185;
tmp_184 = args[0][0];
tmp_185 = args[1][1];
emit_assign(make_lhs(tmp_182), make_op_rhs(OP_MUL, make_compvar_primary(tmp_184), make_compvar_primary(tmp_185)));
}
tmp_183 = make_temporary(TYPE_INT);
{
compvar_t *tmp_186, *tmp_187;
tmp_186 = args[0][1];
tmp_187 = args[1][3];
emit_assign(make_lhs(tmp_183), make_op_rhs(OP_MUL, make_compvar_primary(tmp_186), make_compvar_primary(tmp_187)));
}
emit_assign(make_lhs(result_tmps[tmp_175]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_182), make_compvar_primary(tmp_183)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_188;
for (tmp_188 = 0; tmp_188 < 3; ++tmp_188)
{
switch (tmp_188)
{
case 0 :
{
compvar_t *tmp_189, *tmp_190;
tmp_189 = make_temporary(TYPE_INT);
{
compvar_t *tmp_191, *tmp_192;
tmp_191 = make_temporary(TYPE_INT);
{
compvar_t *tmp_193, *tmp_194;
tmp_193 = args[0][0];
tmp_194 = args[1][0];
emit_assign(make_lhs(tmp_191), make_op_rhs(OP_MUL, make_compvar_primary(tmp_193), make_compvar_primary(tmp_194)));
}
tmp_192 = make_temporary(TYPE_INT);
{
compvar_t *tmp_195, *tmp_196;
tmp_195 = args[0][1];
tmp_196 = args[1][3];
emit_assign(make_lhs(tmp_192), make_op_rhs(OP_MUL, make_compvar_primary(tmp_195), make_compvar_primary(tmp_196)));
}
emit_assign(make_lhs(tmp_189), make_op_rhs(OP_ADD, make_compvar_primary(tmp_191), make_compvar_primary(tmp_192)));
}
tmp_190 = make_temporary(TYPE_INT);
{
compvar_t *tmp_197, *tmp_198;
tmp_197 = args[0][2];
tmp_198 = args[1][6];
emit_assign(make_lhs(tmp_190), make_op_rhs(OP_MUL, make_compvar_primary(tmp_197), make_compvar_primary(tmp_198)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_189), make_compvar_primary(tmp_190)));
}
break;
case 1 :
{
compvar_t *tmp_199, *tmp_200;
tmp_199 = make_temporary(TYPE_INT);
{
compvar_t *tmp_201, *tmp_202;
tmp_201 = make_temporary(TYPE_INT);
{
compvar_t *tmp_203, *tmp_204;
tmp_203 = args[0][0];
tmp_204 = args[1][1];
emit_assign(make_lhs(tmp_201), make_op_rhs(OP_MUL, make_compvar_primary(tmp_203), make_compvar_primary(tmp_204)));
}
tmp_202 = make_temporary(TYPE_INT);
{
compvar_t *tmp_205, *tmp_206;
tmp_205 = args[0][1];
tmp_206 = args[1][4];
emit_assign(make_lhs(tmp_202), make_op_rhs(OP_MUL, make_compvar_primary(tmp_205), make_compvar_primary(tmp_206)));
}
emit_assign(make_lhs(tmp_199), make_op_rhs(OP_ADD, make_compvar_primary(tmp_201), make_compvar_primary(tmp_202)));
}
tmp_200 = make_temporary(TYPE_INT);
{
compvar_t *tmp_207, *tmp_208;
tmp_207 = args[0][2];
tmp_208 = args[1][7];
emit_assign(make_lhs(tmp_200), make_op_rhs(OP_MUL, make_compvar_primary(tmp_207), make_compvar_primary(tmp_208)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_199), make_compvar_primary(tmp_200)));
}
break;
case 2 :
{
compvar_t *tmp_209, *tmp_210;
tmp_209 = make_temporary(TYPE_INT);
{
compvar_t *tmp_211, *tmp_212;
tmp_211 = make_temporary(TYPE_INT);
{
compvar_t *tmp_213, *tmp_214;
tmp_213 = args[0][0];
tmp_214 = args[1][2];
emit_assign(make_lhs(tmp_211), make_op_rhs(OP_MUL, make_compvar_primary(tmp_213), make_compvar_primary(tmp_214)));
}
tmp_212 = make_temporary(TYPE_INT);
{
compvar_t *tmp_215, *tmp_216;
tmp_215 = args[0][1];
tmp_216 = args[1][5];
emit_assign(make_lhs(tmp_212), make_op_rhs(OP_MUL, make_compvar_primary(tmp_215), make_compvar_primary(tmp_216)));
}
emit_assign(make_lhs(tmp_209), make_op_rhs(OP_ADD, make_compvar_primary(tmp_211), make_compvar_primary(tmp_212)));
}
tmp_210 = make_temporary(TYPE_INT);
{
compvar_t *tmp_217, *tmp_218;
tmp_217 = args[0][2];
tmp_218 = args[1][8];
emit_assign(make_lhs(tmp_210), make_op_rhs(OP_MUL, make_compvar_primary(tmp_217), make_compvar_primary(tmp_218)));
}
emit_assign(make_lhs(result_tmps[tmp_188]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_209), make_compvar_primary(tmp_210)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m2x2v2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_219;
for (tmp_219 = 0; tmp_219 < 2; ++tmp_219)
{
switch (tmp_219)
{
case 0 :
{
compvar_t *tmp_220, *tmp_221;
tmp_220 = make_temporary(TYPE_INT);
{
compvar_t *tmp_222, *tmp_223;
tmp_222 = args[0][0];
tmp_223 = args[1][0];
emit_assign(make_lhs(tmp_220), make_op_rhs(OP_MUL, make_compvar_primary(tmp_222), make_compvar_primary(tmp_223)));
}
tmp_221 = make_temporary(TYPE_INT);
{
compvar_t *tmp_224, *tmp_225;
tmp_224 = args[0][1];
tmp_225 = args[1][1];
emit_assign(make_lhs(tmp_221), make_op_rhs(OP_MUL, make_compvar_primary(tmp_224), make_compvar_primary(tmp_225)));
}
emit_assign(make_lhs(result_tmps[tmp_219]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_220), make_compvar_primary(tmp_221)));
}
break;
case 1 :
{
compvar_t *tmp_226, *tmp_227;
tmp_226 = make_temporary(TYPE_INT);
{
compvar_t *tmp_228, *tmp_229;
tmp_228 = args[0][2];
tmp_229 = args[1][0];
emit_assign(make_lhs(tmp_226), make_op_rhs(OP_MUL, make_compvar_primary(tmp_228), make_compvar_primary(tmp_229)));
}
tmp_227 = make_temporary(TYPE_INT);
{
compvar_t *tmp_230, *tmp_231;
tmp_230 = args[0][3];
tmp_231 = args[1][1];
emit_assign(make_lhs(tmp_227), make_op_rhs(OP_MUL, make_compvar_primary(tmp_230), make_compvar_primary(tmp_231)));
}
emit_assign(make_lhs(result_tmps[tmp_219]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_226), make_compvar_primary(tmp_227)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_m3x3v3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_232;
for (tmp_232 = 0; tmp_232 < 3; ++tmp_232)
{
switch (tmp_232)
{
case 0 :
{
compvar_t *tmp_233, *tmp_234;
tmp_233 = make_temporary(TYPE_INT);
{
compvar_t *tmp_235, *tmp_236;
tmp_235 = make_temporary(TYPE_INT);
{
compvar_t *tmp_237, *tmp_238;
tmp_237 = args[0][0];
tmp_238 = args[1][0];
emit_assign(make_lhs(tmp_235), make_op_rhs(OP_MUL, make_compvar_primary(tmp_237), make_compvar_primary(tmp_238)));
}
tmp_236 = make_temporary(TYPE_INT);
{
compvar_t *tmp_239, *tmp_240;
tmp_239 = args[0][1];
tmp_240 = args[1][1];
emit_assign(make_lhs(tmp_236), make_op_rhs(OP_MUL, make_compvar_primary(tmp_239), make_compvar_primary(tmp_240)));
}
emit_assign(make_lhs(tmp_233), make_op_rhs(OP_ADD, make_compvar_primary(tmp_235), make_compvar_primary(tmp_236)));
}
tmp_234 = make_temporary(TYPE_INT);
{
compvar_t *tmp_241, *tmp_242;
tmp_241 = args[0][2];
tmp_242 = args[1][2];
emit_assign(make_lhs(tmp_234), make_op_rhs(OP_MUL, make_compvar_primary(tmp_241), make_compvar_primary(tmp_242)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_233), make_compvar_primary(tmp_234)));
}
break;
case 1 :
{
compvar_t *tmp_243, *tmp_244;
tmp_243 = make_temporary(TYPE_INT);
{
compvar_t *tmp_245, *tmp_246;
tmp_245 = make_temporary(TYPE_INT);
{
compvar_t *tmp_247, *tmp_248;
tmp_247 = args[0][3];
tmp_248 = args[1][0];
emit_assign(make_lhs(tmp_245), make_op_rhs(OP_MUL, make_compvar_primary(tmp_247), make_compvar_primary(tmp_248)));
}
tmp_246 = make_temporary(TYPE_INT);
{
compvar_t *tmp_249, *tmp_250;
tmp_249 = args[0][4];
tmp_250 = args[1][1];
emit_assign(make_lhs(tmp_246), make_op_rhs(OP_MUL, make_compvar_primary(tmp_249), make_compvar_primary(tmp_250)));
}
emit_assign(make_lhs(tmp_243), make_op_rhs(OP_ADD, make_compvar_primary(tmp_245), make_compvar_primary(tmp_246)));
}
tmp_244 = make_temporary(TYPE_INT);
{
compvar_t *tmp_251, *tmp_252;
tmp_251 = args[0][5];
tmp_252 = args[1][2];
emit_assign(make_lhs(tmp_244), make_op_rhs(OP_MUL, make_compvar_primary(tmp_251), make_compvar_primary(tmp_252)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_243), make_compvar_primary(tmp_244)));
}
break;
case 2 :
{
compvar_t *tmp_253, *tmp_254;
tmp_253 = make_temporary(TYPE_INT);
{
compvar_t *tmp_255, *tmp_256;
tmp_255 = make_temporary(TYPE_INT);
{
compvar_t *tmp_257, *tmp_258;
tmp_257 = args[0][6];
tmp_258 = args[1][0];
emit_assign(make_lhs(tmp_255), make_op_rhs(OP_MUL, make_compvar_primary(tmp_257), make_compvar_primary(tmp_258)));
}
tmp_256 = make_temporary(TYPE_INT);
{
compvar_t *tmp_259, *tmp_260;
tmp_259 = args[0][7];
tmp_260 = args[1][1];
emit_assign(make_lhs(tmp_256), make_op_rhs(OP_MUL, make_compvar_primary(tmp_259), make_compvar_primary(tmp_260)));
}
emit_assign(make_lhs(tmp_253), make_op_rhs(OP_ADD, make_compvar_primary(tmp_255), make_compvar_primary(tmp_256)));
}
tmp_254 = make_temporary(TYPE_INT);
{
compvar_t *tmp_261, *tmp_262;
tmp_261 = args[0][8];
tmp_262 = args[1][2];
emit_assign(make_lhs(tmp_254), make_op_rhs(OP_MUL, make_compvar_primary(tmp_261), make_compvar_primary(tmp_262)));
}
emit_assign(make_lhs(result_tmps[tmp_232]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_253), make_compvar_primary(tmp_254)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_263;
for (tmp_263 = 0; tmp_263 < 1; ++tmp_263)
{
switch (tmp_263)
{
case 0 :
{
compvar_t *tmp_264, *tmp_265;
tmp_264 = args[0][0];
tmp_265 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_263]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_264), make_compvar_primary(tmp_265)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_266;
for (tmp_266 = 0; tmp_266 < arglengths[0]; ++tmp_266)
{
{
compvar_t *tmp_267, *tmp_268;
tmp_267 = args[0][tmp_266];
tmp_268 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_266]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_267), make_compvar_primary(tmp_268)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mul_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_269;
for (tmp_269 = 0; tmp_269 < arglengths[0]; ++tmp_269)
{
{
compvar_t *tmp_270, *tmp_271;
tmp_270 = args[0][tmp_269];
tmp_271 = args[1][tmp_269];
emit_assign(make_lhs(result_tmps[tmp_269]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_270), make_compvar_primary(tmp_271)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_272;
tmp_272 = make_temporary(TYPE_INT);
{
compvar_t *tmp_273, *tmp_274;
tmp_273 = args[1][0];
tmp_274 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_274), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_272), make_op_rhs(OP_EQ, make_compvar_primary(tmp_273), make_compvar_primary(tmp_274)));
}
start_if_cond(make_compvar_rhs(tmp_272));
{
compvar_t *tmp_275, *tmp_276;
tmp_275 = args[1][1];
tmp_276 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_276), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_272), make_op_rhs(OP_EQ, make_compvar_primary(tmp_275), make_compvar_primary(tmp_276)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_272));
{
int tmp_277;
for (tmp_277 = 0; tmp_277 < 2; ++tmp_277)
{
switch (tmp_277)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_277]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_277]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_278;

if (2 == 1)
{
tmp_278 = make_temporary(TYPE_INT);
{
compvar_t *tmp_282, *tmp_283;
tmp_282 = args[1][0];
tmp_283 = args[1][0];
emit_assign(make_lhs(tmp_278), make_op_rhs(OP_MUL, make_compvar_primary(tmp_282), make_compvar_primary(tmp_283)));
}

}
else
{
compvar_t *tmp_279, *tmp_280;
int tmp_281;
tmp_278 = make_temporary(TYPE_INT);
tmp_279 = make_temporary(TYPE_INT);
{
compvar_t *tmp_284, *tmp_285;
tmp_284 = args[1][0];
tmp_285 = args[1][0];
emit_assign(make_lhs(tmp_279), make_op_rhs(OP_MUL, make_compvar_primary(tmp_284), make_compvar_primary(tmp_285)));
}
tmp_280 = make_temporary(TYPE_INT);
{
compvar_t *tmp_286, *tmp_287;
tmp_286 = args[1][1];
tmp_287 = args[1][1];
emit_assign(make_lhs(tmp_280), make_op_rhs(OP_MUL, make_compvar_primary(tmp_286), make_compvar_primary(tmp_287)));
}
emit_assign(make_lhs(tmp_278), make_op_rhs(OP_ADD, make_compvar_primary(tmp_279), make_compvar_primary(tmp_280)));
for (tmp_281 = 2; tmp_281 < 2; ++tmp_281)
{
tmp_279 = make_temporary(TYPE_INT);
{
compvar_t *tmp_288, *tmp_289;
tmp_288 = args[1][tmp_281];
tmp_289 = args[1][tmp_281];
emit_assign(make_lhs(tmp_279), make_op_rhs(OP_MUL, make_compvar_primary(tmp_288), make_compvar_primary(tmp_289)));
}
emit_assign(make_lhs(tmp_278), make_op_rhs(OP_ADD, make_compvar_primary(tmp_278), make_compvar_primary(tmp_279)));
}
}

{
int tmp_290;
for (tmp_290 = 0; tmp_290 < 2; ++tmp_290)
{
switch (tmp_290)
{
case 0 :
{
compvar_t *tmp_291, *tmp_292;
if (2 == 1)
{
tmp_291 = make_temporary(TYPE_INT);
{
compvar_t *tmp_296, *tmp_297;
tmp_296 = args[0][0];
tmp_297 = args[1][0];
emit_assign(make_lhs(tmp_291), make_op_rhs(OP_MUL, make_compvar_primary(tmp_296), make_compvar_primary(tmp_297)));
}

}
else
{
compvar_t *tmp_293, *tmp_294;
int tmp_295;
tmp_291 = make_temporary(TYPE_INT);
tmp_293 = make_temporary(TYPE_INT);
{
compvar_t *tmp_298, *tmp_299;
tmp_298 = args[0][0];
tmp_299 = args[1][0];
emit_assign(make_lhs(tmp_293), make_op_rhs(OP_MUL, make_compvar_primary(tmp_298), make_compvar_primary(tmp_299)));
}
tmp_294 = make_temporary(TYPE_INT);
{
compvar_t *tmp_300, *tmp_301;
tmp_300 = args[0][1];
tmp_301 = args[1][1];
emit_assign(make_lhs(tmp_294), make_op_rhs(OP_MUL, make_compvar_primary(tmp_300), make_compvar_primary(tmp_301)));
}
emit_assign(make_lhs(tmp_291), make_op_rhs(OP_ADD, make_compvar_primary(tmp_293), make_compvar_primary(tmp_294)));
for (tmp_295 = 2; tmp_295 < 2; ++tmp_295)
{
tmp_293 = make_temporary(TYPE_INT);
{
compvar_t *tmp_302, *tmp_303;
tmp_302 = args[0][tmp_295];
tmp_303 = args[1][tmp_295];
emit_assign(make_lhs(tmp_293), make_op_rhs(OP_MUL, make_compvar_primary(tmp_302), make_compvar_primary(tmp_303)));
}
emit_assign(make_lhs(tmp_291), make_op_rhs(OP_ADD, make_compvar_primary(tmp_291), make_compvar_primary(tmp_293)));
}
}
tmp_292 = tmp_278;
emit_assign(make_lhs(result_tmps[tmp_290]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_291), make_compvar_primary(tmp_292)));
}
break;
case 1 :
{
compvar_t *tmp_304, *tmp_305;
tmp_304 = make_temporary(TYPE_INT);
{
compvar_t *tmp_306, *tmp_307;
tmp_306 = make_temporary(TYPE_INT);
{
compvar_t *tmp_308, *tmp_309;
tmp_308 = make_temporary(TYPE_INT);
{
compvar_t *tmp_310;
tmp_310 = args[0][0];
emit_assign(make_lhs(tmp_308), make_op_rhs(OP_NEG, make_compvar_primary(tmp_310)));
}
tmp_309 = args[1][1];
emit_assign(make_lhs(tmp_306), make_op_rhs(OP_MUL, make_compvar_primary(tmp_308), make_compvar_primary(tmp_309)));
}
tmp_307 = make_temporary(TYPE_INT);
{
compvar_t *tmp_311, *tmp_312;
tmp_311 = args[1][0];
tmp_312 = args[0][1];
emit_assign(make_lhs(tmp_307), make_op_rhs(OP_MUL, make_compvar_primary(tmp_311), make_compvar_primary(tmp_312)));
}
emit_assign(make_lhs(tmp_304), make_op_rhs(OP_ADD, make_compvar_primary(tmp_306), make_compvar_primary(tmp_307)));
}
tmp_305 = tmp_278;
emit_assign(make_lhs(result_tmps[tmp_290]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_304), make_compvar_primary(tmp_305)));
}
break;
default :
assert(0);
}
}
}
}
end_if_cond();
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_313;

if (2 == 1)
{
tmp_313 = make_temporary(TYPE_INT);
{
compvar_t *tmp_317, *tmp_318;
tmp_317 = args[1][0];
tmp_318 = args[1][0];
emit_assign(make_lhs(tmp_313), make_op_rhs(OP_MUL, make_compvar_primary(tmp_317), make_compvar_primary(tmp_318)));
}

}
else
{
compvar_t *tmp_314, *tmp_315;
int tmp_316;
tmp_313 = make_temporary(TYPE_INT);
tmp_314 = make_temporary(TYPE_INT);
{
compvar_t *tmp_319, *tmp_320;
tmp_319 = args[1][0];
tmp_320 = args[1][0];
emit_assign(make_lhs(tmp_314), make_op_rhs(OP_MUL, make_compvar_primary(tmp_319), make_compvar_primary(tmp_320)));
}
tmp_315 = make_temporary(TYPE_INT);
{
compvar_t *tmp_321, *tmp_322;
tmp_321 = args[1][1];
tmp_322 = args[1][1];
emit_assign(make_lhs(tmp_315), make_op_rhs(OP_MUL, make_compvar_primary(tmp_321), make_compvar_primary(tmp_322)));
}
emit_assign(make_lhs(tmp_313), make_op_rhs(OP_ADD, make_compvar_primary(tmp_314), make_compvar_primary(tmp_315)));
for (tmp_316 = 2; tmp_316 < 2; ++tmp_316)
{
tmp_314 = make_temporary(TYPE_INT);
{
compvar_t *tmp_323, *tmp_324;
tmp_323 = args[1][tmp_316];
tmp_324 = args[1][tmp_316];
emit_assign(make_lhs(tmp_314), make_op_rhs(OP_MUL, make_compvar_primary(tmp_323), make_compvar_primary(tmp_324)));
}
emit_assign(make_lhs(tmp_313), make_op_rhs(OP_ADD, make_compvar_primary(tmp_313), make_compvar_primary(tmp_314)));
}
}

{
compvar_t *tmp_325;
tmp_325 = make_temporary(TYPE_INT);
{
compvar_t *tmp_326, *tmp_327;
tmp_326 = tmp_313;
tmp_327 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_327), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_325), make_op_rhs(OP_EQ, make_compvar_primary(tmp_326), make_compvar_primary(tmp_327)));
}
start_if_cond(make_compvar_rhs(tmp_325));
{
int tmp_328;
for (tmp_328 = 0; tmp_328 < 2; ++tmp_328)
{
switch (tmp_328)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_328]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_328]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_329;
for (tmp_329 = 0; tmp_329 < 2; ++tmp_329)
{
switch (tmp_329)
{
case 0 :
{
compvar_t *tmp_330, *tmp_331;
tmp_330 = make_temporary(TYPE_INT);
{
compvar_t *tmp_332, *tmp_333;
tmp_332 = args[0][0];
tmp_333 = args[1][0];
emit_assign(make_lhs(tmp_330), make_op_rhs(OP_MUL, make_compvar_primary(tmp_332), make_compvar_primary(tmp_333)));
}
tmp_331 = tmp_313;
emit_assign(make_lhs(result_tmps[tmp_329]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_330), make_compvar_primary(tmp_331)));
}
break;
case 1 :
{
compvar_t *tmp_334;
tmp_334 = make_temporary(TYPE_INT);
{
compvar_t *tmp_335, *tmp_336;
tmp_335 = make_temporary(TYPE_INT);
{
compvar_t *tmp_337, *tmp_338;
tmp_337 = args[0][0];
tmp_338 = args[1][1];
emit_assign(make_lhs(tmp_335), make_op_rhs(OP_MUL, make_compvar_primary(tmp_337), make_compvar_primary(tmp_338)));
}
tmp_336 = tmp_313;
emit_assign(make_lhs(tmp_334), make_op_rhs(OP_DIV, make_compvar_primary(tmp_335), make_compvar_primary(tmp_336)));
}
emit_assign(make_lhs(result_tmps[tmp_329]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_334)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_339;
compvar_t *tmp_344;

tmp_339 = make_temporary(TYPE_INT);
{
compvar_t *tmp_340, *tmp_341, *tmp_342, *tmp_343;
tmp_340 = args[1][0];
tmp_341 = args[1][1];
tmp_342 = args[1][2];
tmp_343 = args[1][3];
emit_assign(make_lhs(tmp_339), make_op_rhs(OP_MAKE_M2X2, make_compvar_primary(tmp_340), make_compvar_primary(tmp_341), make_compvar_primary(tmp_342), make_compvar_primary(tmp_343)));
}

tmp_344 = make_temporary(TYPE_INT);
{
compvar_t *tmp_345, *tmp_346;
tmp_345 = args[0][0];
tmp_346 = args[0][1];
emit_assign(make_lhs(tmp_344), make_op_rhs(OP_MAKE_V2, make_compvar_primary(tmp_345), make_compvar_primary(tmp_346)));
}

{
compvar_t *tmp_347;

tmp_347 = make_temporary(TYPE_INT);
{
compvar_t *tmp_348, *tmp_349;
tmp_348 = tmp_339;
tmp_349 = tmp_344;
emit_assign(make_lhs(tmp_347), make_op_rhs(OP_SOLVE_LINEAR_2, make_compvar_primary(tmp_348), make_compvar_primary(tmp_349)));
}

{
int tmp_350;
for (tmp_350 = 0; tmp_350 < 2; ++tmp_350)
{
switch (tmp_350)
{
case 0 :
{
compvar_t *tmp_351, *tmp_352;
tmp_351 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_351), make_int_const_rhs(0));
tmp_352 = tmp_347;
emit_assign(make_lhs(result_tmps[tmp_350]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_351), make_compvar_primary(tmp_352)));
}
break;
case 1 :
{
compvar_t *tmp_353, *tmp_354;
tmp_353 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_353), make_int_const_rhs(1));
tmp_354 = tmp_347;
emit_assign(make_lhs(result_tmps[tmp_350]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_353), make_compvar_primary(tmp_354)));
}
break;
default :
assert(0);
}
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_355;
compvar_t *tmp_365;

tmp_355 = make_temporary(TYPE_INT);
{
compvar_t *tmp_356, *tmp_357, *tmp_358, *tmp_359, *tmp_360, *tmp_361, *tmp_362, *tmp_363, *tmp_364;
tmp_356 = args[1][0];
tmp_357 = args[1][1];
tmp_358 = args[1][2];
tmp_359 = args[1][3];
tmp_360 = args[1][4];
tmp_361 = args[1][5];
tmp_362 = args[1][6];
tmp_363 = args[1][7];
tmp_364 = args[1][8];
emit_assign(make_lhs(tmp_355), make_op_rhs(OP_MAKE_M3X3, make_compvar_primary(tmp_356), make_compvar_primary(tmp_357), make_compvar_primary(tmp_358), make_compvar_primary(tmp_359), make_compvar_primary(tmp_360), make_compvar_primary(tmp_361), make_compvar_primary(tmp_362), make_compvar_primary(tmp_363), make_compvar_primary(tmp_364)));
}

tmp_365 = make_temporary(TYPE_INT);
{
compvar_t *tmp_366, *tmp_367, *tmp_368;
tmp_366 = args[0][0];
tmp_367 = args[0][1];
tmp_368 = args[0][2];
emit_assign(make_lhs(tmp_365), make_op_rhs(OP_MAKE_V3, make_compvar_primary(tmp_366), make_compvar_primary(tmp_367), make_compvar_primary(tmp_368)));
}

{
compvar_t *tmp_369;

tmp_369 = make_temporary(TYPE_INT);
{
compvar_t *tmp_370, *tmp_371;
tmp_370 = tmp_355;
tmp_371 = tmp_365;
emit_assign(make_lhs(tmp_369), make_op_rhs(OP_SOLVE_LINEAR_3, make_compvar_primary(tmp_370), make_compvar_primary(tmp_371)));
}

{
int tmp_372;
for (tmp_372 = 0; tmp_372 < 3; ++tmp_372)
{
switch (tmp_372)
{
case 0 :
{
compvar_t *tmp_373, *tmp_374;
tmp_373 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_373), make_int_const_rhs(0));
tmp_374 = tmp_369;
emit_assign(make_lhs(result_tmps[tmp_372]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_373), make_compvar_primary(tmp_374)));
}
break;
case 1 :
{
compvar_t *tmp_375, *tmp_376;
tmp_375 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_375), make_int_const_rhs(1));
tmp_376 = tmp_369;
emit_assign(make_lhs(result_tmps[tmp_372]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_375), make_compvar_primary(tmp_376)));
}
break;
case 2 :
{
compvar_t *tmp_377, *tmp_378;
tmp_377 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_377), make_int_const_rhs(2));
tmp_378 = tmp_369;
emit_assign(make_lhs(result_tmps[tmp_372]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_377), make_compvar_primary(tmp_378)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_379;
tmp_379 = make_temporary(TYPE_INT);
{
compvar_t *tmp_380;
tmp_380 = tmp_355;
emit_assign(make_lhs(tmp_379), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_380)));
}
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_381;
tmp_381 = make_temporary(TYPE_INT);
{
compvar_t *tmp_382, *tmp_383;
tmp_382 = args[1][0];
tmp_383 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_383), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_381), make_op_rhs(OP_EQ, make_compvar_primary(tmp_382), make_compvar_primary(tmp_383)));
}
start_if_cond(make_compvar_rhs(tmp_381));
{
int tmp_384;
for (tmp_384 = 0; tmp_384 < 1; ++tmp_384)
{
switch (tmp_384)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_384]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_385;
for (tmp_385 = 0; tmp_385 < 1; ++tmp_385)
{
{
compvar_t *tmp_386, *tmp_387;
tmp_386 = args[0][tmp_385];
tmp_387 = args[1][tmp_385];
emit_assign(make_lhs(result_tmps[tmp_385]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_386), make_compvar_primary(tmp_387)));
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_388;
tmp_388 = make_temporary(TYPE_INT);
{
compvar_t *tmp_389, *tmp_390;
tmp_389 = args[1][0];
tmp_390 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_390), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_388), make_op_rhs(OP_EQ, make_compvar_primary(tmp_389), make_compvar_primary(tmp_390)));
}
start_if_cond(make_compvar_rhs(tmp_388));
{
int tmp_391;
for (tmp_391 = 0; tmp_391 < arglengths[0]; ++tmp_391)
{
emit_assign(make_lhs(result_tmps[tmp_391]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_392;
for (tmp_392 = 0; tmp_392 < arglengths[0]; ++tmp_392)
{
{
compvar_t *tmp_393, *tmp_394;
tmp_393 = args[0][tmp_392];
tmp_394 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_392]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_393), make_compvar_primary(tmp_394)));
}
}
}
end_if_cond();
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_div_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_395;
for (tmp_395 = 0; tmp_395 < arglengths[1]; ++tmp_395)
{
{
compvar_t *tmp_396;
tmp_396 = make_temporary(TYPE_INT);
{
compvar_t *tmp_397, *tmp_398;
tmp_397 = args[1][tmp_395];
tmp_398 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_398), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_396), make_op_rhs(OP_EQ, make_compvar_primary(tmp_397), make_compvar_primary(tmp_398)));
}
start_if_cond(make_compvar_rhs(tmp_396));
emit_assign(make_lhs(result_tmps[tmp_395]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_399, *tmp_400;
tmp_399 = args[0][tmp_395];
tmp_400 = args[1][tmp_395];
emit_assign(make_lhs(result_tmps[tmp_395]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_399), make_compvar_primary(tmp_400)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_401;
tmp_401 = make_temporary(TYPE_INT);
{
compvar_t *tmp_402, *tmp_403;
tmp_402 = args[1][0];
tmp_403 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_403), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_401), make_op_rhs(OP_EQ, make_compvar_primary(tmp_402), make_compvar_primary(tmp_403)));
}
start_if_cond(make_compvar_rhs(tmp_401));
{
int tmp_404;
for (tmp_404 = 0; tmp_404 < 1; ++tmp_404)
{
switch (tmp_404)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_404]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_405;
for (tmp_405 = 0; tmp_405 < 1; ++tmp_405)
{
{
compvar_t *tmp_406, *tmp_407;
tmp_406 = args[0][tmp_405];
tmp_407 = args[1][tmp_405];
emit_assign(make_lhs(result_tmps[tmp_405]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_406), make_compvar_primary(tmp_407)));
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_408;
tmp_408 = make_temporary(TYPE_INT);
{
compvar_t *tmp_409, *tmp_410;
tmp_409 = args[1][0];
tmp_410 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_410), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_408), make_op_rhs(OP_EQ, make_compvar_primary(tmp_409), make_compvar_primary(tmp_410)));
}
start_if_cond(make_compvar_rhs(tmp_408));
{
int tmp_411;
for (tmp_411 = 0; tmp_411 < arglengths[0]; ++tmp_411)
{
emit_assign(make_lhs(result_tmps[tmp_411]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_412;
for (tmp_412 = 0; tmp_412 < arglengths[0]; ++tmp_412)
{
{
compvar_t *tmp_413, *tmp_414;
tmp_413 = args[0][tmp_412];
tmp_414 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_412]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_413), make_compvar_primary(tmp_414)));
}
}
}
end_if_cond();
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_mod_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_415;
for (tmp_415 = 0; tmp_415 < arglengths[1]; ++tmp_415)
{
{
compvar_t *tmp_416;
tmp_416 = make_temporary(TYPE_INT);
{
compvar_t *tmp_417, *tmp_418;
tmp_417 = args[1][tmp_415];
tmp_418 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_418), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_416), make_op_rhs(OP_EQ, make_compvar_primary(tmp_417), make_compvar_primary(tmp_418)));
}
start_if_cond(make_compvar_rhs(tmp_416));
emit_assign(make_lhs(result_tmps[tmp_415]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_419, *tmp_420;
tmp_419 = args[0][tmp_415];
tmp_420 = args[1][tmp_415];
emit_assign(make_lhs(result_tmps[tmp_415]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_419), make_compvar_primary(tmp_420)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pmod (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_421;

tmp_421 = make_temporary(TYPE_INT);
{
compvar_t *tmp_422, *tmp_423;
tmp_422 = args[0][0];
tmp_423 = args[1][0];
emit_assign(make_lhs(tmp_421), make_op_rhs(OP_MOD, make_compvar_primary(tmp_422), make_compvar_primary(tmp_423)));
}

{
compvar_t *tmp_424;
tmp_424 = make_temporary(TYPE_INT);
{
compvar_t *tmp_425, *tmp_426;
tmp_425 = args[0][0];
tmp_426 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_426), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_424), make_op_rhs(OP_LESS, make_compvar_primary(tmp_425), make_compvar_primary(tmp_426)));
}
start_if_cond(make_compvar_rhs(tmp_424));
{
int tmp_427;
for (tmp_427 = 0; tmp_427 < 1; ++tmp_427)
{
switch (tmp_427)
{
case 0 :
{
compvar_t *tmp_428, *tmp_429;
tmp_428 = tmp_421;
tmp_429 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_427]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_428), make_compvar_primary(tmp_429)));
}
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_430;
for (tmp_430 = 0; tmp_430 < 1; ++tmp_430)
{
switch (tmp_430)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_430]), make_compvar_rhs(tmp_421));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sqrt_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_431;

tmp_431 = make_temporary(TYPE_INT);
{
compvar_t *tmp_432;
tmp_432 = make_temporary(TYPE_INT);
{
compvar_t *tmp_433, *tmp_434;
tmp_433 = args[0][0];
tmp_434 = args[0][1];
emit_assign(make_lhs(tmp_432), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_433), make_compvar_primary(tmp_434)));
}
emit_assign(make_lhs(tmp_431), make_op_rhs(OP_C_SQRT, make_compvar_primary(tmp_432)));
}

{
int tmp_435;
for (tmp_435 = 0; tmp_435 < 2; ++tmp_435)
{
switch (tmp_435)
{
case 0 :
{
compvar_t *tmp_436;
tmp_436 = tmp_431;
emit_assign(make_lhs(result_tmps[tmp_435]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_436)));
}
break;
case 1 :
{
compvar_t *tmp_437;
tmp_437 = tmp_431;
emit_assign(make_lhs(result_tmps[tmp_435]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_437)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sqrt_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_438;
for (tmp_438 = 0; tmp_438 < 1; ++tmp_438)
{
switch (tmp_438)
{
case 0 :
{
compvar_t *tmp_439;
tmp_439 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_438]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_439)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sum (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_440;
for (tmp_440 = 0; tmp_440 < 1; ++tmp_440)
{
switch (tmp_440)
{
case 0 :
if (arglengths[0] == 1)
{
emit_assign(make_lhs(result_tmps[tmp_440]), make_compvar_rhs(args[0][0]));

}
else
{
compvar_t *tmp_441, *tmp_442;
int tmp_443;
tmp_441 = args[0][0];
tmp_442 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_440]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_441), make_compvar_primary(tmp_442)));
for (tmp_443 = 2; tmp_443 < arglengths[0]; ++tmp_443)
{
tmp_441 = args[0][tmp_443];
emit_assign(make_lhs(result_tmps[tmp_440]), make_op_rhs(OP_ADD, make_compvar_primary(result_tmps[tmp_440]), make_compvar_primary(tmp_441)));
}
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_dotp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_444;
for (tmp_444 = 0; tmp_444 < 1; ++tmp_444)
{
switch (tmp_444)
{
case 0 :
if (arglengths[0] == 1)
{
{
compvar_t *tmp_448, *tmp_449;
tmp_448 = args[0][0];
tmp_449 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_444]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_448), make_compvar_primary(tmp_449)));
}

}
else
{
compvar_t *tmp_445, *tmp_446;
int tmp_447;
tmp_445 = make_temporary(TYPE_INT);
{
compvar_t *tmp_450, *tmp_451;
tmp_450 = args[0][0];
tmp_451 = args[1][0];
emit_assign(make_lhs(tmp_445), make_op_rhs(OP_MUL, make_compvar_primary(tmp_450), make_compvar_primary(tmp_451)));
}
tmp_446 = make_temporary(TYPE_INT);
{
compvar_t *tmp_452, *tmp_453;
tmp_452 = args[0][1];
tmp_453 = args[1][1];
emit_assign(make_lhs(tmp_446), make_op_rhs(OP_MUL, make_compvar_primary(tmp_452), make_compvar_primary(tmp_453)));
}
emit_assign(make_lhs(result_tmps[tmp_444]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_445), make_compvar_primary(tmp_446)));
for (tmp_447 = 2; tmp_447 < arglengths[0]; ++tmp_447)
{
tmp_445 = make_temporary(TYPE_INT);
{
compvar_t *tmp_454, *tmp_455;
tmp_454 = args[0][tmp_447];
tmp_455 = args[1][tmp_447];
emit_assign(make_lhs(tmp_445), make_op_rhs(OP_MUL, make_compvar_primary(tmp_454), make_compvar_primary(tmp_455)));
}
emit_assign(make_lhs(result_tmps[tmp_444]), make_op_rhs(OP_ADD, make_compvar_primary(result_tmps[tmp_444]), make_compvar_primary(tmp_445)));
}
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_crossp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[3];
int i;
for (i = 0; i < 3; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_456;
for (tmp_456 = 0; tmp_456 < 3; ++tmp_456)
{
switch (tmp_456)
{
case 0 :
{
compvar_t *tmp_457, *tmp_458;
tmp_457 = make_temporary(TYPE_INT);
{
compvar_t *tmp_459, *tmp_460;
tmp_459 = args[0][1];
tmp_460 = args[1][2];
emit_assign(make_lhs(tmp_457), make_op_rhs(OP_MUL, make_compvar_primary(tmp_459), make_compvar_primary(tmp_460)));
}
tmp_458 = make_temporary(TYPE_INT);
{
compvar_t *tmp_461, *tmp_462;
tmp_461 = args[0][2];
tmp_462 = args[1][1];
emit_assign(make_lhs(tmp_458), make_op_rhs(OP_MUL, make_compvar_primary(tmp_461), make_compvar_primary(tmp_462)));
}
emit_assign(make_lhs(result_tmps[tmp_456]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_457), make_compvar_primary(tmp_458)));
}
break;
case 1 :
{
compvar_t *tmp_463, *tmp_464;
tmp_463 = make_temporary(TYPE_INT);
{
compvar_t *tmp_465, *tmp_466;
tmp_465 = args[0][2];
tmp_466 = args[1][0];
emit_assign(make_lhs(tmp_463), make_op_rhs(OP_MUL, make_compvar_primary(tmp_465), make_compvar_primary(tmp_466)));
}
tmp_464 = make_temporary(TYPE_INT);
{
compvar_t *tmp_467, *tmp_468;
tmp_467 = args[0][0];
tmp_468 = args[1][2];
emit_assign(make_lhs(tmp_464), make_op_rhs(OP_MUL, make_compvar_primary(tmp_467), make_compvar_primary(tmp_468)));
}
emit_assign(make_lhs(result_tmps[tmp_456]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_463), make_compvar_primary(tmp_464)));
}
break;
case 2 :
{
compvar_t *tmp_469, *tmp_470;
tmp_469 = make_temporary(TYPE_INT);
{
compvar_t *tmp_471, *tmp_472;
tmp_471 = args[0][0];
tmp_472 = args[1][1];
emit_assign(make_lhs(tmp_469), make_op_rhs(OP_MUL, make_compvar_primary(tmp_471), make_compvar_primary(tmp_472)));
}
tmp_470 = make_temporary(TYPE_INT);
{
compvar_t *tmp_473, *tmp_474;
tmp_473 = args[0][1];
tmp_474 = args[1][0];
emit_assign(make_lhs(tmp_470), make_op_rhs(OP_MUL, make_compvar_primary(tmp_473), make_compvar_primary(tmp_474)));
}
emit_assign(make_lhs(result_tmps[tmp_456]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_469), make_compvar_primary(tmp_470)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 3; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_det_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_475;
for (tmp_475 = 0; tmp_475 < 1; ++tmp_475)
{
switch (tmp_475)
{
case 0 :
{
compvar_t *tmp_476, *tmp_477;
tmp_476 = make_temporary(TYPE_INT);
{
compvar_t *tmp_478, *tmp_479;
tmp_478 = args[0][0];
tmp_479 = args[0][3];
emit_assign(make_lhs(tmp_476), make_op_rhs(OP_MUL, make_compvar_primary(tmp_478), make_compvar_primary(tmp_479)));
}
tmp_477 = make_temporary(TYPE_INT);
{
compvar_t *tmp_480, *tmp_481;
tmp_480 = args[0][1];
tmp_481 = args[0][2];
emit_assign(make_lhs(tmp_477), make_op_rhs(OP_MUL, make_compvar_primary(tmp_480), make_compvar_primary(tmp_481)));
}
emit_assign(make_lhs(result_tmps[tmp_475]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_476), make_compvar_primary(tmp_477)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_det_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_482;
for (tmp_482 = 0; tmp_482 < 1; ++tmp_482)
{
switch (tmp_482)
{
case 0 :
{
compvar_t *tmp_483, *tmp_484;
tmp_483 = make_temporary(TYPE_INT);
{
compvar_t *tmp_485, *tmp_486;
tmp_485 = make_temporary(TYPE_INT);
{
compvar_t *tmp_487, *tmp_488;
tmp_487 = make_temporary(TYPE_INT);
{
compvar_t *tmp_489, *tmp_490;
tmp_489 = make_temporary(TYPE_INT);
{
compvar_t *tmp_491, *tmp_492;
tmp_491 = args[0][0];
tmp_492 = args[0][4];
emit_assign(make_lhs(tmp_489), make_op_rhs(OP_MUL, make_compvar_primary(tmp_491), make_compvar_primary(tmp_492)));
}
tmp_490 = args[0][8];
emit_assign(make_lhs(tmp_487), make_op_rhs(OP_MUL, make_compvar_primary(tmp_489), make_compvar_primary(tmp_490)));
}
tmp_488 = make_temporary(TYPE_INT);
{
compvar_t *tmp_493, *tmp_494;
tmp_493 = make_temporary(TYPE_INT);
{
compvar_t *tmp_495, *tmp_496;
tmp_495 = args[0][1];
tmp_496 = args[0][5];
emit_assign(make_lhs(tmp_493), make_op_rhs(OP_MUL, make_compvar_primary(tmp_495), make_compvar_primary(tmp_496)));
}
tmp_494 = args[0][6];
emit_assign(make_lhs(tmp_488), make_op_rhs(OP_MUL, make_compvar_primary(tmp_493), make_compvar_primary(tmp_494)));
}
emit_assign(make_lhs(tmp_485), make_op_rhs(OP_ADD, make_compvar_primary(tmp_487), make_compvar_primary(tmp_488)));
}
tmp_486 = make_temporary(TYPE_INT);
{
compvar_t *tmp_497, *tmp_498;
tmp_497 = make_temporary(TYPE_INT);
{
compvar_t *tmp_499, *tmp_500;
tmp_499 = args[0][2];
tmp_500 = args[0][3];
emit_assign(make_lhs(tmp_497), make_op_rhs(OP_MUL, make_compvar_primary(tmp_499), make_compvar_primary(tmp_500)));
}
tmp_498 = args[0][7];
emit_assign(make_lhs(tmp_486), make_op_rhs(OP_MUL, make_compvar_primary(tmp_497), make_compvar_primary(tmp_498)));
}
emit_assign(make_lhs(tmp_483), make_op_rhs(OP_ADD, make_compvar_primary(tmp_485), make_compvar_primary(tmp_486)));
}
tmp_484 = make_temporary(TYPE_INT);
{
compvar_t *tmp_501, *tmp_502;
tmp_501 = make_temporary(TYPE_INT);
{
compvar_t *tmp_503, *tmp_504;
tmp_503 = make_temporary(TYPE_INT);
{
compvar_t *tmp_505, *tmp_506;
tmp_505 = make_temporary(TYPE_INT);
{
compvar_t *tmp_507, *tmp_508;
tmp_507 = args[0][2];
tmp_508 = args[0][4];
emit_assign(make_lhs(tmp_505), make_op_rhs(OP_MUL, make_compvar_primary(tmp_507), make_compvar_primary(tmp_508)));
}
tmp_506 = args[0][6];
emit_assign(make_lhs(tmp_503), make_op_rhs(OP_MUL, make_compvar_primary(tmp_505), make_compvar_primary(tmp_506)));
}
tmp_504 = make_temporary(TYPE_INT);
{
compvar_t *tmp_509, *tmp_510;
tmp_509 = make_temporary(TYPE_INT);
{
compvar_t *tmp_511, *tmp_512;
tmp_511 = args[0][0];
tmp_512 = args[0][5];
emit_assign(make_lhs(tmp_509), make_op_rhs(OP_MUL, make_compvar_primary(tmp_511), make_compvar_primary(tmp_512)));
}
tmp_510 = args[0][7];
emit_assign(make_lhs(tmp_504), make_op_rhs(OP_MUL, make_compvar_primary(tmp_509), make_compvar_primary(tmp_510)));
}
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_ADD, make_compvar_primary(tmp_503), make_compvar_primary(tmp_504)));
}
tmp_502 = make_temporary(TYPE_INT);
{
compvar_t *tmp_513, *tmp_514;
tmp_513 = make_temporary(TYPE_INT);
{
compvar_t *tmp_515, *tmp_516;
tmp_515 = args[0][1];
tmp_516 = args[0][3];
emit_assign(make_lhs(tmp_513), make_op_rhs(OP_MUL, make_compvar_primary(tmp_515), make_compvar_primary(tmp_516)));
}
tmp_514 = args[0][8];
emit_assign(make_lhs(tmp_502), make_op_rhs(OP_MUL, make_compvar_primary(tmp_513), make_compvar_primary(tmp_514)));
}
emit_assign(make_lhs(tmp_484), make_op_rhs(OP_ADD, make_compvar_primary(tmp_501), make_compvar_primary(tmp_502)));
}
emit_assign(make_lhs(result_tmps[tmp_482]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_483), make_compvar_primary(tmp_484)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_normalize (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_517;

if (arglengths[0] == 1)
{
tmp_517 = make_temporary(TYPE_INT);
{
compvar_t *tmp_521, *tmp_522;
tmp_521 = args[0][0];
tmp_522 = args[0][0];
emit_assign(make_lhs(tmp_517), make_op_rhs(OP_MUL, make_compvar_primary(tmp_521), make_compvar_primary(tmp_522)));
}

}
else
{
compvar_t *tmp_518, *tmp_519;
int tmp_520;
tmp_517 = make_temporary(TYPE_INT);
tmp_518 = make_temporary(TYPE_INT);
{
compvar_t *tmp_523, *tmp_524;
tmp_523 = args[0][0];
tmp_524 = args[0][0];
emit_assign(make_lhs(tmp_518), make_op_rhs(OP_MUL, make_compvar_primary(tmp_523), make_compvar_primary(tmp_524)));
}
tmp_519 = make_temporary(TYPE_INT);
{
compvar_t *tmp_525, *tmp_526;
tmp_525 = args[0][1];
tmp_526 = args[0][1];
emit_assign(make_lhs(tmp_519), make_op_rhs(OP_MUL, make_compvar_primary(tmp_525), make_compvar_primary(tmp_526)));
}
emit_assign(make_lhs(tmp_517), make_op_rhs(OP_ADD, make_compvar_primary(tmp_518), make_compvar_primary(tmp_519)));
for (tmp_520 = 2; tmp_520 < arglengths[0]; ++tmp_520)
{
tmp_518 = make_temporary(TYPE_INT);
{
compvar_t *tmp_527, *tmp_528;
tmp_527 = args[0][tmp_520];
tmp_528 = args[0][tmp_520];
emit_assign(make_lhs(tmp_518), make_op_rhs(OP_MUL, make_compvar_primary(tmp_527), make_compvar_primary(tmp_528)));
}
emit_assign(make_lhs(tmp_517), make_op_rhs(OP_ADD, make_compvar_primary(tmp_517), make_compvar_primary(tmp_518)));
}
}

{
compvar_t *tmp_529;
tmp_529 = make_temporary(TYPE_INT);
{
compvar_t *tmp_530, *tmp_531;
tmp_530 = tmp_517;
tmp_531 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_531), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_529), make_op_rhs(OP_EQ, make_compvar_primary(tmp_530), make_compvar_primary(tmp_531)));
}
start_if_cond(make_compvar_rhs(tmp_529));
{
int tmp_532;
for (tmp_532 = 0; tmp_532 < arglengths[0]; ++tmp_532)
{
emit_assign(make_lhs(result_tmps[tmp_532]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_533;
for (tmp_533 = 0; tmp_533 < arglengths[0]; ++tmp_533)
{
{
compvar_t *tmp_534, *tmp_535;
tmp_534 = args[0][tmp_533];
tmp_535 = make_temporary(TYPE_INT);
{
compvar_t *tmp_536;
tmp_536 = tmp_517;
emit_assign(make_lhs(tmp_535), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_536)));
}
emit_assign(make_lhs(result_tmps[tmp_533]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_534), make_compvar_primary(tmp_535)));
}
}
}
end_if_cond();
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_537;
for (tmp_537 = 0; tmp_537 < 1; ++tmp_537)
{
switch (tmp_537)
{
case 0 :
{
compvar_t *tmp_538, *tmp_539;
tmp_538 = args[0][0];
tmp_539 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_537]), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_538), make_compvar_primary(tmp_539)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_540;
for (tmp_540 = 0; tmp_540 < 1; ++tmp_540)
{
{
compvar_t *tmp_541;
tmp_541 = args[0][tmp_540];
emit_assign(make_lhs(result_tmps[tmp_540]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_541)));
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_abs_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_542;
for (tmp_542 = 0; tmp_542 < arglengths[0]; ++tmp_542)
{
{
compvar_t *tmp_543;
tmp_543 = args[0][tmp_542];
emit_assign(make_lhs(result_tmps[tmp_542]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_543)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_deg2rad (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_544;
for (tmp_544 = 0; tmp_544 < 1; ++tmp_544)
{
switch (tmp_544)
{
case 0 :
{
compvar_t *tmp_545, *tmp_546;
tmp_545 = args[0][0];
tmp_546 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_546), make_float_const_rhs(0.017453292));
emit_assign(make_lhs(result_tmps[tmp_544]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_545), make_compvar_primary(tmp_546)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rad2deg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_547;
for (tmp_547 = 0; tmp_547 < 1; ++tmp_547)
{
switch (tmp_547)
{
case 0 :
{
compvar_t *tmp_548, *tmp_549;
tmp_548 = args[0][0];
tmp_549 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_549), make_float_const_rhs(57.29578));
emit_assign(make_lhs(result_tmps[tmp_547]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_548), make_compvar_primary(tmp_549)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_550;

tmp_550 = make_temporary(TYPE_INT);
{
compvar_t *tmp_551;
tmp_551 = make_temporary(TYPE_INT);
{
compvar_t *tmp_552, *tmp_553;
tmp_552 = args[0][0];
tmp_553 = args[0][1];
emit_assign(make_lhs(tmp_551), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_552), make_compvar_primary(tmp_553)));
}
emit_assign(make_lhs(tmp_550), make_op_rhs(OP_C_SIN, make_compvar_primary(tmp_551)));
}

{
int tmp_554;
for (tmp_554 = 0; tmp_554 < 2; ++tmp_554)
{
switch (tmp_554)
{
case 0 :
{
compvar_t *tmp_555;
tmp_555 = tmp_550;
emit_assign(make_lhs(result_tmps[tmp_554]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_555)));
}
break;
case 1 :
{
compvar_t *tmp_556;
tmp_556 = tmp_550;
emit_assign(make_lhs(result_tmps[tmp_554]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_556)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_557;
for (tmp_557 = 0; tmp_557 < 1; ++tmp_557)
{
switch (tmp_557)
{
case 0 :
{
compvar_t *tmp_558;
tmp_558 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_557]), make_op_rhs(OP_SIN, make_compvar_primary(tmp_558)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_559;

tmp_559 = make_temporary(TYPE_INT);
{
compvar_t *tmp_560;
tmp_560 = make_temporary(TYPE_INT);
{
compvar_t *tmp_561, *tmp_562;
tmp_561 = args[0][0];
tmp_562 = args[0][1];
emit_assign(make_lhs(tmp_560), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_561), make_compvar_primary(tmp_562)));
}
emit_assign(make_lhs(tmp_559), make_op_rhs(OP_C_COS, make_compvar_primary(tmp_560)));
}

{
int tmp_563;
for (tmp_563 = 0; tmp_563 < 2; ++tmp_563)
{
switch (tmp_563)
{
case 0 :
{
compvar_t *tmp_564;
tmp_564 = tmp_559;
emit_assign(make_lhs(result_tmps[tmp_563]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_564)));
}
break;
case 1 :
{
compvar_t *tmp_565;
tmp_565 = tmp_559;
emit_assign(make_lhs(result_tmps[tmp_563]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_565)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_566;
for (tmp_566 = 0; tmp_566 < 1; ++tmp_566)
{
switch (tmp_566)
{
case 0 :
{
compvar_t *tmp_567;
tmp_567 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_566]), make_op_rhs(OP_COS, make_compvar_primary(tmp_567)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_568;

tmp_568 = make_temporary(TYPE_INT);
{
compvar_t *tmp_569;
tmp_569 = make_temporary(TYPE_INT);
{
compvar_t *tmp_570, *tmp_571;
tmp_570 = args[0][0];
tmp_571 = args[0][1];
emit_assign(make_lhs(tmp_569), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_570), make_compvar_primary(tmp_571)));
}
emit_assign(make_lhs(tmp_568), make_op_rhs(OP_C_TAN, make_compvar_primary(tmp_569)));
}

{
int tmp_572;
for (tmp_572 = 0; tmp_572 < 2; ++tmp_572)
{
switch (tmp_572)
{
case 0 :
{
compvar_t *tmp_573;
tmp_573 = tmp_568;
emit_assign(make_lhs(result_tmps[tmp_572]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_573)));
}
break;
case 1 :
{
compvar_t *tmp_574;
tmp_574 = tmp_568;
emit_assign(make_lhs(result_tmps[tmp_572]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_574)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_575;
for (tmp_575 = 0; tmp_575 < 1; ++tmp_575)
{
switch (tmp_575)
{
case 0 :
{
compvar_t *tmp_576;
tmp_576 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_575]), make_op_rhs(OP_TAN, make_compvar_primary(tmp_576)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_577;

tmp_577 = make_temporary(TYPE_INT);
{
compvar_t *tmp_578;
tmp_578 = make_temporary(TYPE_INT);
{
compvar_t *tmp_579, *tmp_580;
tmp_579 = args[0][0];
tmp_580 = args[0][1];
emit_assign(make_lhs(tmp_578), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_579), make_compvar_primary(tmp_580)));
}
emit_assign(make_lhs(tmp_577), make_op_rhs(OP_C_ASIN, make_compvar_primary(tmp_578)));
}

{
int tmp_581;
for (tmp_581 = 0; tmp_581 < 2; ++tmp_581)
{
switch (tmp_581)
{
case 0 :
{
compvar_t *tmp_582;
tmp_582 = tmp_577;
emit_assign(make_lhs(result_tmps[tmp_581]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_582)));
}
break;
case 1 :
{
compvar_t *tmp_583;
tmp_583 = tmp_577;
emit_assign(make_lhs(result_tmps[tmp_581]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_583)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_584;
tmp_584 = make_temporary(TYPE_INT);
{
compvar_t *tmp_585, *tmp_586;
tmp_585 = args[0][0];
tmp_586 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_586), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_584), make_op_rhs(OP_LESS, make_compvar_primary(tmp_585), make_compvar_primary(tmp_586)));
}
start_if_cond(make_compvar_rhs(tmp_584));
switch_if_branch();
{
compvar_t *tmp_587, *tmp_588;
tmp_587 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_587), make_int_const_rhs(1));
tmp_588 = args[0][0];
emit_assign(make_lhs(tmp_584), make_op_rhs(OP_LESS, make_compvar_primary(tmp_587), make_compvar_primary(tmp_588)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_584));
{
int tmp_589;
for (tmp_589 = 0; tmp_589 < 1; ++tmp_589)
{
switch (tmp_589)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_589]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_590;
for (tmp_590 = 0; tmp_590 < 1; ++tmp_590)
{
switch (tmp_590)
{
case 0 :
{
compvar_t *tmp_591;
tmp_591 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_590]), make_op_rhs(OP_ASIN, make_compvar_primary(tmp_591)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_592;

tmp_592 = make_temporary(TYPE_INT);
{
compvar_t *tmp_593;
tmp_593 = make_temporary(TYPE_INT);
{
compvar_t *tmp_594, *tmp_595;
tmp_594 = args[0][0];
tmp_595 = args[0][1];
emit_assign(make_lhs(tmp_593), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_594), make_compvar_primary(tmp_595)));
}
emit_assign(make_lhs(tmp_592), make_op_rhs(OP_C_ACOS, make_compvar_primary(tmp_593)));
}

{
int tmp_596;
for (tmp_596 = 0; tmp_596 < 2; ++tmp_596)
{
switch (tmp_596)
{
case 0 :
{
compvar_t *tmp_597;
tmp_597 = tmp_592;
emit_assign(make_lhs(result_tmps[tmp_596]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_597)));
}
break;
case 1 :
{
compvar_t *tmp_598;
tmp_598 = tmp_592;
emit_assign(make_lhs(result_tmps[tmp_596]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_598)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_599;
tmp_599 = make_temporary(TYPE_INT);
{
compvar_t *tmp_600, *tmp_601;
tmp_600 = args[0][0];
tmp_601 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_601), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_599), make_op_rhs(OP_LESS, make_compvar_primary(tmp_600), make_compvar_primary(tmp_601)));
}
start_if_cond(make_compvar_rhs(tmp_599));
switch_if_branch();
{
compvar_t *tmp_602, *tmp_603;
tmp_602 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_602), make_int_const_rhs(1));
tmp_603 = args[0][0];
emit_assign(make_lhs(tmp_599), make_op_rhs(OP_LESS, make_compvar_primary(tmp_602), make_compvar_primary(tmp_603)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_599));
{
int tmp_604;
for (tmp_604 = 0; tmp_604 < 1; ++tmp_604)
{
switch (tmp_604)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_604]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_605;
for (tmp_605 = 0; tmp_605 < 1; ++tmp_605)
{
switch (tmp_605)
{
case 0 :
{
compvar_t *tmp_606;
tmp_606 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_605]), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_606)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_607;

tmp_607 = make_temporary(TYPE_INT);
{
compvar_t *tmp_608;
tmp_608 = make_temporary(TYPE_INT);
{
compvar_t *tmp_609, *tmp_610;
tmp_609 = args[0][0];
tmp_610 = args[0][1];
emit_assign(make_lhs(tmp_608), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_609), make_compvar_primary(tmp_610)));
}
emit_assign(make_lhs(tmp_607), make_op_rhs(OP_C_ATAN, make_compvar_primary(tmp_608)));
}

{
int tmp_611;
for (tmp_611 = 0; tmp_611 < 2; ++tmp_611)
{
switch (tmp_611)
{
case 0 :
{
compvar_t *tmp_612;
tmp_612 = tmp_607;
emit_assign(make_lhs(result_tmps[tmp_611]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_612)));
}
break;
case 1 :
{
compvar_t *tmp_613;
tmp_613 = tmp_607;
emit_assign(make_lhs(result_tmps[tmp_611]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_613)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_614;
for (tmp_614 = 0; tmp_614 < 1; ++tmp_614)
{
switch (tmp_614)
{
case 0 :
{
compvar_t *tmp_615;
tmp_615 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_614]), make_op_rhs(OP_ATAN, make_compvar_primary(tmp_615)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atan2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_616;
for (tmp_616 = 0; tmp_616 < 1; ++tmp_616)
{
switch (tmp_616)
{
case 0 :
{
compvar_t *tmp_617, *tmp_618;
tmp_617 = args[0][0];
tmp_618 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_616]), make_op_rhs(OP_ATAN2, make_compvar_primary(tmp_617), make_compvar_primary(tmp_618)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_619;

tmp_619 = make_temporary(TYPE_INT);
{
compvar_t *tmp_620, *tmp_621;
tmp_620 = make_temporary(TYPE_INT);
{
compvar_t *tmp_622, *tmp_623;
tmp_622 = args[0][0];
tmp_623 = args[0][1];
emit_assign(make_lhs(tmp_620), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_622), make_compvar_primary(tmp_623)));
}
tmp_621 = make_temporary(TYPE_INT);
{
compvar_t *tmp_624, *tmp_625;
tmp_624 = args[1][0];
tmp_625 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_625), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_621), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_624), make_compvar_primary(tmp_625)));
}
emit_assign(make_lhs(tmp_619), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_620), make_compvar_primary(tmp_621)));
}

{
int tmp_626;
for (tmp_626 = 0; tmp_626 < 2; ++tmp_626)
{
switch (tmp_626)
{
case 0 :
{
compvar_t *tmp_627;
tmp_627 = tmp_619;
emit_assign(make_lhs(result_tmps[tmp_626]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_627)));
}
break;
case 1 :
{
compvar_t *tmp_628;
tmp_628 = tmp_619;
emit_assign(make_lhs(result_tmps[tmp_626]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_628)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_629;

tmp_629 = make_temporary(TYPE_INT);
{
compvar_t *tmp_630, *tmp_631;
tmp_630 = make_temporary(TYPE_INT);
{
compvar_t *tmp_632, *tmp_633;
tmp_632 = args[0][0];
tmp_633 = args[0][1];
emit_assign(make_lhs(tmp_630), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_632), make_compvar_primary(tmp_633)));
}
tmp_631 = make_temporary(TYPE_INT);
{
compvar_t *tmp_634, *tmp_635;
tmp_634 = args[1][0];
tmp_635 = args[1][1];
emit_assign(make_lhs(tmp_631), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_634), make_compvar_primary(tmp_635)));
}
emit_assign(make_lhs(tmp_629), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_630), make_compvar_primary(tmp_631)));
}

{
int tmp_636;
for (tmp_636 = 0; tmp_636 < 2; ++tmp_636)
{
switch (tmp_636)
{
case 0 :
{
compvar_t *tmp_637;
tmp_637 = tmp_629;
emit_assign(make_lhs(result_tmps[tmp_636]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_637)));
}
break;
case 1 :
{
compvar_t *tmp_638;
tmp_638 = tmp_629;
emit_assign(make_lhs(result_tmps[tmp_636]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_638)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_639;

tmp_639 = make_temporary(TYPE_INT);
{
compvar_t *tmp_640, *tmp_641;
tmp_640 = make_temporary(TYPE_INT);
{
compvar_t *tmp_642, *tmp_643;
tmp_642 = args[0][0];
tmp_643 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_643), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_640), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_642), make_compvar_primary(tmp_643)));
}
tmp_641 = make_temporary(TYPE_INT);
{
compvar_t *tmp_644, *tmp_645;
tmp_644 = args[1][0];
tmp_645 = args[1][1];
emit_assign(make_lhs(tmp_641), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_644), make_compvar_primary(tmp_645)));
}
emit_assign(make_lhs(tmp_639), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_640), make_compvar_primary(tmp_641)));
}

{
int tmp_646;
for (tmp_646 = 0; tmp_646 < 2; ++tmp_646)
{
switch (tmp_646)
{
case 0 :
{
compvar_t *tmp_647;
tmp_647 = tmp_639;
emit_assign(make_lhs(result_tmps[tmp_646]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_647)));
}
break;
case 1 :
{
compvar_t *tmp_648;
tmp_648 = tmp_639;
emit_assign(make_lhs(result_tmps[tmp_646]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_648)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_649;
tmp_649 = make_temporary(TYPE_INT);
{
compvar_t *tmp_650, *tmp_651;
tmp_650 = args[1][0];
tmp_651 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_651), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_649), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_650), make_compvar_primary(tmp_651)));
}
start_if_cond(make_compvar_rhs(tmp_649));
{
compvar_t *tmp_652, *tmp_653;
tmp_652 = args[0][0];
tmp_653 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_653), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_649), make_op_rhs(OP_EQ, make_compvar_primary(tmp_652), make_compvar_primary(tmp_653)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_649));
{
int tmp_654;
for (tmp_654 = 0; tmp_654 < 1; ++tmp_654)
{
switch (tmp_654)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_654]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_655;
for (tmp_655 = 0; tmp_655 < 1; ++tmp_655)
{
switch (tmp_655)
{
case 0 :
{
compvar_t *tmp_656, *tmp_657;
tmp_656 = args[0][0];
tmp_657 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_655]), make_op_rhs(OP_POW, make_compvar_primary(tmp_656), make_compvar_primary(tmp_657)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_pow_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_658;
for (tmp_658 = 0; tmp_658 < arglengths[0]; ++tmp_658)
{
{
compvar_t *tmp_659;
tmp_659 = make_temporary(TYPE_INT);
{
compvar_t *tmp_660, *tmp_661;
tmp_660 = args[1][0];
tmp_661 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_661), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_659), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_660), make_compvar_primary(tmp_661)));
}
start_if_cond(make_compvar_rhs(tmp_659));
{
compvar_t *tmp_662, *tmp_663;
tmp_662 = args[0][tmp_658];
tmp_663 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_663), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_659), make_op_rhs(OP_EQ, make_compvar_primary(tmp_662), make_compvar_primary(tmp_663)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_659));
emit_assign(make_lhs(result_tmps[tmp_658]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_664, *tmp_665;
tmp_664 = args[0][tmp_658];
tmp_665 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_658]), make_op_rhs(OP_POW, make_compvar_primary(tmp_664), make_compvar_primary(tmp_665)));
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_exp_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_666;

tmp_666 = make_temporary(TYPE_INT);
{
compvar_t *tmp_667;
tmp_667 = make_temporary(TYPE_INT);
{
compvar_t *tmp_668, *tmp_669;
tmp_668 = args[0][0];
tmp_669 = args[0][1];
emit_assign(make_lhs(tmp_667), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_668), make_compvar_primary(tmp_669)));
}
emit_assign(make_lhs(tmp_666), make_op_rhs(OP_C_EXP, make_compvar_primary(tmp_667)));
}

{
int tmp_670;
for (tmp_670 = 0; tmp_670 < 2; ++tmp_670)
{
switch (tmp_670)
{
case 0 :
{
compvar_t *tmp_671;
tmp_671 = tmp_666;
emit_assign(make_lhs(result_tmps[tmp_670]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_671)));
}
break;
case 1 :
{
compvar_t *tmp_672;
tmp_672 = tmp_666;
emit_assign(make_lhs(result_tmps[tmp_670]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_672)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_exp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_673;
for (tmp_673 = 0; tmp_673 < 1; ++tmp_673)
{
switch (tmp_673)
{
case 0 :
{
compvar_t *tmp_674;
tmp_674 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_673]), make_op_rhs(OP_EXP, make_compvar_primary(tmp_674)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_log_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_675;

tmp_675 = make_temporary(TYPE_INT);
{
compvar_t *tmp_676;
tmp_676 = make_temporary(TYPE_INT);
{
compvar_t *tmp_677, *tmp_678;
tmp_677 = args[0][0];
tmp_678 = args[0][1];
emit_assign(make_lhs(tmp_676), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_677), make_compvar_primary(tmp_678)));
}
emit_assign(make_lhs(tmp_675), make_op_rhs(OP_C_LOG, make_compvar_primary(tmp_676)));
}

{
int tmp_679;
for (tmp_679 = 0; tmp_679 < 2; ++tmp_679)
{
switch (tmp_679)
{
case 0 :
{
compvar_t *tmp_680;
tmp_680 = tmp_675;
emit_assign(make_lhs(result_tmps[tmp_679]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_680)));
}
break;
case 1 :
{
compvar_t *tmp_681;
tmp_681 = tmp_675;
emit_assign(make_lhs(result_tmps[tmp_679]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_681)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_log_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_682;
tmp_682 = make_temporary(TYPE_INT);
{
compvar_t *tmp_683, *tmp_684;
tmp_683 = args[0][0];
tmp_684 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_684), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_682), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_683), make_compvar_primary(tmp_684)));
}
start_if_cond(make_compvar_rhs(tmp_682));
{
int tmp_685;
for (tmp_685 = 0; tmp_685 < 1; ++tmp_685)
{
switch (tmp_685)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_685]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_686;
for (tmp_686 = 0; tmp_686 < 1; ++tmp_686)
{
switch (tmp_686)
{
case 0 :
{
compvar_t *tmp_687;
tmp_687 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_686]), make_op_rhs(OP_LOG, make_compvar_primary(tmp_687)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_arg_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_688;
for (tmp_688 = 0; tmp_688 < 1; ++tmp_688)
{
switch (tmp_688)
{
case 0 :
{
compvar_t *tmp_689;
tmp_689 = make_temporary(TYPE_INT);
{
compvar_t *tmp_690, *tmp_691;
tmp_690 = args[0][0];
tmp_691 = args[0][1];
emit_assign(make_lhs(tmp_689), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_690), make_compvar_primary(tmp_691)));
}
emit_assign(make_lhs(result_tmps[tmp_688]), make_op_rhs(OP_C_ARG, make_compvar_primary(tmp_689)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_conj_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_692;
for (tmp_692 = 0; tmp_692 < 2; ++tmp_692)
{
switch (tmp_692)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_692]), make_compvar_rhs(args[0][0]));
break;
case 1 :
{
compvar_t *tmp_693;
tmp_693 = args[0][1];
emit_assign(make_lhs(result_tmps[tmp_692]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_693)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_694;

tmp_694 = make_temporary(TYPE_INT);
{
compvar_t *tmp_695;
tmp_695 = make_temporary(TYPE_INT);
{
compvar_t *tmp_696, *tmp_697;
tmp_696 = args[0][0];
tmp_697 = args[0][1];
emit_assign(make_lhs(tmp_695), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_696), make_compvar_primary(tmp_697)));
}
emit_assign(make_lhs(tmp_694), make_op_rhs(OP_C_SINH, make_compvar_primary(tmp_695)));
}

{
int tmp_698;
for (tmp_698 = 0; tmp_698 < 2; ++tmp_698)
{
switch (tmp_698)
{
case 0 :
{
compvar_t *tmp_699;
tmp_699 = tmp_694;
emit_assign(make_lhs(result_tmps[tmp_698]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_699)));
}
break;
case 1 :
{
compvar_t *tmp_700;
tmp_700 = tmp_694;
emit_assign(make_lhs(result_tmps[tmp_698]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_700)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_701;
for (tmp_701 = 0; tmp_701 < 1; ++tmp_701)
{
switch (tmp_701)
{
case 0 :
{
compvar_t *tmp_702;
tmp_702 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_701]), make_op_rhs(OP_SINH, make_compvar_primary(tmp_702)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_703;

tmp_703 = make_temporary(TYPE_INT);
{
compvar_t *tmp_704;
tmp_704 = make_temporary(TYPE_INT);
{
compvar_t *tmp_705, *tmp_706;
tmp_705 = args[0][0];
tmp_706 = args[0][1];
emit_assign(make_lhs(tmp_704), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_705), make_compvar_primary(tmp_706)));
}
emit_assign(make_lhs(tmp_703), make_op_rhs(OP_C_COSH, make_compvar_primary(tmp_704)));
}

{
int tmp_707;
for (tmp_707 = 0; tmp_707 < 2; ++tmp_707)
{
switch (tmp_707)
{
case 0 :
{
compvar_t *tmp_708;
tmp_708 = tmp_703;
emit_assign(make_lhs(result_tmps[tmp_707]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_708)));
}
break;
case 1 :
{
compvar_t *tmp_709;
tmp_709 = tmp_703;
emit_assign(make_lhs(result_tmps[tmp_707]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_709)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_cosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_710;
for (tmp_710 = 0; tmp_710 < 1; ++tmp_710)
{
switch (tmp_710)
{
case 0 :
{
compvar_t *tmp_711;
tmp_711 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_710]), make_op_rhs(OP_COSH, make_compvar_primary(tmp_711)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_712;

tmp_712 = make_temporary(TYPE_INT);
{
compvar_t *tmp_713;
tmp_713 = make_temporary(TYPE_INT);
{
compvar_t *tmp_714, *tmp_715;
tmp_714 = args[0][0];
tmp_715 = args[0][1];
emit_assign(make_lhs(tmp_713), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_714), make_compvar_primary(tmp_715)));
}
emit_assign(make_lhs(tmp_712), make_op_rhs(OP_C_TANH, make_compvar_primary(tmp_713)));
}

{
int tmp_716;
for (tmp_716 = 0; tmp_716 < 2; ++tmp_716)
{
switch (tmp_716)
{
case 0 :
{
compvar_t *tmp_717;
tmp_717 = tmp_712;
emit_assign(make_lhs(result_tmps[tmp_716]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_717)));
}
break;
case 1 :
{
compvar_t *tmp_718;
tmp_718 = tmp_712;
emit_assign(make_lhs(result_tmps[tmp_716]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_718)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_719;
for (tmp_719 = 0; tmp_719 < 1; ++tmp_719)
{
switch (tmp_719)
{
case 0 :
{
compvar_t *tmp_720;
tmp_720 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_719]), make_op_rhs(OP_TANH, make_compvar_primary(tmp_720)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_721;

tmp_721 = make_temporary(TYPE_INT);
{
compvar_t *tmp_722;
tmp_722 = make_temporary(TYPE_INT);
{
compvar_t *tmp_723, *tmp_724;
tmp_723 = args[0][0];
tmp_724 = args[0][1];
emit_assign(make_lhs(tmp_722), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_723), make_compvar_primary(tmp_724)));
}
emit_assign(make_lhs(tmp_721), make_op_rhs(OP_C_ASINH, make_compvar_primary(tmp_722)));
}

{
int tmp_725;
for (tmp_725 = 0; tmp_725 < 2; ++tmp_725)
{
switch (tmp_725)
{
case 0 :
{
compvar_t *tmp_726;
tmp_726 = tmp_721;
emit_assign(make_lhs(result_tmps[tmp_725]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_726)));
}
break;
case 1 :
{
compvar_t *tmp_727;
tmp_727 = tmp_721;
emit_assign(make_lhs(result_tmps[tmp_725]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_727)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_asinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_728;
for (tmp_728 = 0; tmp_728 < 1; ++tmp_728)
{
switch (tmp_728)
{
case 0 :
{
compvar_t *tmp_729;
tmp_729 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_728]), make_op_rhs(OP_ASINH, make_compvar_primary(tmp_729)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_730;

tmp_730 = make_temporary(TYPE_INT);
{
compvar_t *tmp_731;
tmp_731 = make_temporary(TYPE_INT);
{
compvar_t *tmp_732, *tmp_733;
tmp_732 = args[0][0];
tmp_733 = args[0][1];
emit_assign(make_lhs(tmp_731), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_732), make_compvar_primary(tmp_733)));
}
emit_assign(make_lhs(tmp_730), make_op_rhs(OP_C_ACOSH, make_compvar_primary(tmp_731)));
}

{
int tmp_734;
for (tmp_734 = 0; tmp_734 < 2; ++tmp_734)
{
switch (tmp_734)
{
case 0 :
{
compvar_t *tmp_735;
tmp_735 = tmp_730;
emit_assign(make_lhs(result_tmps[tmp_734]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_735)));
}
break;
case 1 :
{
compvar_t *tmp_736;
tmp_736 = tmp_730;
emit_assign(make_lhs(result_tmps[tmp_734]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_736)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_acosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_737;
for (tmp_737 = 0; tmp_737 < 1; ++tmp_737)
{
switch (tmp_737)
{
case 0 :
{
compvar_t *tmp_738;
tmp_738 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_737]), make_op_rhs(OP_ACOSH, make_compvar_primary(tmp_738)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_739;

tmp_739 = make_temporary(TYPE_INT);
{
compvar_t *tmp_740;
tmp_740 = make_temporary(TYPE_INT);
{
compvar_t *tmp_741, *tmp_742;
tmp_741 = args[0][0];
tmp_742 = args[0][1];
emit_assign(make_lhs(tmp_740), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_741), make_compvar_primary(tmp_742)));
}
emit_assign(make_lhs(tmp_739), make_op_rhs(OP_C_ATANH, make_compvar_primary(tmp_740)));
}

{
int tmp_743;
for (tmp_743 = 0; tmp_743 < 2; ++tmp_743)
{
switch (tmp_743)
{
case 0 :
{
compvar_t *tmp_744;
tmp_744 = tmp_739;
emit_assign(make_lhs(result_tmps[tmp_743]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_744)));
}
break;
case 1 :
{
compvar_t *tmp_745;
tmp_745 = tmp_739;
emit_assign(make_lhs(result_tmps[tmp_743]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_745)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_atanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_746;
for (tmp_746 = 0; tmp_746 < 1; ++tmp_746)
{
switch (tmp_746)
{
case 0 :
{
compvar_t *tmp_747;
tmp_747 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_746]), make_op_rhs(OP_ATANH, make_compvar_primary(tmp_747)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gamma_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_748;

tmp_748 = make_temporary(TYPE_INT);
{
compvar_t *tmp_749;
tmp_749 = make_temporary(TYPE_INT);
{
compvar_t *tmp_750, *tmp_751;
tmp_750 = args[0][0];
tmp_751 = args[0][1];
emit_assign(make_lhs(tmp_749), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_750), make_compvar_primary(tmp_751)));
}
emit_assign(make_lhs(tmp_748), make_op_rhs(OP_C_GAMMA, make_compvar_primary(tmp_749)));
}

{
int tmp_752;
for (tmp_752 = 0; tmp_752 < 2; ++tmp_752)
{
switch (tmp_752)
{
case 0 :
{
compvar_t *tmp_753;
tmp_753 = tmp_748;
emit_assign(make_lhs(result_tmps[tmp_752]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_753)));
}
break;
case 1 :
{
compvar_t *tmp_754;
tmp_754 = tmp_748;
emit_assign(make_lhs(result_tmps[tmp_752]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_754)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gamma_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_755;
tmp_755 = make_temporary(TYPE_INT);
{
compvar_t *tmp_756, *tmp_757;
tmp_756 = args[0][0];
tmp_757 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_757), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_755), make_op_rhs(OP_LESS, make_compvar_primary(tmp_756), make_compvar_primary(tmp_757)));
}
start_if_cond(make_compvar_rhs(tmp_755));
{
int tmp_758;
for (tmp_758 = 0; tmp_758 < 1; ++tmp_758)
{
switch (tmp_758)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_758]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_759;
for (tmp_759 = 0; tmp_759 < 1; ++tmp_759)
{
switch (tmp_759)
{
case 0 :
{
compvar_t *tmp_760;
tmp_760 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_759]), make_op_rhs(OP_GAMMA, make_compvar_primary(tmp_760)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_beta_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_761;
tmp_761 = make_temporary(TYPE_INT);
{
compvar_t *tmp_762, *tmp_763;
tmp_762 = args[0][0];
tmp_763 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_763), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_761), make_op_rhs(OP_LESS, make_compvar_primary(tmp_762), make_compvar_primary(tmp_763)));
}
start_if_cond(make_compvar_rhs(tmp_761));
switch_if_branch();
{
compvar_t *tmp_764, *tmp_765;
tmp_764 = args[1][0];
tmp_765 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_765), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_761), make_op_rhs(OP_LESS, make_compvar_primary(tmp_764), make_compvar_primary(tmp_765)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_761));
{
int tmp_766;
for (tmp_766 = 0; tmp_766 < 1; ++tmp_766)
{
switch (tmp_766)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_766]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_767;
for (tmp_767 = 0; tmp_767 < 1; ++tmp_767)
{
switch (tmp_767)
{
case 0 :
{
compvar_t *tmp_768, *tmp_769;
tmp_768 = args[0][0];
tmp_769 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_767]), make_op_rhs(OP_BETA, make_compvar_primary(tmp_768), make_compvar_primary(tmp_769)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_kcomp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_770;
for (tmp_770 = 0; tmp_770 < 1; ++tmp_770)
{
switch (tmp_770)
{
case 0 :
{
compvar_t *tmp_771;
tmp_771 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_770]), make_op_rhs(OP_ELL_INT_K_COMP, make_compvar_primary(tmp_771)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_ecomp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_772;
for (tmp_772 = 0; tmp_772 < 1; ++tmp_772)
{
switch (tmp_772)
{
case 0 :
{
compvar_t *tmp_773;
tmp_773 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_772]), make_op_rhs(OP_ELL_INT_E_COMP, make_compvar_primary(tmp_773)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_f (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_774;
for (tmp_774 = 0; tmp_774 < 1; ++tmp_774)
{
switch (tmp_774)
{
case 0 :
{
compvar_t *tmp_775, *tmp_776;
tmp_775 = args[0][0];
tmp_776 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_774]), make_op_rhs(OP_ELL_INT_F, make_compvar_primary(tmp_775), make_compvar_primary(tmp_776)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_e (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_777;
for (tmp_777 = 0; tmp_777 < 1; ++tmp_777)
{
switch (tmp_777)
{
case 0 :
{
compvar_t *tmp_778, *tmp_779;
tmp_778 = args[0][0];
tmp_779 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_777]), make_op_rhs(OP_ELL_INT_E, make_compvar_primary(tmp_778), make_compvar_primary(tmp_779)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_p (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_780;
for (tmp_780 = 0; tmp_780 < 1; ++tmp_780)
{
switch (tmp_780)
{
case 0 :
{
compvar_t *tmp_781, *tmp_782, *tmp_783;
tmp_781 = args[0][0];
tmp_782 = args[1][0];
tmp_783 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_780]), make_op_rhs(OP_ELL_INT_P, make_compvar_primary(tmp_781), make_compvar_primary(tmp_782), make_compvar_primary(tmp_783)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_d (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_784;
for (tmp_784 = 0; tmp_784 < 1; ++tmp_784)
{
switch (tmp_784)
{
case 0 :
{
compvar_t *tmp_785, *tmp_786, *tmp_787;
tmp_785 = args[0][0];
tmp_786 = args[1][0];
tmp_787 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_784]), make_op_rhs(OP_ELL_INT_D, make_compvar_primary(tmp_785), make_compvar_primary(tmp_786), make_compvar_primary(tmp_787)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rc (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_788;
for (tmp_788 = 0; tmp_788 < 1; ++tmp_788)
{
switch (tmp_788)
{
case 0 :
{
compvar_t *tmp_789, *tmp_790;
tmp_789 = args[0][0];
tmp_790 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_788]), make_op_rhs(OP_ELL_INT_RC, make_compvar_primary(tmp_789), make_compvar_primary(tmp_790)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rd (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_791;
for (tmp_791 = 0; tmp_791 < 1; ++tmp_791)
{
switch (tmp_791)
{
case 0 :
{
compvar_t *tmp_792, *tmp_793, *tmp_794;
tmp_792 = args[0][0];
tmp_793 = args[1][0];
tmp_794 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_791]), make_op_rhs(OP_ELL_INT_RD, make_compvar_primary(tmp_792), make_compvar_primary(tmp_793), make_compvar_primary(tmp_794)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rf (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_795;
for (tmp_795 = 0; tmp_795 < 1; ++tmp_795)
{
switch (tmp_795)
{
case 0 :
{
compvar_t *tmp_796, *tmp_797, *tmp_798;
tmp_796 = args[0][0];
tmp_797 = args[1][0];
tmp_798 = args[2][0];
emit_assign(make_lhs(result_tmps[tmp_795]), make_op_rhs(OP_ELL_INT_RF, make_compvar_primary(tmp_796), make_compvar_primary(tmp_797), make_compvar_primary(tmp_798)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_int_rj (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_799;
for (tmp_799 = 0; tmp_799 < 1; ++tmp_799)
{
switch (tmp_799)
{
case 0 :
{
compvar_t *tmp_800, *tmp_801, *tmp_802, *tmp_803;
tmp_800 = args[0][0];
tmp_801 = args[1][0];
tmp_802 = args[2][0];
tmp_803 = args[3][0];
emit_assign(make_lhs(result_tmps[tmp_799]), make_op_rhs(OP_ELL_INT_RJ, make_compvar_primary(tmp_800), make_compvar_primary(tmp_801), make_compvar_primary(tmp_802), make_compvar_primary(tmp_803)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_sn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_804;

tmp_804 = make_temporary(TYPE_INT);
{
compvar_t *tmp_805, *tmp_806;
tmp_805 = args[0][0];
tmp_806 = args[1][0];
emit_assign(make_lhs(tmp_804), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_805), make_compvar_primary(tmp_806)));
}

{
int tmp_807;
for (tmp_807 = 0; tmp_807 < 1; ++tmp_807)
{
switch (tmp_807)
{
case 0 :
{
compvar_t *tmp_808, *tmp_809;
tmp_808 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_808), make_int_const_rhs(0));
tmp_809 = tmp_804;
emit_assign(make_lhs(result_tmps[tmp_807]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_808), make_compvar_primary(tmp_809)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_cn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_810;

tmp_810 = make_temporary(TYPE_INT);
{
compvar_t *tmp_811, *tmp_812;
tmp_811 = args[0][0];
tmp_812 = args[1][0];
emit_assign(make_lhs(tmp_810), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_811), make_compvar_primary(tmp_812)));
}

{
int tmp_813;
for (tmp_813 = 0; tmp_813 < 1; ++tmp_813)
{
switch (tmp_813)
{
case 0 :
{
compvar_t *tmp_814, *tmp_815;
tmp_814 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_814), make_int_const_rhs(1));
tmp_815 = tmp_810;
emit_assign(make_lhs(result_tmps[tmp_813]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_814), make_compvar_primary(tmp_815)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_dn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_816;

tmp_816 = make_temporary(TYPE_INT);
{
compvar_t *tmp_817, *tmp_818;
tmp_817 = args[0][0];
tmp_818 = args[1][0];
emit_assign(make_lhs(tmp_816), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_817), make_compvar_primary(tmp_818)));
}

{
int tmp_819;
for (tmp_819 = 0; tmp_819 < 1; ++tmp_819)
{
switch (tmp_819)
{
case 0 :
{
compvar_t *tmp_820, *tmp_821;
tmp_820 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_820), make_int_const_rhs(2));
tmp_821 = tmp_816;
emit_assign(make_lhs(result_tmps[tmp_819]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_820), make_compvar_primary(tmp_821)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_sn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_822;
compvar_t *tmp_825;

tmp_822 = make_temporary(TYPE_INT);
{
compvar_t *tmp_823, *tmp_824;
tmp_823 = args[0][0];
tmp_824 = args[1][0];
emit_assign(make_lhs(tmp_822), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_823), make_compvar_primary(tmp_824)));
}

tmp_825 = make_temporary(TYPE_INT);
{
compvar_t *tmp_826, *tmp_827;
tmp_826 = args[0][1];
tmp_827 = make_temporary(TYPE_INT);
{
compvar_t *tmp_828, *tmp_829;
tmp_828 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_828), make_int_const_rhs(1));
tmp_829 = args[1][0];
emit_assign(make_lhs(tmp_827), make_op_rhs(OP_SUB, make_compvar_primary(tmp_828), make_compvar_primary(tmp_829)));
}
emit_assign(make_lhs(tmp_825), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_826), make_compvar_primary(tmp_827)));
}

{
compvar_t *tmp_830;
compvar_t *tmp_833;
compvar_t *tmp_836;
compvar_t *tmp_839;
compvar_t *tmp_842;
compvar_t *tmp_845;

tmp_830 = make_temporary(TYPE_INT);
{
compvar_t *tmp_831, *tmp_832;
tmp_831 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_831), make_int_const_rhs(0));
tmp_832 = tmp_822;
emit_assign(make_lhs(tmp_830), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_831), make_compvar_primary(tmp_832)));
}

tmp_833 = make_temporary(TYPE_INT);
{
compvar_t *tmp_834, *tmp_835;
tmp_834 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_834), make_int_const_rhs(1));
tmp_835 = tmp_822;
emit_assign(make_lhs(tmp_833), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_834), make_compvar_primary(tmp_835)));
}

tmp_836 = make_temporary(TYPE_INT);
{
compvar_t *tmp_837, *tmp_838;
tmp_837 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_837), make_int_const_rhs(2));
tmp_838 = tmp_822;
emit_assign(make_lhs(tmp_836), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_837), make_compvar_primary(tmp_838)));
}

tmp_839 = make_temporary(TYPE_INT);
{
compvar_t *tmp_840, *tmp_841;
tmp_840 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_840), make_int_const_rhs(0));
tmp_841 = tmp_825;
emit_assign(make_lhs(tmp_839), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_840), make_compvar_primary(tmp_841)));
}

tmp_842 = make_temporary(TYPE_INT);
{
compvar_t *tmp_843, *tmp_844;
tmp_843 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_843), make_int_const_rhs(1));
tmp_844 = tmp_825;
emit_assign(make_lhs(tmp_842), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_843), make_compvar_primary(tmp_844)));
}

tmp_845 = make_temporary(TYPE_INT);
{
compvar_t *tmp_846, *tmp_847;
tmp_846 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_846), make_int_const_rhs(2));
tmp_847 = tmp_825;
emit_assign(make_lhs(tmp_845), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_846), make_compvar_primary(tmp_847)));
}

{
compvar_t *tmp_848;

tmp_848 = make_temporary(TYPE_INT);
{
compvar_t *tmp_849, *tmp_850;
tmp_849 = make_temporary(TYPE_INT);
{
compvar_t *tmp_851, *tmp_852;
tmp_851 = tmp_842;
tmp_852 = tmp_842;
emit_assign(make_lhs(tmp_849), make_op_rhs(OP_MUL, make_compvar_primary(tmp_851), make_compvar_primary(tmp_852)));
}
tmp_850 = make_temporary(TYPE_INT);
{
compvar_t *tmp_853, *tmp_854;
tmp_853 = args[1][0];
tmp_854 = make_temporary(TYPE_INT);
{
compvar_t *tmp_855, *tmp_856;
tmp_855 = make_temporary(TYPE_INT);
{
compvar_t *tmp_857, *tmp_858;
tmp_857 = tmp_830;
tmp_858 = tmp_830;
emit_assign(make_lhs(tmp_855), make_op_rhs(OP_MUL, make_compvar_primary(tmp_857), make_compvar_primary(tmp_858)));
}
tmp_856 = make_temporary(TYPE_INT);
{
compvar_t *tmp_859, *tmp_860;
tmp_859 = tmp_839;
tmp_860 = tmp_839;
emit_assign(make_lhs(tmp_856), make_op_rhs(OP_MUL, make_compvar_primary(tmp_859), make_compvar_primary(tmp_860)));
}
emit_assign(make_lhs(tmp_854), make_op_rhs(OP_MUL, make_compvar_primary(tmp_855), make_compvar_primary(tmp_856)));
}
emit_assign(make_lhs(tmp_850), make_op_rhs(OP_MUL, make_compvar_primary(tmp_853), make_compvar_primary(tmp_854)));
}
emit_assign(make_lhs(tmp_848), make_op_rhs(OP_ADD, make_compvar_primary(tmp_849), make_compvar_primary(tmp_850)));
}

{
compvar_t *tmp_861, *tmp_862;
tmp_861 = make_temporary(TYPE_INT);
{
compvar_t *tmp_863, *tmp_864;
tmp_863 = tmp_830;
tmp_864 = tmp_845;
emit_assign(make_lhs(tmp_861), make_op_rhs(OP_MUL, make_compvar_primary(tmp_863), make_compvar_primary(tmp_864)));
}
tmp_862 = tmp_848;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_861), make_compvar_primary(tmp_862)));
}
{
compvar_t *tmp_865, *tmp_866;
tmp_865 = make_temporary(TYPE_INT);
{
compvar_t *tmp_867, *tmp_868;
tmp_867 = make_temporary(TYPE_INT);
{
compvar_t *tmp_869, *tmp_870;
tmp_869 = tmp_833;
tmp_870 = tmp_836;
emit_assign(make_lhs(tmp_867), make_op_rhs(OP_MUL, make_compvar_primary(tmp_869), make_compvar_primary(tmp_870)));
}
tmp_868 = make_temporary(TYPE_INT);
{
compvar_t *tmp_871, *tmp_872;
tmp_871 = tmp_839;
tmp_872 = tmp_842;
emit_assign(make_lhs(tmp_868), make_op_rhs(OP_MUL, make_compvar_primary(tmp_871), make_compvar_primary(tmp_872)));
}
emit_assign(make_lhs(tmp_865), make_op_rhs(OP_MUL, make_compvar_primary(tmp_867), make_compvar_primary(tmp_868)));
}
tmp_866 = tmp_848;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_865), make_compvar_primary(tmp_866)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_cn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_873;
compvar_t *tmp_876;

tmp_873 = make_temporary(TYPE_INT);
{
compvar_t *tmp_874, *tmp_875;
tmp_874 = args[0][0];
tmp_875 = args[1][0];
emit_assign(make_lhs(tmp_873), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_874), make_compvar_primary(tmp_875)));
}

tmp_876 = make_temporary(TYPE_INT);
{
compvar_t *tmp_877, *tmp_878;
tmp_877 = args[0][1];
tmp_878 = make_temporary(TYPE_INT);
{
compvar_t *tmp_879, *tmp_880;
tmp_879 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_879), make_int_const_rhs(1));
tmp_880 = args[1][0];
emit_assign(make_lhs(tmp_878), make_op_rhs(OP_SUB, make_compvar_primary(tmp_879), make_compvar_primary(tmp_880)));
}
emit_assign(make_lhs(tmp_876), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_877), make_compvar_primary(tmp_878)));
}

{
compvar_t *tmp_881;
compvar_t *tmp_884;
compvar_t *tmp_887;
compvar_t *tmp_890;
compvar_t *tmp_893;
compvar_t *tmp_896;

tmp_881 = make_temporary(TYPE_INT);
{
compvar_t *tmp_882, *tmp_883;
tmp_882 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_882), make_int_const_rhs(0));
tmp_883 = tmp_873;
emit_assign(make_lhs(tmp_881), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_882), make_compvar_primary(tmp_883)));
}

tmp_884 = make_temporary(TYPE_INT);
{
compvar_t *tmp_885, *tmp_886;
tmp_885 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_885), make_int_const_rhs(1));
tmp_886 = tmp_873;
emit_assign(make_lhs(tmp_884), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_885), make_compvar_primary(tmp_886)));
}

tmp_887 = make_temporary(TYPE_INT);
{
compvar_t *tmp_888, *tmp_889;
tmp_888 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_888), make_int_const_rhs(2));
tmp_889 = tmp_873;
emit_assign(make_lhs(tmp_887), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_888), make_compvar_primary(tmp_889)));
}

tmp_890 = make_temporary(TYPE_INT);
{
compvar_t *tmp_891, *tmp_892;
tmp_891 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_891), make_int_const_rhs(0));
tmp_892 = tmp_876;
emit_assign(make_lhs(tmp_890), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_891), make_compvar_primary(tmp_892)));
}

tmp_893 = make_temporary(TYPE_INT);
{
compvar_t *tmp_894, *tmp_895;
tmp_894 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_894), make_int_const_rhs(1));
tmp_895 = tmp_876;
emit_assign(make_lhs(tmp_893), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_894), make_compvar_primary(tmp_895)));
}

tmp_896 = make_temporary(TYPE_INT);
{
compvar_t *tmp_897, *tmp_898;
tmp_897 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_897), make_int_const_rhs(2));
tmp_898 = tmp_876;
emit_assign(make_lhs(tmp_896), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_897), make_compvar_primary(tmp_898)));
}

{
compvar_t *tmp_899;

tmp_899 = make_temporary(TYPE_INT);
{
compvar_t *tmp_900, *tmp_901;
tmp_900 = make_temporary(TYPE_INT);
{
compvar_t *tmp_902, *tmp_903;
tmp_902 = tmp_893;
tmp_903 = tmp_893;
emit_assign(make_lhs(tmp_900), make_op_rhs(OP_MUL, make_compvar_primary(tmp_902), make_compvar_primary(tmp_903)));
}
tmp_901 = make_temporary(TYPE_INT);
{
compvar_t *tmp_904, *tmp_905;
tmp_904 = args[1][0];
tmp_905 = make_temporary(TYPE_INT);
{
compvar_t *tmp_906, *tmp_907;
tmp_906 = make_temporary(TYPE_INT);
{
compvar_t *tmp_908, *tmp_909;
tmp_908 = tmp_881;
tmp_909 = tmp_881;
emit_assign(make_lhs(tmp_906), make_op_rhs(OP_MUL, make_compvar_primary(tmp_908), make_compvar_primary(tmp_909)));
}
tmp_907 = make_temporary(TYPE_INT);
{
compvar_t *tmp_910, *tmp_911;
tmp_910 = tmp_890;
tmp_911 = tmp_890;
emit_assign(make_lhs(tmp_907), make_op_rhs(OP_MUL, make_compvar_primary(tmp_910), make_compvar_primary(tmp_911)));
}
emit_assign(make_lhs(tmp_905), make_op_rhs(OP_MUL, make_compvar_primary(tmp_906), make_compvar_primary(tmp_907)));
}
emit_assign(make_lhs(tmp_901), make_op_rhs(OP_MUL, make_compvar_primary(tmp_904), make_compvar_primary(tmp_905)));
}
emit_assign(make_lhs(tmp_899), make_op_rhs(OP_ADD, make_compvar_primary(tmp_900), make_compvar_primary(tmp_901)));
}

{
compvar_t *tmp_912, *tmp_913;
tmp_912 = make_temporary(TYPE_INT);
{
compvar_t *tmp_914, *tmp_915;
tmp_914 = tmp_884;
tmp_915 = tmp_893;
emit_assign(make_lhs(tmp_912), make_op_rhs(OP_MUL, make_compvar_primary(tmp_914), make_compvar_primary(tmp_915)));
}
tmp_913 = tmp_899;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_912), make_compvar_primary(tmp_913)));
}
{
compvar_t *tmp_916, *tmp_917;
tmp_916 = make_temporary(TYPE_INT);
{
compvar_t *tmp_918;
tmp_918 = make_temporary(TYPE_INT);
{
compvar_t *tmp_919, *tmp_920;
tmp_919 = make_temporary(TYPE_INT);
{
compvar_t *tmp_921, *tmp_922;
tmp_921 = tmp_881;
tmp_922 = tmp_887;
emit_assign(make_lhs(tmp_919), make_op_rhs(OP_MUL, make_compvar_primary(tmp_921), make_compvar_primary(tmp_922)));
}
tmp_920 = make_temporary(TYPE_INT);
{
compvar_t *tmp_923, *tmp_924;
tmp_923 = tmp_890;
tmp_924 = tmp_896;
emit_assign(make_lhs(tmp_920), make_op_rhs(OP_MUL, make_compvar_primary(tmp_923), make_compvar_primary(tmp_924)));
}
emit_assign(make_lhs(tmp_918), make_op_rhs(OP_MUL, make_compvar_primary(tmp_919), make_compvar_primary(tmp_920)));
}
emit_assign(make_lhs(tmp_916), make_op_rhs(OP_NEG, make_compvar_primary(tmp_918)));
}
tmp_917 = tmp_899;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_916), make_compvar_primary(tmp_917)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ell_jac_dn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_925;
compvar_t *tmp_928;

tmp_925 = make_temporary(TYPE_INT);
{
compvar_t *tmp_926, *tmp_927;
tmp_926 = args[0][0];
tmp_927 = args[1][0];
emit_assign(make_lhs(tmp_925), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_926), make_compvar_primary(tmp_927)));
}

tmp_928 = make_temporary(TYPE_INT);
{
compvar_t *tmp_929, *tmp_930;
tmp_929 = args[0][1];
tmp_930 = make_temporary(TYPE_INT);
{
compvar_t *tmp_931, *tmp_932;
tmp_931 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_931), make_int_const_rhs(1));
tmp_932 = args[1][0];
emit_assign(make_lhs(tmp_930), make_op_rhs(OP_SUB, make_compvar_primary(tmp_931), make_compvar_primary(tmp_932)));
}
emit_assign(make_lhs(tmp_928), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_929), make_compvar_primary(tmp_930)));
}

{
compvar_t *tmp_933;
compvar_t *tmp_936;
compvar_t *tmp_939;
compvar_t *tmp_942;
compvar_t *tmp_945;
compvar_t *tmp_948;

tmp_933 = make_temporary(TYPE_INT);
{
compvar_t *tmp_934, *tmp_935;
tmp_934 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_934), make_int_const_rhs(0));
tmp_935 = tmp_925;
emit_assign(make_lhs(tmp_933), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_934), make_compvar_primary(tmp_935)));
}

tmp_936 = make_temporary(TYPE_INT);
{
compvar_t *tmp_937, *tmp_938;
tmp_937 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_937), make_int_const_rhs(1));
tmp_938 = tmp_925;
emit_assign(make_lhs(tmp_936), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_937), make_compvar_primary(tmp_938)));
}

tmp_939 = make_temporary(TYPE_INT);
{
compvar_t *tmp_940, *tmp_941;
tmp_940 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_940), make_int_const_rhs(2));
tmp_941 = tmp_925;
emit_assign(make_lhs(tmp_939), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_940), make_compvar_primary(tmp_941)));
}

tmp_942 = make_temporary(TYPE_INT);
{
compvar_t *tmp_943, *tmp_944;
tmp_943 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_943), make_int_const_rhs(0));
tmp_944 = tmp_928;
emit_assign(make_lhs(tmp_942), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_943), make_compvar_primary(tmp_944)));
}

tmp_945 = make_temporary(TYPE_INT);
{
compvar_t *tmp_946, *tmp_947;
tmp_946 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_946), make_int_const_rhs(1));
tmp_947 = tmp_928;
emit_assign(make_lhs(tmp_945), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_946), make_compvar_primary(tmp_947)));
}

tmp_948 = make_temporary(TYPE_INT);
{
compvar_t *tmp_949, *tmp_950;
tmp_949 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_949), make_int_const_rhs(2));
tmp_950 = tmp_928;
emit_assign(make_lhs(tmp_948), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_949), make_compvar_primary(tmp_950)));
}

{
compvar_t *tmp_951;

tmp_951 = make_temporary(TYPE_INT);
{
compvar_t *tmp_952, *tmp_953;
tmp_952 = make_temporary(TYPE_INT);
{
compvar_t *tmp_954, *tmp_955;
tmp_954 = tmp_945;
tmp_955 = tmp_945;
emit_assign(make_lhs(tmp_952), make_op_rhs(OP_MUL, make_compvar_primary(tmp_954), make_compvar_primary(tmp_955)));
}
tmp_953 = make_temporary(TYPE_INT);
{
compvar_t *tmp_956, *tmp_957;
tmp_956 = args[1][0];
tmp_957 = make_temporary(TYPE_INT);
{
compvar_t *tmp_958, *tmp_959;
tmp_958 = make_temporary(TYPE_INT);
{
compvar_t *tmp_960, *tmp_961;
tmp_960 = tmp_933;
tmp_961 = tmp_933;
emit_assign(make_lhs(tmp_958), make_op_rhs(OP_MUL, make_compvar_primary(tmp_960), make_compvar_primary(tmp_961)));
}
tmp_959 = make_temporary(TYPE_INT);
{
compvar_t *tmp_962, *tmp_963;
tmp_962 = tmp_942;
tmp_963 = tmp_942;
emit_assign(make_lhs(tmp_959), make_op_rhs(OP_MUL, make_compvar_primary(tmp_962), make_compvar_primary(tmp_963)));
}
emit_assign(make_lhs(tmp_957), make_op_rhs(OP_MUL, make_compvar_primary(tmp_958), make_compvar_primary(tmp_959)));
}
emit_assign(make_lhs(tmp_953), make_op_rhs(OP_MUL, make_compvar_primary(tmp_956), make_compvar_primary(tmp_957)));
}
emit_assign(make_lhs(tmp_951), make_op_rhs(OP_ADD, make_compvar_primary(tmp_952), make_compvar_primary(tmp_953)));
}

{
compvar_t *tmp_964, *tmp_965;
tmp_964 = make_temporary(TYPE_INT);
{
compvar_t *tmp_966, *tmp_967;
tmp_966 = tmp_945;
tmp_967 = make_temporary(TYPE_INT);
{
compvar_t *tmp_968, *tmp_969;
tmp_968 = tmp_939;
tmp_969 = tmp_948;
emit_assign(make_lhs(tmp_967), make_op_rhs(OP_MUL, make_compvar_primary(tmp_968), make_compvar_primary(tmp_969)));
}
emit_assign(make_lhs(tmp_964), make_op_rhs(OP_MUL, make_compvar_primary(tmp_966), make_compvar_primary(tmp_967)));
}
tmp_965 = tmp_951;
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_964), make_compvar_primary(tmp_965)));
}
{
compvar_t *tmp_970, *tmp_971;
tmp_970 = make_temporary(TYPE_INT);
{
compvar_t *tmp_972, *tmp_973;
tmp_972 = make_temporary(TYPE_INT);
{
compvar_t *tmp_974, *tmp_975;
tmp_974 = tmp_933;
tmp_975 = tmp_942;
emit_assign(make_lhs(tmp_972), make_op_rhs(OP_MUL, make_compvar_primary(tmp_974), make_compvar_primary(tmp_975)));
}
tmp_973 = make_temporary(TYPE_INT);
{
compvar_t *tmp_976, *tmp_977;
tmp_976 = args[1][0];
tmp_977 = tmp_936;
emit_assign(make_lhs(tmp_973), make_op_rhs(OP_MUL, make_compvar_primary(tmp_976), make_compvar_primary(tmp_977)));
}
emit_assign(make_lhs(tmp_970), make_op_rhs(OP_SUB, make_compvar_primary(tmp_972), make_compvar_primary(tmp_973)));
}
tmp_971 = tmp_951;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_970), make_compvar_primary(tmp_971)));
}
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_floor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_978;
for (tmp_978 = 0; tmp_978 < 1; ++tmp_978)
{
switch (tmp_978)
{
case 0 :
{
compvar_t *tmp_979;
tmp_979 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_978]), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_979)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_ceil (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_980;
for (tmp_980 = 0; tmp_980 < 1; ++tmp_980)
{
switch (tmp_980)
{
case 0 :
{
compvar_t *tmp_981;
tmp_981 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_980]), make_op_rhs(OP_CEIL, make_compvar_primary(tmp_981)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_sign_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_982;
for (tmp_982 = 0; tmp_982 < arglengths[0]; ++tmp_982)
{
{
compvar_t *tmp_983;
tmp_983 = make_temporary(TYPE_INT);
{
compvar_t *tmp_984, *tmp_985;
tmp_984 = args[0][tmp_982];
tmp_985 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_985), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_983), make_op_rhs(OP_LESS, make_compvar_primary(tmp_984), make_compvar_primary(tmp_985)));
}
start_if_cond(make_compvar_rhs(tmp_983));
emit_assign(make_lhs(result_tmps[tmp_982]), make_int_const_rhs(-1));
switch_if_branch();
{
compvar_t *tmp_986;
tmp_986 = make_temporary(TYPE_INT);
{
compvar_t *tmp_987, *tmp_988;
tmp_987 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_987), make_int_const_rhs(0));
tmp_988 = args[0][tmp_982];
emit_assign(make_lhs(tmp_986), make_op_rhs(OP_LESS, make_compvar_primary(tmp_987), make_compvar_primary(tmp_988)));
}
start_if_cond(make_compvar_rhs(tmp_986));
emit_assign(make_lhs(result_tmps[tmp_982]), make_int_const_rhs(1));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_982]), make_int_const_rhs(0));
end_if_cond();
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_min_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_989;
for (tmp_989 = 0; tmp_989 < arglengths[0]; ++tmp_989)
{
{
compvar_t *tmp_990;
tmp_990 = make_temporary(TYPE_INT);
{
compvar_t *tmp_991, *tmp_992;
tmp_991 = args[0][tmp_989];
tmp_992 = args[1][tmp_989];
emit_assign(make_lhs(tmp_990), make_op_rhs(OP_LESS, make_compvar_primary(tmp_991), make_compvar_primary(tmp_992)));
}
start_if_cond(make_compvar_rhs(tmp_990));
emit_assign(make_lhs(result_tmps[tmp_989]), make_compvar_rhs(args[0][tmp_989]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_989]), make_compvar_rhs(args[1][tmp_989]));
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_max_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_993;
for (tmp_993 = 0; tmp_993 < arglengths[0]; ++tmp_993)
{
{
compvar_t *tmp_994;
tmp_994 = make_temporary(TYPE_INT);
{
compvar_t *tmp_995, *tmp_996;
tmp_995 = args[0][tmp_993];
tmp_996 = args[1][tmp_993];
emit_assign(make_lhs(tmp_994), make_op_rhs(OP_LESS, make_compvar_primary(tmp_995), make_compvar_primary(tmp_996)));
}
start_if_cond(make_compvar_rhs(tmp_994));
emit_assign(make_lhs(result_tmps[tmp_993]), make_compvar_rhs(args[1][tmp_993]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_993]), make_compvar_rhs(args[0][tmp_993]));
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_clamp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_997;
for (tmp_997 = 0; tmp_997 < arglengths[0]; ++tmp_997)
{
{
compvar_t *tmp_998;
tmp_998 = make_temporary(TYPE_INT);
{
compvar_t *tmp_999, *tmp_1000;
tmp_999 = args[0][tmp_997];
tmp_1000 = args[1][tmp_997];
emit_assign(make_lhs(tmp_998), make_op_rhs(OP_LESS, make_compvar_primary(tmp_999), make_compvar_primary(tmp_1000)));
}
start_if_cond(make_compvar_rhs(tmp_998));
emit_assign(make_lhs(result_tmps[tmp_997]), make_compvar_rhs(args[1][tmp_997]));
switch_if_branch();
{
compvar_t *tmp_1001;
tmp_1001 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1002, *tmp_1003;
tmp_1002 = args[2][tmp_997];
tmp_1003 = args[0][tmp_997];
emit_assign(make_lhs(tmp_1001), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1002), make_compvar_primary(tmp_1003)));
}
start_if_cond(make_compvar_rhs(tmp_1001));
emit_assign(make_lhs(result_tmps[tmp_997]), make_compvar_rhs(args[2][tmp_997]));
switch_if_branch();
emit_assign(make_lhs(result_tmps[tmp_997]), make_compvar_rhs(args[0][tmp_997]));
end_if_cond();
}
end_if_cond();
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lerp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[1]];
int i;
for (i = 0; i < arglengths[1]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1004;

tmp_1004 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1005, *tmp_1006;
tmp_1005 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1005), make_int_const_rhs(1));
tmp_1006 = args[0][0];
emit_assign(make_lhs(tmp_1004), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1005), make_compvar_primary(tmp_1006)));
}

{
int tmp_1007;
for (tmp_1007 = 0; tmp_1007 < arglengths[1]; ++tmp_1007)
{
{
compvar_t *tmp_1008, *tmp_1009;
tmp_1008 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1010, *tmp_1011;
tmp_1010 = tmp_1004;
tmp_1011 = args[1][tmp_1007];
emit_assign(make_lhs(tmp_1008), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1010), make_compvar_primary(tmp_1011)));
}
tmp_1009 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1012, *tmp_1013;
tmp_1012 = args[0][0];
tmp_1013 = args[2][tmp_1007];
emit_assign(make_lhs(tmp_1009), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1012), make_compvar_primary(tmp_1013)));
}
emit_assign(make_lhs(result_tmps[tmp_1007]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1008), make_compvar_primary(tmp_1009)));
}
}
}
}
for (i = 0; i < arglengths[1]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lerp_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1014;
for (tmp_1014 = 0; tmp_1014 < arglengths[1]; ++tmp_1014)
{
{
compvar_t *tmp_1015, *tmp_1016;
tmp_1015 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1017, *tmp_1018;
tmp_1017 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1019, *tmp_1020;
tmp_1019 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1019), make_int_const_rhs(1));
tmp_1020 = args[0][tmp_1014];
emit_assign(make_lhs(tmp_1017), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1019), make_compvar_primary(tmp_1020)));
}
tmp_1018 = args[1][tmp_1014];
emit_assign(make_lhs(tmp_1015), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1017), make_compvar_primary(tmp_1018)));
}
tmp_1016 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1021, *tmp_1022;
tmp_1021 = args[0][tmp_1014];
tmp_1022 = args[2][tmp_1014];
emit_assign(make_lhs(tmp_1016), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1021), make_compvar_primary(tmp_1022)));
}
emit_assign(make_lhs(result_tmps[tmp_1014]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1015), make_compvar_primary(tmp_1016)));
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_scale (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[arglengths[0]];
int i;
for (i = 0; i < arglengths[0]; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1023;
for (tmp_1023 = 0; tmp_1023 < arglengths[0]; ++tmp_1023)
{
{
compvar_t *tmp_1024;

tmp_1024 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1025, *tmp_1026;
tmp_1025 = args[2][tmp_1023];
tmp_1026 = args[1][tmp_1023];
emit_assign(make_lhs(tmp_1024), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1025), make_compvar_primary(tmp_1026)));
}

{
compvar_t *tmp_1027;
tmp_1027 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1028, *tmp_1029;
tmp_1028 = tmp_1024;
tmp_1029 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1029), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1027), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1028), make_compvar_primary(tmp_1029)));
}
start_if_cond(make_compvar_rhs(tmp_1027));
emit_assign(make_lhs(result_tmps[tmp_1023]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1030, *tmp_1031;
tmp_1030 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1032, *tmp_1033;
tmp_1032 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1034, *tmp_1035;
tmp_1034 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1036, *tmp_1037;
tmp_1036 = args[0][tmp_1023];
tmp_1037 = args[1][tmp_1023];
emit_assign(make_lhs(tmp_1034), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1036), make_compvar_primary(tmp_1037)));
}
tmp_1035 = tmp_1024;
emit_assign(make_lhs(tmp_1032), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1034), make_compvar_primary(tmp_1035)));
}
tmp_1033 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1038, *tmp_1039;
tmp_1038 = args[4][tmp_1023];
tmp_1039 = args[3][tmp_1023];
emit_assign(make_lhs(tmp_1033), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1038), make_compvar_primary(tmp_1039)));
}
emit_assign(make_lhs(tmp_1030), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1032), make_compvar_primary(tmp_1033)));
}
tmp_1031 = args[3][tmp_1023];
emit_assign(make_lhs(result_tmps[tmp_1023]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1030), make_compvar_primary(tmp_1031)));
}
end_if_cond();
}
}
}
}
for (i = 0; i < arglengths[0]; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_not (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1040;
tmp_1040 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1041, *tmp_1042;
tmp_1041 = args[0][0];
tmp_1042 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1042), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1040), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1041), make_compvar_primary(tmp_1042)));
}
start_if_cond(make_compvar_rhs(tmp_1040));
{
int tmp_1043;
for (tmp_1043 = 0; tmp_1043 < 1; ++tmp_1043)
{
switch (tmp_1043)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1043]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1044;
for (tmp_1044 = 0; tmp_1044 < 1; ++tmp_1044)
{
switch (tmp_1044)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1044]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_or (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1045;
tmp_1045 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1046, *tmp_1047;
tmp_1046 = args[0][0];
tmp_1047 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1047), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1045), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1046), make_compvar_primary(tmp_1047)));
}
start_if_cond(make_compvar_rhs(tmp_1045));
{
compvar_t *tmp_1048, *tmp_1049;
tmp_1048 = args[1][0];
tmp_1049 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1049), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1045), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1048), make_compvar_primary(tmp_1049)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1045));
{
int tmp_1050;
for (tmp_1050 = 0; tmp_1050 < 1; ++tmp_1050)
{
switch (tmp_1050)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1050]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1051;
for (tmp_1051 = 0; tmp_1051 < 1; ++tmp_1051)
{
switch (tmp_1051)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1051]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_and (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1052;
tmp_1052 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1053, *tmp_1054;
tmp_1053 = args[0][0];
tmp_1054 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1054), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1052), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1053), make_compvar_primary(tmp_1054)));
}
start_if_cond(make_compvar_rhs(tmp_1052));
switch_if_branch();
{
compvar_t *tmp_1055, *tmp_1056;
tmp_1055 = args[1][0];
tmp_1056 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1056), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1052), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1055), make_compvar_primary(tmp_1056)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1052));
{
int tmp_1057;
for (tmp_1057 = 0; tmp_1057 < 1; ++tmp_1057)
{
switch (tmp_1057)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1057]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1058;
for (tmp_1058 = 0; tmp_1058 < 1; ++tmp_1058)
{
switch (tmp_1058)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1058]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_xor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1059;
tmp_1059 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1060, *tmp_1061;
tmp_1060 = args[0][0];
tmp_1061 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1061), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1059), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1060), make_compvar_primary(tmp_1061)));
}
emit_assign(make_lhs(tmp_1059), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1059)));
start_if_cond(make_compvar_rhs(tmp_1059));
{
compvar_t *tmp_1062, *tmp_1063;
tmp_1062 = args[1][0];
tmp_1063 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1063), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1059), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1062), make_compvar_primary(tmp_1063)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1059));
switch_if_branch();
{
compvar_t *tmp_1064, *tmp_1065;
tmp_1064 = args[1][0];
tmp_1065 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1065), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1059), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1064), make_compvar_primary(tmp_1065)));
}
emit_assign(make_lhs(tmp_1059), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1059)));
start_if_cond(make_compvar_rhs(tmp_1059));
{
compvar_t *tmp_1066, *tmp_1067;
tmp_1066 = args[0][0];
tmp_1067 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1067), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1059), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1066), make_compvar_primary(tmp_1067)));
}
switch_if_branch();
end_if_cond();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1059));
{
int tmp_1068;
for (tmp_1068 = 0; tmp_1068 < 1; ++tmp_1068)
{
switch (tmp_1068)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1068]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1069;
for (tmp_1069 = 0; tmp_1069 < 1; ++tmp_1069)
{
switch (tmp_1069)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1069]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_equal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1070;
for (tmp_1070 = 0; tmp_1070 < 1; ++tmp_1070)
{
switch (tmp_1070)
{
case 0 :
{
compvar_t *tmp_1071, *tmp_1072;
tmp_1071 = args[0][0];
tmp_1072 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1070]), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1071), make_compvar_primary(tmp_1072)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_less (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1073;
for (tmp_1073 = 0; tmp_1073 < 1; ++tmp_1073)
{
switch (tmp_1073)
{
case 0 :
{
compvar_t *tmp_1074, *tmp_1075;
tmp_1074 = args[0][0];
tmp_1075 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1073]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1074), make_compvar_primary(tmp_1075)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_greater (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1076;
for (tmp_1076 = 0; tmp_1076 < 1; ++tmp_1076)
{
switch (tmp_1076)
{
case 0 :
{
compvar_t *tmp_1077, *tmp_1078;
tmp_1077 = args[1][0];
tmp_1078 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1076]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1077), make_compvar_primary(tmp_1078)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_lessequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1079;
for (tmp_1079 = 0; tmp_1079 < 1; ++tmp_1079)
{
switch (tmp_1079)
{
case 0 :
{
compvar_t *tmp_1080, *tmp_1081;
tmp_1080 = args[0][0];
tmp_1081 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1079]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1080), make_compvar_primary(tmp_1081)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_greaterequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1082;
for (tmp_1082 = 0; tmp_1082 < 1; ++tmp_1082)
{
switch (tmp_1082)
{
case 0 :
{
compvar_t *tmp_1083, *tmp_1084;
tmp_1083 = args[1][0];
tmp_1084 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1082]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1083), make_compvar_primary(tmp_1084)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_notequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1085;
for (tmp_1085 = 0; tmp_1085 < 1; ++tmp_1085)
{
switch (tmp_1085)
{
case 0 :
{
compvar_t *tmp_1086;
tmp_1086 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1087, *tmp_1088;
tmp_1087 = args[0][0];
tmp_1088 = args[1][0];
emit_assign(make_lhs(tmp_1086), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1087), make_compvar_primary(tmp_1088)));
}
emit_assign(make_lhs(result_tmps[tmp_1085]), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1086)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_inintv (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1089;
tmp_1089 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1090, *tmp_1091;
tmp_1090 = args[1][0];
tmp_1091 = args[0][0];
emit_assign(make_lhs(tmp_1089), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1090), make_compvar_primary(tmp_1091)));
}
start_if_cond(make_compvar_rhs(tmp_1089));
{
compvar_t *tmp_1092, *tmp_1093;
tmp_1092 = args[0][0];
tmp_1093 = args[2][0];
emit_assign(make_lhs(tmp_1089), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1092), make_compvar_primary(tmp_1093)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1089));
{
int tmp_1094;
for (tmp_1094 = 0; tmp_1094 < 1; ++tmp_1094)
{
switch (tmp_1094)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1094]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1095;
for (tmp_1095 = 0; tmp_1095 < 1; ++tmp_1095)
{
switch (tmp_1095)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1095]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_origvalxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1096;

tmp_1096 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1097, *tmp_1098, *tmp_1099, *tmp_1100;
tmp_1097 = args[0][0];
tmp_1098 = args[0][1];
tmp_1099 = args[2][0];
tmp_1100 = args[1][0];
emit_assign(make_lhs(tmp_1096), make_op_rhs(OP_ORIG_VAL, make_compvar_primary(tmp_1097), make_compvar_primary(tmp_1098), make_compvar_primary(tmp_1099), make_compvar_primary(tmp_1100)));
}

{
int tmp_1101;
for (tmp_1101 = 0; tmp_1101 < 4; ++tmp_1101)
{
switch (tmp_1101)
{
case 0 :
{
compvar_t *tmp_1102;
tmp_1102 = tmp_1096;
emit_assign(make_lhs(result_tmps[tmp_1101]), make_op_rhs(OP_RED, make_compvar_primary(tmp_1102)));
}
break;
case 1 :
{
compvar_t *tmp_1103;
tmp_1103 = tmp_1096;
emit_assign(make_lhs(result_tmps[tmp_1101]), make_op_rhs(OP_GREEN, make_compvar_primary(tmp_1103)));
}
break;
case 2 :
{
compvar_t *tmp_1104;
tmp_1104 = tmp_1096;
emit_assign(make_lhs(result_tmps[tmp_1101]), make_op_rhs(OP_BLUE, make_compvar_primary(tmp_1104)));
}
break;
case 3 :
{
compvar_t *tmp_1105;
tmp_1105 = tmp_1096;
emit_assign(make_lhs(result_tmps[tmp_1101]), make_op_rhs(OP_ALPHA, make_compvar_primary(tmp_1105)));
}
break;
default :
assert(0);
}
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_red (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1106;
for (tmp_1106 = 0; tmp_1106 < 1; ++tmp_1106)
{
switch (tmp_1106)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1106]), make_compvar_rhs(args[0][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_green (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1107;
for (tmp_1107 = 0; tmp_1107 < 1; ++tmp_1107)
{
switch (tmp_1107)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1107]), make_compvar_rhs(args[0][1]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_blue (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1108;
for (tmp_1108 = 0; tmp_1108 < 1; ++tmp_1108)
{
switch (tmp_1108)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1108]), make_compvar_rhs(args[0][2]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_alpha (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1109;
for (tmp_1109 = 0; tmp_1109 < 1; ++tmp_1109)
{
switch (tmp_1109)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1109]), make_compvar_rhs(args[0][3]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_gray (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1110;
for (tmp_1110 = 0; tmp_1110 < 1; ++tmp_1110)
{
switch (tmp_1110)
{
case 0 :
{
compvar_t *tmp_1111, *tmp_1112;
tmp_1111 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1113, *tmp_1114;
tmp_1113 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1115, *tmp_1116;
tmp_1115 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1115), make_float_const_rhs(0.299));
tmp_1116 = args[0][0];
emit_assign(make_lhs(tmp_1113), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1115), make_compvar_primary(tmp_1116)));
}
tmp_1114 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1117, *tmp_1118;
tmp_1117 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1117), make_float_const_rhs(0.587));
tmp_1118 = args[0][1];
emit_assign(make_lhs(tmp_1114), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1117), make_compvar_primary(tmp_1118)));
}
emit_assign(make_lhs(tmp_1111), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1113), make_compvar_primary(tmp_1114)));
}
tmp_1112 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1119, *tmp_1120;
tmp_1119 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1119), make_float_const_rhs(0.114));
tmp_1120 = args[0][2];
emit_assign(make_lhs(tmp_1112), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1119), make_compvar_primary(tmp_1120)));
}
emit_assign(make_lhs(result_tmps[tmp_1110]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1111), make_compvar_primary(tmp_1112)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rgbcolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1121;
for (tmp_1121 = 0; tmp_1121 < 4; ++tmp_1121)
{
switch (tmp_1121)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1121]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1121]), make_compvar_rhs(args[1][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1121]), make_compvar_rhs(args[2][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1121]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rgbacolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1122;
for (tmp_1122 = 0; tmp_1122 < 4; ++tmp_1122)
{
switch (tmp_1122)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1122]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1122]), make_compvar_rhs(args[1][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1122]), make_compvar_rhs(args[2][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1122]), make_compvar_rhs(args[3][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_graycolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1123;
for (tmp_1123 = 0; tmp_1123 < 4; ++tmp_1123)
{
switch (tmp_1123)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1123]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1123]), make_compvar_rhs(args[0][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1123]), make_compvar_rhs(args[0][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1123]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_grayacolor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1124;
for (tmp_1124 = 0; tmp_1124 < 4; ++tmp_1124)
{
switch (tmp_1124)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1124]), make_compvar_rhs(args[0][0]));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1124]), make_compvar_rhs(args[0][0]));
break;
case 2 :
emit_assign(make_lhs(result_tmps[tmp_1124]), make_compvar_rhs(args[0][0]));
break;
case 3 :
emit_assign(make_lhs(result_tmps[tmp_1124]), make_compvar_rhs(args[1][0]));
break;
default :
assert(0);
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tohsva (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1125;
compvar_t *tmp_1130;
compvar_t *tmp_1135;

tmp_1125 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1126, *tmp_1127;
tmp_1126 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1126), make_int_const_rhs(0));
tmp_1127 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1128, *tmp_1129;
tmp_1128 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1128), make_int_const_rhs(1));
tmp_1129 = args[0][0];
emit_assign(make_lhs(tmp_1127), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1128), make_compvar_primary(tmp_1129)));
}
emit_assign(make_lhs(tmp_1125), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1126), make_compvar_primary(tmp_1127)));
}

tmp_1130 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1131, *tmp_1132;
tmp_1131 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1131), make_int_const_rhs(0));
tmp_1132 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1133, *tmp_1134;
tmp_1133 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1133), make_int_const_rhs(1));
tmp_1134 = args[0][1];
emit_assign(make_lhs(tmp_1132), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1133), make_compvar_primary(tmp_1134)));
}
emit_assign(make_lhs(tmp_1130), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1131), make_compvar_primary(tmp_1132)));
}

tmp_1135 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1136, *tmp_1137;
tmp_1136 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1136), make_int_const_rhs(0));
tmp_1137 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1138, *tmp_1139;
tmp_1138 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1138), make_int_const_rhs(1));
tmp_1139 = args[0][2];
emit_assign(make_lhs(tmp_1137), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1138), make_compvar_primary(tmp_1139)));
}
emit_assign(make_lhs(tmp_1135), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1136), make_compvar_primary(tmp_1137)));
}

{
compvar_t *tmp_1140, *tmp_1141;
tmp_1140 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1140), make_int_const_rhs(0));
tmp_1141 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1142, *tmp_1143;
tmp_1142 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1142), make_int_const_rhs(1));
tmp_1143 = args[0][3];
emit_assign(make_lhs(tmp_1141), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1142), make_compvar_primary(tmp_1143)));
}
emit_assign(make_lhs(result_tmps[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1140), make_compvar_primary(tmp_1141)));
}
{
compvar_t *tmp_1144;
compvar_t *tmp_1149;

tmp_1144 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1145, *tmp_1146;
tmp_1145 = tmp_1125;
tmp_1146 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1147, *tmp_1148;
tmp_1147 = tmp_1130;
tmp_1148 = tmp_1135;
emit_assign(make_lhs(tmp_1146), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1147), make_compvar_primary(tmp_1148)));
}
emit_assign(make_lhs(tmp_1144), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1145), make_compvar_primary(tmp_1146)));
}

tmp_1149 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1150, *tmp_1151;
tmp_1150 = tmp_1125;
tmp_1151 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1152, *tmp_1153;
tmp_1152 = tmp_1130;
tmp_1153 = tmp_1135;
emit_assign(make_lhs(tmp_1151), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1152), make_compvar_primary(tmp_1153)));
}
emit_assign(make_lhs(tmp_1149), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1150), make_compvar_primary(tmp_1151)));
}

emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1144));
{
compvar_t *tmp_1154;
tmp_1154 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1155, *tmp_1156;
tmp_1155 = tmp_1144;
tmp_1156 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1156), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1154), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1155), make_compvar_primary(tmp_1156)));
}
start_if_cond(make_compvar_rhs(tmp_1154));
emit_assign(make_lhs(result_tmps[0]), make_int_const_rhs(0));
emit_assign(make_lhs(result_tmps[1]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1157;
compvar_t *tmp_1160;

tmp_1157 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1158, *tmp_1159;
tmp_1158 = tmp_1144;
tmp_1159 = tmp_1149;
emit_assign(make_lhs(tmp_1157), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1158), make_compvar_primary(tmp_1159)));
}

tmp_1160 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1160), make_int_const_rhs(0));

{
compvar_t *tmp_1161, *tmp_1162;
tmp_1161 = tmp_1157;
tmp_1162 = tmp_1144;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1161), make_compvar_primary(tmp_1162)));
}
{
compvar_t *tmp_1163;
tmp_1163 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1164, *tmp_1165;
tmp_1164 = tmp_1125;
tmp_1165 = tmp_1144;
emit_assign(make_lhs(tmp_1163), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1164), make_compvar_primary(tmp_1165)));
}
start_if_cond(make_compvar_rhs(tmp_1163));
{
compvar_t *tmp_1166, *tmp_1167;
tmp_1166 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1168, *tmp_1169;
tmp_1168 = tmp_1130;
tmp_1169 = tmp_1135;
emit_assign(make_lhs(tmp_1166), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1168), make_compvar_primary(tmp_1169)));
}
tmp_1167 = tmp_1157;
emit_assign(make_lhs(tmp_1160), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1166), make_compvar_primary(tmp_1167)));
}
switch_if_branch();
{
compvar_t *tmp_1170;
tmp_1170 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1171, *tmp_1172;
tmp_1171 = tmp_1130;
tmp_1172 = tmp_1144;
emit_assign(make_lhs(tmp_1170), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1171), make_compvar_primary(tmp_1172)));
}
start_if_cond(make_compvar_rhs(tmp_1170));
{
compvar_t *tmp_1173, *tmp_1174;
tmp_1173 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1173), make_int_const_rhs(2));
tmp_1174 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1175, *tmp_1176;
tmp_1175 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1177, *tmp_1178;
tmp_1177 = tmp_1135;
tmp_1178 = tmp_1125;
emit_assign(make_lhs(tmp_1175), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1177), make_compvar_primary(tmp_1178)));
}
tmp_1176 = tmp_1157;
emit_assign(make_lhs(tmp_1174), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1175), make_compvar_primary(tmp_1176)));
}
emit_assign(make_lhs(tmp_1160), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1173), make_compvar_primary(tmp_1174)));
}
switch_if_branch();
{
compvar_t *tmp_1179, *tmp_1180;
tmp_1179 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1179), make_int_const_rhs(4));
tmp_1180 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1181, *tmp_1182;
tmp_1181 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1183, *tmp_1184;
tmp_1183 = tmp_1125;
tmp_1184 = tmp_1130;
emit_assign(make_lhs(tmp_1181), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1183), make_compvar_primary(tmp_1184)));
}
tmp_1182 = tmp_1157;
emit_assign(make_lhs(tmp_1180), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1181), make_compvar_primary(tmp_1182)));
}
emit_assign(make_lhs(tmp_1160), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1179), make_compvar_primary(tmp_1180)));
}
end_if_cond();
}
end_if_cond();
}
{
compvar_t *tmp_1185, *tmp_1186;
tmp_1185 = tmp_1160;
tmp_1186 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1186), make_float_const_rhs(6.0));
emit_assign(make_lhs(tmp_1160), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1185), make_compvar_primary(tmp_1186)));
}
{
compvar_t *tmp_1187;
tmp_1187 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1188, *tmp_1189;
tmp_1188 = tmp_1160;
tmp_1189 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1189), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1187), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1188), make_compvar_primary(tmp_1189)));
}
start_if_cond(make_compvar_rhs(tmp_1187));
{
compvar_t *tmp_1190, *tmp_1191;
tmp_1190 = tmp_1160;
tmp_1191 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1191), make_int_const_rhs(1));
emit_assign(make_lhs(result_tmps[0]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1190), make_compvar_primary(tmp_1191)));
}
switch_if_branch();
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1160));
end_if_cond();
}
}
end_if_cond();
}
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_torgba (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[4];
int i;
for (i = 0; i < 4; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1192;
compvar_t *tmp_1197;

tmp_1192 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1193, *tmp_1194;
tmp_1193 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1193), make_int_const_rhs(0));
tmp_1194 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1195, *tmp_1196;
tmp_1195 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1195), make_int_const_rhs(1));
tmp_1196 = args[0][1];
emit_assign(make_lhs(tmp_1194), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1195), make_compvar_primary(tmp_1196)));
}
emit_assign(make_lhs(tmp_1192), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1193), make_compvar_primary(tmp_1194)));
}

tmp_1197 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1198, *tmp_1199;
tmp_1198 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1198), make_int_const_rhs(0));
tmp_1199 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1200, *tmp_1201;
tmp_1200 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1200), make_int_const_rhs(1));
tmp_1201 = args[0][2];
emit_assign(make_lhs(tmp_1199), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1200), make_compvar_primary(tmp_1201)));
}
emit_assign(make_lhs(tmp_1197), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1198), make_compvar_primary(tmp_1199)));
}

{
compvar_t *tmp_1202, *tmp_1203;
tmp_1202 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1202), make_int_const_rhs(0));
tmp_1203 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1204, *tmp_1205;
tmp_1204 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1204), make_int_const_rhs(1));
tmp_1205 = args[0][3];
emit_assign(make_lhs(tmp_1203), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1204), make_compvar_primary(tmp_1205)));
}
emit_assign(make_lhs(result_tmps[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1202), make_compvar_primary(tmp_1203)));
}
{
compvar_t *tmp_1206;
tmp_1206 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1207, *tmp_1208;
tmp_1207 = tmp_1192;
tmp_1208 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1208), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1206), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1207), make_compvar_primary(tmp_1208)));
}
start_if_cond(make_compvar_rhs(tmp_1206));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1197));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1197));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1197));
switch_if_branch();
{
compvar_t *tmp_1209;

tmp_1209 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1210, *tmp_1211;
tmp_1210 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1210), make_int_const_rhs(0));
tmp_1211 = args[0][0];
emit_assign(make_lhs(tmp_1209), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1210), make_compvar_primary(tmp_1211)));
}

{
compvar_t *tmp_1212;
tmp_1212 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1213, *tmp_1214;
tmp_1213 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1213), make_int_const_rhs(1));
tmp_1214 = tmp_1209;
emit_assign(make_lhs(tmp_1212), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1213), make_compvar_primary(tmp_1214)));
}
start_if_cond(make_compvar_rhs(tmp_1212));
emit_assign(make_lhs(tmp_1209), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1215, *tmp_1216;
tmp_1215 = tmp_1209;
tmp_1216 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1216), make_int_const_rhs(6));
emit_assign(make_lhs(tmp_1209), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1215), make_compvar_primary(tmp_1216)));
}
end_if_cond();
}
{
compvar_t *tmp_1217;

tmp_1217 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1218;
tmp_1218 = tmp_1209;
emit_assign(make_lhs(tmp_1217), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1218)));
}

{
compvar_t *tmp_1219;

tmp_1219 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1220, *tmp_1221;
tmp_1220 = tmp_1209;
tmp_1221 = tmp_1217;
emit_assign(make_lhs(tmp_1219), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1220), make_compvar_primary(tmp_1221)));
}

{
compvar_t *tmp_1222;
compvar_t *tmp_1227;
compvar_t *tmp_1234;

tmp_1222 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1223, *tmp_1224;
tmp_1223 = tmp_1197;
tmp_1224 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1225, *tmp_1226;
tmp_1225 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1225), make_int_const_rhs(1));
tmp_1226 = tmp_1192;
emit_assign(make_lhs(tmp_1224), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1225), make_compvar_primary(tmp_1226)));
}
emit_assign(make_lhs(tmp_1222), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1223), make_compvar_primary(tmp_1224)));
}

tmp_1227 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1228, *tmp_1229;
tmp_1228 = tmp_1197;
tmp_1229 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1230, *tmp_1231;
tmp_1230 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1230), make_int_const_rhs(1));
tmp_1231 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1232, *tmp_1233;
tmp_1232 = tmp_1192;
tmp_1233 = tmp_1219;
emit_assign(make_lhs(tmp_1231), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1232), make_compvar_primary(tmp_1233)));
}
emit_assign(make_lhs(tmp_1229), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1230), make_compvar_primary(tmp_1231)));
}
emit_assign(make_lhs(tmp_1227), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1228), make_compvar_primary(tmp_1229)));
}

tmp_1234 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1235, *tmp_1236;
tmp_1235 = tmp_1197;
tmp_1236 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1237, *tmp_1238;
tmp_1237 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1237), make_int_const_rhs(1));
tmp_1238 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1239, *tmp_1240;
tmp_1239 = tmp_1192;
tmp_1240 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1241, *tmp_1242;
tmp_1241 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1241), make_int_const_rhs(1));
tmp_1242 = tmp_1219;
emit_assign(make_lhs(tmp_1240), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1241), make_compvar_primary(tmp_1242)));
}
emit_assign(make_lhs(tmp_1238), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1239), make_compvar_primary(tmp_1240)));
}
emit_assign(make_lhs(tmp_1236), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1237), make_compvar_primary(tmp_1238)));
}
emit_assign(make_lhs(tmp_1234), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1235), make_compvar_primary(tmp_1236)));
}

{
compvar_t *tmp_1243;
tmp_1243 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1244, *tmp_1245;
tmp_1244 = tmp_1217;
tmp_1245 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1245), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1243), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1244), make_compvar_primary(tmp_1245)));
}
start_if_cond(make_compvar_rhs(tmp_1243));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1197));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1234));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1222));
switch_if_branch();
{
compvar_t *tmp_1246;
tmp_1246 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1247, *tmp_1248;
tmp_1247 = tmp_1217;
tmp_1248 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1248), make_int_const_rhs(1));
emit_assign(make_lhs(tmp_1246), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1247), make_compvar_primary(tmp_1248)));
}
start_if_cond(make_compvar_rhs(tmp_1246));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1227));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1197));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1222));
switch_if_branch();
{
compvar_t *tmp_1249;
tmp_1249 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1250, *tmp_1251;
tmp_1250 = tmp_1217;
tmp_1251 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1251), make_int_const_rhs(2));
emit_assign(make_lhs(tmp_1249), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1250), make_compvar_primary(tmp_1251)));
}
start_if_cond(make_compvar_rhs(tmp_1249));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1222));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1197));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1234));
switch_if_branch();
{
compvar_t *tmp_1252;
tmp_1252 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1253, *tmp_1254;
tmp_1253 = tmp_1217;
tmp_1254 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1254), make_int_const_rhs(3));
emit_assign(make_lhs(tmp_1252), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1253), make_compvar_primary(tmp_1254)));
}
start_if_cond(make_compvar_rhs(tmp_1252));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1222));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1227));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1197));
switch_if_branch();
{
compvar_t *tmp_1255;
tmp_1255 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1256, *tmp_1257;
tmp_1256 = tmp_1217;
tmp_1257 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1257), make_int_const_rhs(4));
emit_assign(make_lhs(tmp_1255), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1256), make_compvar_primary(tmp_1257)));
}
start_if_cond(make_compvar_rhs(tmp_1255));
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1234));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1222));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1197));
switch_if_branch();
emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1197));
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1222));
emit_assign(make_lhs(result_tmps[2]), make_compvar_rhs(tmp_1227));
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
}
}
}
}
end_if_cond();
}
}
for (i = 0; i < 4; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_toxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1258;
for (tmp_1258 = 0; tmp_1258 < 2; ++tmp_1258)
{
switch (tmp_1258)
{
case 0 :
{
compvar_t *tmp_1259, *tmp_1260;
tmp_1259 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1261;
tmp_1261 = args[0][1];
emit_assign(make_lhs(tmp_1259), make_op_rhs(OP_COS, make_compvar_primary(tmp_1261)));
}
tmp_1260 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1258]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1259), make_compvar_primary(tmp_1260)));
}
break;
case 1 :
{
compvar_t *tmp_1262, *tmp_1263;
tmp_1262 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1264;
tmp_1264 = args[0][1];
emit_assign(make_lhs(tmp_1262), make_op_rhs(OP_SIN, make_compvar_primary(tmp_1264)));
}
tmp_1263 = args[0][0];
emit_assign(make_lhs(result_tmps[tmp_1258]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1262), make_compvar_primary(tmp_1263)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_toxy_trivial (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1265;
for (tmp_1265 = 0; tmp_1265 < 2; ++tmp_1265)
{
emit_assign(make_lhs(result_tmps[tmp_1265]), make_compvar_rhs(args[0][tmp_1265]));
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tora (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
compvar_t *tmp_1266;

tmp_1266 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1267, *tmp_1268;
tmp_1267 = args[0][0];
tmp_1268 = args[0][1];
emit_assign(make_lhs(tmp_1266), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_1267), make_compvar_primary(tmp_1268)));
}

{
compvar_t *tmp_1269;
tmp_1269 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1270, *tmp_1271;
tmp_1270 = tmp_1266;
tmp_1271 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1271), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1269), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1270), make_compvar_primary(tmp_1271)));
}
start_if_cond(make_compvar_rhs(tmp_1269));
{
int tmp_1272;
for (tmp_1272 = 0; tmp_1272 < 2; ++tmp_1272)
{
switch (tmp_1272)
{
case 0 :
emit_assign(make_lhs(result_tmps[tmp_1272]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result_tmps[tmp_1272]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_1273;

tmp_1273 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1274;
tmp_1274 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1275, *tmp_1276;
tmp_1275 = args[0][0];
tmp_1276 = tmp_1266;
emit_assign(make_lhs(tmp_1274), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1275), make_compvar_primary(tmp_1276)));
}
emit_assign(make_lhs(tmp_1273), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_1274)));
}

emit_assign(make_lhs(result_tmps[0]), make_compvar_rhs(tmp_1266));
{
compvar_t *tmp_1277;
tmp_1277 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1278, *tmp_1279;
tmp_1278 = args[0][1];
tmp_1279 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1279), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1277), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1278), make_compvar_primary(tmp_1279)));
}
start_if_cond(make_compvar_rhs(tmp_1277));
{
compvar_t *tmp_1280, *tmp_1281;
tmp_1280 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1282, *tmp_1283;
tmp_1282 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1282), make_int_const_rhs(2));
tmp_1283 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1283), make_float_const_rhs(M_PI));
emit_assign(make_lhs(tmp_1280), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1282), make_compvar_primary(tmp_1283)));
}
tmp_1281 = tmp_1273;
emit_assign(make_lhs(result_tmps[1]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1280), make_compvar_primary(tmp_1281)));
}
switch_if_branch();
emit_assign(make_lhs(result_tmps[1]), make_compvar_rhs(tmp_1273));
end_if_cond();
}
}
end_if_cond();
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_tora_trivial (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[2];
int i;
for (i = 0; i < 2; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1284;
for (tmp_1284 = 0; tmp_1284 < 2; ++tmp_1284)
{
emit_assign(make_lhs(result_tmps[tmp_1284]), make_compvar_rhs(args[0][tmp_1284]));
}
}
for (i = 0; i < 2; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_rand (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1285;
for (tmp_1285 = 0; tmp_1285 < 1; ++tmp_1285)
{
switch (tmp_1285)
{
case 0 :
{
compvar_t *tmp_1286, *tmp_1287;
tmp_1286 = args[0][0];
tmp_1287 = args[1][0];
emit_assign(make_lhs(result_tmps[tmp_1285]), make_op_rhs(OP_RAND, make_compvar_primary(tmp_1286), make_compvar_primary(tmp_1287)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}

static void
gen_noise (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
compvar_t *result_tmps[1];
int i;
for (i = 0; i < 1; ++i) result_tmps[i] = make_temporary(result[i]->type);
{
int tmp_1288;
for (tmp_1288 = 0; tmp_1288 < 1; ++tmp_1288)
{
switch (tmp_1288)
{
case 0 :
{
compvar_t *tmp_1289, *tmp_1290, *tmp_1291;
tmp_1289 = args[0][0];
tmp_1290 = args[0][1];
tmp_1291 = args[0][2];
emit_assign(make_lhs(result_tmps[tmp_1288]), make_op_rhs(OP_NOISE, make_compvar_primary(tmp_1289), make_compvar_primary(tmp_1290), make_compvar_primary(tmp_1291)));
}
break;
default :
assert(0);
}
}
}
for (i = 0; i < 1; ++i) emit_assign(make_lhs(result[i]), make_compvar_rhs(result_tmps[i]));
}


void
init_builtins (void)
{
register_overloaded_builtin("print", "((nil 1) (_ _))", gen_print);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (ri 2))", gen_add_ri);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (_ 1))", gen_add_ri_1);
register_overloaded_builtin("__add", "((ri 2) (_ 1) (ri 2))", gen_add_1_ri);
register_overloaded_builtin("__add", "((T 1) (T 1) (T 1))", gen_add_1);
register_overloaded_builtin("__add", "((T L) (T L) (_ 1))", gen_add_s);
register_overloaded_builtin("__add", "((T L) (T L) (T L))", gen_add_n);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (ri 2))", gen_sub_ri);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (_ 1))", gen_sub_ri_1);
register_overloaded_builtin("__sub", "((ri 2) (_ 1) (ri 2))", gen_sub_1_ri);
register_overloaded_builtin("__sub", "((T 1) (T 1) (T 1))", gen_sub_1);
register_overloaded_builtin("__sub", "((T L) (T L) (_ 1))", gen_sub_s);
register_overloaded_builtin("__sub", "((T L) (T L) (T L))", gen_sub_n);
register_overloaded_builtin("__neg", "((T L) (T L))", gen_neg);
register_overloaded_builtin("__mul", "((ri 2) (ri 2) (ri 2))", gen_mul_ri);
register_overloaded_builtin("__mul", "((ri 2) (_ 1) (ri 2))", gen_mul_1_ri);
register_overloaded_builtin("__mul", "((m2x2 4) (m2x2 4) (m2x2 4))", gen_mul_m2x2);
register_overloaded_builtin("__mul", "((m3x3 9) (m3x3 9) (m3x3 9))", gen_mul_m3x3);
register_overloaded_builtin("__mul", "((v2 2) (v2 2) (m2x2 4))", gen_mul_v2m2x2);
register_overloaded_builtin("__mul", "((v3 3) (v3 3) (m3x3 9))", gen_mul_v3m3x3);
register_overloaded_builtin("__mul", "((v2 2) (m2x2 4) (v2 2))", gen_mul_m2x2v2);
register_overloaded_builtin("__mul", "((v3 3) (m3x3 9) (v3 3))", gen_mul_m3x3v3);
register_overloaded_builtin("__mul", "((T 1) (T 1) (T 1))", gen_mul_1);
register_overloaded_builtin("__mul", "((T L) (T L) (_ 1))", gen_mul_s);
register_overloaded_builtin("__mul", "((T L) (T L) (T L))", gen_mul_n);
register_overloaded_builtin("__div", "((ri 2) (ri 2) (ri 2))", gen_div_ri);
register_overloaded_builtin("__div", "((ri 2) (T 1) (ri 2))", gen_div_1_ri);
register_overloaded_builtin("__div", "((v2 2) (_ 2) (m2x2 4))", gen_div_v2m2x2);
register_overloaded_builtin("__div", "((v3 3) (_ 3) (m3x3 9))", gen_div_v3m3x3);
register_overloaded_builtin("__div", "((T 1) (T 1) (T 1))", gen_div_1);
register_overloaded_builtin("__div", "((T L) (T L) (_ 1))", gen_div_s);
register_overloaded_builtin("__div", "((T L) (T L) (T L))", gen_div_n);
register_overloaded_builtin("__mod", "((T 1) (T 1) (T 1))", gen_mod_1);
register_overloaded_builtin("__mod", "((T L) (T L) (_ 1))", gen_mod_s);
register_overloaded_builtin("__mod", "((T L) (T L) (T L))", gen_mod_n);
register_overloaded_builtin("pmod", "((T 1) (T 1) (T 1))", gen_pmod);
register_overloaded_builtin("sqrt", "((ri 2) (ri 2))", gen_sqrt_ri);
register_overloaded_builtin("sqrt", "((T 1) (T 1))", gen_sqrt_1);
register_overloaded_builtin("sum", "((T 1) (T L))", gen_sum);
register_overloaded_builtin("dotp", "((nil 1) (T L) (T L))", gen_dotp);
register_overloaded_builtin("crossp", "((T 3) (T 3) (T 3))", gen_crossp);
register_overloaded_builtin("det", "((nil 1) (m2x2 4))", gen_det_m2x2);
register_overloaded_builtin("det", "((nil 1) (m3x3 9))", gen_det_m3x3);
register_overloaded_builtin("normalize", "((T L) (T L))", gen_normalize);
register_overloaded_builtin("abs", "((nil 1) (ri 2))", gen_abs_ri);
register_overloaded_builtin("abs", "((T 1) (T 1))", gen_abs_1);
register_overloaded_builtin("abs", "((T L) (T L))", gen_abs_n);
register_overloaded_builtin("deg2rad", "((nil 1) (_ 1))", gen_deg2rad);
register_overloaded_builtin("rad2deg", "((deg 1) (_ 1))", gen_rad2deg);
register_overloaded_builtin("sin", "((ri 2) (ri 2))", gen_sin_ri);
register_overloaded_builtin("sin", "((T 1) (T 1))", gen_sin);
register_overloaded_builtin("cos", "((ri 2) (ri 2))", gen_cos_ri);
register_overloaded_builtin("cos", "((T 1) (T 1))", gen_cos);
register_overloaded_builtin("tan", "((ri 2) (ri 2))", gen_tan_ri);
register_overloaded_builtin("tan", "((T 1) (T 1))", gen_tan);
register_overloaded_builtin("asin", "((ri 2) (ri 2))", gen_asin_ri);
register_overloaded_builtin("asin", "((T 1) (T 1))", gen_asin);
register_overloaded_builtin("acos", "((ri 2) (ri 2))", gen_acos_ri);
register_overloaded_builtin("acos", "((T 1) (T 1))", gen_acos);
register_overloaded_builtin("atan", "((ri 2) (ri 2))", gen_atan_ri);
register_overloaded_builtin("atan", "((T 1) (T 1))", gen_atan);
register_overloaded_builtin("atan", "((T 1) (T 1) (T 1))", gen_atan2);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (T 1))", gen_pow_ri_1);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (ri 2))", gen_pow_ri);
register_overloaded_builtin("__pow", "((ri 2) (T 1) (ri 2))", gen_pow_1_ri);
register_overloaded_builtin("__pow", "((T 1) (T 1) (T 1))", gen_pow_1);
register_overloaded_builtin("__pow", "((T L) (T L) (_ 1))", gen_pow_s);
register_overloaded_builtin("exp", "((ri 2) (ri 2))", gen_exp_ri);
register_overloaded_builtin("exp", "((T 1) (T 1))", gen_exp_1);
register_overloaded_builtin("log", "((ri 2) (ri 2))", gen_log_ri);
register_overloaded_builtin("log", "((T 1) (T 1))", gen_log_1);
register_overloaded_builtin("arg", "((nil 1) (ri 2))", gen_arg_ri);
register_overloaded_builtin("conj", "((ri 2) (ri 2))", gen_conj_ri);
register_overloaded_builtin("sinh", "((ri 2) (ri 2))", gen_sinh_ri);
register_overloaded_builtin("sinh", "((T 1) (T 1))", gen_sinh_1);
register_overloaded_builtin("cosh", "((ri 2) (ri 2))", gen_cosh_ri);
register_overloaded_builtin("cosh", "((T 1) (T 1))", gen_cosh_1);
register_overloaded_builtin("tanh", "((ri 2) (ri 2))", gen_tanh_ri);
register_overloaded_builtin("tanh", "((T 1) (T 1))", gen_tanh_1);
register_overloaded_builtin("asinh", "((ri 2) (ri 2))", gen_asinh_ri);
register_overloaded_builtin("asinh", "((T 1) (T 1))", gen_asinh_1);
register_overloaded_builtin("acosh", "((ri 2) (ri 2))", gen_acosh_ri);
register_overloaded_builtin("acosh", "((T 1) (T 1))", gen_acosh_1);
register_overloaded_builtin("atanh", "((ri 2) (ri 2))", gen_atanh_ri);
register_overloaded_builtin("atanh", "((T 1) (T 1))", gen_atanh_1);
register_overloaded_builtin("gamma", "((ri 2) (ri 2))", gen_gamma_ri);
register_overloaded_builtin("gamma", "((T 1) (T 1))", gen_gamma_1);
register_overloaded_builtin("beta", "((T 1) (T 1) (T 1))", gen_beta_1);
register_overloaded_builtin("ell_int_Kcomp", "((T 1) (T 1))", gen_ell_int_kcomp);
register_overloaded_builtin("ell_int_Ecomp", "((T 1) (T 1))", gen_ell_int_ecomp);
register_overloaded_builtin("ell_int_F", "((T 1) (T 1) (T 1))", gen_ell_int_f);
register_overloaded_builtin("ell_int_E", "((T 1) (T 1) (T 1))", gen_ell_int_e);
register_overloaded_builtin("ell_int_P", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_p);
register_overloaded_builtin("ell_int_D", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_d);
register_overloaded_builtin("ell_int_RC", "((T 1) (T 1) (T 1))", gen_ell_int_rc);
register_overloaded_builtin("ell_int_RD", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rd);
register_overloaded_builtin("ell_int_RF", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rf);
register_overloaded_builtin("ell_int_RJ", "((T 1) (T 1) (T 1) (T 1) (T 1))", gen_ell_int_rj);
register_overloaded_builtin("ell_jac_sn", "((T 1) (T 1) (T 1))", gen_ell_jac_sn_1);
register_overloaded_builtin("ell_jac_cn", "((T 1) (T 1) (T 1))", gen_ell_jac_cn_1);
register_overloaded_builtin("ell_jac_dn", "((T 1) (T 1) (T 1))", gen_ell_jac_dn_1);
register_overloaded_builtin("ell_jac_sn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_sn_ri);
register_overloaded_builtin("ell_jac_cn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_cn_ri);
register_overloaded_builtin("ell_jac_dn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_dn_ri);
register_overloaded_builtin("floor", "((T 1) (T 1))", gen_floor);
register_overloaded_builtin("ceil", "((T 1) (T 1))", gen_ceil);
register_overloaded_builtin("sign", "((T L) (T L))", gen_sign_n);
register_overloaded_builtin("min", "((T L) (T L) (T L))", gen_min_n);
register_overloaded_builtin("max", "((T L) (T L) (T L))", gen_max_n);
register_overloaded_builtin("clamp", "((T L) (T L) (T L) (T L))", gen_clamp);
register_overloaded_builtin("lerp", "((T L) (_ 1) (T L) (T L))", gen_lerp_1);
register_overloaded_builtin("lerp", "((T L) (T L) (T L) (T L))", gen_lerp_n);
register_overloaded_builtin("scale", "((T L) (T L) (T L) (T L) (T L) (T L))", gen_scale);
register_overloaded_builtin("__not", "((T 1) (T 1))", gen_not);
register_overloaded_builtin("__or", "((T 1) (T 1) (T 1))", gen_or);
register_overloaded_builtin("__and", "((T 1) (T 1) (T 1))", gen_and);
register_overloaded_builtin("__xor", "((T 1) (T 1) (T 1))", gen_xor);
register_overloaded_builtin("__equal", "((T 1) (T 1) (T 1))", gen_equal);
register_overloaded_builtin("__less", "((T 1) (T 1) (T 1))", gen_less);
register_overloaded_builtin("__greater", "((T 1) (T 1) (T 1))", gen_greater);
register_overloaded_builtin("__lessequal", "((T 1) (T 1) (T 1))", gen_lessequal);
register_overloaded_builtin("__greaterequal", "((T 1) (T 1) (T 1))", gen_greaterequal);
register_overloaded_builtin("__notequal", "((T 1) (T 1) (T 1))", gen_notequal);
register_overloaded_builtin("inintv", "((T 1) (T 1) (T 1) (T 1))", gen_inintv);
register_overloaded_builtin("origVal", "((rgba 4) (xy 2) (nil 1) (image 1))", gen_origvalxy);
register_overloaded_builtin("red", "((nil 1) (rgba 4))", gen_red);
register_overloaded_builtin("green", "((nil 1) (rgba 4))", gen_green);
register_overloaded_builtin("blue", "((nil 1) (rgba 4))", gen_blue);
register_overloaded_builtin("alpha", "((nil 1) (rgba 4))", gen_alpha);
register_overloaded_builtin("gray", "((nil 1) (rgba 4))", gen_gray);
register_overloaded_builtin("rgbColor", "((rgba 4) (T 1) (T 1) (T 1))", gen_rgbcolor);
register_overloaded_builtin("rgbaColor", "((rgba 4) (T 1) (T 1) (T 1) (T 1))", gen_rgbacolor);
register_overloaded_builtin("grayColor", "((rgba 4) (T 1))", gen_graycolor);
register_overloaded_builtin("grayaColor", "((rgba 4) (T 1) (T 1))", gen_grayacolor);
register_overloaded_builtin("toHSVA", "((hsva 4) (rgba 4))", gen_tohsva);
register_overloaded_builtin("toRGBA", "((rgba 4) (hsva 4))", gen_torgba);
register_overloaded_builtin("toXY", "((xy 2) (ra 2))", gen_toxy);
register_overloaded_builtin("toXY", "((xy 2) (xy 2))", gen_toxy_trivial);
register_overloaded_builtin("toRA", "((ra 2) (xy 2))", gen_tora);
register_overloaded_builtin("toRA", "((ra 2) (ra 2))", gen_tora_trivial);
register_overloaded_builtin("rand", "((T 1) (T 1) (T 1))", gen_rand);
register_overloaded_builtin("noise", "((nil 1) (_ 3))", gen_noise);
}
