//
//  MMAppDelegate.h
//
//  Created by Herbert Pötzl on Sun Mar 31 2002.
//  Copyright (c) 2002-2007 Herbert Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import "MMAppDelegate.h"

#import "MMLibrary.h"
#import "MMPreview.h"
#import "UserDefaults.h"

@implementation MMAppDelegate


+ (void)initialize{

    [[NSUserDefaults standardUserDefaults] 
        registerDefaults:[NSDictionary
        dictionaryWithObjectsAndKeys:
            FirstTimeDValue, FirstTimeDefault,
            nil]];
}

- (void)stopModal:(id)sender {
    [NSApp stopModal];
}


-(void)showFirstTimePanel:(id)sender {
    NSModalSession session;

    [NSBundle loadNibNamed:@"FirstTime" owner:self];
    [firstTimeTextView readRTFDFromFile:[[NSBundle mainBundle] 
            pathForResource:@"FirstTime" ofType: @"rtf"]];

    session = [NSApp beginModalSessionForWindow:firstTimeWindow];
    while (1) {
        if ([NSApp runModalSession:session] != 
            NSRunContinuesResponse)
            break;
    }
    [NSApp endModalSession:session];
    [firstTimeWindow close];
}

-(void)showLicense:(id)sender {
    NSModalSession session;

    [NSBundle loadNibNamed:@"License" owner:self];
    [licenseTextView readRTFDFromFile:[[NSBundle mainBundle] 
            pathForResource:@"License" ofType: @"rtf"]];

    session = [NSApp beginModalSessionForWindow:licenseWindow];
    while (1) {
        if ([NSApp runModalSession:session] != 
            NSRunContinuesResponse)
            break;
    }
    [NSApp endModalSession:session];
    [licenseWindow close];
}

-(void)openMainURL:(id)sender {
	NSString *where = @"http://www.complang.tuwien.ac.at/schani/mathmap/";
	NSURL *url = [NSURL URLWithString: where];
	NSWorkspace *workspace = [NSWorkspace sharedWorkspace];

	[workspace openURL: url];
}

-(void)openIntroMovie:(id)sender {
    [[NSWorkspace sharedWorkspace] openFile:
     [[NSBundle mainBundle] pathForResource: @"IntroMovie" ofType: @"mov"]];
}


- (void)firstTimeModal {
    
    if ([[[NSUserDefaults standardUserDefaults] 
        stringForKey:FirstTimeDefault] intValue]) {

        [self showFirstTimePanel:self];
        [[NSUserDefaults standardUserDefaults]
            setObject:@"0" forKey:FirstTimeDefault];
    }
}


- (void)showLibrary:(id)sender {
    [[MMLibrary sharedLibrary]
        showWindows]; 
}

- (void)showPreview:(id)sender {
    [[MMPreview previewController]
        openPreviewWindow:self];
}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    [[NSColorPanel sharedColorPanel] 
        setShowsAlpha:YES];
		
//  [[[NSApp mainWindow] firstResponder] setString:@"origVal(xy)"];
//	[[[[NSApp mainWindow] firstResponder] delegate] textDidChange:nil];
    [self firstTimeModal];
	
    [self showLibrary:self];
    [self showPreview:self];
}

@end
