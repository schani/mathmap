//
//  UVEHelper.m
//
//  Created by Herbert Pötzl on Fri Mar 08 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "UVEHelper.h"

#import "UVColorEditor.h"
#import "UVCurveEditor.h"
#import "UVImageEditor.h"

static	NSString *UVEHNumberEditor	= @"NumberEditor";
static	NSString *UVEHBoolEditor	= @"BoolEditor";
static	NSString *UVEHColorEditor	= @"ColorEditor";
static	NSString *UVEHCurveEditor	= @"CurveEditor";
static	NSString *UVEHGradientEditor	= @"GradientEditor";
static	NSString *UVEHImageEditor	= @"ImageEditor";

@implementation UVEHelper

+ (UVEHelper *)globalHelper 
{
    static UVEHelper *_globalHelper = nil;

    if (!_globalHelper) {
        _globalHelper = [[self alloc] init];
    }
    return _globalHelper;
}

- (id)init 
{
    self = [super init];
    if (self) {
        [NSBundle loadNibNamed:@"UVEditors" owner:self];
        
        // NSLog(@"XX editor = %@ [%d]", curveEditor, [gradientEditor retainCount]);
        
        [curveEditor configureForCurve];
        [gradientEditor configureForGradient];
        [imageEditor configureForImage];
        
        _encodedEditors = [[NSDictionary alloc] 
            initWithObjectsAndKeys:
            [NSArchiver archivedDataWithRootObject:numberEditor], 
                UVEHNumberEditor, 
            [NSArchiver archivedDataWithRootObject:boolEditor], 
                UVEHBoolEditor, 
            [NSArchiver archivedDataWithRootObject:colorEditor], 
                UVEHColorEditor, 
            [NSArchiver archivedDataWithRootObject:curveEditor], 
                UVEHCurveEditor, 
            [NSArchiver archivedDataWithRootObject:gradientEditor], 
                UVEHGradientEditor, 
            [NSArchiver archivedDataWithRootObject:imageEditor], 
                UVEHImageEditor, 
            nil];
    }
    return self;
}

- (UVEditor *)numberEditor { 
    return [NSUnarchiver unarchiveObjectWithData:
        [_encodedEditors objectForKey:UVEHNumberEditor]]; 
}

- (UVEditor *)boolEditor { 
    return [NSUnarchiver unarchiveObjectWithData:
        [_encodedEditors objectForKey:UVEHBoolEditor]]; 
}

- (UVEditor *)colorEditor { 
    return [NSUnarchiver unarchiveObjectWithData:
        [_encodedEditors objectForKey:UVEHColorEditor]]; 
}

- (UVEditor *)curveEditor { 
    return [NSUnarchiver unarchiveObjectWithData:
        [_encodedEditors objectForKey:UVEHCurveEditor]]; 
}

- (UVEditor *)gradientEditor { 
    return [NSUnarchiver unarchiveObjectWithData:
        [_encodedEditors objectForKey:UVEHGradientEditor]]; 
}

- (UVEditor *)imageEditor { 
    return [NSUnarchiver unarchiveObjectWithData:
        [_encodedEditors objectForKey:UVEHImageEditor]]; 
}

@end
