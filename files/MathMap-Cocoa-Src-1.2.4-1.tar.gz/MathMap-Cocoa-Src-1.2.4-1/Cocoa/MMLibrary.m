//
//  MMLibrary.m
//
//  Created by Herbert Pötzl on Mon Mar 25 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA



#import "MMLibrary.h"
// #import "MMLibraryToolbar.h"
#import "UserDefaults.h"

#import "MMArchive.h"
#import "MMTreeNode.h"
#import "MMNodeData.h"

#import "MMOutlineView.h"
#import "ImageAndTextCell.h"
#import "MMSplitView.h"

#import "NSExtensions.h"
#import "DragAndDrop.h"
#import "PropertyList.h"


#define	LIBRARY_MINSIZE		100
#define	LIBINFO_MINSIZE		78





@interface MMLibrary (Private)

- (void)_updateSelectionInfo;

@end

@implementation MMLibrary


+ (void)initialize{

    [[NSUserDefaults standardUserDefaults] 
        registerDefaults:[NSDictionary
        dictionaryWithObjectsAndKeys:
            NSStringFromSize(
                NSMakeSize(LIBINFO_MINSIZE, LIBINFO_MINSIZE)),
            LibraryCommentSizeDefault,
            LibraryPathDValue, LibraryPathDefault,
            nil]];
}

- (id)init {
    self = [super init];
    if (self) {
        _dataFromFile = nil;
    }
    return self;
}

- (void)dealloc {
    [_dataFromFile release];
    [super dealloc];
}


+ (MMLibrary *)sharedLibrary {
    NSDocumentController *docController =
        [NSDocumentController sharedDocumentController];
    NSEnumerator *docEnum = [[docController 
            documents] objectEnumerator];
    NSDocument *document = nil;
    NSString *filePath = nil;
    
    while((document = [docEnum nextObject])) {
        if ([document isKindOfClass:[MMLibrary class]]) {
            if ([(MMLibrary *)document isMainLibrary])
                break;
        }
    }
    if (!document) {
        NSString *dirPath;
        BOOL exists, result, isDirectory;
        
        filePath = [[[NSUserDefaults standardUserDefaults] 
            stringForKey:LibraryPathDefault]
            stringByStandardizingPath];
        dirPath = [filePath 
            stringByDeletingLastPathComponent];
        exists = [[NSFileManager defaultManager] 
            fileExistsAtPath:filePath 
            isDirectory:&isDirectory];

        // NSLog(@"File %@ => %d,%d", filePath, exists, isDirectory);

        if (exists) {
            document = [docController 
                makeDocumentWithContentsOfFile:filePath
                ofType:@"MathMap Library"];
        } 
        if (!document) {
            result = [[NSFileManager defaultManager] 
                createDirectoryAtPath:dirPath 
                attributes:nil];
            // NSLog(@"Create Dir %@ => %d", dirPath, result);
            result = [[NSFileManager defaultManager] 
                copyPath:[[NSBundle mainBundle] 
                    pathForResource:@"DefaultLibrary" 
                    ofType:@"mml"] 
                toPath:filePath handler:nil];
            // NSLog(@"Copy Default %@ => %d", filePath, result);
            
			// NSLog(@"filePath %@", filePath);

			document = [docController 
                makeDocumentWithContentsOfFile:filePath
                ofType:@"MathMap Library"];
        }
		// NSLog(@"mainLibrary %@", document);
        [(MMLibrary *)document makeMainLibrary];
        [document makeWindowControllers];
        [docController addDocument:document];
    }
    return (MMLibrary *)document;
}


- (NSString *)windowNibName 		{ return @"MMLibrary"; }

- (void)synchronize {
    [self _updateSelectionInfo];
    [nodeArchive setSimpleOutline:YES];
    [simpleButton setState:0];
    [self toggleSimple:simpleButton];
    // [outlineView reloadData];
}

- (void)windowControllerWillLoadNib:(NSWindowController *)aController {
	[aController setShouldCascadeWindows:NO];
}

- (void)windowControllerDidLoadNib:(NSWindowController *)aController {
    NSTableColumn *tableColumn;
    ImageAndTextCell *cell;
    
    [super windowControllerDidLoadNib:aController];
//    [self setupToolbar];

    [documentWindow setFrameUsingName: @"MMLibraryWindow"];
    [documentWindow setFrameAutosaveName: @"MMLibraryWindow"];
//    [documentWindow setShowsResizeIndicator:NO];
    [documentWindow useOptimizedDrawing:YES];

    _splitDefaultsDone = NO;

    tableColumn = [outlineView 
        tableColumnWithIdentifier: LibraryDataColumn];
    cell = [[[ImageAndTextCell alloc] init] autorelease];
    [cell setEditable:YES];
    [cell setImage:[NSImage imageNamed:@"MysteryIcon"]];
    [cell setWraps:NO];
    [cell setFont: [NSFont labelFontOfSize:11.0]];
    [tableColumn setDataCell:cell];

/*
    [nodeArchive setRootNode:[MMTreeNode 
        treeFromDictionary:[NSDictionary 
            dictionaryWithContentsOfFile: [[NSBundle mainBundle] 
                pathForResource:@"LibTest" ofType: @"mml"]]]];
    [nodeArchive setSimpleOutline:YES];
*/

    if (_dataFromFile) {
        [nodeArchive setRootNode:[MMTreeNode 
            treeFromPropertyList:[_dataFromFile propertyList]]];
        [self synchronize];
	[_dataFromFile autorelease];
	_dataFromFile = nil;
    }


    [outlineView registerForDraggedTypes:
        [NSArray arrayWithObjects:
            NodeDragPboardType, 
            NSStringPboardType, 
            NSFilenamesPboardType, 
            nil]];
    [outlineView setVerticalMotionCanBeginDrag:YES];
    [outlineView setAutoresizesOutlineColumn:NO];
    
    [descTextView setHorizontallyResizable:NO];
    [[descTextView textContainer] setWidthTracksTextView:NO];

    [[infoScrollView verticalScroller] 
        setArrowsPosition:NSScrollerArrowsNone];
    [infoScrollView setFrame:[infoScrollView frame]];

    [self synchronize];
}

- (NSData *)dataRepresentationOfType:(NSString *)aType {
    // NSLog(@"data rep for %@", aType);
    if ([aType isEqual:@"MathMap Library"]) {
        return [NSData 
            dataWithPropertyList:[nodeArchive rootNode]];
    }
    return nil;
}

- (BOOL)loadDataRepresentation:(NSData *)data 
    ofType:(NSString *)aType {
    // NSLog(@"load data for %@", aType);
    if ([aType isEqual:@"MathMap Library"]) {
		if (nodeArchive) {
            [nodeArchive setRootNode:[MMTreeNode 
                treeFromPropertyList:[data propertyList]]];
            [self synchronize];
		} else {
			_dataFromFile = [data retain];
		}
		return YES;
    }
    return NO;
}


- (void)_updateSelectionInfo {
    NSArray *selection = [outlineView allSelectedItems];
    
    if ([selection count] == 0) {
        _infoSelection = nil;
        [selTextField setStringValue:@"Empty Selection"];
        [descTextView setString:@" "];
        [infoTabView selectTabViewItemWithIdentifier:@"Selection"];
    } else if ([selection count] == 1) {
        _infoSelection = [selection lastObject];
        [descTextView setString:[_infoSelection overview]];
        [infoTextView replaceCharactersInRange:
            NSMakeRange(0, [[infoTextView string] length]) 
            withRTF:[_infoSelection infoRTF]];
        [infoTextView setNeedsDisplay:YES];
        [infoTabView selectTabViewItemWithIdentifier:@"Comment"];
    } else {
        _infoSelection = nil;
        [descTextView setString:[NSString
            stringWithFormat:@"Selection of %d items.", 
                [selection count]]];
        [selTextField setStringValue:@"Multiple Selection"];
        [infoTabView selectTabViewItemWithIdentifier:@"Selection"];
    }
}

-(IBAction)toggleSimple:(id)sender {
    BOOL isSimple = ![sender state];
    
    [simpleButton setImage:[NSImage 
        imageNamed:(isSimple)?@"SimpleSIcon":@"CompositeSIcon"]];
    [simpleButton setAlternateImage:[NSImage
        imageNamed:(isSimple)?@"SimpleSAIcon":@"CompositeSAIcon"]];
    [nodeArchive setSimpleOutline:isSimple];
    [outlineView reloadData];
}


-(void)makeMainLibrary {
	_isMainLibrary = YES; 
    [documentWindow setFrameUsingName: @"MainLibraryWindow"];
    [documentWindow setFrameAutosaveName: @"MainLibraryWindow"];
}

-(BOOL)isMainLibrary		{ return _isMainLibrary; }


@end


@implementation MMLibrary (OutlineViewDelegate)

- (void)outlineViewSelectionDidChange:(NSNotification *)notification {
    [self _updateSelectionInfo];
}

- (void)outlineView:(NSOutlineView *)olv 
    willDisplayCell:(NSCell *)cell 
    forTableColumn:(NSTableColumn *)tableColumn 
    item:(id)item {    
    if ([[tableColumn identifier] 
        isEqualToString: LibraryDataColumn]) {
        NSColor *textColor;
        
	[(ImageAndTextCell*)cell 
            setImage:[NODEDATA(item) icon]];
        if (![NODEDATA(item) isValid])
            textColor = [NSColor redColor];
		else if ([cell isHighlighted]) {
			textColor = [NSColor whiteColor];
        } else if ([NODEDATA(item) isLocked]) {
            textColor = [NSColor brownColor];
        } else {
            textColor = [NSColor blackColor];
        }
	[(ImageAndTextCell*)cell setTextColor:textColor];
    }
}

@end

@implementation MMLibrary (TextViewDelegate)

- (void)textDidChange:(NSNotification *)aNotification {
    if (_infoSelection) {
        [_infoSelection setInfoRTF:        
            [infoTextView RTFFromRange:
                NSMakeRange(0, [[infoTextView string] length])]];
    }
    [self updateChangeCount:NSChangeDone];
}

@end




@implementation MMLibrary (SplitViewDelegate)


- (float)mmsplitView:(MMSplitView *)sender 
    constrainSplitPosition:(float)proposedPosition 
    ofSubviewAt:(int)offset {
    NSRect boundsRect = [sender bounds];

#if 0	/* vertical */
    float limit = NSWidth(boundsRect) - 
        (LIBINFO_MINSIZE + [sender dividerThickness]);
#else
    float limit = NSHeight(boundsRect) - 
        (LIBINFO_MINSIZE + [sender dividerThickness]);
#endif 
    float collapse = limit + LIBINFO_MINSIZE/2;
    
    if (proposedPosition < LIBRARY_MINSIZE) {
        return LIBRARY_MINSIZE;
    } else if (proposedPosition > limit) {
        if (proposedPosition > collapse) {
#if 0	/* vertical */
            return NSWidth(boundsRect) - 
                [sender dividerThickness];
#else
            return NSHeight(boundsRect) - 
                [sender dividerThickness];
#endif 
        } else {
            return limit;
        }
    }
    return proposedPosition;
}

- (void)mmsplitView:(MMSplitView *)sender 
    resizeSubviewsWithOldSize:(NSSize)oldSize {
    NSRect dividerRect;
    NSRect firstRect = [firstSubview frame];
    NSRect secondRect = [secondSubview frame];
    NSRect boundsRect = [sender bounds];

    if (!_splitDefaultsDone) {
    	secondRect.size = NSSizeFromString(
            [[NSUserDefaults standardUserDefaults] 
                stringForKey:LibraryCommentSizeDefault]);
        if (NSHeight(secondRect) < LIBINFO_MINSIZE)
            secondRect.size.height = 0;
        firstRect.size.height = NSHeight(boundsRect) -
            (NSHeight(secondRect) + [sender dividerThickness]);
        _splitDefaultsDone = YES;
    }

#if 0	/* vertical */
    if (NSWidth(secondRect) == 0) {
        NSDivideRect(boundsRect, &dividerRect, &firstRect,
            [sender dividerThickness], NSMaxXEdge);
        secondRect.origin.x = NSMaxX(boundsRect);
    } else if ((NSWidth(boundsRect) - NSWidth(firstRect)) < 
        (LIBINFO_MINSIZE + [sender dividerThickness])) {
        NSDivideRect(boundsRect, &secondRect, &firstRect, 
            LIBINFO_MINSIZE, NSMaxXEdge);
        NSDivideRect(firstRect, &dividerRect, &firstRect, 
            [sender dividerThickness], NSMaxXEdge);
    } else {
        NSDivideRect(boundsRect, &firstRect, &secondRect, 
            NSWidth(firstRect), NSMinXEdge);
        NSDivideRect(secondRect, &dividerRect, &secondRect, 
            [sender dividerThickness], NSMinXEdge);
    }
#else 
    if (NSHeight(secondRect) < LIBINFO_MINSIZE/2) {
        NSDivideRect(boundsRect, &dividerRect, &firstRect,
            [sender dividerThickness], NSMaxYEdge);
        secondRect.origin.y = NSMaxY(boundsRect);
        secondRect.size.height = 0;
    } else if (NSHeight(firstRect) < LIBRARY_MINSIZE) {
        NSDivideRect(boundsRect, &firstRect, &secondRect, 
            LIBRARY_MINSIZE, NSMinYEdge);
        NSDivideRect(secondRect, &dividerRect, &secondRect, 
            [sender dividerThickness], NSMinYEdge);
    } else {
        NSDivideRect(boundsRect, &secondRect, &firstRect, 
            NSHeight(secondRect), NSMaxYEdge);
        NSDivideRect(firstRect, &dividerRect, &firstRect, 
            [sender dividerThickness], NSMaxYEdge);
    }
#endif

    [secondSubview setFrame:secondRect];
    [firstSubview setFrame:firstRect];

    [[NSUserDefaults standardUserDefaults]
        setObject:NSStringFromSize(secondRect.size) 
        forKey:LibraryCommentSizeDefault];
}



@end


@implementation MMLibrary (ArchiveDelegate)

- (void)archiveContentsDidChange:(id)sender {
    [self updateChangeCount:NSChangeDone];
}

@end


