//
//  MMImageView.m
//
//  Created by Herbert Pötzl on Fri Mar 29 2002.
//  Copyright (c) 2002-2008 Herbert Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMImageView.h"

#import "MMExpression.h"
#import "MMInvocation.h"
#import "NSExtensions.h"


@implementation MMImageView

- (BOOL)isFlipped 		{ return YES; }

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
//    [coder encodeConditionalObject:_target];
//    [coder encodeValueOfObjCType:@encode(SEL) at:&_action];
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
//    _target = [coder decodeObject];
//    [coder decodeValueOfObjCType:@encode(SEL) at:&_action];
    return self;
}



- (void)drawRect:(NSRect)rect {
    NSRectClip(rect);

    [[NSColor checkerBoard] set];
    NSRectFill([self bounds]);

    if ([self inLiveResize]) {
        NSSize size = [_activeRep size];
        [_activeImage drawInRect:[self bounds] 
            fromRect:NSMakeRect(0,0, size.width, size.height) 
            operation:NSCompositeSourceOver
            fraction: 1.0];
    } else {
        NSSize size = [_activeRep size];
        [_activeImage drawInRect:[self bounds] 
            fromRect:NSMakeRect(0,0, size.width, size.height) 
            operation:NSCompositeSourceOver
            fraction: 1.0];
    }
}


- (void)enableRefreshTimer {
    if (_refreshTimer && ![_refreshTimer isValid]) {
        [_refreshTimer release];
        _refreshTimer = nil;
    }
    if (!_refreshTimer) {
        _refreshTimer = [[NSTimer 
            scheduledTimerWithTimeInterval:_refreshInterval 
            target:self selector:@selector(refresh:) 
            userInfo:nil repeats:YES] retain];
    
        [[NSRunLoop currentRunLoop] addTimer:_refreshTimer 
            forMode:NSModalPanelRunLoopMode];
        [[NSRunLoop currentRunLoop] addTimer:_refreshTimer 
            forMode:NSEventTrackingRunLoopMode];
    }
}

- (void)disableRefreshTimer {
    if (_refreshTimer) {
        if ([_refreshTimer isValid])
            [_refreshTimer invalidate];
        [_refreshTimer release];
        _refreshTimer = nil;
    }
}

- (void)updateRenderedRects {
    if ([[self window] isMiniaturized]) {
            // what else is required?
        [[self window] setMiniwindowImage:_activeImage];
    } else {
        if (_invocation) {
			while (1) {
				NSRect rect = [_invocation nextRectFinished];
				if (NSEqualRects(rect, NSZeroRect))
					break;
                [self setNeedsDisplayInRect:rect];
			}
        } else {
//            NSLog(@"NO INVOCATION ...");
        }
    }
}


- (void)updateActive:(BOOL)copy {
	[_activeRep release];
	[_activeImage release];
	if (copy) {
		_activeRep = [_renderRep copy];
		_activeImage = [_renderImage copy];
	} else {
		_activeRep = [_renderRep retain];
		_activeImage = [_renderImage retain];
	}
	_isActive = YES;
}

- (BOOL)launchInvocation {
	[_invocation release];
	_invocation = nil;
	
	if (!_expression)
		return NO;

    _invocation = [[MMInvocation alloc] 
		initWithExpression:_expression
		userValues:_userValues
		bitmapImageRep:_renderRep];
    
	// NSLog(@"INVOCATION (%p)", _invocation);
	
	if (!_invocation)
		return NO;

	_isRendering = YES;
	[_invocation setTimeValue:_timeValue];
	[_invocation setSupersampling:_flags.supersampling];
	[_invocation setAntialiasing:_flags.antialiasing];
	[_invocation renderThreaded:YES];
	[self enableRefreshTimer];
	return YES;
}




- (void)adjustRenderImage:(NSSize)size {
    if (0 && [self inLiveResize])
		return;

    _renderImage = [[NSImage alloc] initWithSize:size];
    [_renderImage setDataRetained:YES];
    [_renderImage setFlipped:YES];
    _renderRep = [[NSBitmapImageRep alloc]
		initWithBitmapDataPlanes:NULL 
		pixelsWide:size.width
		pixelsHigh:size.height 
		bitsPerSample:8 samplesPerPixel:4 
		hasAlpha:YES isPlanar:NO 
		colorSpaceName:NSCalibratedRGBColorSpace 
		bitmapFormat:NSAlphaNonpremultipliedBitmapFormat
		bytesPerRow:0 bitsPerPixel:0];
	// NSLog(@"adjustRenderImage: %fx%f", size.width, size.height);
    [_renderImage addRepresentation:_renderRep];
}

- (void)viewWillStartLiveResize {
	// NSLog(@"startLiveResize");
	[self stop];
}

- (void)viewDidEndLiveResize {
	// NSLog(@"endLiveResize");
    [self adjustRenderImage:[self frame].size];
    [self rescheduleExpression:_expression
        userValues:_userValues];
}

- (void)refresh:(NSTimer *)aTimer {
	if (!_syncOnFrame)
		[self updateRenderedRects];

	//NSLog(@"refresh R=%d", _isRendering, _needsRestart);

	if (!_invocation || [_invocation hasFinished])
		_isRendering = NO;

	if (!_isRendering) {
		[self disableRefreshTimer];
		if (![self inLiveResize]) {
			[self updateActive:YES];
			[self setNeedsDisplay:YES];
			if (_needsRestart) {
				//NSLog(@"restarting ...");
				[_userValues release];
				_userValues = _nextUserValues;
				_nextUserValues = nil;
				_needsRestart = NO;
				[self launchInvocation];
			}
		}
	}
}





- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _renderImage = nil;
        _renderRep = nil;

        _activeImage = nil;
        _activeRep = nil;
        _isActive = NO;

        _needsRestart = NO;
        _isRendering = NO;
        _syncOnFrame = YES;

        _expression = nil;
        _invocation = nil;
        _userValues = nil;
    
        _timeValue = 0.0;
        _refreshTimer = nil;
        _refreshInterval = 0.01;
        _flags.supersampling = NO;
        _flags.antialiasing = NO;
    }
    return self;
}

- (void)setFrame:(NSRect)frameRect
{
    [super setFrame:frameRect];
	if (![self inLiveResize]) {
		[self adjustRenderImage:frameRect.size];
		[self rescheduleExpression:_expression
			userValues:_userValues];
	}
}


-(BOOL)scheduleExpression:(MMExpression *)expression
    userValues:(NSArray *)userValues {
    // NSLog(@"SCHEDULE (%p,%p)", expression, userValues);
	[self stop];
    [expression retain];
    [_expression release];
    _expression = expression;
    [userValues retain];
    [_userValues release];
    _userValues = userValues;
	[_nextUserValues release];
	_nextUserValues = nil;
	_needsRestart = NO;
    return [self launchInvocation];
}    
    
-(BOOL)rescheduleExpression:(MMExpression *)expression
    userValues:(NSArray *)userValues {
    // NSLog(@"RESCHEDULE (%p,%p)", expression, userValues);
    if ([_expression isEqual:expression]) {
		[userValues retain];
		if (_isRendering) {
			[_nextUserValues release];
			_nextUserValues = userValues;
			_needsRestart = YES;
			return YES;
		} else {
			[_userValues release];
			_userValues = userValues;
			return [self launchInvocation];
		}
	}
	return [self scheduleExpression:expression 
		userValues:userValues];
}    
    

-(void)stop{
    if (_invocation && [_invocation isRunning]) {
        [_invocation stop];
		[self disableRefreshTimer];
		_isRendering = NO;
    }
}    
    
-(void)stopAfterFrame {
}    
    


-(void)setSyncOnFrame:(BOOL)flag 	{ _syncOnFrame = flag; }
-(BOOL)syncsOnFrame					{ return _syncOnFrame; }    
    
- (void)setSupersampling:(BOOL)flag	{ _flags.supersampling = flag; }
- (void)setAntialiasing:(BOOL)flag	{ _flags.antialiasing = flag; }


-(void)setRefreshInterval:(NSTimeInterval)interval {
    
}    
    

-(NSTimeInterval)refreshInterval	{ return _refreshInterval; }
    


-(float)progress {
    return 0.0;
}    
    
-(NSImage *)image					{ return _activeImage; }
-(NSImage *)renderImage				{ return _renderImage; }

-(IBAction)takeFloatFrom:(id)sender {
    _timeValue = [sender floatValue];
	
	[self rescheduleExpression:_expression
        userValues:_userValues];
}


@end
