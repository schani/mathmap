//
//  MMDocument.h
//
//  Created by Herbert P�tzl on Wed Mar 06 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import <Cocoa/Cocoa.h>

#import "MMUVView.h"
#import "AuxHelper.h"


extern	NSString *	ExpressionChangedNotification;


@class MMExpression, MMArchive, MMOutlineView, MMDragField;

@interface MMDocument : NSDocument
{
@private
    NSTimer *_checkTimer;
    NSData *_dataFromFile;		

    IBOutlet NSWindow 		*documentWindow;

    IBOutlet MMArchive 		*nodeArchive;
    IBOutlet MMOutlineView 	*outlineView;

    IBOutlet NSTextView 	*expressionTextView;
    IBOutlet NSScrollView 	*expressionScrollView;
    IBOutlet NSTextField	*expressionInfoField;
    IBOutlet MMDragField	*expressionDragField;
    
    IBOutlet MMUVView	 	*userValueView;
    IBOutlet NSTextField	*userValueInfoField;
    IBOutlet MMDragField	*userValueDragField;

    AuxHelper *_auxHelper;
    MMExpression *_expression;				/* remove? */
    NSArray *_userValues;				/* remove? */
//    BOOL _userValuesInvalid;
    BOOL _expressionChanged;
    
}

- (void)setExpression:(MMExpression *)expression;
- (MMExpression *)currentExpression;

- (void)setUserValues:(NSArray *)userValues;
- (NSArray *)currentUserValues;

@end




