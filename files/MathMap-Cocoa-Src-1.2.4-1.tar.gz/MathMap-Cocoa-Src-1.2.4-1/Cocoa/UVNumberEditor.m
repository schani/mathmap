//
//  UVNumberEditor.m
//
//  Created by Herbert P�tzl on Fri Mar 08 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "UVNumberEditor.h"


@implementation UVNumberEditor

- (void)configureForInt {
    _type = MMIntUserValueType;
}

- (void)configureForFloat {
    _type = MMFloatUserValueType;
}

- (MMUserValueType)type			{ return _type; }

- (void)synchronize			
{ 
    [editorSlider setMinValue:[_userValue minValue]];
    [editorStepper setMinValue:[_userValue minValue]];
    [editorSlider setMaxValue:[_userValue maxValue]];
    [editorStepper setMaxValue:[_userValue maxValue]];
    [editorSlider setNumberOfTickMarks:[_userValue numberOfTickMarks]];
    [super synchronize];
}

- (void)update
{
    [editorSlider setFloatValue:[_userValue floatValue]];
    [editorStepper setFloatValue:[_userValue floatValue]];
    [editorTextField setFloatValue:[_userValue floatValue]];
    [super update];
}

@end


@implementation UVNumberEditor (Modification)

- (IBAction)takeFloatValueFrom:(id)sender
{
    [_userValue setFloatValue:[sender floatValue]];
    [self modified];
}

@end


@implementation UVNumberEditor (NSCoding)

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
    [coder encodeConditionalObject:editorTextField];
    [coder encodeConditionalObject:editorStepper];
    [coder encodeConditionalObject:editorSlider];
    [coder encodeValueOfObjCType:@encode(MMUserValueType) at:&_type];
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    editorTextField = [[coder decodeObject] retain];
    editorStepper = [[coder decodeObject] retain];
    editorSlider = [[coder decodeObject] retain];
    [coder decodeValueOfObjCType:@encode(MMUserValueType) at:&_type];
    return self;
}

@end

