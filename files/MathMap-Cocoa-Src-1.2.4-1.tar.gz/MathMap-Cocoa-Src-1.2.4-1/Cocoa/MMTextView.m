//
//  MMTextView.m
//
//  Created by Herbert P�tzl on Sat Mar 30 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMTextView.h"

#import "DragAndDrop.h"

@implementation MMTextView


- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
/*
        _acceptedTypes = [[NSArray
            arrayWithObjects:
                ExpressionPboardType, 
                nil]];
*/                
        [self registerForDraggedTypes: 
            [NSArray arrayWithObjects:
                ExpressionPboardType, 
                nil]];

    }
    return self;
}

@end

@implementation MMTextView (DragAndDrop)


- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender {
    NSPasteboard *pboard = [sender draggingPasteboard];
    
    if ([[pboard types] 
        indexOfObject:ExpressionPboardType] != NSNotFound) {
//        NSLog(@"private entered ...");
        return NSDragOperationPrivate;
    }
//    NSLog(@"generic entered ...");
    return [super draggingEntered:sender];
}

- (NSDragOperation)draggingUpdated:(id <NSDraggingInfo>)sender {
    NSPasteboard *pboard = [sender draggingPasteboard];
    
    if ([[pboard types] 
        indexOfObject:ExpressionPboardType] != NSNotFound) {
//        NSLog(@"private updated ...");
        return NSDragOperationPrivate;
    }
//    NSLog(@"generic updated ...");
    return [super draggingUpdated:sender];
}

- (void)draggingExited:(id <NSDraggingInfo>)sender {
//    NSLog(@"generic exited ...");
    [super draggingExited:sender];
}

/*
- (BOOL)prepareForDragOperation:(id <NSDraggingInfo>)sender 
    NSPasteboard *pboard = [sender draggingPasteboard];
    
    if ([[pboard types] 
        indexOfObject:NodeDragPboardType] != NSNotFound) {
        return [delegate prepareForDragOperation:sender];
    } 
    return [super prepareForDragOperation:sender];
}
*/

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender {
    NSPasteboard *pboard = [sender draggingPasteboard];
    
    if ([[pboard types] 
        indexOfObject:ExpressionPboardType] != NSNotFound) {
//        NSLog(@"private perform ...");
        return [[self delegate] performDragOperation:sender];
    } 
//    NSLog(@"generic perform ...");
    return [super performDragOperation:sender];
}

- (void)concludeDragOperation:(id <NSDraggingInfo>)sender {
    NSPasteboard *pboard = [sender draggingPasteboard];
    
    if ([[pboard types] 
        indexOfObject:ExpressionPboardType] != NSNotFound) {
//        NSLog(@"private conclude ...");
        [[self delegate] concludeDragOperation:sender];
        return;
    } 
//    NSLog(@"generic conclude ...");
    [super concludeDragOperation:sender];
}


@end

