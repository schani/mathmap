//
//  MMArchive.h
//
//  Created by Herbert Pötzl on Tue Mar 26 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import <Cocoa/Cocoa.h>


extern NSString *	LibraryDataColumn;
// extern NSString *	NodeDragPboardType;


@class MMTreeNode;

@interface MMArchive : NSObject
{
@private
    IBOutlet id delegate;

    MMTreeNode *	_rootNode;
    NSArray *		_draggedNodes;
    BOOL		_simpleOutline;
}

- (void)setRootNode:(MMTreeNode *)node;
- (MMTreeNode *)rootNode;

- (void)removeNodes:(NSArray *)nodes;
- (void)insertNodes:(NSArray *)nodes
    atRow:(int)row;

- (void)addGroupNodeAfter:(MMTreeNode *)node;
- (void)addGroupNodeTo:(MMTreeNode *)node;

-(void)setSimpleOutline:(BOOL)flag;
-(BOOL)simpleOutline;

- (NSMutableDictionary *)rootNodeDictionary;

@end


@interface NSObject (ArchiveDelegate)

- (void)archiveContentsDidChange:(id)sender;

@end

#define	NODEDATA(i)	(MMNodeData *)[(i) nodeData]
#define SAFENODE(n) 	(TreeNode *)((n)?(n):(_rootNode))

