//
//  MMExpression.m
//
//  Created by Herbert Pötzl on Wed Mar 06 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <assert.h>

#import "MMExpression.h"
#import "MMInvocation.h"
#import "MMUserValue.h"

#import "tags.h"
#import "noise.h"
#import "drawable.h"
#import "cocoa.h"


@implementation MMExpression

+ (void)initialize {
    static BOOL firstTime = YES;

    if (firstTime) {
		init_builtins();
		init_tags();
		init_macros();
		init_noise();
		init_compiler();

		firstTime = NO;
    }
}

+ (id)expressionWithString:(NSString *)aString
{
    return [[[self alloc] initWithString: aString] autorelease];
}

+ (NSDictionary *)verifyExpressionString:(NSString *)aString
{
    if (check_mathmap((char *)[aString cString]))
		return nil;
    return [NSDictionary dictionaryWithObjectsAndKeys:
		[NSString stringWithCString: error_string], @"message",
		[NSNumber numberWithInt:0], @"start",
		[NSNumber numberWithInt:0], @"end", nil];
}

- (id)initWithString:(NSString *)aString
{
    self = [super init];
    if (self) {
        _expression = [aString retain];
        _mathmap = compile_mathmap_cocoa([_expression cString],
            [[[NSBundle mainBundle] 
                pathForResource:@"new_template" 
                ofType:@"c"] cString], 
			[[[NSBundle mainBundle] 
                pathForResource:@"opmacros" 
                ofType:@"h"] cString]);
		assert(_mathmap != 0);     
    }
    return self;
}

- (id)initWithData:(NSData *)data encoding:(MMExpressionEncoding)encoding
{
    return nil;
}


- (void) dealloc
{
    [_expression release];
    free_mathmap(_mathmap);
    [super dealloc];
}


- (NSString *)string	{ return _expression; }

- (BOOL)isEqual:(id)object {
    if ([object isKindOfClass:[self class]]) {
        return [[self string] isEqual:[object string]];
    } else return NO;
}

- (NSData *)dataUsingEncoding:(MMExpressionEncoding)encoding
{
    return nil;
}

- (MMInvocation *)invocationWithUserValues:(NSArray *)values
    bitmapImageRep:(NSBitmapImageRep *)imageRep {
    MMInvocation *invocation;

    invocation = [[MMInvocation alloc] 
        initWithExpression:self
        userValues:values
        bitmapImageRep:imageRep];
    return [invocation autorelease];
}


- (NSArray *)defaultUserValues
{
    NSMutableArray *values = [NSMutableArray arrayWithCapacity: 16];
    userval_info_t *info;

    for (info = _mathmap->main_filter->userval_infos; info != 0; info = info->next)
		[values addObject:[MMUserValue userValueWithCInfo:info]];
	// NSLog(@"default values=%@", values);
    return values;
}

- (NSArray *)userValuesWithProposedValues:(NSArray *)proposal {
    NSMutableArray *values = [NSMutableArray 
        arrayWithCapacity:[proposal count]];
    userval_info_t *info;

    for (info = _mathmap->main_filter->userval_infos; info != 0; info = info->next) {
        MMUserValue *oldValue;
	MMUserValue *value = [MMUserValue userValueWithCInfo:info];
        NSEnumerator  *enumerator = [proposal objectEnumerator];
        
        while ((oldValue = [enumerator nextObject]) != nil) {
            if (([oldValue type] == [value type]) &&
                ([[oldValue name] isEqual:[value name]])) {
                switch ([value type]) {
                case MMIntUserValueType:
                case MMFloatUserValueType:
                    [value setFloatValue:[oldValue floatValue]];
                    break;
                    
                case MMBoolUserValueType:
                    [value setBoolValue:[oldValue boolValue]];
                    break;
                    
                case MMColorUserValueType:
                    [value setColor:[oldValue color]];
                    break;
                    
                case MMCurveUserValueType:
                case MMGradientUserValueType:
                    [value setCurve:[oldValue curve]];
                    break;
                    
                case MMImageUserValueType:
                    [value setImage:[oldValue image]];
                    break;
                }
                break;
            }
        }
        [values addObject:value];
    }
    return values;
}

@end

#import "MMTreeNode.h"
#import "UserDefaults.h"

@implementation MMExpression (PropertyList)

- (id)propertyList {
    NSDictionary *dict = [NSDictionary 
        dictionaryWithObjectsAndKeys:
            [[NSUserDefaults standardUserDefaults] 
                stringForKey:ExpressionLabelDefault], 
            EntryNameKey,
            ExpressionEntryKind, EntryKindKey,
            _expression, ValueKey,
            nil];
    return dict;
}

@end

#import "MMNodeData.h"

@implementation MMTreeNode (ExpressionHelper)

- (void)addExpressionToArray:(NSMutableArray *)expArray {
    MMNodeData *data = (MMNodeData *)[self nodeData];
    
    if ([data type] == MMExpressionNodeType) {
        NSDictionary *dict = [data object];
        NSString *value = [dict objectForKey:ValueKey];
        [expArray addObject:value];
    }
}

@end
