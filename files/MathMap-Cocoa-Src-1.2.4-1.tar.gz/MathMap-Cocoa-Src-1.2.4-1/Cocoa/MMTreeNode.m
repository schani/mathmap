//
//  MMTreeNode.m
//
//  Created by Herbert Pötzl on Mon Mar 25 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMTreeNode.h"
#import "MMNodeData.h"
#import "NSExtensions.h"
#import "PropertyList.h"

NSString *GroupNameKey = 		@"Group";		
NSString *EntryNameKey = 		@"Name";		
NSString *EntryKindKey =		@"Kind";		
NSString *EntryDateKey =		@"Date";		
NSString *EntriesKey =			@"Children";		
NSString *InfoRTFKey =			@"Info";		

NSString *EntryPathKey =		@"Path";		
NSString *EntryDataKey =		@"Data";		
NSString *ValueTypeKey =		@"Type";		
NSString *ValueKey =			@"Value";		

NSString *LockedFlagKey =		@"Locked";		

NSString *ExpressionEntryKind =		@"Expression";
NSString *UserValueEntryKind =		@"UserValue";
NSString *UserValueSetEntryKind =	@"UserValueSet";
NSString *ReferenceEntryKind =		@"Reference";
NSString *ImageLinkEntryKind =		@"ImageLink";
NSString *UnknownEntryKind =		@"Unknown";



@implementation MMTreeNode

+ (NSString *)dateString {
    return [[NSDate date] description];
}

+ (NSData *)defaultInfoRTF {
    static NSData *defaultInfoRTF = nil;
    
    if (!defaultInfoRTF) {
        defaultInfoRTF = [[NSData dataWithContentsOfFile:
            [[NSBundle mainBundle] 
                pathForResource:@"DefaultInfo" 
                ofType: @"rtf"]] retain];
    }
    return defaultInfoRTF;
}

+ (NSDictionary *)valueFromDictionary:(NSDictionary *)dict {
    NSArray *badKeys = [NSArray arrayWithObjects:
        GroupNameKey, EntryNameKey, EntriesKey, nil];
    NSMutableDictionary *value = 
        [NSMutableDictionary dictionaryWithCapacity:4];
    NSEnumerator *keyEnum = [dict keyEnumerator];
    NSString *key;
    
    while ((key = [keyEnum nextObject])) {
        if ([badKeys indexOfObject:key] == NSNotFound) {
            [value setObject:[dict objectForKey:key] 
                forKey:key];
        }
    }
    if (![value objectForKey:EntryDateKey])
        [value setObject:[self dateString] forKey:EntryDateKey];
    return value;
}



+ (MMTreeNode *)groupNodeWithName:(NSString *)name {
    MMTreeNode *node = [[[MMTreeNode alloc] 
        initWithData:[MMNodeData 
            nodeWithName:name
            type:MMGroupNodeType
            object:[NSDictionary dictionaryWithObjectsAndKeys:
                name, GroupNameKey,
                [self dateString], EntryDateKey,
                nil]]
        parent:nil 
        children: [NSArray array]] 
        autorelease];
    return node;
}

+ (MMTreeNode *)referenceNodeWithPath:(NSString *)path {
    NSString *fullPath = [path stringByStandardizingPath];
    BOOL isImage = [[NSImage imageFileTypes] 
        containsObject:[fullPath pathExtension]];
    MMNodeData *data = [MMNodeData 
        nodeWithName:[[fullPath lastPathComponent] 
            stringByDeletingPathExtension]
        type:((isImage)?MMImageLinkNodeType:MMReferenceNodeType)
        object:[NSDictionary dictionaryWithObjectsAndKeys:
            ((isImage)?ImageLinkEntryKind:ReferenceEntryKind), 
                EntryKindKey,
            [self dateString], EntryDateKey,
            nil]];
    MMTreeNode *node = [[[MMTreeNode alloc] 
        initWithData:data
        parent:nil 
        children: [NSArray array]] 
        autorelease];
    [data setPath:fullPath];
    return node;
}

+ (MMTreeNode *)containerNodeWithProperty:(id)property {
    MMTreeNode *node = [[[MMTreeNode alloc] 
        initWithData:[MMNodeData 
            nodeWithName:@"Unlabeled"
            type:MMUnknownNodeType
            object:[NSDictionary dictionaryWithObjectsAndKeys:
                property, EntryDataKey,
                UnknownEntryKind, EntryKindKey,
                [self dateString], EntryDateKey,
                nil]]
        parent:nil 
        children: [NSArray array]] 
        autorelease];
    return node;
}


+ (MMTreeNode *)treeFromDictionary:(NSDictionary *)dict {
    return [[[MMTreeNode alloc] 
        initFromDictionary:dict] autorelease];
}

+ (MMTreeNode *)treeFromArray:(NSArray *)array {
    return [[[MMTreeNode alloc] 
        initFromDictionary:[NSDictionary
            dictionaryWithObjectsAndKeys:
                array, EntriesKey,
                GroupNameKey, GroupNameKey,
                [self dateString], EntryDateKey,
                nil
            ]] autorelease];
}

- (id)initFromDictionary:(NSDictionary *)dict {
    NSEnumerator *entryEnum = [[dict 
        objectForKey: EntriesKey] objectEnumerator];
    NSDictionary *value = [MMTreeNode valueFromDictionary:dict];
    MMNodeData *data;
    NSString *name, *path;
    
    if ((name = [dict objectForKey: GroupNameKey])) {
        data = [MMNodeData nodeWithName:name
            type:MMGroupNodeType
            object:value];
    } else {
        NSString *kind = [dict objectForKey: EntryKindKey];
        name = [dict objectForKey: EntryNameKey];
        path = [dict objectForKey: EntryPathKey];
        
        if ([kind isEqual:ExpressionEntryKind]) {
            data = [MMNodeData nodeWithName:name
                type:MMExpressionNodeType
                object:value];
        } else if ([kind isEqual:UserValueSetEntryKind]) {
            data = [MMNodeData nodeWithName:name
                type:MMUserValueSetNodeType
                object:value];
        } else if ([kind isEqual:UserValueEntryKind]) {
            data = [MMNodeData nodeWithName:name
                type:MMExpressionNodeType
                object:value];
        } else if ([kind isEqual:ImageLinkEntryKind]) {
            data = [MMNodeData nodeWithName:name
                type:MMImageLinkNodeType
                object:value];
            [data setPath:path];
        } else if ([kind isEqual:ReferenceEntryKind]) {
            data = [MMNodeData nodeWithName:name
                type:MMReferenceNodeType
                object:value];
            [data setPath:path];
        } else {
            data = [MMNodeData nodeWithName:name
                type:MMUnknownNodeType
                object:value];
        }
    }

    self = [super initWithData:data parent:nil 
        children:[NSArray array]];
    if (self) {
        id entry;
        while ((entry = [entryEnum nextObject])) {
            MMTreeNode *child = [MMTreeNode treeFromPropertyList: entry];
            [self insertChild: child atIndex:[self numberOfChildren]];
        }
        if ([[dict objectForKey: InfoRTFKey] 
            isKindOfClass: [NSString class]]) {
            _infoRTF = [[NSData RTFWithString:
                [dict objectForKey: InfoRTFKey]] retain];
        } else {
            _infoRTF = [[dict objectForKey: InfoRTFKey] retain];
        }
    }
    return self;
}

- (id) initFromExpressionDB: (expression_db_t*) edb
{
    NSString *name = [NSString stringWithCString: edb->name encoding: NSASCIIStringEncoding];
    NSMutableDictionary *value = [NSMutableDictionary dictionaryWithCapacity: 4];
    MMNodeData *data;

    [value setObject: [MMTreeNode dateString]
	      forKey: EntryDateKey];

    switch (edb->kind)
    {
	case EXPRESSION_DB_GROUP :
	    data = [MMNodeData nodeWithName: name
				       type: MMGroupNodeType
				     object: value];
	    break;

	case EXPRESSION_DB_EXPRESSION :
	{
	    char *expression = read_expression(edb->v.expression.path);
	
	    if (expression == NULL)
		break;
	
	    [value setObject: [NSString stringWithCString: expression
						 encoding: NSASCIIStringEncoding]
		      forKey: ValueKey];
	    [value setObject: ExpressionEntryKind forKey: EntryKindKey];
	
	    data = [MMNodeData nodeWithName: name
				       type: MMExpressionNodeType
				     object: value];

	    break;
	}
	    
	default :
	    NSAssert(FALSE, @"Illegal expression type");
    }
    
    self = [super initWithData: data
			parent: nil
		      children: [NSArray array]];

    if (!self)
	return nil;
    
    switch (edb->kind)
    {
	case EXPRESSION_DB_GROUP :
	{
	    expression_db_t *sub;
	    
	    for (sub = edb->v.group.subs; sub != NULL; sub = sub->next)
	    {
		MMTreeNode *child = [[[MMTreeNode alloc] initFromExpressionDB: sub] autorelease];
		
		[self insertChild: child
			  atIndex: [self numberOfChildren]];
	    }
	    
	    _infoRTF = [[NSData RTFWithString: @""] retain];
	    break;
	}

	case EXPRESSION_DB_EXPRESSION :
	{
	    char *docstring = get_expression_docstring(edb);
	    
	    if (docstring == NULL)
		docstring = "";

	    _infoRTF = [[NSData RTFWithString: [NSString stringWithCString: docstring
								  encoding: NSASCIIStringEncoding]]
			retain];
	    break;
	}

	default :
	    NSAssert(FALSE, @"Illegal expression type");
    }
    
    return self;
}

- (NSString *)description {
    return [[self propertyList] description];
}

- (NSString *)overview {
    MMNodeData *data = (MMNodeData *)[self nodeData];
    id dict = [data object];
    NSString *entryKind = [dict objectForKey:EntryKindKey];
    NSString *entryDate = [dict objectForKey:EntryDateKey];
    NSArray *flags = [NSArray array];
    NSString *desc = [NSString stringWithFormat:
        @"%@\t%@\n%@\t%@\n%@\t%@\n",
        @"Name:", [data name],
        @"Kind:", (entryKind)?entryKind:@"Group",
        @"Date:", (entryDate)?entryDate:@"Unknown"];
    BOOL lockedEntry = NO;
    
    if ([dict objectForKey:LockedFlagKey]) {
        flags = [flags arrayByAddingObject:@"Locked"]; 
        lockedEntry = YES;
    }
    if ([flags count]) {
        desc = [desc stringByAppendingFormat:@"%@\t%@\n",
            @"Flags:", [flags componentsJoinedByString:@", "]];
    }
    desc = [desc stringByAppendingFormat:@"%@\t%p\n",
        @"OID:", self];
    return desc;
}


- (void)setInfoRTF:(NSData *)info {
    [info retain];
    [_infoRTF release];
    _infoRTF = info;
}

- (NSData *)infoRTF {
    if (!_infoRTF) {
        return [MMTreeNode defaultInfoRTF];
    } 
    return _infoRTF;
}


@end
