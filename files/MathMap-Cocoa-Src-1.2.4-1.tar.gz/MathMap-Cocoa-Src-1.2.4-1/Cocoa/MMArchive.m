//
//  MMArchive.m
//
//  Created by Herbert Pötzl on Tue Mar 26 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import "MMArchive.h"

#import "MMTreeNode.h"
#import "MMNodeData.h"
#import "MMOutlineView.h"
#import "ImageAndTextCell.h"
#import "DragAndDrop.h"
#import "PropertyList.h"

NSString *	LibraryDataColumn 	 = @"LibraryColumn";

// NSString *	NodeDragPboardType 	 = @"NodeDragPboardType";


@implementation MMArchive

- (id)init {
    self = [super init];
    if (self) {
        _rootNode = [[MMTreeNode 
            groupNodeWithName:@"ROOT"] retain];
    }
    return self;
}

- (void)dealloc {
    [_rootNode release];
    // [_draggedNodes release];
    [super dealloc];
}

- (void)setDelegate:(id)object {
    [object retain];
    [delegate release];
    delegate = object;
}

- (id)delegate		{ return delegate; }

- (void)setRootNode:(MMTreeNode *)node {
    [node retain];
    [_rootNode release];
    _rootNode = node;
}

- (MMTreeNode *)rootNode 		{ return _rootNode; }

- (void)_informDelegate
{
    if ([delegate respondsToSelector:
        @selector(archiveContentsDidChange:)]) {
        [delegate archiveContentsDidChange:self];
    }
}

- (void)removeNodes:(NSArray *)nodes {
    NSEnumerator *nodesEnum = [nodes objectEnumerator];
    TreeNode *node = nil, *parent = nil;
    
    while ((node = [nodesEnum nextObject])) {
        parent = (TreeNode *)[node nodeParent];
        [parent removeChild: node];
    }
	[self _informDelegate];
}

- (void)insertNodes:(NSArray *)nodes
    atRow:(int)row {
    NSLog(@"not implemented ...");
}

- (void)addGroupNodeAfter:(MMTreeNode *)node {
	MMTreeNode *parent = (MMTreeNode *)[node nodeParent];
	int index = [parent indexOfChild:node] + 1;
	[parent insertChild:
		[[MMTreeNode groupNodeWithName:@"New Group"] retain]
		atIndex:index];
	[self _informDelegate];
}

- (void)addGroupNodeTo:(MMTreeNode *)node {
	int index = [node numberOfChildren];
	[node insertChild:
		[[MMTreeNode groupNodeWithName:@"New Group"] retain]
		atIndex:index];
	[self _informDelegate];
}


-(void)setSimpleOutline:(BOOL)flag	{ _simpleOutline = flag; }
-(BOOL)simpleOutline;			{ return _simpleOutline; }

- (NSMutableDictionary *)rootNodeDictionary { 
    id object = [NODEDATA(_rootNode) object]; 
    if ([object isKindOfClass:[NSMutableDictionary class]]) {
        return (NSMutableDictionary *)object;
    } else {
//        NSLog(@"badRootNodeClass: %@", [object className]);
        return [NSMutableDictionary dictionaryWithCapacity:4];
    }
}


@end

@implementation MMArchive (DataSource)

- (id)outlineView:(NSOutlineView *)view 
    child:(int)index 
    ofItem:(id)item {
    return [SAFENODE(item) childAtIndex:index];
}

- (BOOL)outlineView:(NSOutlineView *)view 
    isItemExpandable:(id)item {
    if (_simpleOutline) {
        return [NODEDATA(item) isGroup];
    } else {
        return ![NODEDATA(item) isLeaf];
    }
}

- (int)outlineView:(NSOutlineView *)view 
    numberOfChildrenOfItem:(id)item {
    return [SAFENODE(item) numberOfChildren];
}

- (id)outlineView:(NSOutlineView *)view 
    objectValueForTableColumn:(NSTableColumn *)tableColumn 
    byItem:(id)item {
    id objectValue = nil;
    
    if([[tableColumn identifier] 
        isEqualToString: LibraryDataColumn]) {
		objectValue = [NODEDATA(item) name];
    }
    return objectValue;
}

- (void)outlineView:(NSOutlineView *)view 
    setObjectValue:(id)object 
    forTableColumn:(NSTableColumn *)tableColumn 
    byItem:(id)item {
    if([[tableColumn identifier] 
        isEqualToString: LibraryDataColumn]) {
		[NODEDATA(item) setName: object];
    }
	[self _informDelegate];
}


- (void)outlineView:(NSOutlineView *)olv 
    willDisplayCell:(NSCell *)cell 
    forTableColumn:(NSTableColumn *)tableColumn 
    item:(id)item {    
    if ([[tableColumn identifier] isEqualToString: LibraryDataColumn]) {
		if (item && ![NODEDATA(item) icon]) {
			[NODEDATA(item) setIcon:[NSImage imageNamed:@"EmptyIcon"]];
		}
		[(ImageAndTextCell*)cell setImage:[NODEDATA(item) icon]];
    }
}

@end


@implementation MMArchive (DragAndDrop)

- (NSArray *)draggedNodes   	{ return _draggedNodes; }

- (BOOL)outlineView:(NSOutlineView *)olv 
    writeItems:(NSArray*)items 
    toPasteboard:(NSPasteboard*)pboard {
    NSMutableArray *expArray;
    _draggedNodes = items; 
    
    [pboard declareTypes:[NSArray 
        arrayWithObjects: 
            NodeDragPboardType,
            ExpressionPboardType,
	/*		NSFileContentsPboardType,
			NSStringPboardType,
            NSFilenamesPboardType, */
            nil] owner:self];

/*	NSFileWrapper *wrapper = [[NSFileWrapper alloc] 
		initRegularFileWithContents:[NSData 
			dataWithBytes:"12345" length:5]];
	[wrapper setPreferredFilename:[NODEDATA([items lastObject]) name]]; */

    [pboard setData:[NSData data] 
        forType:NodeDragPboardType]; 
    [pboard setString: [_draggedNodes description]
        forType: NSStringPboardType];
/*	[pboard setData:[wrapper data] forType:NSFileContentsPboardType]; */
	
/*     [pboard setPropertyList: 
		[NSArray arrayWithObject:@"hansi.mm"]
        forType: NSFilenamesPboardType];     */

    expArray = [NSMutableArray 
        arrayWithCapacity:[items count]];
    [_draggedNodes makeObjectsPerformSelector:
        @selector(addExpressionToArray:)
        withObject:expArray];
    [pboard setString: 
        [expArray componentsJoinedByString:@"\n\n"] 
        forType: ExpressionPboardType];
    return YES;
}

- (NSArray *)outlineView:(NSOutlineView *)olv  
	namesOfPromisedFilesDroppedAtDestination:(NSURL *)dropDestination  
	forDraggedItems:(NSArray *)items {
	return nil;
}

- (unsigned int)outlineView:(NSOutlineView*)olv 
    validateDrop:(id <NSDraggingInfo>)info 
    proposedItem:(id)item 
    proposedChildIndex:(int)childIndex {
    TreeNode *targetNode = item;
    BOOL targetNodeIsValid = YES;
    MMNodeData *nodeData = (MMNodeData*)[item nodeData];

    if ([nodeData isLeaf])
	targetNodeIsValid = NO;

    if (targetNodeIsValid && 
        ([info draggingSource] == olv) && 
        [[info draggingPasteboard] availableTypeFromArray:
        [NSArray arrayWithObject: NodeDragPboardType]] != nil) {
        NSArray *draggedNodes = [[[info draggingSource] dataSource] draggedNodes];
        targetNodeIsValid = ![targetNode isDescendantOfNodeInArray: draggedNodes];
    }
    [olv setDropItem:targetNode dropChildIndex:childIndex];    
    return targetNodeIsValid ? NSDragOperationGeneric : NSDragOperationNone;
}


- (NSArray *)_performDropOperation:(id <NSDraggingInfo>)info 
    onNode:(TreeNode*)parentNode 
    atIndex:(int)childIndex 
    oldSelection:(NSArray *)selection {
    NSPasteboard * pboard = [info draggingPasteboard];
    NSArray *itemsToSelect = nil;
    
    if ([pboard availableTypeFromArray:[NSArray 
        arrayWithObjects:NodeDragPboardType, nil]] != nil) {
        MMArchive *dragDataSource = [[info draggingSource] dataSource];
        NSArray *draggedNodes = [TreeNode 
            minimumNodeCoverFromNodesInArray: [dragDataSource draggedNodes]];
        NSEnumerator *draggedNodesEnum = [draggedNodes objectEnumerator];
        TreeNode *draggedNode = nil, *draggedNodeParent = nil;
	
        while ((draggedNode = [draggedNodesEnum nextObject])) {
            draggedNodeParent = (TreeNode *)[draggedNode nodeParent];
            if (parentNode == draggedNodeParent && 
                [parentNode indexOfChild: draggedNode]<childIndex) childIndex--;
            [draggedNodeParent removeChild: draggedNode];
        }
	itemsToSelect = selection;
        [[info draggingSource] reloadData];
        [parentNode insertChildren: draggedNodes atIndex: childIndex];
    } 
    else if ([pboard availableTypeFromArray:[NSArray 
        arrayWithObject: NSStringPboardType]]) {
        NSString *string = [pboard stringForType: NSStringPboardType];
	itemsToSelect = [MMTreeNode 
            nodesFromPropertyList:[string propertyList]];
	[parentNode insertChildren:itemsToSelect atIndex:childIndex++];
    } 
    else if ([pboard availableTypeFromArray:[NSArray 
        arrayWithObject: NSFilenamesPboardType]]) {
        id propertyList = [pboard 
            propertyListForType:NSFilenamesPboardType];
	itemsToSelect = [MMTreeNode 
            nodesFromPropertyList:propertyList];
	[parentNode insertChildren:itemsToSelect atIndex:childIndex++];
    }
    return itemsToSelect;
}

- (BOOL)outlineView:(NSOutlineView*)olv 
    acceptDrop:(id <NSDraggingInfo>)info 
    item:(id)targetItem 
    childIndex:(int)childIndex {
    TreeNode *parentNode = nil;
    NSArray *newSelection;
    
    if ([NODEDATA(targetItem) isLeaf]) {
        parentNode = (TreeNode *)
            ((childIndex==NSOutlineViewDropOnItemIndex) ? 
            [targetItem nodeParent] : targetItem);
        childIndex = ((childIndex==NSOutlineViewDropOnItemIndex) ? 
            [[targetItem nodeParent] indexOfChild: targetItem]+1 : 0);
        if ([NODEDATA(parentNode) isLeaf]) 
            [NODEDATA(parentNode) setIsLeaf:NO];
    } else {            
        parentNode = SAFENODE(targetItem);
		childIndex = ((childIndex==NSOutlineViewDropOnItemIndex) ?
            0 : childIndex);
    }
    
    newSelection = [self _performDropOperation:info 
        onNode:parentNode atIndex:childIndex
        oldSelection:[(MMOutlineView *)olv allSelectedItems]];
    [olv reloadData];
    [(MMOutlineView *)olv selectItems:newSelection 
        byExtendingSelection:NO];
	[self _informDelegate];
    return YES;
}

@end
