//
//  UVColorEditor.m
//
//  Created by Herbert P�tzl on Tue Mar 12 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "UVColorEditor.h"

// #import "MMColorWell.h"


@implementation UVColorEditor

- (MMUserValueType)type			{ return MMColorUserValueType; }

- (void)update
{
    float red, green, blue, alpha;
    int ired, igreen, iblue, ialpha;
    NSColor *color = [_userValue color];
    
    if (!color) color = 
        [[NSColor blackColor] 
            colorUsingColorSpaceName:NSDeviceRGBColorSpace];
    
    [color getRed:&red green:&green blue:&blue alpha:&alpha];
    ired = red*255.0;	igreen = green*255.0;
    iblue = blue*255.0;	ialpha = alpha*255.0;
    
    [editorColorWell setColor:color];
    [editorTextField setStringValue:
        [NSString stringWithFormat:@"#%02X%02X%02X,%02X",
            ired, igreen, iblue, ialpha]];
    [super update];
}

@end


@implementation UVColorEditor (Modification)

- (NSColor *)colorWithString:(NSString *)string {
    unsigned value[4];
    float red = 0, green = 0, blue = 0, alpha = 0;
    int mask = 0;
    int index;
    
    NSScanner *scanner = [NSScanner 
        scannerWithString:string];
    NSCharacterSet *charSet = [NSCharacterSet
        characterSetWithCharactersInString:
            @"0123456789ABCDEF"];
    [scanner setCharactersToBeSkipped:[charSet invertedSet]];
    [scanner setCaseSensitive:NO];
    
    for (index=0; index<4; index++) {
        mask |= [scanner scanHexInt:&value[index]]?(1<<index):0;
    }
    if ((mask == 7) || (mask == 15)) {
        red = value[0]/255.0;
        green = value[1]/255.0;
        blue = value[2]/255.0;
        alpha = (mask == 7)?1.0:(value[3]/255.0);
    }
    if ((mask == 1) || (mask == 3)) {
        red = ((value[0] >> 16) & 0xff)/255.0;
        green = ((value[0] >> 8) & 0xff)/255.0;
        blue = ((value[0] >> 0) & 0xff)/255.0;
        alpha = (mask == 7)?1.0:(value[1]/255.0);
    }
    return [NSColor 
        colorWithDeviceRed:red green:green blue:blue alpha:alpha];
}

- (IBAction)takeColorFrom:(id)sender
{
    if ([sender isKindOfClass:[NSColorWell class]]) {
        [_userValue setColor:[[sender color] 
            colorUsingColorSpaceName:NSDeviceRGBColorSpace]];
    } else if ([sender isKindOfClass:[NSTextField class]]) {
        [_userValue setColor:[[self 
            colorWithString:[sender stringValue]]  
            colorUsingColorSpaceName:NSDeviceRGBColorSpace]];
    } else {
        // color list entry?
    }
    [self modified];
}

@end


@implementation UVColorEditor (NSCoding)

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
    [coder encodeObject:editorColorWell];
    [coder encodeObject:editorTextField];
    [coder encodeObject:editorInfoField];
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    editorColorWell = [[coder decodeObject] retain];
    editorTextField = [[coder decodeObject] retain];
    editorInfoField = [[coder decodeObject] retain];
        // why is this necessary?
    [editorColorWell setTarget:self];
    [editorColorWell setAction:@selector(takeColorFrom:)];
    return self;
}

@end


