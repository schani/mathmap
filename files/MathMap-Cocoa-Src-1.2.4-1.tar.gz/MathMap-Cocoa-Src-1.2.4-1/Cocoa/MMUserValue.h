//
//  MMUserValue.h
//
//  Created by Herbert Pötzl on Thu Mar 07 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Cocoa/Cocoa.h>

#import "userval.h"

typedef unsigned MMUserValueEncoding;

enum {
    MMASCIIEncoding = 1,		
    MMProprietaryEncoding = 65536   
};

typedef unsigned MMUserValueType;

enum {
    MMUnknownUserValueType = -1,
    MMIntUserValueType = USERVAL_INT_CONST,
    MMFloatUserValueType = USERVAL_FLOAT_CONST,
    MMBoolUserValueType = USERVAL_BOOL_CONST,
    MMColorUserValueType = USERVAL_COLOR,
    MMCurveUserValueType = USERVAL_CURVE,
    MMGradientUserValueType = USERVAL_GRADIENT,
    MMImageUserValueType = USERVAL_IMAGE
};

@class Curve;

@interface MMUserValue : NSObject {
@private
    NSString *_name;
    userval_info_t _info;
    
@protected
    userval_t _value;
}

+ (id)userValueWithData:(NSData *)data
    encoding:(MMUserValueEncoding)encoding;

+ (NSString *)nameForType:(MMUserValueType)type;
+ (MMUserValueType)typeForName:(NSString *)name;

- (id)initWithData:(NSData *)data
    encoding:(MMUserValueEncoding)encoding;

- (id)initWithName:(NSString *)name
    type:(MMUserValueType)type
    string:(NSString *)value;
	
- (NSData *)dataUsingEncoding:(MMUserValueEncoding)encoding;

- (MMUserValueType)type;
- (NSString *)typeName;
- (NSString *)name;

- (void) resetToDefault;

/* int/float */
- (float) minValue;
- (float) maxValue;
- (int) numberOfTickMarks;
- (float) floatValue;
- (void) setFloatValue: (float) val;

/* bool */
- (BOOL) boolValue;
- (void) setBoolValue: (BOOL) val;

/* color */
- (NSColor *)color;
- (void) setColor: (NSColor *) val;

/* curve / gradient */

- (Curve *)curve;
- (void) setCurve: (Curve *) val;

/* image */
- (NSImage *)image;
- (void) setImage: (NSImage *) val;

@end

@interface MMUserValue (Expression)

+ (id)userValueWithCInfo:(userval_info_t *)info;

- (id)initWithCInfo:(userval_info_t *)info;

- (userval_info_t *)cInfo;
- (void)copyToCValue:(userval_t *)val;

@end

