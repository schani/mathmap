//
//  MMUVMatrix.m
//
//  Created by Herbert Pötzl on Thu Mar 07 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMUVMatrix.h"
#import "MMUserValue.h"

#import "UVEditor.h"
#import "UVEHelper.h"
#import "NSExtensions.h"

@implementation MMUVMatrix



- (NSRect)calcFrames:(NSRect)valueFrame 
    grid:(NSRect *)gridFrame
    sep:(NSRect *)sepFrame
    name:(NSRect *)nameFrame
    type:(NSRect *)typeFrame
{
    NSRect workFrame, descFrame, cellFrame;
    NSRect aFrame, bFrame;

    NSDivideRect(valueFrame, &aFrame, &workFrame, 
        1, NSMaxYEdge);
    if (sepFrame) *sepFrame = aFrame;
    NSDivideRect(workFrame, &descFrame, &cellFrame, 
        _descriptionWidth, NSMinXEdge);
    NSDivideRect(descFrame, &aFrame, &descFrame, 
        1, NSMaxXEdge);
    if (gridFrame) *gridFrame = aFrame;
    if (nameFrame || typeFrame) {
        NSDivideRect(descFrame, &aFrame, &bFrame, 
            [NSFont labelFontSize], NSMinYEdge);
        if (nameFrame) *nameFrame = aFrame;
        if (typeFrame) *typeFrame = bFrame;
    }
    return cellFrame;    
}


- (BOOL)isFlipped 	{ return YES; }

- (void)keyWindowNotification:(NSNotification *)notif
{
    [self setNeedsDisplay:YES];
}


- (id)initWithFrame:(NSRect)frame 
{
    self = [super initWithFrame:frame];
    if (self) {
        _userValues = [[NSArray alloc] init];
        _valueEditors = [[NSArray alloc] init];
        _valueRects = NULL;
        _descriptionWidth = 100.0;
        _textCell = [[NSCell alloc] initTextCell:@"TextCell"];
        
        [self registerKeyWindowNotification];
        [self setAutoresizesSubviews:NO];
        [self recalcLayout:YES];
    }
    return self;
}

- (void)dealloc {
    [self unregisterKeyWindowNotification];
    [_userValues release];
    [_valueEditors release];
    [_textCell release];
    [super dealloc];
}

- (void)setFrame:(NSRect)frameRect
{
    [super setFrame:frameRect];
    [self recalcLayout:YES];
}

- (void)editor:(UVEditor *)editor 
    didChangeMinSize:(NSSize)oldMinSize {
    // NSLog(@"editor %@ didChangeMinSize ...", editor);
    [self recalcLayout:NO];
    {
        NSRect dirty = [self bounds];
        NSRect edRect = [editor frame];
        dirty.origin.y = NSMinY(edRect);
        [self setNeedsDisplayInRect:dirty];
    }
    // [self setNeedsDisplay:YES];
}


- (void)drawRect:(NSRect)rect {
    NSFont *nameFont, *typeFont;
    int index, count;
    
//    NSLog(@"draw Rect: [%f,%f,%f,%f]", NSMinX(rect), NSMinY(rect), NSWidth(rect), NSHeight(rect));
    nameFont = [NSFont labelFontOfSize:[NSFont labelFontSize]];
    typeFont = [NSFont labelFontOfSize:[NSFont labelFontSize]-1];
    
    count = [_userValues count];
    for (index=0; index<count; index++) {
        MMUserValue *value = [_userValues objectAtIndex:index];
        NSRect valueFrame = _valueRects[index];
        NSRect editorFrame, gridFrame, sepFrame;
        NSRect nameFrame, typeFrame;
        
        if (NSIntersectsRect(valueFrame, rect)) {
        
            editorFrame = [self calcFrames:valueFrame 
                grid:&gridFrame sep:&sepFrame
                name:&nameFrame type:&typeFrame];
                
            [[NSColor colorWithDeviceWhite:0.9 alpha:1.0] set];
            NSRectFill(nameFrame);
            NSRectFill(typeFrame);
            [[[NSColor gridColor] highlightWithLevel:0.5] set];
            NSRectFill(gridFrame);
            NSRectFill(sepFrame);
            
            [_textCell setStringValue:[value name]];
            [_textCell setFont:nameFont];
            [_textCell drawWithFrame:nameFrame inView:self];
            
            [_textCell setStringValue:[value typeName]];
            [_textCell setFont:typeFont];
            [_textCell drawWithFrame:typeFrame inView:self];
        }
    }
}

- (UVEditor *)editorForType:(MMUserValueType)type
    reuseFrom:(NSMutableArray *)editors {
    NSEnumerator *enumerator = [editors objectEnumerator];
    UVEditor *editor;
    while ((editor = [enumerator nextObject])) {
        if ([editor type] == type) break;
    }
    if (editor) {
//        NSLog(@"BR editor = %@ [%d]", editor, [editor retainCount]);
        [editors removeObject:editor];
//        NSLog(@"AR editor = %@ [%d]", editor, [editor retainCount]);
    } else {
        editor = [UVEditor editorForType:type];
//        NSLog(@"AC editor = %@ [%d]", editor, [editor retainCount]);
    }
    return editor;
}

- (void)setUserValues:(NSArray *)userValues
{
    NSMutableArray *newEditors;
    
    int index, count;

    [userValues retain];
    [_userValues release];
    _userValues = userValues;
    
    if (_valueRects) 
        NSZoneFree([self zone], _valueRects);
    
    count = [_userValues count];
    _valueRects = NSZoneCalloc([self zone], count, sizeof(NSRect));
    
    newEditors = [[NSMutableArray alloc] init];
    for (index=0; index<count; index++) {
        MMUserValue *value = [_userValues objectAtIndex:index];
        UVEditor *editor = [self editorForType:[value type] 
            reuseFrom:_valueEditors];
	    
        if ([editor superview] != self)
            [self addSubview:editor];
        [editor setUserValue:value];
        [newEditors addObject:editor];
    }
    [_valueEditors makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [_valueEditors release];
    _valueEditors = newEditors;
    [self recalcLayout:YES];
}


- (NSArray *)userValues		{ return _userValues; }

- (void)resetUserValues {
    [_userValues makeObjectsPerformSelector:@selector(resetToDefault)];
    [_valueEditors makeObjectsPerformSelector:@selector(synchronize)];
}


- (void)recalcLayout:(BOOL)setFrame
{
    NSRect bounds;
    float currentPos;
    int index, count;
    
    currentPos = 0.0;
    bounds = [self bounds];
    
    count = [_userValues count];
    for (index=0; index<count; index++) {
//        MMUserValue *value = [_userValues objectAtIndex:index];
        UVEditor *editor = [_valueEditors objectAtIndex:index];
        NSSize minSize = [editor minSize];
        float minHeight = MAX([NSFont labelFontSize]*2.5, minSize.height);    
        NSRect cellFrame;
    
        _valueRects[index] = NSMakeRect(0, currentPos,
            bounds.size.width, minHeight + 1);
        cellFrame = [self calcFrames:_valueRects[index] 
            grid:NULL sep:NULL name:NULL type:NULL];    
        if (setFrame) [editor setFrame:cellFrame];
        else [editor setFrameOrigin:cellFrame.origin];
        currentPos += minHeight + 1;
    }
    [self setFrameSize:NSMakeSize(bounds.size.width, currentPos-1)];
}



- (BOOL)acceptsFirstMouse:(NSEvent *)theEvent		{ return NO; }

/*
- (void)mouseDown:(NSEvent *)theEvent
{
    int index, count;
    NSPoint location;
    
    location = [self convertPoint:[theEvent locationInWindow] 
        fromView:nil];

    _mouseDownFlags = [theEvent modifierFlags];
    count = [_userValues count];
    for (index=0; index<count; index++) {
        NSRect valueFrame = _valueRects[index];
    
        if ([self mouse:location inRect:valueFrame]) {
            NSRect cellFrame = [self calcFrames:valueFrame 
                grid:NULL sep:NULL name:NULL type:NULL];
            if ([self mouse:location inRect:cellFrame]) {
                MMUserValue *value = [_userValues objectAtIndex:index];
                NSCell *valueCell = [_valueCells objectAtIndex:index];
                
                [valueCell editWithFrame:cellFrame 
                    inView:self editor:[[self window] 
                        fieldEditor:YES forObject:self] 
                        delegate:self event:theEvent];

                [valueCell trackMouse:theEvent 
                    inRect:cellFrame ofView:self untilMouseUp:YES];

            }
            break;
        }
    }
}

- (int)mouseDownFlags 					{ return _mouseDownFlags; }
        
*/

@end
