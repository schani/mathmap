//
//  MMInvocation.h
//
//  Created by Herbert Pötzl on Sun Mar 24 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Cocoa/Cocoa.h>
#import <pthread.h>

#import "mathmap.h"

@class MMExpression;

typedef	struct _thread_data MMThreadData;

@interface MMInvocation : NSObject {
@private
    MMExpression *_expression;
    NSArray *_userValues;
    NSBitmapImageRep *_imageRep;
    MMThreadData *_threadData;
    void *_threadHandle;
    char *_updateData;
	NSSize _updateSize;
    float _timeValue;
    struct _mminvocation_flags {
        unsigned int supersampling:1;
        unsigned int antialiasing:1;
    } _flags;
}

- (id)initWithExpression:(MMExpression *)expression
    userValues:(NSArray *)values
    bitmapImageRep:(NSBitmapImageRep *)imageRep;

- (MMExpression *)expression;
- (NSArray *)userValues;
- (NSBitmapImageRep *)imageRep;

- (void)setTimeValue:(float)value;
- (void)setSupersampling:(BOOL)flag;
- (void)setAntialiasing:(BOOL)flag;

- (void)render;
- (void)renderThreaded:(BOOL)flag;

- (void)stop;

- (BOOL)isRunning;
- (BOOL)hasFinished;
- (float)progress;

- (NSRange)nextRangeFinished;
- (NSRect)nextRectFinished;

@end
