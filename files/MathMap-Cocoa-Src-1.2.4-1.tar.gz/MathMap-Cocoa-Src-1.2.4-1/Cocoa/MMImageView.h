//
//  MMImageView.h
//
//  Created by Herbert Pötzl on Fri Mar 29 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <AppKit/AppKit.h>

@class MMExpression, MMInvocation;

@interface MMImageView : NSView {

    NSImage *_renderImage;
    NSBitmapImageRep *_renderRep;

    NSImage *_activeImage;
    NSBitmapImageRep *_activeRep;

    BOOL _syncOnFrame;
    BOOL _isActive;
    BOOL _needsRestart;
    BOOL _isRendering;
	
    // BOOL _backupIsActive;
    // BOOL _isInitialRun;

	
    MMExpression *_expression;
    MMInvocation *_invocation;
    NSArray *_userValues;
    NSArray *_nextUserValues;

    
    float _timeValue;
    unsigned _state;
    NSTimer *_refreshTimer;
	NSTimeInterval _refreshInterval;
    
    struct _mmimageview_flags {
        unsigned int supersampling:1;
        unsigned int antialiasing:1;
    } _flags;
}

-(BOOL)scheduleExpression:(MMExpression *)expression
    userValues:(NSArray *)userValues;
-(BOOL)rescheduleExpression:(MMExpression *)expression
    userValues:(NSArray *)userValues;

-(void)stop;
-(void)stopAfterFrame;

-(void)setSyncOnFrame:(BOOL)flag;
-(BOOL)syncsOnFrame; 

-(void)setRefreshInterval:(NSTimeInterval)interval;
-(NSTimeInterval)refreshInterval;

-(void)setSupersampling:(BOOL)flag;
-(void)setAntialiasing:(BOOL)flag;

-(float)progress;
-(NSImage *)image;

-(IBAction)takeFloatFrom:(id)sender;

@end
