//
//  UVBoolEditor.m
//
//  Created by Herbert P�tzl on Tue Mar 12 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "UVBoolEditor.h"

static	NSString * StateInfoFalse = 	@"(0, FALSE, NO, off)";
static	NSString * StateInfoTrue =  	@"(1, TRUE, YES, on)";


@implementation UVBoolEditor

- (MMUserValueType)type			{ return MMBoolUserValueType; }

- (void)update
{
    [editorSwitch setState:[_userValue boolValue]];
    [editorInfoField setStringValue:
        ([_userValue boolValue] ?
            StateInfoTrue : StateInfoFalse)];
    [super update];
}

@end


@implementation UVBoolEditor (Modification)

- (IBAction)takeBoolValueFrom:(id)sender
{
    [_userValue setBoolValue:[sender state]];
    [self modified];
}

@end


@implementation UVBoolEditor (NSCoding)

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
    [coder encodeConditionalObject:editorSwitch];
    [coder encodeConditionalObject:editorInfoField];
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    editorSwitch = [[coder decodeObject] retain];
    editorInfoField = [[coder decodeObject] retain];
    return self;
}

@end
