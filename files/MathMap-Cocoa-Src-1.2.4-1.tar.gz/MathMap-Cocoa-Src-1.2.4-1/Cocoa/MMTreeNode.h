//
//  MMTreeNode.h
//
//  Created by Herbert P�tzl on Mon Mar 25 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Foundation/Foundation.h>

#import "TreeNode.h"

#import "expression_db.h"

extern NSString *GroupNameKey;		
extern NSString *EntryNameKey;		
extern NSString *EntriesKey;
extern NSString *EntryKindKey;		
extern NSString *EntryDateKey;		
extern NSString *EntryDataKey;		
extern NSString *ValueTypeKey;		
extern NSString *ValueKey;		

extern NSString *InfoRTFKey;		
extern NSString *EntryPathKey;		

extern NSString *LockedFlagKey;		


extern NSString *ExpressionEntryKind;
extern NSString *UserValueEntryKind;
extern NSString *UserValueSetEntryKind;
extern NSString *ImageLinkEntryKind;


@interface MMTreeNode : TreeNode {
    NSData *_infoRTF;
}

+ (MMTreeNode *)groupNodeWithName:(NSString *)name;
+ (MMTreeNode *)referenceNodeWithPath:(NSString *)path;
+ (MMTreeNode *)containerNodeWithProperty:(id)property;

+ (MMTreeNode *)treeFromDictionary:(NSDictionary*)dict;
+ (MMTreeNode *)treeFromArray:(NSArray *)array;

- (id)initFromDictionary:(NSDictionary *)dict;
- (id) initFromExpressionDB: (expression_db_t*) edb;

- (NSString *)description;
- (NSString *)overview;

+ (NSData *)defaultInfoRTF;
- (void)setInfoRTF:(NSData *)info;
- (NSData *)infoRTF;


@end
