//
//  MMInvocation.m
//
//  Created by Herbert Pötzl on Sun Mar 24 2002.
//  Copyright (c) 2002-2008 Herbert Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMInvocation.h"
#import "MMExpression.h"
#import "MMUserValue.h"

#import "tags.h"
#import "noise.h"

#import <unistd.h>
#import <mach/thread_act.h>


@interface MMExpression	(Invocation)

- (mathmap_t *)mathmap;

@end

@implementation MMExpression	(Invocation)

- (mathmap_t *)mathmap		{ return _mathmap; }

@end



enum {
    MMInvocationPrepared = 1,		
    MMInvocationLaunching = 2,		
    MMInvocationActive = 3,		
    MMInvocationDone = 4,
    MMInvocationAborted = 5
};

#define	THREAD_FINISHED(d)	(((d)->state == MMInvocationDone) ||		\
                                 ((d)->state == MMInvocationAborted))

#define	THREAD_RUNNING(d)	(((d)->state == MMInvocationActive) ||		\
                                 ((d)->state == MMInvocationLaunching))
								 
#define	THREAD_ACTIVE(d)	(((d)->state == MMInvocationActive))


struct _thread_data {
    NSSize bitmapSize;
	int rowStride; 
    unsigned char *bitmapData;
    mathmap_invocation_t *invocation;
    unsigned int state;
    BOOL isThreaded;
};


enum {
	MMRowEmpty = 0,
	MMRowFinished = 1,
	MMRowUpdated = 2
};


@implementation MMInvocation


- (void)copyUserValues {
    mathmap_invocation_t *invocation = 
        _threadData->invocation;
    mathmap_t *mathmap = [_expression mathmap];
    NSEnumerator *enumerator = 
        [_userValues objectEnumerator];
    MMUserValue *value;
    
    while ((value = [enumerator nextObject]) != nil) {
	userval_info_t *info = 
            lookup_matching_userval(mathmap->main_filter->userval_infos, 
                [value cInfo]);
	if (info != 0)
	    [value copyToCValue: &invocation->uservals[info->index]];
    }
}


- (id)initWithExpression:(MMExpression *)expression
    userValues:(NSArray *)values
    bitmapImageRep:(NSBitmapImageRep *)imageRep {
    self = [super init];
    if (self) {
        NSSize size = [imageRep size];
        mathmap_t *mathmap = [expression mathmap];

        _timeValue = 0.0;
        _flags.antialiasing = NO;
        _flags.supersampling = NO;
        _expression = [expression retain];
        _imageRep = [imageRep retain];
        _userValues = [values copy];
        _threadData = NSZoneMalloc([self zone], sizeof(MMThreadData));
        _threadData->invocation = 
            invoke_mathmap(mathmap, 0, 
            size.width, size.height);
		_threadData->rowStride = [imageRep bytesPerRow];
        _threadData->isThreaded = NO;
        _threadData->state = MMInvocationPrepared;
		_updateSize = size;
        _updateData = NSZoneCalloc([self zone], size.height, sizeof(char));
    }
//    NSLog(@"+ Invocation %p", self);
    return self;
}

- (void) dealloc {
    if (THREAD_RUNNING(_threadData)) [self stop];
    free_invocation(_threadData->invocation);
    [_expression release];
    [_imageRep release];
    [_userValues release];
    NSZoneFree([self zone], _updateData);
    NSZoneFree([self zone], _threadData);
//    NSLog(@"- Invocation %p", self);
    [super dealloc];
}

- (MMExpression *)expression		{ return _expression; }
- (NSArray *)userValues			{ return _userValues; }
- (NSBitmapImageRep *)imageRep		{ return _imageRep; }

- (void)setTimeValue:(float)value 	{ _timeValue = value; }

- (void)setSupersampling:(BOOL)flag	{ _flags.supersampling = flag; }
- (void)setAntialiasing:(BOOL)flag	{ _flags.antialiasing = flag; }

- (void)renderThreaded:(BOOL)flag {
    mathmap_invocation_t *invocation = _threadData->invocation;
    unsigned char *output;

    if (_threadData->state == MMInvocationPrepared)
        [self copyUserValues];

    _threadData->bitmapData = [_imageRep bitmapData];
    _threadData->bitmapSize = [_imageRep size];
	_threadData->rowStride = [_imageRep bytesPerRow];
    _threadData->state = MMInvocationLaunching;
    _threadData->isThreaded = flag;
	    
    invocation->antialiasing = _flags.antialiasing;
    invocation->supersampling = _flags.supersampling;
    invocation->output_bpp = 4;
	invocation->row_stride = _threadData->rowStride;
    // invocation->num_rows_finished = range.location;
	invocation->row_stride = _threadData->rowStride;
    invocation->current_t = _timeValue;
	invocation->edge_color_x = MAKE_RGBA_COLOR(0, 0, 0, 0);

    update_image_internals(invocation);

	output = _threadData->bitmapData;
	
	_threadHandle = call_invocation_parallel(invocation,
		0, 0, invocation->img_width, invocation->img_height,
		output, MPProcessorsScheduled());
	// NSLog(@"- Invocation %p on %d processors", self, MPProcessorsScheduled());
	_threadData->state = MMInvocationActive;
}

- (void)render {
    [self renderThreaded:YES];
	join_invocation_call(_threadHandle);
	_threadData->state = MMInvocationDone;
}

- (void)stop {
	if (THREAD_ACTIVE(_threadData))
		kill_invocation_call(_threadHandle);
    _threadData->state = MMInvocationAborted;
}

- (BOOL)isRunning		{ 
	return THREAD_RUNNING(_threadData);
}

- (BOOL)hasFinished		{ 
	if (THREAD_ACTIVE(_threadData) &&
		invocation_call_is_done(_threadHandle)) {
		_threadData->state = MMInvocationDone;
		join_invocation_call(_threadHandle);
	}
	return THREAD_FINISHED(_threadData);
}


- (float)progress { 
	return -1.0;
}

- (NSRange)nextRangeFinished {
	NSRange new = { 0, 0 };
	
	for (;new.location < _updateSize.height; new.location++) {
		switch (_updateData[new.location]) {
		case MMRowUpdated: continue;
		case MMRowEmpty:
			if (_threadData->invocation->rows_finished[new.location])
				_updateData[new.location] = MMRowFinished;
			else break;
		case MMRowFinished:
			for (new.length = 0; new.location + new.length < _updateSize.height; 
				new.length++) {
				switch (_updateData[new.location + new.length]) {
				case MMRowFinished: 
					_updateData[new.location + new.length] = MMRowUpdated;
					continue;
				case MMRowUpdated:
					return new;
				case MMRowEmpty:
					if (_threadData->invocation->rows_finished[new.location + new.length])
						_updateData[new.location + new.length] = MMRowUpdated;
					else return new;
				}
			}
			return new;
		}
	}
	return new;
}


- (NSRect)nextRectFinished {
	NSRange new = [self nextRangeFinished];
	
	return (new.length) ?
		NSMakeRect(0, new.location, _updateSize.width, new.length) :
		NSZeroRect;
}

@end
