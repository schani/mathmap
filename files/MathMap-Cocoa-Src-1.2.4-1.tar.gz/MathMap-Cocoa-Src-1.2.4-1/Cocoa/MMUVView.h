//
//  MMUVView.h
//
//  Created by Herbert P�tzl on Thu Mar 07 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import <AppKit/AppKit.h>

#import "MMUVMatrix.h"

extern	NSString *	UserValueSetModifiedNotification;


@interface MMUVView : NSView {
    NSScrollView *_scrollView;
    MMUVMatrix *_userValueMatrix;
    IBOutlet id delegate;

    NSRect _headerRect;
    NSTableHeaderCell *_headerCell;
    float _descriptionWidth;
}

- (void)resetUserValues;

- (void)setDelegate:(id)object;
- (id)delegate;

- (void)setUserValues:(NSArray *)userValues;
- (NSArray *)userValues;

- (void)recalcLayout;


@end


@interface NSObject (UserValueViewDelegate)

- (BOOL)userValueView:(MMUVView *)view 
    shouldResetUserValues:(NSArray *)userValues;
- (void)userValueView:(MMUVView *)view 
    didResetUserValues:(NSArray *)userValues;
    
- (void)userValueView:(MMUVView *)view 
    changedUserValue:(MMUserValue *)value;

@end
