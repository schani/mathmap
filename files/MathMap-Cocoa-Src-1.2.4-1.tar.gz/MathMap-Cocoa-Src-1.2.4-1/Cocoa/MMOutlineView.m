//
//  MMOutlineView.m
//
//  Created by Herbert Pötzl on Fri Mar 15 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  based on NSOutlineView_Extensions (c) 2001 by Apple Computer, Chuck Pisula
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMOutlineView.h"

#import "MMArchive.h"

@implementation MMOutlineView

- (id)selectedItem { return [self itemAtRow: [self selectedRow]]; }

- (NSArray*)allSelectedItems {
    NSMutableArray *items = [NSMutableArray array];
    NSEnumerator *selectedRows = [self selectedRowEnumerator];
    NSNumber *selRow = nil;
    while( (selRow = [selectedRows nextObject]) ) {
        if ([self itemAtRow:[selRow intValue]]) 
            [items addObject: [self itemAtRow:[selRow intValue]]];
    }
    return items;
}

- (void)selectItems:(NSArray*)items byExtendingSelection:(BOOL)extend {
    int i;
    if (extend==NO) [self deselectAll:nil];
    for (i=0;i<[items count];i++) {
        int row = [self rowForItem:[items objectAtIndex:i]];
        if(row>=0) [self selectRow: row byExtendingSelection:YES];
    }
}

- (NSDragOperation)draggingSourceOperationMaskForLocal:(BOOL)isLocal {
    if (isLocal) {
        return NSDragOperationGeneric;
    } else {
        return (NSDragOperationCopy | NSDragOperationMove);
    }
}

- (void)newGroup:(id)sender {
	id item = [self selectedItem];
	
    // NSLog(@"new group ...");
	if (item) {
		if ([self isItemExpanded:item])
			[[self dataSource] addGroupNodeTo:item];
		else
			[[self dataSource] addGroupNodeAfter:item];
	} else {
		[[self dataSource] 
			addGroupNodeTo:[[self dataSource] rootNode]];
	}
    [self reloadData];
}

- (void)group:(id)sender {
    // NSLog(@"group group ...");
}

- (void)ungroup:(id)sender {
    // NSLog(@"ungroup group ...");
}



- (void)delete:(id)sender {
    // NSLog(@"delete group ...");
    [[self dataSource] 
        removeNodes:[self allSelectedItems]];
    [self reloadData];
}


@end


@implementation MMOutlineView (KeyboardShortcuts)

- (void) keyDown:(NSEvent *) theEvent
{
	unichar firstChar = [[theEvent characters] characterAtIndex: 0];
	
	if (firstChar == NSDeleteFunctionKey ||
		firstChar == NSDeleteCharFunctionKey ||
		firstChar == NSDeleteCharacter ||
		firstChar == NSBackspaceCharacter) {
		id item = [self selectedItem];
		
		if (item)
			[self delete:self];
		return;
	}

	[super keyDown:theEvent];
}

@end
