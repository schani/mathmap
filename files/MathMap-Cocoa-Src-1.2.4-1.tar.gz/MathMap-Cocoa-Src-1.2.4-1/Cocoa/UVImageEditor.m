//
//  UVImageEditor.m
//
//  Created by Herbert P�tzl on Fri Mar 15 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "UVImageEditor.h"


@implementation UVImageEditor

- (void)configureForImage {
    [editorImageView setEditable:YES];
    [editorImageView setImageFrameStyle:NSImageFramePhoto];
    [editorImageView setImageScaling:NSScaleProportionally];
}

- (MMUserValueType)type			{ return MMImageUserValueType; }

- (NSSize)minSize { 
    if (_isExpanded) {
        NSSize minSize = _minSize;
        minSize.height = 200 + (6+22);
        return minSize;
    }
    return _minSize;
}

- (IBAction)toggleSize:(id)sender {
    NSRect frame = [self frame];
    NSRect imageRect, infoRect;
    NSSize oldMinSize = [self minSize];
    
    if (_isExpanded) {
        [self setFrameSize:NSMakeSize(NSWidth(frame), _minSize.height)];
        imageRect = NSMakeRect(27, 3, 
            70, NSHeight([self bounds]) - (2*3));
        infoRect = NSMakeRect(99, 22,
            NSWidth([self bounds])-(99+7), 17);
        [editorImageView setAutoresizingMask:NSViewNotSizable];
        _isExpanded = NO;
    } else {
        [self setFrameSize:NSMakeSize(NSWidth(frame), 200 + (6+22))];
        imageRect = NSMakeRect(27, 22, 
            NSWidth([self bounds])-(27+7), 
            NSHeight([self bounds])-(3+22));
        infoRect = NSMakeRect(27, 6,
            NSWidth([self bounds])-(27+7), 17);
        [editorImageView setAutoresizingMask:NSViewWidthSizable];
        _isExpanded = YES;
    }
    [editorImageView setFrame:imageRect];
    [editorInfoField setFrame:infoRect];
    if ([[self superview] respondsToSelector:
        @selector(editor:didChangeMinSize:)]) {
        [[self superview] editor:self 
            didChangeMinSize:oldMinSize];
    }
    [self setNeedsDisplay:YES];
}


- (void)update
{
    [editorImageView setImage:[_userValue image]];
    [super update];
}

@end


@implementation UVImageEditor (Modification)

- (IBAction)takeImageFrom:(id)sender
{
    [_userValue setImage:[sender image]];
    [self modified];
}

@end


@implementation UVImageEditor (NSCoding)

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
    [coder encodeConditionalObject:editorImageView];
    [coder encodeConditionalObject:editorExpandButton];
    [coder encodeConditionalObject:editorInfoField];
    [coder encodeValueOfObjCType:@encode(BOOL) at:&_isExpanded];
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    editorImageView = [[coder decodeObject] retain];
    editorExpandButton = [[coder decodeObject] retain];
    editorInfoField = [[coder decodeObject] retain];
    [coder decodeValueOfObjCType:@encode(BOOL) at:&_isExpanded];
        // why is this necessary?
    [editorImageView setTarget:self];
    [editorImageView setAction:@selector(takeImageFrom:)];
    return self;
}

@end


