//
//  MMPreview.m
//
//  Created by Herbert P�tzl on Wed Mar 06 2002.
//  Copyright (c) 2002-2007 Herbert P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMPreview.h"
#import "UserDefaults.h"

#import "MMDocument.h"
#import "MMExpression.h"
#import "MMInvocation.h"

#import "MMImageView.h"

@implementation MMPreview

+ (void)initialize{

    [[NSUserDefaults standardUserDefaults] 
        registerDefaults:[NSDictionary
        dictionaryWithObjectsAndKeys:
            PreviewAutoUpdateDValue, PreviewAutoUpdateDefault,
            nil]];
}

+ (id)previewController 
{
    static MMPreview *_preview = nil;

    if (!_preview) {
        _preview = [[self alloc] init];
    }
    return _preview;
}


- (id)init 
{
    self = [super init];
    if (self) {
        [NSBundle loadNibNamed:@"MMPreview" owner:self];
		[previewWindow setFrameUsingName: @"MMPreviewWindow"];
		[previewWindow setFrameAutosaveName: @"MMPreviewWindow"];

        _expression = nil;
        _userValues = nil;
        _document = nil;
        _pollTimer = nil;
        _invocation = nil;
    }
    return self;
}


- (void)setDocument:(MMDocument *)document {
    [document retain];
    [_document release];
    _document = document;
    _shouldBecomeIdle = NO;
}

- (void)setExpression:(MMExpression *)expression {
    [expression retain];
    [_expression release];
    _expression = expression;
    _shouldBecomeIdle = NO;
}

- (void)setUserValues:(NSArray *)values {
    [_userValues release];
    _userValues = [values copy];
    _shouldBecomeIdle = NO;
}

- (void)schedule {
	if (_expression)
		[imageView scheduleExpression:_expression
			userValues:_userValues];
}

- (void)reschedule {
	if (_expression)
		[imageView rescheduleExpression:_expression
			userValues:_userValues];
}

- (void)updatePreviewForDocument:(MMDocument *)document {
    BOOL doIt = YES;
    
    if ([document isKindOfClass:[MMDocument class]]) {
        MMExpression *expression = [document currentExpression];
        NSArray *userValues = [document currentUserValues];
        
	if (document != _document) {
	    [self setDocument:document];
	    [self setExpression:expression];
	    [self setUserValues:userValues];
	} else {
	    if (![_expression isEqual:expression]) {
		[self setExpression:expression];
		[self setUserValues:userValues];
	    } else if (![_userValues isEqual:userValues]) {
		[self setUserValues:userValues];
	    } else doIt = NO;
	}
	if (doIt) {
	    [self schedule];
	}
    }
}

- (void)mainWindowChanged:(NSNotification *)notification {
    NSDocument *document = [[NSDocumentController 
        sharedDocumentController] 
            currentDocument];
    
    if ([document isKindOfClass:[MMDocument class]]) {
        MMDocument *mmdoc = (MMDocument *)document;
        [[NSNotificationCenter defaultCenter] 
            removeObserver:self 
            name:ExpressionChangedNotification 
            object:nil];
        [[NSNotificationCenter defaultCenter] 
            addObserver:self 
            selector:@selector(expressionChanged:) 
            name:ExpressionChangedNotification 
            object:document];
        [self updatePreviewForDocument:mmdoc];
    } else {
        [[NSNotificationCenter defaultCenter] 
            addObserver:self 
            selector:@selector(expressionChanged:) 
            name:ExpressionChangedNotification 
            object:nil];
    }
}

- (void)expressionChanged:(NSNotification *)notification {
/*    MMDocument *document = [[NSDocumentController 
        sharedDocumentController] 
            currentDocument]; 
*/
    MMDocument *document = [notification object]; 

    if ([document isKindOfClass:[MMDocument class]]) {
        MMDocument *mmdoc = (MMDocument *)document;

        MMExpression *expression = [mmdoc currentExpression];
        NSArray *userValues = [mmdoc currentUserValues];
        [self setExpression:expression];
        [self setUserValues:userValues];
        [self schedule];

        // lock 
/*
        [[NSNotificationCenter defaultCenter] 
            removeObserver:self 
            name:ExpressionChangedNotification 
            object:nil];
        [[NSNotificationCenter defaultCenter] 
            addObserver:self 
            selector:@selector(expressionChanged:) 
            name:ExpressionChangedNotification 
            object:document];
*/        
/*
    [self updatePreviewForDocument:
        [[NSDocumentController sharedDocumentController] 
        currentDocument]];
*/
    }
}

- (void)userValueSetModified:(NSNotification *)notification {
    MMUVView *uvview = [notification object]; 
    NSArray *userValues = [uvview userValues];
    [self setUserValues:userValues];
    [self reschedule];
}



- (void)activateObserver {
    [[NSNotificationCenter defaultCenter] 
        addObserver:self 
        selector:@selector(mainWindowChanged:) 
        name:NSWindowDidBecomeMainNotification 
        object:nil];
    [[NSNotificationCenter defaultCenter] 
        addObserver:self 
        selector:@selector(expressionChanged:) 
        name:ExpressionChangedNotification 
        object:nil];
    [[NSNotificationCenter defaultCenter] 
        addObserver:self 
        selector:@selector(userValueSetModified:) 
        name:UserValueSetModifiedNotification 
        object:nil];
}

- (void)deactivateObserver {
    [[NSNotificationCenter defaultCenter] 
        removeObserver:self 
        name:NSWindowDidBecomeMainNotification 
        object:nil];
    [[NSNotificationCenter defaultCenter] 
        removeObserver:self 
        name:ExpressionChangedNotification 
        object:nil];
    [[NSNotificationCenter defaultCenter] 
        removeObserver:self 
        name:UserValueSetModifiedNotification 
        object:nil];
}        

- (void)updatePreviewTitle {
    NSRect rect = [imageView frame];
    [previewWindow setTitle:[NSString 
        stringWithFormat:@"Preview - %dx%d",
        (int)NSWidth(rect), (int)NSHeight(rect)]];
}

- (void)openPreviewWindow:(id)sender
{
    [self updatePreviewTitle];
    [previewWindow makeKeyAndOrderFront:self];
    [self activateObserver];
    [self updatePreviewForDocument:
        [[NSDocumentController sharedDocumentController] 
        currentDocument]];
}


- (BOOL)windowShouldClose:(id)sender {
    [self deactivateObserver];
    [self setDocument:nil];
    return YES;
}

- (void)windowDidResize:(NSNotification *)notification {
    [self updatePreviewTitle];
}

/*
APPKIT_EXTERN NSString *NSWindowDidBecomeKeyNotification;
APPKIT_EXTERN NSString *NSWindowDidBecomeMainNotification;
*/

- (BOOL)windowShouldZoom:(NSWindow *)sender 
    toFrame:(NSRect)newFrame
{
    return YES;
}

-(void)enableAntialias:(id)sender {
    [antialiasButton setToolTip:@"Enable Antialiasing"];
    [antialiasButton setImage:[NSImage 
        imageNamed:@"AntialiasTTIcon"]];
    [antialiasButton setAlternateImage:[NSImage 
        imageNamed:@"AntialiasTTAIcon"]];
    [antialiasButton setAction:@selector(disableAntialias:)];
    [imageView setAntialiasing:YES];
    [self reschedule];
}

-(void)disableAntialias:(id)sender {
    [antialiasButton setToolTip:@"Disable Antialiasing"];
    [antialiasButton setImage:[NSImage 
        imageNamed:@"AntialiasTFIcon"]];
    [antialiasButton setAlternateImage:[NSImage 
        imageNamed:@"AntialiasTFAIcon"]];
    [antialiasButton setAction:@selector(enableAntialias:)];
    [imageView setAntialiasing:NO];
    [self reschedule];
}

-(void)enableSupersample:(id)sender {
    [supersampleButton setToolTip:@"Enable Supersampling"];
    [supersampleButton setImage:[NSImage 
        imageNamed:@"SupersampleTTIcon"]];
    [supersampleButton setAlternateImage:[NSImage 
        imageNamed:@"SupersampleTTAIcon"]];
    [supersampleButton setAction:@selector(disableSupersample:)];
    [imageView setSupersampling:YES];
    [self reschedule];
}

-(void)disableSupersample:(id)sender {
    [supersampleButton setToolTip:@"Disable Supersampling"];
    [supersampleButton setImage:[NSImage 
        imageNamed:@"SupersampleTFIcon"]];
    [supersampleButton setAlternateImage:[NSImage 
        imageNamed:@"SupersampleTFAIcon"]];
    [supersampleButton setAction:@selector(enableSupersample:)];
    [imageView setSupersampling:NO];
    [self reschedule];
}

@end

@implementation MMPreview (WindowDelegate)

/*
- (void)windowDidUpdate:(NSNotification *)aNotification {
    if ([previewWindow isMiniaturized]) {
        [previewWindow setMiniwindowImage:[imageView image]];
    }
}
*/

@end
