//
//  MMNodeData.m
//
//  Created by Herbert P�tzl on Wed Mar 13 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  based on SimpleNodeData (c) 2001 by Apple Computer, Chuck Pisula
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMNodeData.h"

static NSString *MMGroupNodeTypeName = 		@"Group";		
static NSString *MMExpressionNodeTypeName = 	@"Expression";		
static NSString *MMUserValueNodeTypeName =	@"UserValue";		
static NSString *MMUserValueSetNodeTypeName =	@"UserValueSet";		
// static NSString *MMImageLinkTypeName =		@"ImageLink";		
static NSString *MMImageSettingsNodeTypeName =	@"ImageSettings";		
static NSString *MMReferenceNodeTypeName =	@"Reference";		
static NSString *MMUnknownNodeTypeName =	@"Unknown";		

static NSString *MMEmptyIconName = 		@"EmptyIcon";	
static NSString *MMMysteryIconName = 		@"MysteryIcon";	
static NSString *MMGroupIconName = 		@"GroupIcon";		
static NSString *MMExpressionIconName = 	@"ExpressionIcon";		
static NSString *MMImageLinkIconName = 		@"ImageLinkIcon";		
static NSString *MMReferenceIconName = 		@"ReferenceIcon";		
	
static NSString *MMUVEmptyIconName = 		@"UVEmptyIcon";		
static NSString *MMUVSetIconName = 		@"UVSetIcon";		
// static NSString *MMUVNumberIconName = 		@"UVNumberIcon";		
// static NSString *MMUVColorIconName = 		@"UVColorIcon";		
// static NSString *MMUVCurveIconName = 		@"UVCurveIcon";		
// static NSString *MMUVGradientIconName = 	@"UVGradientIcon";		
// static NSString *MMUVImageIconName = 		@"UVImageIcon";		


@implementation MMNodeData


+ (NSString *)nameForType:(MMNodeDataType)type
{
    NSString *name = nil;
    switch (type) {
    case MMGroupNodeType:
        name = MMGroupNodeTypeName;
    case MMExpressionNodeType:
        name = MMExpressionNodeTypeName;
    case MMUserValueNodeType:
        name = MMUserValueNodeTypeName;
    case MMUserValueSetNodeType:
        name = MMUserValueSetNodeTypeName;
    case MMImageSettingsNodeType:
        name = MMImageSettingsNodeTypeName;
    case MMReferenceNodeType:
        name = MMReferenceNodeTypeName;
    default:
        name = MMUnknownNodeTypeName;
    }
    NSAssert1(name, @"nameForType: %d", type);
    return name;
}

+ (NSImage *)iconForType:(MMNodeDataType)type
{
    NSImage *icon = nil;
    switch (type) {
    case MMGroupNodeType:
        icon = [NSImage imageNamed:MMGroupIconName];
        break;
    case MMExpressionNodeType:
        icon = [NSImage imageNamed:MMExpressionIconName];
        break;
    case MMUserValueNodeType:
        icon = [NSImage imageNamed:MMUVEmptyIconName];
        break;
    case MMUserValueSetNodeType:
        icon = [NSImage imageNamed:MMUVSetIconName];
        break;
    case MMImageSettingsNodeType:
        icon = [NSImage imageNamed:MMEmptyIconName];
        break;
    case MMReferenceNodeType:
        icon = [NSImage imageNamed:MMReferenceIconName];
        break;
    case MMImageLinkNodeType:
        icon = [NSImage imageNamed:MMImageLinkIconName];
        break;
    default:
        icon = [NSImage imageNamed:MMMysteryIconName];
        break;
    }
    NSAssert1(icon, @"IconForType: %d", type);
    return icon;
}


+ (id)nodeWithName:(NSString *)name
    type:(MMNodeDataType)type
    object:(id)object {
    return [[[MMNodeData alloc] 
        initWithName:name type:type object:object] 
            autorelease];
}


- (id)initWithName:(NSString *)name
    type:(MMNodeDataType)type
    object:(id)object {
    self = [super init];
    if (self) {
        _name = [name retain];
        _type = type;
        _object = [object retain];
        _isLeaf = (type != MMGroupNodeType);
        _icon = nil;
        _path = nil;
    }
    return self;
}

- (void)dealloc {
    [_name release];
    [_object release];
    [_icon release];
    [_path release];
    _name = nil;
    _icon = nil;
    [super dealloc];
}

- (void)setName:(NSString *)name {
    [name retain]; 
    [_name release]; 
    _name = name;
}

- (NSString*)name 		{ return _name; }

- (void)setObject:(id)object { 
    [object retain]; 
    [_object release]; 
    _object = object;
}

- (id)object 			{ return _object; }

- (BOOL)isLocked		{ return YES; }

    // fix me should check
- (BOOL)isValid			{ return YES; }

- (void)setPath:(NSString *)path { 
    [path retain]; 
    [_path release]; 
    _path = path;
}

- (id)path			{ return _path; }

- (void)setIsLeaf:(BOOL)value	{ _isLeaf = value; }

- (BOOL)isLeaf 			{ return _isLeaf; }
- (BOOL)isGroup 		{ return (_type == MMGroupNodeType); }

- (void)setIcon:(NSImage *)icon {
    NSAssert(icon != nil, @"Icon is nil");
    [icon retain];
    [_icon release]; 
    _icon = icon;
}

- (NSImage *)icon
{
    if (_icon == nil)
	_icon = [[MMNodeData iconForType: _type] retain];
    return _icon;
}

- (NSString*)description 	{ return _name; }

- (MMNodeDataType)type		{ return _type; }


- (NSComparisonResult)compare:(TreeNodeData *)other {
    return [_name compare: [(MMNodeData *)other name]];
}

@end

