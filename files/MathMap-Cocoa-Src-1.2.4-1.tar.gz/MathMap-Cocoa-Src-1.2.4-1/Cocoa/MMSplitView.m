//
//  MMSplitView.m
//
//  Created by Herbert P�tzl on Mon Mar 25 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMSplitView.h"

#import "NSExtensions.h"

@implementation MMSplitView


- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self registerKeyWindowNotification];
        _isVertical = NO;
    }
    return self;
}

- (void)dealloc {
    [self unregisterKeyWindowNotification];
    [super dealloc];
}

- (void)keyWindowNotification:(NSNotification *)notif {
    [self setNeedsDisplay:YES];
}


-(void)awakeFromNib {
    [self setFrame:[self frame]];
}

- (BOOL)isFlipped			{ return YES; }

- (BOOL)isVertical			{ return _isVertical; }
- (void)setVertical:(BOOL)flag		{ _isVertical = flag; }


- (void)drawDividerInRect:(NSRect)aRect {
    NSRect firstLine, secondLine;
    NSRect innerRect;

    if (_isVertical) {
        NSDivideRect(aRect, &firstLine, &innerRect, 1, NSMinXEdge);
        NSDivideRect(innerRect, &secondLine, &innerRect, 1, NSMaxXEdge);
    } else {
        NSDivideRect(aRect, &firstLine, &innerRect, 1, NSMinYEdge);
        NSDivideRect(innerRect, &secondLine, &innerRect, 1, NSMaxYEdge);
    }
    [[NSColor darkGrayColor] set];
    NSRectFill(firstLine);
    NSRectFill(secondLine);
    NSDrawWindowBackground(innerRect);
}

- (NSRect)dividerRectAt:(int)index {
    NSRect subviewFrame = [[[self subviews] 
        objectAtIndex:index] frame];
    NSRect dividerRect = subviewFrame;

    if (_isVertical) {
        dividerRect.origin.x = NSMaxX(subviewFrame);
        dividerRect.size.width = [self dividerThickness];
    } else {
        dividerRect.origin.y = NSMaxY(subviewFrame);
        dividerRect.size.height = [self dividerThickness];
    }
    return dividerRect;
}

- (void)drawRect:(NSRect)rect {
    int index, count = [[self subviews] count];
    
    for (index=0; index<(count-1); index++) {
        NSRect dividerRect = [self dividerRectAt:index];
        if (NSIntersectsRect(rect, dividerRect)) {
            [self drawDividerInRect:dividerRect];
        }
    }
}


- (float)dividerThickness 		{ return 8.0; }

- (void)setFrame:(NSRect)frameRect {
    NSRect oldFrame = [self frame];
    [super setFrame:frameRect];

    if ([delegate respondsToSelector:
        @selector(mmsplitView:resizeSubviewsWithOldSize:)]) {
	[delegate mmsplitView:self 
            resizeSubviewsWithOldSize:oldFrame.size];
    }
}


- (void)setDelegate:(id)object {
//    [object retain];
//    [delegate release];
    delegate = object;
}

- (id)delegate		{ return delegate; }


- (void)mouseDown:(NSEvent *)theEvent
{
    int index, count = [[self subviews] count];
    NSPoint mouseLoc, mouseDown;
    NSRect unionRect, boundsRect;
    NSRect firstRect, secondRect, dividerRect;
    NSView *firstView = nil, *secondView = nil;
    float oldPosition = 0.0, proposedPosition;
    BOOL keepOn = NO;
    BOOL isInside = YES;

    boundsRect = [self bounds];
    mouseDown = [self convertPoint:[theEvent 
        locationInWindow] fromView:nil];
    for (index=0; index<(count-1); index++) {
        NSRect dividerRect = [self dividerRectAt:index];
            
        if ([self  mouse:mouseDown inRect:dividerRect]) {
            oldPosition = _isVertical?NSMinX(dividerRect):NSMinY(dividerRect);
            firstView = [[self subviews] objectAtIndex:index];
            secondView = [[self subviews] objectAtIndex:index+1];
            unionRect = NSIntersectionRect(NSUnionRect(
                [firstView frame], [secondView frame]), 
                [self bounds]);
            keepOn = YES;
            break;
        }
    }

    while (keepOn) {
        theEvent = [[self window] nextEventMatchingMask: 
            NSLeftMouseUpMask | NSLeftMouseDraggedMask];
        mouseLoc = [self convertPoint:[theEvent 
            locationInWindow] fromView:nil];
        isInside = [self mouse:mouseLoc inRect:boundsRect];

        proposedPosition = oldPosition +
            (_isVertical?
                (mouseLoc.x - mouseDown.x):
                (mouseLoc.y - mouseDown.y));
        // constraints would go here ...

        switch ([theEvent type]) {
        case NSLeftMouseDragged:
            if ([delegate respondsToSelector:
                @selector(mmsplitView:constrainSplitPosition:ofSubviewAt:)]) {
                proposedPosition = [delegate mmsplitView:self 
                    constrainSplitPosition:proposedPosition 
                    ofSubviewAt:index];
            }
            proposedPosition = MIN(MAX(0, proposedPosition),
                ((_isVertical?NSWidth(unionRect):NSHeight(unionRect)) 
                    - [self dividerThickness]));
            NSDivideRect (unionRect, &firstRect, &secondRect, 
                proposedPosition, _isVertical?NSMinXEdge:NSMinYEdge);
            NSDivideRect (secondRect, &dividerRect, &secondRect, 
                [self dividerThickness], _isVertical?NSMinXEdge:NSMinYEdge);
            [firstView setFrame:firstRect];
            [secondView setFrame:secondRect];
            if ([delegate respondsToSelector:
                @selector(mmsplitView:resizeSubviewsWithOldSize:)]) {
                [delegate mmsplitView:self 
                    resizeSubviewsWithOldSize:boundsRect.size];
            }
            [self setNeedsDisplayInRect:[self dividerRectAt:index]];
            break;
        case NSLeftMouseUp:
            keepOn = NO;
        default:
            break;
        }
    }
}


@end



/*

// tab view style divider ...

- (void)drawDividerInRect:(NSRect)aRect {
    static unsigned char colorGradientData[] =
        {  11,  83, 174, 0,
          164, 196, 230, 0,
          183, 210, 239, 0,
          120, 174, 235, 0,
          156, 207, 255, 0,
           11,  83, 174, 0 };
    static unsigned char grayGradientData[] =
        { 135, 135, 135, 0,
          218, 218, 218, 0, 
          227, 227, 227, 0,
          210, 210, 210, 0,
          239, 239, 239, 0,
          135, 135, 135, 0 };
    unsigned char *colorGradient[5] = {colorGradientData, 0,0,0,0 };
    unsigned char *grayGradient[5] = {grayGradientData, 0,0,0,0 };
    
    if ([[self window] isKeyWindow]) {
        NSDrawBitmap(aRect, 6, 1, 8, 3, 32, 0, NO, NO,
            NSDeviceRGBColorSpace, colorGradient);
    } else {
        NSDrawBitmap(aRect, 6, 1, 8, 3, 32, 0, NO, NO,
            NSDeviceRGBColorSpace, grayGradient);
    }
}
*/

