//
//  Doc_Extensions.h
//
//  Created by Herbert P�tzl on Thu Mar 28 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import <Cocoa/Cocoa.h>


@interface NSData (PropertyList)

+ (NSData *)dataWithPropertyList:(id)propertyList;

- (id)propertyList;

@end


@interface NSData (RTFExtensions)

+ (NSData *)RTFWithString:(NSString *)string;

- (BOOL)isAttributedRTF;

@end


@interface NSString (RTFExtensions)

+ (NSString *)stringWithRTF:(NSData *)data;

@end


@interface NSTextView (SyntaxHighlighting)

- (void)highlightWithColors:(NSArray *)colors;

@end


@interface NSColor (CheckerBoard) 

+ (NSColor *)checkerBoard;

@end


@interface NSImage (RGBAConversion) 

- (NSBitmapImageRep *)properBitmapImageRep;

@end


@interface NSView (Extensions)

- (void)registerKeyWindowNotification;
- (void)unregisterKeyWindowNotification;
- (void)keyWindowNotification:(NSNotification *)notif;

@end


@interface NSArray (Extensions)
- (BOOL)containsObjectIdenticalTo: (id)object;
@end

@interface NSMutableArray (Extensions)
- (void) insertObjectsFromArray:(NSArray *)array atIndex:(int)index;
@end


