//
//  UVCurveEditor.m
//
//  Created by Herbert P�tzl on Fri Mar 15 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "UVCurveEditor.h"

#import "CurveView.h"

@interface UVCurveEditor (Private)

- (void)recalcMinSize;

@end


@implementation UVCurveEditor

- (void)configureForCurve {
    [editorCurveView setFillsArea:NO];
    [editorCurveView setAllowsReorder:NO];
    [editorCurveView setIsExpanded:YES];
    [editorCurveView setComponents:1];
    _type = MMCurveUserValueType;
}

- (void)configureForGradient {
    [editorCurveView setFillsArea:YES];
    [editorCurveView setAllowsReorder:YES];
    [editorCurveView setIsExpanded:NO];
    [editorCurveView setComponents:4];
    _type = MMGradientUserValueType;
}

- (MMUserValueType)type			{ return _type; }

- (void)recalcMinSize {
    NSRect cvRect = [editorCurveView frame];
    _minSize.height = NSMinY(cvRect)*2 + NSHeight(cvRect);
}

- (void)curveView:(CurveView *)view 
    didAdjustSize:(NSSize)oldSize {
    NSView *superview = [self superview];
    NSRect frame = [self frame];
    NSSize oldMinSize = _minSize;

    [self recalcMinSize];
    if ([superview respondsToSelector:
        @selector(editor:didChangeMinSize:)]) {
        [superview editor:self 
            didChangeMinSize:oldMinSize];
    }
    frame.size.height = _minSize.height;
    [self setFrameSize:frame.size];
    [self setNeedsDisplay:YES];
}

- (void)update
{
    [editorCurveView setCurve:[_userValue curve]];
    [super update];
}



@end


@implementation UVCurveEditor (ValueUpdate)

- (IBAction)takeCurveFrom:(id)sender {
        // curve is shared ...
    [self modified];
}

@end


@implementation UVCurveEditor (NSCoding)

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
    [coder encodeConditionalObject:editorCurveView];
    [coder encodeConditionalObject:editorExpandButton];
    [coder encodeConditionalObject:editorSplineButton];
    [coder encodeValueOfObjCType:@encode(MMUserValueType) at:&_type];
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    editorCurveView = [[coder decodeObject] retain];
    editorExpandButton = [[coder decodeObject] retain];
    editorSplineButton = [[coder decodeObject] retain];
    [coder decodeValueOfObjCType:@encode(MMUserValueType) at:&_type];
        // why is this necessary?
    [editorCurveView setTarget:self];
    [editorCurveView setAction:@selector(takeCurveFrom:)];
    [self recalcMinSize];
    return self;
}

@end

