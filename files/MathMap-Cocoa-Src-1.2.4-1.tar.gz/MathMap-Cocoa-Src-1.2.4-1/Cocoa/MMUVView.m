//
//  MMUVView.m
//
//  Created by Herbert Pötzl on Thu Mar 07 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMUVView.h"

#define	DESCRIPTION_WIDTH	100.0
#define	HEADER_HEIGHT		 16.0

NSString *	UserValueSetModifiedNotification  = @"UserValueSetModifiedNotification";

@implementation MMUVView

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _userValueMatrix = [[MMUVMatrix alloc] initWithFrame:frame];
        [_userValueMatrix setAutoresizingMask:NSViewWidthSizable];

        _scrollView = [[NSScrollView alloc] initWithFrame:frame];
        [_scrollView setDocumentView:[_userValueMatrix autorelease]];
        [_scrollView setHasHorizontalScroller:NO];
        [_scrollView setHasVerticalScroller:YES];
        [_scrollView setDrawsBackground:YES];
        
        _headerCell = [[NSTableHeaderCell alloc] initTextCell:@"Text"];
        
        [self addSubview:[_scrollView autorelease]];
        _descriptionWidth = DESCRIPTION_WIDTH;
        [self recalcLayout];
        
        [[NSNotificationCenter defaultCenter] 
            addObserver:self 
            selector:@selector(userValueModified:) 
            name:UserValueModifiedNotification 
            object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] 
        removeObserver:self 
        name:UserValueModifiedNotification 
        object:nil];
    [_headerCell release];
    [super dealloc];
}

- (void)setFrame:(NSRect)frameRect
{
    [super setFrame:frameRect];
    [self recalcLayout];
}

- (BOOL)isFlipped 	{ return YES; }

- (void)drawRect:(NSRect)rect {
    NSRect descFrame, valueFrame;

    NSDivideRect(_headerRect, &descFrame, &valueFrame, 
        _descriptionWidth, NSMinXEdge);
                    
    [_headerCell setStringValue:@"Name/Type"];
    [_headerCell drawWithFrame:descFrame inView:self];
    [_headerCell setStringValue:@"Current Value"];
    [_headerCell drawWithFrame:valueFrame inView:self];
        
    [_scrollView drawRect:[self 
        convertRect:rect toView:_scrollView]];

}

- (void)setDelegate:(id)object {
    [object retain];
    [delegate release];
    delegate = object;
}

- (id)delegate		{ return delegate; }

- (void)setUserValues:(NSArray *)userValues {
    [_userValueMatrix setUserValues:userValues];
    [self setNeedsDisplay:YES];
}

- (NSArray *)userValues		{ return [_userValueMatrix userValues]; }

- (void)recalcLayout {
    NSRect scrollRect;
    NSSize headerSize = [_headerCell cellSize];

    NSDivideRect([self bounds], &_headerRect, &scrollRect, 
        MIN(HEADER_HEIGHT, headerSize.height), NSMinYEdge);
    [_scrollView setFrame:scrollRect];
}

- (void)resetUserValues {
    BOOL doIt = YES;
    if ([delegate respondsToSelector:
        @selector(userValueView:shouldResetUserValues:)]) {
        doIt = [delegate userValueView:self 
            shouldResetUserValues:[_userValueMatrix userValues]];
    }
    if (doIt) {
        [_userValueMatrix resetUserValues];
        [[NSNotificationCenter defaultCenter]
            postNotificationName:UserValueSetModifiedNotification 
            object:self
            userInfo:[NSDictionary 
                dictionaryWithObjectsAndKeys:
                [_userValueMatrix userValues], @"UserValues",
                nil]];
    }
    if ([delegate respondsToSelector:
        @selector(userValueView:didResetUserValues:)]) {
        [delegate userValueView:self 
            didResetUserValues:[_userValueMatrix userValues]];
    }
}

- (void)userValueModified:(NSNotification *)notif {
//    NSLog(@"user value changed ... ");
    if ([[_userValueMatrix userValues] 
        containsObject:[notif object]]) {
//        NSLog(@"set changed notif ... ");
        [[NSNotificationCenter defaultCenter]
            postNotificationName:UserValueSetModifiedNotification 
            object:self
            userInfo:[NSDictionary 
                dictionaryWithObjectsAndKeys:
                [notif object], @"UserValue",
                [_userValueMatrix userValues], @"UserValues",
                nil]];
    }
}

@end
