//
//  AuxHelper.m
//
//  Created by Herbert P�tzl on Sat Mar 30 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "AuxHelper.h"

@implementation AuxHelper

+ (AuxHelper *)globalHelper 
{
    static AuxHelper *_globalHelper = nil;

    if (!_globalHelper) {
        _globalHelper = [[self alloc] init];
    }
    return _globalHelper;
}

+ (AuxHelper *)helper {
    return [[[AuxHelper alloc] init] autorelease];
}


- (id)init 
{
    self = [super init];
    if (self) {
        [NSBundle loadNibNamed:@"AuxViews" owner:self];
        [exportImageAuxView retain];
        [exportMovieAuxView retain];
        return self;
    }
    return self;
}

- (void)dealloc {
    [exportImageAuxView release];
    [exportMovieAuxView release];
    [auxViewsWindow release];
    [super dealloc];
}

- (NSSavePanel *)exportImageSavePanel {
    NSSavePanel *panel = [NSSavePanel savePanel];
    [panel setAccessoryView:exportImageAuxView];
    [panel setPrompt:@"Export"];
    [panel setRequiredFileType:@"tiff"];
    [panel setTitle:@"Export TIFF Image"];

    return panel;
}

- (int)exportImageWidth 	 { return [exportImageWidthTextField intValue]; }
- (int)exportImageHeight 	 { return [exportImageHeightTextField intValue]; }

- (BOOL)exportImageSupersampling { return [exportImageSupersamplingButton state]; }
- (BOOL)exportImageAntialiasing  { return [exportImageAntialiasingButton state]; }

- (NSSavePanel *)exportMovieSavePanel {
    NSSavePanel *panel = [NSSavePanel savePanel];
    [panel setAccessoryView:exportMovieAuxView];
    [panel setPrompt:@"Export"];
    [panel setRequiredFileType:@"mov"];
    [panel setTitle:@"Export QuickTime(tm) Movie"];
    return panel;
}

- (int)exportMovieWidth 	 { return [exportMovieWidthTextField intValue]; }
- (int)exportMovieHeight 	 { return [exportMovieHeightTextField intValue]; }
- (int)exportMovieFrames 	 { return [exportMovieFramesTextField intValue]; }

- (BOOL)exportMovieSupersampling { return [exportMovieSupersamplingButton state]; }
- (BOOL)exportMovieAntialiasing  { return [exportMovieAntialiasingButton state]; }
- (BOOL)exportMovieLooping  	 { return [exportMovieLoopingButton state]; }


@end
