//
//  PropertyList.m
//
//  Created by Herbert Pötzl on Sat Mar 16 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Foundation/Foundation.h>

#import "PropertyList.h"

#import "Curve.h"
#import "MMTreeNode.h"
#import "MMNodeData.h"
#import "MMUserValue.h"

#import "NSExtensions.h"
#import "UserDefaults.h"


@implementation Curve	(PropertyList)

+ (Curve *)curveWithPropertyList:(id)propertyList {
    if ([propertyList isKindOfClass: [NSDictionary class]]) {
        NSDictionary *dict = (NSDictionary *)propertyList;
        NSArray *vectors = [dict objectForKey:@"vectors"];
        NSEnumerator *vectorEnum = [vectors objectEnumerator];
        NSArray *vector;
        Curve *curve = [Curve curve];
        
        while ((vector = [vectorEnum nextObject])) {
            Vector5D vec;
            int index;
            
            for (index=0; index<5; index++) {
                vec.v[index] = [[vector 
                    objectAtIndex:index] floatValue];
            }
            [curve addVector:vec];
        }
        [curve setInterpolationType:
            [[dict objectForKey:@"interpolation"]
                intValue]];
        return curve;
    } else {
        NSAssert(0, @"PL: not supported ...");
    }
    return nil;
}


- (id)propertyList {
    CurvePoint *cp = _curvePoints;
    NSMutableArray *vectors = [NSMutableArray 
        arrayWithCapacity:_numPoints];
    NSMutableArray *vector;
    
    while (cp) {
        int index;
        vector = [NSMutableArray arrayWithCapacity:5];
        
        for (index=0; index<5; index++) {
            [vector addObject:[[NSNumber 
                numberWithFloat:cp->vector.v[0]]
                stringValue]];
        }
        [vectors addObject:vector];
        cp = cp->next;
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:
        [[NSNumber numberWithInt:_interpol] 
            stringValue], @"interpolation",
        vectors, @"vectors", nil];
}


@end



@implementation MMTreeNode (PropertyList)


+ (MMTreeNode *)treeFromPropertyList:(id)propertyList {
    MMTreeNode *tree = nil;
    if ([propertyList isKindOfClass: [NSDictionary class]]) {
        tree = [MMTreeNode treeFromDictionary: propertyList];
    } else if ([propertyList isKindOfClass: [NSArray class]]) {
        tree = [MMTreeNode treeFromArray: propertyList];
    } else if ([propertyList isKindOfClass: [NSString class]]) {
        tree = [MMTreeNode referenceNodeWithPath: propertyList];
    } else {
        tree = [MMTreeNode containerNodeWithProperty: propertyList];
    }
    return tree;
}

+ (NSArray *)nodesFromPropertyList:(id)propertyList {
    if ([propertyList isKindOfClass: [NSArray class]]) {
        NSMutableArray *nodes = [NSMutableArray array];
        NSEnumerator *nodeEnum = [propertyList objectEnumerator];
        id entry;
        while ((entry = [nodeEnum nextObject])) {
            [nodes addObject:[MMTreeNode 
                treeFromPropertyList:entry]];
        }
        return nodes;
    } else { 
        return [NSArray arrayWithObject:
            [MMTreeNode treeFromPropertyList:propertyList]];
    }
    return nil;
}

- (id)propertyList {
    MMNodeData *data = (MMNodeData *)[self nodeData];
    NSMutableDictionary *dict = 
        [NSMutableDictionary dictionaryWithDictionary:[data object]];
    if ([self numberOfChildren]) 
        [dict setObject:[self children] forKey:EntriesKey]; 
    [dict setObject:[data name] 
        forKey:([data type] == MMGroupNodeType) ?
            GroupNameKey : EntryNameKey]; 
    if (_infoRTF) {
        if (![_infoRTF isEqual:[MMTreeNode defaultInfoRTF]]) {
            if ([_infoRTF isAttributedRTF]) {
                [dict setObject:_infoRTF forKey:InfoRTFKey];
            } else { 
                [dict setObject:[NSString stringWithRTF:_infoRTF] 
                    forKey:InfoRTFKey]; 
            }
        }
    }
    if ([data path]) {
        [dict setObject:[data path] forKey:EntryPathKey]; 
    }
    return dict;
}

@end




@implementation MMUserValue (PropertyList)

- (id)valuePropertyList {
    switch ([self type]) {
    case MMIntUserValueType:
    case MMFloatUserValueType:
        return [[NSNumber numberWithFloat:
            [self floatValue]] stringValue];
        break;
    case MMBoolUserValueType:
        return [[NSNumber numberWithBool:
            [self boolValue]] stringValue];
        break;
    case MMColorUserValueType:
        return [[self color] propertyList];
        break;
    case MMCurveUserValueType:
    case MMGradientUserValueType:
        return [[self curve] propertyList];
        break;
    default:
        return @"[Undescribeable]";
        break;
    }
}

- (id) propertyList {
    NSDictionary *dict = [NSDictionary 
        dictionaryWithObjectsAndKeys:
            _name, EntryNameKey,
            UserValueEntryKind, EntryKindKey,
            [self typeName], ValueTypeKey,
            [self valuePropertyList], ValueKey,
            nil];
    return dict;
}

+ (MMUserValue *)userValueWithPropertyList:(id)propertyList {
    if ([propertyList isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dict = (NSDictionary *)propertyList;
        MMUserValueType type = [MMUserValue 
            typeForName:[(NSDictionary *)propertyList
                objectForKey:ValueTypeKey]];
        MMUserValue *value = [[MMUserValue alloc]
            initWithName:[dict objectForKey:EntryNameKey]
            type:type string:[dict objectForKey:ValueKey]];
        return [value autorelease];
/*  } else if ([propertyList isKindOfClass:[NSString class]]) {
        return [MMUserValue userValueWithPropertyList:
            [(NSString *)propertyList propertyList]];
*/  } else {
        NSAssert(0, @"PL: not supported ...");
    }
    return nil;
}

@end



@implementation NSArray (PropertyList)

+ (NSArray *)usetValueSetWithPropertyList:(id)propertyList {
    if ([propertyList isKindOfClass:[NSArray class]]) {
        NSEnumerator *enumerator = 
            [propertyList objectEnumerator];
        NSMutableArray *array = [NSMutableArray 
            arrayWithCapacity:[propertyList count]];
        NSDictionary *entry;
            
        while ((entry = [enumerator nextObject])) {
            [array addObject:[MMUserValue 
                userValueWithPropertyList:entry]];
        }
        return array;
/*  } else if ([propertyList isKindOfClass:[NSString class]]) {
        return [NSArray usetValueSetWithPropertyList:
            [(NSString *)propertyList propertyList]];
*/  } else {
        NSAssert(0, @"NSArray PL: not supported ...");
    }
    return nil;
}

- (id)userValueSetPropertyList {
    NSDictionary *dict;
    MMUserValue *entry = nil;
    NSEnumerator *enumerator = [self objectEnumerator];
    NSMutableArray *array = [NSMutableArray 
        arrayWithCapacity:[self count]];

    while ((entry = [enumerator nextObject])) {
        [array addObject:[entry propertyList]];
    }

    dict = [NSDictionary dictionaryWithObjectsAndKeys:
        [[NSUserDefaults standardUserDefaults] 
            stringForKey:UserValueSetLabelDefault], 
        EntryNameKey,
        UserValueSetEntryKind, EntryKindKey,
        array, EntriesKey,
        nil];
    return dict;
}

@end


@implementation NSColor (PropertyList)

+ (NSColor *)colorWithPropertyList:(id)propertyList {
    if ([propertyList isKindOfClass:[NSArray class]]) {
        NSArray *array = (NSArray *)propertyList;
        float red, green, blue, alpha = 0;
        if ([array count] >= 3) {
            red = [[array objectAtIndex:0] floatValue];
            green = [[array objectAtIndex:1] floatValue];
            blue = [[array objectAtIndex:2] floatValue];
            if ([array count] >= 4) {
                alpha = [[array objectAtIndex:3] floatValue];
            }
        } else {
            red = 0.0; green = 0.0;
            blue = 0.0; alpha = 0.0;
        } 
        return [NSColor colorWithDeviceRed:red 
            green:green blue:blue alpha:alpha];
/*  } else if ([propertyList isKindOfClass:[NSString class]]) {
        return [NSArray userValueSetWithPropertyList:
            [(NSString *)propertyList propertyList]];
*/  } else {
        NSAssert(0, @"PL: not supported ...");
    }
    return nil;
}

- (id)propertyList {
    NSArray *array;
    float red, green, blue, alpha;

    [[self colorUsingColorSpaceName:NSDeviceRGBColorSpace]
        getRed:&red green:&green blue:&blue alpha:&alpha];
    array = [NSArray arrayWithObjects:
        [[NSNumber numberWithFloat:red] stringValue],
        [[NSNumber numberWithFloat:green] stringValue],
        [[NSNumber numberWithFloat:blue] stringValue],
        [[NSNumber numberWithFloat:alpha] stringValue],
        nil];
    return array;
}

@end

