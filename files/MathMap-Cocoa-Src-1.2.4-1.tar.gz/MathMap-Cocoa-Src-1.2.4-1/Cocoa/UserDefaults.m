//
//  UserDefaults.m
//
//  Created by Herbert P�tzl on Sun Mar 31 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Foundation/Foundation.h>

#import "UserDefaults.h"

    //	Library Defaults

NSString *	LibraryCommentSizeDefault =	@"LibraryCommentSize";	
NSString *	LibraryPathDefault =		@"LibraryPath";	
NSString *	LibraryCompositeDefault =	@"LibraryComposite";	
NSString *	LibraryLockedDefault =		@"LibraryLocked";	

NSString *	LibraryPathDValue = 		@"~/Library/MathMap/Library.mml";
NSString *	LibraryCompositeDValue = 	@"0";
NSString *	LibraryLockedDValue = 		@"0";

    //	Expression Defaults

NSString *	ExpressionCheckDefault =	@"ExpressionCheck";	
NSString *	ExpressionHighlightDefault =	@"ExpressionHighlight";	
NSString *	ExpressionLabelDefault =	@"ExpressionLabel";	
NSString *	ExpressionCommentDefault =	@"ExpressionComment";	

NSString *	ExpressionCheckDValue = 	@"1";
NSString *	ExpressionHighlightDValue = 	@"1";
NSString *	ExpressionLabelDValue =		@"Expression";	
NSString *	ExpressionCommentDValue =	@"";	

    //	UserValueSet Defaults

NSString *	UserValueSetLabelDefault =	@"UserValueSetLabel";	
NSString *	UserValueSetCommentDefault =	@"UserValueSetComment";	

NSString *	UserValueSetLabelDValue =	@"ValueSet";	
NSString *	UserValueSetCommentDValue =	@"";	

    //	Preview Defaults

NSString *	PreviewAutoUpdateDefault =	@"PreviewAutoUpdate";	
NSString *	PreviewAutoUpdateDValue =	@"1";	


    //	First Time Default

NSString *	FirstTimeDefault =		@"FirstTimeLaunch";	
NSString *	FirstTimeDValue =		@"1";	
