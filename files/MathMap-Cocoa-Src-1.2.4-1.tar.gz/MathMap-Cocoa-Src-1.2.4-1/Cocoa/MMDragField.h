//
//  MMDragField.h
//
//  Created by Herbert P�tzl on Fri Mar 15 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import <AppKit/AppKit.h>

#import "MMDragField.h"

@class ImageAndTextCell;

@interface MMDragField : NSControl {
    IBOutlet id delegate;

    ImageAndTextCell *_contentsCell;
    NSString *_name;
    NSImage *_icon;
    id _object;
}

- (void)setDelegate:(id)object;
- (id)delegate;

- (void)setObject:(id)object;
- (id)object;

- (void)setName:(NSString *)name;
- (NSString *)name;

- (void)setIcon:(NSImage *)icon;
- (NSImage *)icon;

@end

@interface NSObject (DragFieldDelegate)

- (BOOL)dragField:(MMDragField *)dragField 
    writeObject:(id)object 
    toPasteboard:(NSPasteboard *)pboard;

@end

