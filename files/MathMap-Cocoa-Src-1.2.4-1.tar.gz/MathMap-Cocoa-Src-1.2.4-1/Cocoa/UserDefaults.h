//
//  UserDefaults.h
//
//  Created by Herbert P�tzl on Sun Mar 31 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Foundation/Foundation.h>

extern	NSString *	LibraryCommentSizeDefault;	
extern	NSString *	LibraryPathDefault;	
extern	NSString *	LibraryCompositeDefault;	
extern	NSString *	LibraryLockedDefault;	

extern	NSString *	LibraryPathDValue;
extern	NSString *	LibraryCompositeDValue;
extern	NSString *	LibraryLockedDValue;

    //	Expression Defaults

extern	NSString *	ExpressionCheckDefault;	
extern	NSString *	ExpressionHighlightDefault;	
extern	NSString *	ExpressionLabelDefault;	
extern	NSString *	ExpressionCommentDefault;	

extern	NSString *	ExpressionCheckDValue;
extern	NSString *	ExpressionHighlightDValue;
extern	NSString *	ExpressionLabelDValue;	
extern	NSString *	ExpressionCommentDValue;	

    //	UserValueSet Defaults

extern	NSString *	UserValueSetLabelDefault;	
extern	NSString *	UserValueSetCommentDefault;	

extern	NSString *	UserValueSetLabelDValue;	
extern	NSString *	UserValueSetCommentDValue;	

    //	Preview Defaults

extern	NSString *	PreviewAutoUpdateDefault;	
extern	NSString *	PreviewAutoUpdateDValue;	

    //	First Time Default

extern	NSString *	FirstTimeDefault;	
extern	NSString *	FirstTimeDValue;	
