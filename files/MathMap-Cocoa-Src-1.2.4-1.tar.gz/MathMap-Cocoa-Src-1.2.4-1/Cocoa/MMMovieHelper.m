#import <QuickTime/QuickTime.h>
#import <Cocoa/Cocoa.h>
#import <unistd.h>
#import <fcntl.h>

#import "MMInvocation.h"

//////////
//
// QTUtils_ConvertCToPascalString
// Convert a C string into a Pascal string.
//
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////

static StringPtr QTUtils_ConvertCToPascalString (char *theString)
{
	StringPtr	myString = malloc(strlen(theString) + 1);
	short		myIndex = 0;

	while (theString[myIndex] != '\0') {
		myString[myIndex + 1] = theString[myIndex];
		myIndex++;
	}
	
	myString[0] = (unsigned char)myIndex;
	
	return(myString);
}

int
make_fsspec_from_filename (char *name, FSSpec *spec)
{
    CFURLRef urlref;
    FSRef fsref;
    int fd;

    fd = open(name, O_WRONLY | O_CREAT, 0666);
    if (fd == -1)
        return 0;
    close(fd);

    urlref = CFURLCreateWithFileSystemPath(kCFAllocatorDefault, CFStringCreateWithCString(NULL, name, CFStringGetSystemEncoding()), kCFURLPOSIXPathStyle, FALSE);
    if (urlref == NULL)
        return 0;
    printf("%s\n", CFStringGetCStringPtr(CFURLGetString(urlref), CFStringGetSystemEncoding()));
    if (!CFURLGetFSRef(urlref, &fsref))
        return 0;
    FSGetCatalogInfo(&fsref, kFSCatInfoNone, NULL, NULL, spec, NULL);

    unlink(name);

    return 1;
}

int
render_movie_to_file (MMInvocation *invocation, int num_frames, int fps, BOOL periodic, char *filename)
{
    static int did_init = 0;

    NSBitmapImageRep *imageRep = [invocation imageRep];
    NSSize size = [imageRep size];
    int width = size.width, height = size.height;
    Rect trackFrame = {0,0,0,0};
    Movie theMovie = nil;
    FSSpec mySpec;
    short resRefNum = 0;
    short resId = movieInDataForkResID;
    OSErr err = noErr;

    if (!did_init)
    {
        EnterMovies();
        did_init = 1;
    }

    trackFrame.right = width;
    trackFrame.bottom = height;

    if (!make_fsspec_from_filename(filename, &mySpec))
        return 0;

    err = CreateMovieFile (&mySpec, 
			   FOUR_CHAR_CODE('TVOD'),
			   smCurrentScript, 
			   createMovieFileDeleteCurFile | createMovieFileDontCreateResFile,
			   &resRefNum, 
			   &theMovie );
    if (err != noErr || theMovie == nil)
        return 0;

    {
	Track theTrack;
	Media theMedia;

	// 1. Create the track
	theTrack = NewMovieTrack (theMovie, 		/* movie specifier */
				  FixRatio(width,1),  /* width */
				  FixRatio(height,1), /* height */
				  kNoVolume);  /* trackVolume */
	if (GetMoviesError() != noErr)
            return 0;

	// 2. Create the media for the track
	theMedia = NewTrackMedia (theTrack,		/* track identifier */
				  VideoMediaType,		/* type of media */
				  fps, 	/* time coordinate system */
				  nil,	/* data reference - use the file that is associated with the movie  */
				  0);		/* data reference type */
	if (GetMoviesError() != noErr)
            return 0;

	// 3. Establish a media-editing session
	err = BeginMediaEdits (theMedia);
	if (err != noErr)
            return 0;

	// 3a. Add Samples to the media
	{
	    GWorldPtr theGWorld = nil;
	    long maxCompressedSize;
	    long curSample;
	    Handle compressedData = nil;
	    Ptr compressedDataPtr;
	    ImageDescriptionHandle imageDesc = nil;
	    CGrafPtr oldPort;
	    GDHandle oldGDeviceH;
            
	    // Create a graphics world
	    err = NewGWorld (&theGWorld,	/* pointer to created gworld */	
			     32,		/* pixel depth */
			     &trackFrame, 		/* bounds */
			     nil, 			/* color table */
			     nil,			/* handle to GDevice */ 
			     (GWorldFlags)0);	/* flags */
	    if (err != noErr)
                return 0;
        
	    // Lock the pixels
	    LockPixels (GetGWorldPixMap(theGWorld)/*GetPortPixMap(theGWorld)*/);
        
	    // Determine the maximum size the image will be after compression.
	    // Specify the compression characteristics, along with the image.
	    err = GetMaxCompressionSize(GetGWorldPixMap(theGWorld),		/* Handle to the source image */
					&trackFrame, 				/* bounds */
					32, 					/* let ICM choose depth */
					codecNormalQuality,				/* desired image quality */ 
					kAnimationCodecType,			/* compressor type */ 
					(CompressorComponent)anyCodec,  		/* compressor identifier */
					&maxCompressedSize);		    	/* returned size */
	    if (err != noErr)
                return 0;
        
	    // Create a new handle of the right size for our compressed image data
	    compressedData = NewHandle(maxCompressedSize);
	    if (MemError() != noErr)
                return 0;
        
	    MoveHHi( compressedData );
	    HLock( compressedData );
	    compressedDataPtr = *compressedData;
        
	    // Create a handle for the Image Description Structure
	    imageDesc = (ImageDescriptionHandle)NewHandle(4);
	    if (MemError() != noErr)
                return 0;
        
	    // Change the current graphics port to the GWorld
	    GetGWorld(&oldPort, &oldGDeviceH);
	    SetGWorld(theGWorld, nil);
        
	    // For each sample...
	    for (curSample = 0; curSample < num_frames; curSample++) 
	    {
		[invocation setTimeValue: (float)curSample / (float)num_frames];
		[invocation render];

		// do the drawing of our image
		{
		    PixMapHandle 	pixMapHandle;
		    Ptr 		pixBaseAddr;
		    Ptr bitMapDataPtr = [imageRep bitmapData];
                    
		    // Lock the pixels
		    pixMapHandle = GetGWorldPixMap(theGWorld);
		    LockPixels (pixMapHandle);
		    pixBaseAddr = GetPixBaseAddr(pixMapHandle);

		    if ((bitMapDataPtr == nil) || (pixBaseAddr == nil))
                        return 0;

		    {
			int i,j;
			int pixmapRowBytes = GetPixRowBytes(pixMapHandle);
                            
			for (i=0; i< height; i++)
			{
			    unsigned char *src = bitMapDataPtr + i * [imageRep bytesPerRow];
			    unsigned char *dst = pixBaseAddr + i * pixmapRowBytes;
			    for (j = 0; j < width; j++)
			    {
				*dst++ = 0;		// X - our src is 24-bit only
				*dst++ = *src++;	// Red component
				*dst++ = *src++;	// Green component
				*dst++ = *src++;	// Blue component           
				++src;		// skip source alpha
			    }
			}
		    }

		    UnlockPixels(pixMapHandle);
                    
		}
        
		// Use the ICM to compress the image 
		err = CompressImage(GetGWorldPixMap(theGWorld),	/* source image to compress */
				    &trackFrame, 		/* bounds */
				    codecNormalQuality,	/* desired image quality */
				    kAnimationCodecType,	/* compressor identifier */
				    imageDesc, 		/* handle to Image Description Structure; will be resized by call */
				    compressedDataPtr);	/* pointer to a location to recieve the compressed image data */
		if (err != noErr)
                    return 0;
        
		// Add sample data and a description to a media
		err = AddMediaSample(theMedia,	/* media specifier */ 
				     compressedData,	/* handle to sample data - dataIn */
				     0,		/* specifies offset into data reffered to by dataIn handle */
				     (**imageDesc).dataSize, /* number of bytes of sample data to be added */ 
				     1,		 /* frame duration = 1/10 sec */
				     (SampleDescriptionHandle)imageDesc,	/* sample description handle */ 
				     1,	/* number of samples */
				     0,	/* control flag indicating self-contained samples */
				     nil);		/* returns a time value where sample was insterted */
		if (err != noErr)
                    return 0;
	    } // for loop
                        
	    UnlockPixels (GetGWorldPixMap(theGWorld)/*GetPortPixMap(theGWorld)*/);
        
	    SetGWorld (oldPort, oldGDeviceH);
        
	    // Dealocate our previously alocated handles and GWorld
	    if (imageDesc)
	    {
		DisposeHandle ((Handle)imageDesc);
	    }
                
	    if (compressedData)
	    {
		DisposeHandle (compressedData);
	    }
                
	    if (theGWorld)
	    {
		DisposeGWorld (theGWorld);
	    }
	}

	// 3b. End media-editing session
	err = EndMediaEdits (theMedia);
	if (err != noErr)
            return 0;

	// 4. Insert a reference to a media segment into the track
	err = InsertMediaIntoTrack (theTrack,		/* track specifier */
                                    0,	/* track start time */
                                    0, 	/* media start time */
                                    GetMediaDuration(theMedia), /* media duration */
                                    fixed1);		/* media rate ((Fixed) 0x00010000L) */
	if (err != noErr)
            return 0;
    }

    err = AddMovieResource (theMovie, resRefNum, &resId, QTUtils_ConvertCToPascalString ("MathMap"));
    if (resRefNum)
    {
	CloseMovieFile (resRefNum);
//	NSLog(@"closing");
    }
    
    DisposeMovie(theMovie);
    return 1;
}
