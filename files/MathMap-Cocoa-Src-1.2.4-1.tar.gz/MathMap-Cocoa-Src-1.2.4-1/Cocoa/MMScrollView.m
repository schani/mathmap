//
//  MMScrollView.m
//
//  Created by Herbert P�tzl on Fri Mar 29 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMScrollView.h"


@implementation MMScrollView

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _indicatorRect = NSZeroRect;
    }
    return self;
}


- (void)tile {
    NSScroller *scroller = [self verticalScroller];
    NSRect rect, frame = [self frame];
    
    [super tile];
    rect = [scroller frame];
        // why is this necessary?
    rect.size.height = NSHeight(frame);
    NSDivideRect(rect, &_indicatorRect, &rect, 
        NSWidth(rect), NSMaxYEdge);
    [scroller setFrame:rect];
}

- (void)drawRect:(NSRect)rect {
    if (NSIntersectsRect(rect, _indicatorRect)) {
        NSRect leftLine, topLine, rect;
        NSDivideRect(_indicatorRect, &leftLine, &rect, 1, NSMinXEdge);
        NSDivideRect(rect, &topLine, &rect, 1, NSMinYEdge);
        [[NSColor whiteColor] set];
        NSRectFill(rect);
        [[NSColor colorWithDeviceWhite:0.9 alpha:1.0] set];
        NSRectFill(leftLine);
        NSRectFill(topLine);
    }
}


@end
