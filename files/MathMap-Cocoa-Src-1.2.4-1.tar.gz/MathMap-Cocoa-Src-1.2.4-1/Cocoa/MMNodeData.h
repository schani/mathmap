//
//  MMNodeData.h
//
//  Created by Herbert P�tzl on Wed Mar 13 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  based on SimpleNodeData (c) 2001 by Apple Computer, Chuck Pisula
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Cocoa/Cocoa.h>

#import "TreeNode.h"

typedef unsigned MMNodeDataEncoding;

typedef unsigned MMNodeDataType;

enum {
    MMUnknownNodeType = 0,
    MMGroupNodeType = 1,
    MMExpressionNodeType = 2,
    MMUserValueNodeType = 3,
    MMUserValueSetNodeType = 4,
    MMImageSettingsNodeType = 5,
    MMImageLinkNodeType = 6,
    MMReferenceNodeType = 7,
};



@interface MMNodeData : TreeNodeData {
@private
    NSString *_name;
    NSImage *_icon;
    MMNodeDataType _type;
    NSString *_path;
    BOOL _isLeaf;
    id _object;
}

+ (id)nodeWithName:(NSString *)name
    type:(MMNodeDataType)type
    object:(id)object;
    
+ (NSString *)nameForType:(MMNodeDataType)type;

- (id)initWithName:(NSString *)name
    type:(MMNodeDataType)type
    object:(id)object;

- (void)setName:(NSString *)name;
- (NSString *)name;

- (void)setObject:(id)object;
- (id)object;

- (BOOL)isLocked;
- (BOOL)isValid;
- (void)setPath:(NSString *)path;
- (id)path;

- (void)setIsLeaf:(BOOL)value;
- (BOOL)isLeaf;

- (BOOL)isGroup;

- (void)setIcon:(NSImage *)icon;
- (NSImage *)icon;

- (MMNodeDataType)type;

@end
