//
//  MMDragField.m
//
//  Created by Herbert Pötzl on Thu Mar 07 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMDragField.h"

#import "ImageAndTextCell.h"
#import "DragAndDrop.h"

@implementation MMDragField

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _contentsCell = [[ImageAndTextCell alloc] 
            initTextCell:@"Text"];
        [_contentsCell setFont:[NSFont systemFontOfSize:11.0]];
        [_contentsCell setImage:[NSImage imageNamed:@"EmptyIcon"]];
        [_contentsCell setEditable: NO];
    }
    return self;
}

// - (BOOL)isFlipped 	{ return YES; }

- (void)drawRect:(NSRect)rect {
    if ([self isEnabled] && _object) {
        [_contentsCell drawWithFrame:[self bounds] inView:self];
    } else {
        
    }
}


- (void)setDelegate:(id)object {
    [object retain];
    [delegate release];
    delegate = object;
}

- (id)delegate		{ return delegate; }

- (void)setObject:(id)object {
    [object retain];
    [_object release];
    _object = object;
}

- (id)object 		{ return _object; }

- (void)setName:(NSString *)name {
    [name retain]; 
    [_name release]; 
    _name = name;
}

- (NSString*)name 		{ return _name; }

- (void)setIcon:(NSImage *)icon {
    [_contentsCell setImage:icon];
}

- (NSImage *)icon { 
    return [_contentsCell image]; 
}

- (void)setStringValue:(NSString *)string {
    [_contentsCell setStringValue:string];
}

- (NSString *)stringValue { 
    return [_contentsCell stringValue]; 
}


- (NSImage *)cellImage {
    NSSize cellSize = [_contentsCell cellSize];
    NSImage *image = [[NSImage alloc] initWithSize:cellSize];
    NSRect cellFrame = NSZeroRect;

    cellFrame.size = cellSize;
    [image lockFocus];
	[_contentsCell drawWithFrame:cellFrame inView:[NSView focusView]];
    [image unlockFocus];
    return [image autorelease];
}

- (void)mouseDown:(NSEvent *)theEvent
{
    NSSize dragOffset = NSMakeSize(0.0, 0.0);
    NSPasteboard *pboard;
    BOOL drag = NO;

    if (![self isEnabled] || !_object) return;
    NSAssert(_object, @"DF: Object missing");
    pboard = [NSPasteboard pasteboardWithName:NSDragPboard];
    [pboard declareTypes:[NSArray 
        arrayWithObject: NSStringPboardType] owner:nil];
    
    if ([_object respondsToSelector:
        @selector(propertyList)]) {
        [pboard setString:[[_object propertyList] description] 
            forType: NSStringPboardType];    
    } else {
        [pboard setString:[_object description] 
            forType: NSStringPboardType];    
    }
    
    if ([delegate respondsToSelector:
        @selector(dragField:writeObject:toPasteboard:)]) {
        drag = [delegate dragField:self 
            writeObject:_object 
            toPasteboard:pboard];
    }

    if (drag) [self dragImage:[self cellImage]
        at: NSMakePoint(0,0) 
        offset:dragOffset
        event:theEvent  
        pasteboard:pboard 
        source:self slideBack:YES];
    return;
}


- (NSArray *)draggedNodes {
    if (_object) {
        return [NSArray arrayWithObject:_object];
    } else {
        return [NSArray array];
    }
}

- (id)dataSource 				{ return self; }
- (void)reloadData 				{ }

@end
