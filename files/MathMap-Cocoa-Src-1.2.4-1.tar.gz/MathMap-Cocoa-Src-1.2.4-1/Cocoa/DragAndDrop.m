//
//  DragAndDrop.m
//
//  Created by Herbert P�tzl on Sat Mar 16 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Foundation/Foundation.h>

#import "DragAndDrop.h"

NSString *	NodeDragPboardType 	 = @"NodeDragPboardType";

NSString *	ExpressionPboardType 	 = @"ExpressionPboardType";
NSString *	UserValueSetPboardType 	 = @"UserValueSetPboardType";
NSString *	UserValuePboardType 	 = @"UserValuePboardType";
NSString *	ImageSettingsPboardType	 = @"ImageSettingsPboardType";


@implementation MMExpression (DragAndDrop)

- (NSArray *)providedPboardTypes {
    return [NSArray arrayWithObjects:
        ExpressionPboardType,
        NSStringPboardType,
        nil];
}

- (id)dataForType:(NSString *)type {
    if ([type isEqual:ExpressionPboardType]) {
        return self;
    } else if ([type isEqual:NSStringPboardType]) {
        return [self string];
    }
    assert(0);
}

@end

@implementation MMUserValue (DragAndDrop)

- (NSArray *)providedPboardTypes {
    return [NSArray arrayWithObjects:
        UserValuePboardType,
        NSStringPboardType,
        nil];
}

- (id)dataForType:(NSString *)type {
    if ([type isEqual:UserValuePboardType ]) {
        return self;
    } else if ([type isEqual:NSStringPboardType]) {
        return [self description];
    }
    assert(0);
}

@end


@implementation NSWindow (DragAndDropDelegation)


- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender {
    if ([[self delegate] respondsToSelector:
        @selector(draggingEntered:)]) {
        return [[self delegate] draggingEntered:sender];
    }
    return NSDragOperationNone;
}

- (NSDragOperation)draggingUpdated:(id <NSDraggingInfo>)sender {
    if ([[self delegate] respondsToSelector:
        @selector(draggingUpdated:)]) {
        return [[self delegate] draggingUpdated:sender];
    }
    return NSDragOperationNone;
}

- (void)draggingExited:(id <NSDraggingInfo>)sender {
    if ([[self delegate] respondsToSelector:
        @selector(draggingExited:)]) {
        [[self delegate] draggingExited:sender];
    }
}

- (BOOL)prepareForDragOperation:(id <NSDraggingInfo>)sender {
    if ([[self delegate] respondsToSelector:
        @selector(prepareForDragOperation:)]) {
        return [[self delegate] prepareForDragOperation:sender];
    }
    return NO;
}

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender {
    if ([[self delegate] respondsToSelector:
        @selector(performDragOperation:)]) {
        return [[self delegate] performDragOperation:sender];
    }
    return NO;
}

- (void)concludeDragOperation:(id <NSDraggingInfo>)sender {
    if ([[self delegate] respondsToSelector:
        @selector(concludeDragOperation:)]) {
        [[self delegate] concludeDragOperation:sender];
    }
}

@end


