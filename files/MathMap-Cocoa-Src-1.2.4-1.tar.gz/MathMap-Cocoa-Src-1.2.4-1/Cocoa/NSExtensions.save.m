//
//  Doc_Extensions.m
//
//  Created by Herbert Pötzl on Thu Mar 28 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import "NSExtensions.h"


@implementation NSData (PropertyList)

+ (NSData *)dataWithPropertyList:(id)propertyList {
    NSData *data = [[propertyList description]
        dataUsingEncoding:NSASCIIStringEncoding 
            allowLossyConversion:YES];
    return data;
}

- (id)propertyList {
    NSString *string = [[[NSString alloc] 
        initWithData:self
        encoding:NSASCIIStringEncoding] autorelease];
    return [string propertyList];
}

@end


@implementation NSData (RTFExtensions)

+ (NSData *)RTFWithString:(NSString *)string {
    NSAttributedString *attribString = 
        [[[NSAttributedString alloc] 
            initWithString:string]
            autorelease];
    return [attribString RTFFromRange:
        NSMakeRange(0, [string length]) 
        documentAttributes:nil];
}

- (BOOL)isAttributedRTF {
/*
    NSText *text = [[[NSText alloc] init] autorelease];
    NSData *before, *after;
    [text setString:@" "];
    [text replaceCharactersInRange:
        NSMakeRange(1, 0) withRTF:self];
    before = [text RTFFromRange:NSMakeRange(0, 
        [[text string] length])];
    [text replaceCharactersInRange:NSMakeRange(1, 
        [[text string] length]-1) withString:[text string]];
    after = [text RTFFromRange:NSMakeRange(0, 
        [[text string] length])];
    return (![after isEqual:before]);
*/
    return YES;
}

@end


@implementation NSString (RTFExtensions)

+ (NSString *)stringWithRTF:(NSData *)data {
    NSAttributedString *attribString = 
        [[[NSAttributedString alloc] 
            initWithRTF:data 
            documentAttributes:NULL]
            autorelease];
    return [attribString string];
}

@end


#import "highlight.h"

@implementation NSTextView (SyntaxHighlighting)

- (void)highlightWithColors:(NSArray *)colors {
    int first, last = 0, prev = 0, result;
    NSString * string = [self string];
    const char *exp = [string cString];
    NSColor *defcol = [colors objectAtIndex:0];

    while ((result = next_highlight((char *)exp, last, &first, &last)) 
        != HIGHLIGHT_EOS) {
        if (first - prev) {
            [self setTextColor:defcol
                range:NSMakeRange(prev, first-prev)];
        }
        [self setTextColor:
            [colors objectAtIndex:result] 
            range:NSMakeRange(first, last-first)];
        prev = last;
    }
    last = [string length];
    if (last - prev) {
        [self setTextColor:defcol
            range:NSMakeRange(prev, last-prev)];
    }
}

@end


@implementation NSColor (CheckerBoard) 

+ (NSColor *)checkerBoard {
    static NSColor *checkerBoard = nil;
    if (!checkerBoard) {
        checkerBoard = [[NSColor 
            colorWithPatternImage:[NSImage 
                imageNamed:@"CheckerBoard"]] retain];
    }
    return checkerBoard;
}

@end

@implementation NSImage (RGBAConversion) 


- (NSBitmapImageRep *)properBitmapImageRep {
    NSEnumerator *enumerator = [[self 
        representations] objectEnumerator];
    NSImageRep *entry;
    int maxWidth = -1, maxHeight = -1;
    NSBitmapImageRep *properRep = nil;

    while ((entry = [enumerator nextObject])) {
        if ([entry isKindOfClass:[NSBitmapImageRep class]]) {
            NSBitmapImageRep *bitmapRep = (NSBitmapImageRep *)entry;
	    BOOL valid = NO;

	    NSLog(@"rep: %@", bitmapRep);

            if (((([bitmapRep bitsPerPixel] == 24) && ([bitmapRep samplesPerPixel] == 3) && (![bitmapRep hasAlpha])) ||
                (([bitmapRep bitsPerPixel] == 32) && ([bitmapRep samplesPerPixel] == 4) && ([bitmapRep hasAlpha]))) &&
                (![bitmapRep isPlanar]) && 
                ([bitmapRep bitsPerSample] == 8) &&
                ([[bitmapRep colorSpaceName] isEqual:NSDeviceRGBColorSpace] ||
		 [[bitmapRep colorSpaceName] isEqual:NSCalibratedRGBColorSpace]))
		valid = YES;

	    if ([bitmapRep pixelsWide] > maxWidth)
	    {
		maxWidth = [bitmapRep pixelsWide];
		maxHeight = [bitmapRep pixelsHigh];

		if (valid)
		    properRep = bitmapRep;
	    }
        }
    }
    
    NSLog(@"proper rep: %@", properRep);

    if (properRep == nil) {
	float width, height;
	
	if (maxWidth > 0 && maxHeight > 0)
	{
	    width = maxWidth;
	    height = maxHeight;
	}
	else
	{
	    NSSize size = [self size];

	    width = size.width;
	    height = size.height;
	}

        [self lockFocus];
        properRep = [[[NSBitmapImageRep alloc]
		      initWithFocusedViewRect:NSMakeRect(0, 0, width, height)]
		     retain];
        [self unlockFocus];
    }
    
    NSLog(@"image rep has size %d x %d\n", [properRep pixelsWide], [properRep pixelsHigh]);

    if ([properRep samplesPerPixel] == 3) {
	int width = [properRep pixelsWide];
	int height = [properRep pixelsHigh];
        NSBitmapImageRep *altRep =
            [[NSBitmapImageRep alloc]
                initWithBitmapDataPlanes:NULL 
                pixelsWide:width 
                pixelsHigh:height
                bitsPerSample:8 samplesPerPixel:4 
                hasAlpha:YES isPlanar:NO 
                colorSpaceName:NSDeviceRGBColorSpace 
                bytesPerRow:0 bitsPerPixel:0];
        const unsigned char *src = [properRep bitmapData];
        unsigned char *dst = [altRep bitmapData];
        int sskip = [properRep bytesPerRow] - width*3;
		int dskip = [altRep bytesPerRow] - width*4;
        int y = height;

        while (y--) {
            int x = width;
            while (x--) {
                *dst++ = *src++;
                *dst++ = *src++;
                *dst++ = *src++;
                *dst++ = 255;
            }
            src += sskip;
	    dst += dskip;
        }
        [properRep release];
        properRep = altRep;
    }
    
    [self addRepresentation:properRep];
    [self setDataRetained:YES];
    return properRep;
}

@end


@implementation NSView (Extensions)

- (void)registerKeyWindowNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self 
        selector:@selector(keyWindowNotification:) 
        name:NSWindowDidBecomeKeyNotification 
        object:[self window]];
    [[NSNotificationCenter defaultCenter] addObserver:self 
        selector:@selector(keyWindowNotification:) 
        name:NSWindowDidResignKeyNotification 
        object:[self window]];
}

- (void)unregisterKeyWindowNotification {
    [[NSNotificationCenter defaultCenter] 
        removeObserver:self 
        name:NSWindowDidBecomeKeyNotification 
        object:[self window]];
    [[NSNotificationCenter defaultCenter] 
        removeObserver:self 
        name:NSWindowDidResignKeyNotification 
        object:[self window]];
}

- (void)keyWindowNotification:(NSNotification *)notif {
    NSAssert(0, @"KeyWindowNotification ...");
}

@end


//  Array Extensions by Chuck Pisula
//  Copyright (c) 2001 by Apple Computer, Inc.

@implementation NSArray (Extensions)

- (BOOL) containsObjectIdenticalTo: (id)obj { 
    return [self indexOfObjectIdenticalTo: obj]!=NSNotFound; 
}

@end

@implementation NSMutableArray (Extensions)

- (void) insertObjectsFromArray:(NSArray *)array atIndex:(int)index {
    NSObject *entry = nil;
    NSEnumerator *enumerator = [array objectEnumerator];
    while ((entry=[enumerator nextObject])) {
        [self insertObject:entry atIndex:index++];
    }
}

@end


