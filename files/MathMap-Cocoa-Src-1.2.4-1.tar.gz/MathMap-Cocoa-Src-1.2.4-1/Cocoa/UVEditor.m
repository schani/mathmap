//
//  UVEditor.m
//
//  Created by Herbert Pötzl on Fri Mar 08 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "UVEditor.h"
#import "UVEHelper.h"

NSString *	UserValueModifiedNotification 	 = @"UserValueModifiedNotification";


@implementation UVEditor

+ (UVEditor *)editorForType:(MMUserValueType)type
{
	// NSLog(@"editorForType %d helper=%@", type, [UVEHelper globalHelper]);

    switch (type) {
    case MMIntUserValueType:
        return [[UVEHelper globalHelper] numberEditor];
		
    case MMFloatUserValueType:
        return [[UVEHelper globalHelper] numberEditor];
		
    case MMBoolUserValueType:
        return [[UVEHelper globalHelper] boolEditor];
		
    case MMColorUserValueType:
        return [[UVEHelper globalHelper] colorEditor];
		
    case MMCurveUserValueType:
        return [[UVEHelper globalHelper] curveEditor];
		
    case MMGradientUserValueType:
        return [[UVEHelper globalHelper] gradientEditor];
		
    case MMImageUserValueType:
        return [[UVEHelper globalHelper] imageEditor];

    default:
        NSAssert1(0, @"Unknown Editor Type: %d", type);
        return nil;
    }
}


- (void)awakeFromNib 
{
    NSRect frame = [self frame];
    _minSize = frame.size;
}

- (MMUserValueType)type	{ 
    NSAssert(0, @"SuperClass UVEditor should not create instances.");
    return MMUnknownUserValueType;
}

- (void)setUserValue:(MMUserValue *)userValue {
    [userValue retain];
    [_userValue release];
    _userValue = userValue;
    [self synchronize];
}

- (MMUserValue *)userValue		{ return _userValue; }

- (void)synchronize			{ [self update]; }
- (void)update				{ }

- (void)modified {
    [[NSNotificationCenter defaultCenter]
        postNotificationName:UserValueModifiedNotification 
        object:_userValue];
    [self update];
}

- (NSSize)minSize			{ return _minSize; }

- (BOOL)isOpaque			{ return YES; }

- (void)drawRect:(NSRect)rect {
    [[NSColor colorWithDeviceWhite:0.95 alpha:1.0] set];
    NSRectFill(rect); 
}

@end 


@implementation UVEditor (NSCoding)

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
    [coder encodeSize:_minSize];
    [coder encodeConditionalObject:_userValue];
    return;
}

- (id)initWithCoder:(NSCoder *)coder 
{
    self = [super initWithCoder:coder];
    _minSize = [coder decodeSize];
    _userValue = [[coder decodeObject] retain];
    return self;
}

@end
