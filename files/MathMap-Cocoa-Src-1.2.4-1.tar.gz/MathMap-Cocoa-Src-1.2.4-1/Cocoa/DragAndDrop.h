//
//  DragAndDrop.h
//
//  Created by Herbert P�tzl on Sat Mar 16 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <Foundation/Foundation.h>

#import "MMExpression.h"
#import "MMUserValue.h"



extern	NSString *	NodeDragPboardType;
extern	NSString *	ExpressionPboardType;
extern	NSString *	UserValueSetPboardType;
extern	NSString *	UserValuePboardType;
extern	NSString *	ImageSettingsPboardType;

@interface MMExpression (DragAndDrop)

- (NSArray *)providedPboardTypes;
- (id)dataForType:(NSString *)type;

@end

@interface MMUserValue (DragAndDrop)

- (NSArray *)providedPboardTypes;
- (id)dataForType:(NSString *)type;

@end
