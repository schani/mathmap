//
//  MMToolbar.m
//
//  Created by Herbert P�tzl on Wed Mar 13 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import "MMToolbar.h"

static NSString* 	MathMapToolbarIdentifier 	= @"MathMapToolbarIdentifier";

static NSString*	SaveDocToolbarItemIdentifier 	= @"SaveDocToolbarItemIdentifier";
static NSString*	LibraryToolbarItemIdentifier	= @"LibraryToolbarItemIdentifier";
static NSString*	PreviewToolbarItemIdentifier	= @"PreviewToolbarItemIdentifier";


@implementation MMDocument (ToolBar)

- (void) setupToolbar {
    NSToolbar *toolbar = [[[NSToolbar alloc] 
        initWithIdentifier: MathMapToolbarIdentifier] autorelease];
    
    [toolbar setAllowsUserCustomization: YES];
    [toolbar setAutosavesConfiguration: YES];
    [toolbar setDisplayMode: NSToolbarDisplayModeIconOnly];
    
    [toolbar setDelegate: self];
    [documentWindow setToolbar: toolbar];
}

- (NSToolbarItem *) toolbar: (NSToolbar *)toolbar 
    itemForItemIdentifier: (NSString *) ident 
    willBeInsertedIntoToolbar:(BOOL) willBeInserted {

    NSToolbarItem *toolbarItem = [[[NSToolbarItem alloc] 
        initWithItemIdentifier: ident] autorelease];
    /*
    if ([ident isEqual: SaveDocToolbarItemIdentifier]) {
	[toolbarItem setLabel: @"Save"];
	[toolbarItem setPaletteLabel: @"Save"];
        [toolbarItem setToolTip: @"Save Your Document"];
	[toolbarItem setImage: [NSImage imageNamed: @"SaveDocument"]];
	
	[toolbarItem setTarget: self];
	[toolbarItem setAction: @selector(saveDocument:)];
        
    } 
    else */
    if ([ident isEqual: LibraryToolbarItemIdentifier]) {
	[toolbarItem setLabel: @"Library"];
	[toolbarItem setPaletteLabel: @"Library"];
	[toolbarItem setToolTip: @"Open Library Window"];
	[toolbarItem setImage: [NSImage imageNamed: @"OpenLibrary"]];
	
	[toolbarItem setTarget: nil];
	[toolbarItem setAction: @selector(showLibrary:)];
    } 
    else if ([ident isEqual: PreviewToolbarItemIdentifier]) {
	[toolbarItem setLabel: @"Preview"];
	[toolbarItem setPaletteLabel: @"Preview"];
	[toolbarItem setToolTip: @"Open Preview Window"];
	[toolbarItem setImage: [NSImage imageNamed: @"OpenPreview"]];
	
	[toolbarItem setTarget: nil];
	[toolbarItem setAction: @selector(showPreview:)];
    }else {
	toolbarItem = nil;
    }
    return toolbarItem;
}

- (NSArray *) toolbarDefaultItemIdentifiers: (NSToolbar *) toolbar {
    return [NSArray arrayWithObjects:	
//        SaveDocToolbarItemIdentifier, 
        LibraryToolbarItemIdentifier, 
        PreviewToolbarItemIdentifier, 
        
        NSToolbarSeparatorItemIdentifier, 
        NSToolbarFlexibleSpaceItemIdentifier, 
        NSToolbarPrintItemIdentifier, 
        NSToolbarShowColorsItemIdentifier, 
//        NSToolbarShowFontsItemIdentifier, 
        nil];
}

- (NSArray *) toolbarAllowedItemIdentifiers: (NSToolbar *) toolbar {
    return [NSArray arrayWithObjects: 	
//        SaveDocToolbarItemIdentifier, 
        LibraryToolbarItemIdentifier, 
        PreviewToolbarItemIdentifier, 

        NSToolbarPrintItemIdentifier, 
	NSToolbarShowColorsItemIdentifier, 
        NSToolbarShowFontsItemIdentifier,
        NSToolbarCustomizeToolbarItemIdentifier,
	NSToolbarFlexibleSpaceItemIdentifier, 
        NSToolbarSpaceItemIdentifier,
        NSToolbarSeparatorItemIdentifier, 
        nil];
}

- (void) toolbarWillAddItem: (NSNotification *) notif {
//    NSToolbarItem *addedItem = [[notif userInfo] objectForKey: @"item"];

/*
    if ([[addedItem itemIdentifier] isEqual: SearchDocToolbarItemIdentifier]) {
	activeSearchItem = [addedItem retain];
	[activeSearchItem setTarget: self];
	[activeSearchItem setAction: @selector(searchUsingToolbarTextField:)];
    } else if ([[addedItem itemIdentifier] isEqual: NSToolbarPrintItemIdentifier]) {
	[addedItem setToolTip: @"Print Your Document"];
	[addedItem setTarget: self];
    } else if ([[addedItem itemIdentifier] isEqual: LibraryToolbarItemIdentifier]) {
	[addedItem setToolTip: @"Open Library Window"];
	[addedItem setTarget: self];
	[addedItem setAction: @selector(openLibrary:)];
    }
*/
}  

- (void) toolbarDidRemoveItem: (NSNotification *) notif {
//    NSToolbarItem *removedItem = [[notif userInfo] objectForKey: @"item"];
}

- (BOOL) validateToolbarItem: (NSToolbarItem *) item {
    if ([[item itemIdentifier] isEqual: SaveDocToolbarItemIdentifier]) {
	return [self isDocumentEdited];
    }	
    return YES;
}


@end
