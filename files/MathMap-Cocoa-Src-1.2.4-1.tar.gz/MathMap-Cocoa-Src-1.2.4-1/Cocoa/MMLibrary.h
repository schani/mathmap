//
//  MMLibrary.h
//
//  Created by Herbert P�tzl on Mon Mar 25 2002.
//  Copyright (c) 2002-2008 H.P�tzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#import <Cocoa/Cocoa.h>

@class MMSplitView, MMOutlineView, MMArchive;
@class MMTreeNode;

@interface MMLibrary : NSDocument
{
@private
    MMTreeNode *_infoSelection;
    BOOL _splitDefaultsDone;
    BOOL _isMainLibrary;
    NSData *_dataFromFile;

    IBOutlet NSWindow 		*documentWindow;
    
    IBOutlet MMArchive 		*nodeArchive;
    IBOutlet MMOutlineView 	*outlineView;
    
    IBOutlet NSTabView		*infoTabView;
    IBOutlet NSTextField	*selTextField;
    IBOutlet NSTextView		*descTextView;
    
    IBOutlet NSScrollView	*infoScrollView;
    IBOutlet NSTextView		*infoTextView;
    
    IBOutlet MMSplitView	*splitView;
    IBOutlet NSView			*firstSubview;
    IBOutlet NSView			*secondSubview;
    
    IBOutlet NSButton		*simpleButton;
}

+ (MMLibrary *)sharedLibrary;

-(IBAction)toggleSimple:(id)sender;

-(void)makeMainLibrary;
-(BOOL)isMainLibrary;

@end
