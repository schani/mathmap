//
//  MMDocument.m
//
//  Created by Herbert Pötzl on Wed Mar 06 2002.
//  Copyright (c) 2002-2008 Herbert Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <QTKit/QTKit.h>

#import "MMDocument.h"
#import "MMToolbar.h"

#import "MMLibrary.h"
#import "MMPreview.h"
#import "MMArchive.h"
#import "MMTreeNode.h"
#import "MMNodeData.h"
#import "MMExpression.h"
#import "MMInvocation.h"

#import "UVEHelper.h"
#import "AuxHelper.h"
#import "MMOutlineView.h"
#import "MMUserValue.h"
#import "MMUVMatrix.h"
#import "MMDragField.h"

#import "NSExtensions.h"
#import "DragAndDrop.h"
#import "PropertyList.h"
#import "UserDefaults.h"

NSString *	ExpressionChangedNotification 	 = @"ExpressionChangedNotification";

@interface MMDocument (Private)

- (void)synchronize;

- (void)invalidateCheckTimer;
- (void)scheduleCheckTimer;

- (void)verifyExpression;
- (void)colorizeExpression;
- (void)updateExpression:(NSTimer *)timer;

- (AuxHelper *)auxHelper;

@end

static	NSString *	ResetUserValueSheet	= @"ResetUserValueSheet";


@implementation MMDocument

+ (void)initialize{

    [[NSUserDefaults standardUserDefaults] 
        registerDefaults:[NSDictionary
        dictionaryWithObjectsAndKeys:
            ExpressionCheckDValue, ExpressionCheckDefault,
            ExpressionHighlightDValue, ExpressionHighlightDefault,
            ExpressionLabelDValue, ExpressionLabelDefault,
            UserValueSetLabelDValue, UserValueSetLabelDefault,
            UserValueSetCommentDValue, UserValueSetCommentDefault,
            nil]];
}


- (id)init {
    self = [super init];
    if (self) {
        _dataFromFile = nil;
        _checkTimer = nil;
        _auxHelper = nil;
        _expression = nil;
        _userValues = nil;
    }
    return self;
}

- (void)dealloc {
    [_expression release];
    [_userValues release];
    [_auxHelper release];
    [self invalidateCheckTimer];
    [_dataFromFile release];
    [super dealloc];
}


- (NSString *)windowNibName 		{ return @"MMDocument"; }

- (void)windowControllerDidLoadNib:(NSWindowController *)aController {
    [super windowControllerDidLoadNib:aController];
    
    [documentWindow setFrameUsingName: @"MMDocumentWindow"];
    [documentWindow setFrameAutosaveName: @"MMDocumentWindow"];
    [documentWindow registerForDraggedTypes:
        [NSArray arrayWithObjects:
            NodeDragPboardType, 
            NSStringPboardType, 
            NSFilenamesPboardType, 
            nil]];
            
    [expressionTextView setAllowsUndo:YES];
    [expressionTextView setUsesFontPanel:NO];
    [expressionScrollView setHasHorizontalScroller:NO];
 //   [expressionScrollView setBorderType:NSNoBorder];

    [expressionDragField setStringValue:@"None"];


    if (_dataFromFile) {
	[expressionTextView setString: [[[NSString alloc] initWithData: _dataFromFile
							      encoding: NSASCIIStringEncoding]
					autorelease]];
	[self updateExpression:nil];
	[_dataFromFile autorelease];
	_dataFromFile = nil;
    }
    
        // wants to go to App
    [NSColor setIgnoresAlpha:NO];

    [self setupToolbar];
}

- (NSData *)dataRepresentationOfType:(NSString *)aType {
//    NSLog(@"data rep for %@", aType);
    if ([aType isEqual:@"MathMap Document"])
	return [[expressionTextView string] dataUsingEncoding:NSASCIIStringEncoding];
    return nil;
}

- (BOOL)loadDataRepresentation:(NSData *)data 
    ofType:(NSString *)aType {
//    NSLog(@"load data for %@", aType);
    if ([aType isEqual:@"MathMap Document"]) {
	if (0 && nodeArchive) {
            [nodeArchive setRootNode:[MMTreeNode 
                treeFromPropertyList:[data propertyList]]];
            [self synchronize];
	} else {
	    _dataFromFile = [data retain];
	}
	return YES;
    }
    return NO;
}

- (void)setExpression:(MMExpression *)expression {
    [expression retain];
    [_expression release];
    _expression = expression;
    _expressionChanged = YES;
    
    // update drag field
    if (_expression) {
        [expressionDragField setIcon:[NSImage 
            imageNamed:@"ExpressionIcon"]];
        [expressionDragField setName:@"Unlabeled"];
        [expressionDragField setStringValue:@"Filter"];
        [expressionDragField setObject:[_expression propertyList]];        
        [expressionDragField setEnabled:YES];
        
    } else {
        [expressionDragField setIcon:[NSImage 
            imageNamed:@"EmptyIcon"]];
        [expressionDragField setName:@"None"];
        [expressionDragField setStringValue:@"None"];
        [expressionDragField setObject:nil];        
        [expressionDragField setEnabled:NO];
    }
//    NSLog(@"DOC:Expression = %@", _expression);
}

- (MMExpression *)currentExpression	{ return _expression; }

- (void)setUserValues:(NSArray *)values {
    [values retain];
    [_userValues release];
    _userValues = values;

    if (_expression) {
        [userValueDragField setIcon:[NSImage 
            imageNamed:@"UVSetIcon"]];
        [userValueDragField setName:@"Unlabeled"];
        [userValueDragField setStringValue:@"UserValueSet"];
        [userValueDragField setObject:[_userValues 
            userValueSetPropertyList]];        
        [userValueDragField setEnabled:NO];
        
    } else {
        [userValueDragField setIcon:[NSImage 
            imageNamed:@"EmptyIcon"]];
        [userValueDragField setName:@"None"];
        [userValueDragField setStringValue:@"None"];
        [userValueDragField setObject:nil];        
        [userValueDragField setEnabled:NO];
    }
    // NSLog(@"DOC:UserValues = %@", _userValues);
}

- (NSArray *)currentUserValues 		{ return _userValues; }


@end



@implementation MMDocument (Private)

- (void)synchronize {
//    MMTreeNode *rootNode = [nodeArchive rootNode];
//    MMTreeNode *child = [rootNode firstChild];
    NSString *expression;

    // []
    
    expression = [[nodeArchive rootNodeDictionary] 
            objectForKey:ValueKey];
    [expressionTextView setString:expression];
    // []

    [self setExpression:[MMExpression
        expressionWithString:expression]];
/*
    [self setUserValues:[[_expression 
        userValuesWithProposedValues:[child ???]] retain];
*/
	// NSLog(@"default values ...");
    [self setUserValues:[_expression defaultUserValues]];
    [userValueView setUserValues:_userValues];
}


- (void)invalidateCheckTimer {
    if (_checkTimer) {
        [_checkTimer invalidate];
        [_checkTimer release];
        _checkTimer = nil;
    }
}

- (void)scheduleCheckTimer {
    _checkTimer = [[NSTimer 
        scheduledTimerWithTimeInterval:0.5 
        target:self selector:@selector(updateExpression:) 
        userInfo:nil repeats:NO] retain];
}


- (void)verifyExpression {
    NSString *exp = [expressionTextView string];
    NSDictionary *ret = [MMExpression 
        verifyExpressionString:exp];
    if (ret) {
        [expressionInfoField setStringValue:[NSString 
            stringWithFormat:@"Malformed filter: %@", 
                [ret objectForKey:@"message"]]];
        [self setExpression:nil];
        [[NSNotificationCenter defaultCenter] 
            removeObserver:self 
            name:UserValueSetModifiedNotification 
            object:userValueView];

    } else {
        [expressionInfoField setStringValue:[NSString 
            stringWithFormat:@"Valid filter."]];

        [self setExpression:[MMExpression expressionWithString:exp]];
        [self setUserValues:[_expression 
            userValuesWithProposedValues:_userValues]];
        [[NSNotificationCenter defaultCenter] 
            addObserver:self 
            selector:@selector(userValueSetChanged:) 
            name:UserValueSetModifiedNotification 
            object:userValueView];
    }        
}

- (void)colorizeExpression {
    [expressionTextView highlightWithColors:[NSArray 
        arrayWithObjects:
            [NSColor blackColor], [NSColor redColor],
            [NSColor lightGrayColor], [NSColor blueColor],
            [NSColor magentaColor], [NSColor blackColor],
            [NSColor blueColor], 
                [NSColor colorWithDeviceRed:0.2 green:0.6 blue:0.1 alpha:1.0],
                [NSColor colorWithDeviceRed:0.1 green:0.5 blue:0.0 alpha:1.0],
            [NSColor brownColor],
            [NSColor blueColor], [NSColor darkGrayColor],
                [NSColor colorWithDeviceRed:0.1 green:0.5 blue:0.0 alpha:1.0],
            nil]];
}


- (void)updateExpression:(NSTimer *)timer {
    // NSLog(@"update ...");
    [self invalidateCheckTimer];
    [self verifyExpression];
    [self colorizeExpression];
    // NSLog(@"update notification with %@", self);
    [[NSNotificationCenter defaultCenter]
        postNotificationName:ExpressionChangedNotification 
        object:self];
}


- (void)userValueSetChanged:(NSNotification *)notification {
    [userValueDragField setObject:[_userValues 
        userValueSetPropertyList]];        
}

- (AuxHelper *)auxHelper {
    if (!_auxHelper) {
        _auxHelper = [[AuxHelper helper] retain];
    }
    return _auxHelper;
}


@end



enum	{
    ExportSubmenuItemTag = 100,
    ExportImageMenuItemTag = 101,
    ExportMovieMenuItemTag = 102,
};


@implementation MMDocument (MenuItems)


- (BOOL)validateMenuItem:(NSMenuItem *)anItem {
    if (([anItem tag] == ExportImageMenuItemTag) ||
        ([anItem tag] == ExportMovieMenuItemTag) ||
        ([anItem tag] == ExportSubmenuItemTag)) {
        return (_expression && _userValues);
    }
//    NSLog(@"MENU: %@", anItem);
    return [super validateMenuItem:anItem];
}


@end





@implementation MMDocument (ToolBarActions)


- (void) printDocument:(id) sender {
    NSPrintOperation *printOperation = [NSPrintOperation 
        printOperationWithView: expressionTextView];
    [printOperation runOperationModalForWindow: documentWindow 
        delegate: nil didRunSelector: NULL contextInfo: NULL];
}





- (void)sheetDidEnd:(NSWindow *)sheet 
    returnCode:(int)returnCode 
    contextInfo:(void *)contextInfo {
    NSString *context = (NSString *)contextInfo;
//    NSLog(@"AlertSheet ... sheetDidEnd");
    if ([context isEqual:ResetUserValueSheet]) {
        if (returnCode == NSAlertDefaultReturn) { 
            [userValueView resetUserValues];
        }
    }
}

- (void)sheetDidDismiss:(NSWindow *)sheet 
    returnCode:(int)returnCode 
    contextInfo:(void *)contextInfo {
//    NSLog(@"AlertSheet ... sheetDidDismiss");
}

@end


@implementation MMDocument (TextViewDelegate)

- (void)textDidChange:(NSNotification *)aNotification {
    [self invalidateCheckTimer];
    [self scheduleCheckTimer];
}

@end

static	NSString *	ExpressionTabIdentifier		= @"ExpressionTab";
static	NSString *	UserValueTabIdentifier		= @"UserValueTab";
static	NSString *	ImageTabIdentifier		= @"ImageTab";

@implementation MMDocument (TabViewDelegate)

- (void)tabView:(NSTabView *)tabView 
    willSelectTabViewItem:(NSTabViewItem *)tabViewItem {
    if ([[tabViewItem identifier] isEqual:ExpressionTabIdentifier]) {
    
    } else if ([[tabViewItem identifier] isEqual:UserValueTabIdentifier]) {
        if (_checkTimer) {
            [self updateExpression:nil];
        }
        if (_expressionChanged) {
            [userValueView setUserValues:_userValues];
            _expressionChanged = NO;
        }
    } else if ([[tabViewItem identifier] isEqual:ImageTabIdentifier]) {
    
    }
}

@end



@implementation MMDocument (WindowDragAndDrop)


- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender {
/*    NSColor *color = [NSColor 
        colorFromPasteboard:[sender draggingPasteboard]];
*/
//    NSLog(@"D draggingEntered ...");
    return NSDragOperationEvery;
}

- (NSDragOperation)draggingUpdated:(id <NSDraggingInfo>)sender {
//    NSLog(@"D draggingUpdated ...");
    return NSDragOperationEvery;
}

- (void)draggingExited:(id <NSDraggingInfo>)sender {
//    NSLog(@"D draggingExited ...");
}


- (BOOL)prepareForDragOperation:(id <NSDraggingInfo>)sender {
//    NSLog(@"prepareForDragOperation ...");
    return YES;
}

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender {
//    NSLog(@"performDragOperation ...");
    return YES;
}

- (void)concludeDragOperation:(id <NSDraggingInfo>)sender {
    NSArray *array = [MMTreeNode
        nodesFromPropertyList:
        [[[sender draggingPasteboard]
            stringForType:NSStringPboardType] 
                propertyList]];
    MMTreeNode *firstNode = [array objectAtIndex:0];
    MMNodeData *nodeData = (MMNodeData *)[firstNode nodeData];

    if ([nodeData type] == MMExpressionNodeType) {
        [expressionTextView setString:
            [[sender draggingPasteboard]
                stringForType:ExpressionPboardType]];
        [self updateChangeCount:NSChangeDone];	// fix me ..
		[self setExpression:_expression];
        [self updateExpression:nil];
        [userValueView setUserValues:_userValues];	// fix me ...

    } else if ([nodeData type] == MMUserValueSetNodeType) {
	//[self setUserValues:(NSArray *)values {
/*        NSLog(@"UV: %@,%@", nodeData, 
            [firstNode children]);*/
    }
}

@end


@implementation MMDocument (DragFieldDelegate)

- (BOOL)dragField:(MMDragField *)dragField 
    writeObject:(id)object 
    toPasteboard:(NSPasteboard *)pboard {
    return YES;
}

@end

@interface QTMovie (QuickTimeV721)

- (id)initToWritableFile:(NSString *)filename error:(NSError **)errorPtr;

@end


@implementation MMDocument (Responder)

- (IBAction) verifyExpression:(id)sender {
    [self verifyExpression];
}

- (IBAction) colorizeExpression:(id)sender {
    [self colorizeExpression];
}

- (IBAction)resetUserValues:(id)sender {
    if (_userValues && _expression &&
        ![_userValues isEqualToArray:
            [_expression defaultUserValues]]) {		/* UV changed ? */

        NSBeginAlertSheet(@"Reset User Values?", 
            @"Yes", @"Cancel", nil, documentWindow, self, 
            @selector(sheetDidEnd:returnCode:contextInfo:), 
            @selector(sheetDidDismiss:returnCode:contextInfo:), 
            ResetUserValueSheet, 
            @"Resetting will lose all adjustments you made ...");
    } else {
        [userValueView resetUserValues];
    }
}

- (IBAction) exportAsImage:(id)sender {
    AuxHelper *helper = [self auxHelper];
    NSSavePanel *panel = [helper exportImageSavePanel];
    [panel beginSheetForDirectory:@"" file:@"MyImage" 
        modalForWindow:documentWindow 
        modalDelegate:self didEndSelector:
        @selector(exportAsImagePanelDidEnd:returnCode:contextInfo:) 
        contextInfo:NULL];
//    NSLog(@"AuxHelper ...%@", [self auxHelper]);

}

- (void)exportAsImagePanelDidEnd:(NSWindow *)sheet 
    returnCode:(int)returnCode 
    contextInfo:(void  *)contextInfo {
    AuxHelper *helper = [self auxHelper];
//    NSLog(@"AuxHelper ...%@", helper);
    
    if (returnCode) {
        MMInvocation *invocation;
        NSBitmapImageRep *imageRep;
        NSImage *image;
        int width, height;
        
        width = [helper exportImageWidth];
        height = [helper exportImageHeight];
    
        imageRep = [[NSBitmapImageRep alloc]
            initWithBitmapDataPlanes:NULL 
            pixelsWide:width 
            pixelsHigh:height 
            bitsPerSample:8 
            samplesPerPixel:4 
            hasAlpha:YES 
            isPlanar:NO 
            colorSpaceName:NSDeviceRGBColorSpace 
            bytesPerRow:0 
            bitsPerPixel:0];
    
        invocation = [_expression 
            invocationWithUserValues:_userValues
            bitmapImageRep:imageRep];
        [invocation setSupersampling:
            [helper exportImageSupersampling]];
        [invocation setAntialiasing:
            [helper exportImageAntialiasing]];
        [invocation render];
        
        image = [[NSImage alloc] 
            initWithSize:NSMakeSize(width, height)]; 
        [image addRepresentation:imageRep];
        [[image TIFFRepresentationUsingCompression:NSTIFFCompressionLZW 
            factor:1.0] writeToFile:[(NSSavePanel *)sheet filename] atomically:YES];
    }

/*    NSLog(@"Yeah now save the stuff ...%@ %d,%d (%d,%d,%d)",
        [sheet filename],
        [helper exportImageWidth],
        [helper exportImageHeight],
        [helper exportImageSupersampling],
        [helper exportImageAntialiasing],
        returnCode);
*/
}

- (IBAction) exportAsMovie:(id)sender {
    AuxHelper *helper = [self auxHelper];
    NSSavePanel *panel = [helper exportMovieSavePanel];
    [panel beginSheetForDirectory:@"" file:@"MyMovie" 
        modalForWindow:documentWindow 
        modalDelegate:self didEndSelector:
        @selector(exportAsMoviePanelDidEnd:returnCode:contextInfo:) 
        contextInfo:NULL];
}

- (void)renderToFileInvocation: (MMInvocation*) invocation
		     numFrames: (int) numFrames
			   fps: (int) fps
		      periodic: (BOOL) periodic
		      filename: (NSString*) filename
{
    NSDictionary *attribs = [NSDictionary dictionaryWithObjectsAndKeys:
			     @"jpeg", QTAddImageCodecType,
			     [NSNumber numberWithLong: codecHighQuality], QTAddImageCodecQuality,
			     nil];
    QTTime duration = QTMakeTime(600 / fps, 600);
    NSSize size = [[invocation imageRep] size];
    QTMovie *movie;
    BOOL success;
    int i;
    NSString *tempName = [NSString stringWithCString: tmpnam(NULL)
					    encoding: NSASCIIStringEncoding];

    if (![[[[QTMovie alloc] init] autorelease] respondsToSelector:@selector(initToWritableFile:error:)])
    {
	NSRunAlertPanel(@"Cannot export movie", @"Quicktime 7.2.1 or higher required to export movie.",
			@"OK", nil, nil);
	return;
    }

    movie = [[QTMovie alloc] initToWritableFile: tempName error: NULL];
    [movie setAttribute: [NSNumber numberWithBool:YES]
		 forKey:QTMovieEditableAttribute];

    for (i = 0; i < numFrames; ++i)
    {
	NSImage *image = [[NSImage alloc] initWithSize: size];
	float t;

	if (periodic)
	    t = (float)i / (float)numFrames;
	else if (numFrames == 1)
	    t = 0.0;
	else
	    t = (float)i / (float)(numFrames - 1);

	[invocation setTimeValue: t];
	[invocation render];

	[image addRepresentation: [invocation imageRep]];

	[movie addImage: image
	    forDuration: duration
	 withAttributes: attribs];

	[image release];
    }

    // sure is sure sagt die hur
    [[NSFileManager defaultManager] removeFileAtPath: filename
					     handler: nil];

    success = [movie writeToFile: filename
		  withAttributes: [NSDictionary dictionaryWithObject: [NSNumber numberWithBool: YES] 
							      forKey: QTMovieFlatten]];
    if (!success)
	NSRunAlertPanel(@"Could not write movie",
			@"Could not write movie file",
			@"OK", nil, nil);

    [movie release];

    [[NSFileManager defaultManager] removeFileAtPath: tempName
					     handler: nil];
}

- (void)exportAsMoviePanelDidEnd:(NSWindow *)sheet 
    returnCode:(int)returnCode 
    contextInfo:(void  *)contextInfo {
    AuxHelper *helper = [self auxHelper];
    
/*    NSLog(@"Yeah now save the stuff ... %dx%dx%d (%d,%d,%d)",
        [helper exportMovieWidth],
        [helper exportMovieHeight],
        [helper exportMovieFrames],
        [helper exportMovieSupersampling],
        [helper exportMovieAntialiasing],
        [helper exportMovieLooping]);
*/
    if (returnCode) {
        MMInvocation *invocation;
        NSBitmapImageRep *imageRep;
        int width, height;
        
        width = [helper exportMovieWidth];
        height = [helper exportMovieHeight];
    
        imageRep = [[NSBitmapImageRep alloc]
            initWithBitmapDataPlanes:NULL 
            pixelsWide:width 
            pixelsHigh:height 
            bitsPerSample:8 
            samplesPerPixel:4 
            hasAlpha:YES 
            isPlanar:NO 
            colorSpaceName:NSDeviceRGBColorSpace 
            bytesPerRow:0 
            bitsPerPixel:0];
    
        invocation = [_expression 
            invocationWithUserValues:_userValues
            bitmapImageRep:imageRep];
        [invocation setSupersampling:
            [helper exportMovieSupersampling]];
        [invocation setAntialiasing:
            [helper exportMovieAntialiasing]];
        //[invocation render];

	[self renderToFileInvocation: invocation
			   numFrames: [helper exportMovieFrames]
				 fps: 30
			    periodic: [helper exportMovieLooping]
			    filename: [(NSSavePanel*)sheet filename]];

/*
        if (!render_movie_to_file(invocation, [helper exportMovieFrames], 
                15, [helper exportMovieLooping],
                [[(NSSavePanel *)sheet filename] cString]))
            NSRunAlertPanel(@"Movie not saved", @"The Movie could not be saved", @"OK", nil, nil, nil);
*/
    }
}

@end



@implementation MMDocument (Unused)

/*
-(void)toggleAntialiasing:(id)sender {
    if ([sender state]) {
        [sender setToolTip:@"Disable Antialiasing"];
        [sender setImage:[NSImage 
            imageNamed:@"AntialiasTFIcon"]];
        [sender setAlternateImage:[NSImage 
            imageNamed:@"AntialiasTFAIcon"]];
        [sender setAction:@selector(enableAntialias:)];
    } else {
        [sender setToolTip:@"Enable Antialiasing"];
        [sender setImage:[NSImage 
            imageNamed:@"AntialiasTTIcon"]];
        [sender setAlternateImage:[NSImage 
            imageNamed:@"AntialiasTTAIcon"]];
        [sender setAction:@selector(disableAntialias:)];
    }
    NSLog(@"in document ...");
}
*/
/*
- (IBAction) action:(id)sender 
{
}
*/
@end
