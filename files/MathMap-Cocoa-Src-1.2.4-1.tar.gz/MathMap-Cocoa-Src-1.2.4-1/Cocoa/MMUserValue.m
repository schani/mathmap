//
//  MMUserValue.m
//
//  Created by Herbert Pötzl on Thu Mar 07 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "MMUserValue.h"

#import "NSExtensions.h"
#import "UserDefaults.h"
#import "PropertyList.h"
#import "Curve.h"


static NSString *MMIntUserValueTypeName =		@"Integer";		
static NSString *MMFloatUserValueTypeName =		@"Float";		
static NSString *MMBoolUserValueTypeName =		@"Bool";		
static NSString *MMColorUserValueTypeName = 	@"Color";		
static NSString *MMCurveUserValueTypeName = 	@"Curve";		
static NSString *MMGradientUserValueTypeName =	@"Gradient";		
static NSString *MMImageUserValueTypeName =		@"Image";		
static NSString *MMUnknownUserValueTypeName =	@"Unknown";		

@interface MMCurveUserValue : MMUserValue {
    Curve *_curve;
}

@end

@interface MMImageUserValue : MMUserValue {
    NSImage *_image;
}

@end

@interface MMUserValue (Private) 

- (id)_initWithCInfo:(userval_info_t *)info;

@end



@implementation MMUserValue

+ (id)userValueWithData:(NSData *)data 
    encoding:(MMUserValueEncoding)encoding {
    return [[[self alloc]
        initWithData:(NSData *)data 
        encoding:(MMUserValueEncoding)encoding] 
        autorelease];
}


+ (NSString *)nameForType:(MMUserValueType)type {
    switch (type) {
    case MMIntUserValueType:
        return MMIntUserValueTypeName;
    case MMFloatUserValueType:
        return MMFloatUserValueTypeName;
    case MMBoolUserValueType:
        return MMBoolUserValueTypeName;
    case MMColorUserValueType:
        return MMColorUserValueTypeName;
    case MMCurveUserValueType:
        return MMCurveUserValueTypeName;
    case MMGradientUserValueType:
        return MMGradientUserValueTypeName;
    case MMImageUserValueType:
        return MMImageUserValueTypeName;
    default:
        return MMUnknownUserValueTypeName;
    }
}

+ (MMUserValueType)typeForName:(NSString *)name {
    if ([name isEqual:MMIntUserValueTypeName])
        return MMIntUserValueType;
    else if ([name isEqual:MMFloatUserValueTypeName])
        return MMFloatUserValueType;
    else if ([name isEqual:MMBoolUserValueTypeName])
        return MMBoolUserValueType;
    else if ([name isEqual:MMColorUserValueTypeName])
        return MMColorUserValueType;
    else if ([name isEqual:MMCurveUserValueTypeName])
        return MMCurveUserValueType;
    else if ([name isEqual:MMGradientUserValueTypeName])
        return MMGradientUserValueType;
    else if ([name isEqual:MMImageUserValueTypeName])
        return MMImageUserValueType;
    else return -1;	// fix me ..
}

    
- (id)initWithData:(NSData *)data 
    encoding:(MMUserValueEncoding)encoding {
    return nil;		/* fix me */
}

#if 0
- (id)initWithName:(NSString *)name
    type:(MMUserValueType)type
    string:(NSString *)value {
    _name = [name retain];
    _info = dirty_hack_userval_info(type);
    
    self = [self initWithCInfo:&_info];
    if (self) {
        switch (type) {
        case MMIntUserValueType:
            [self setFloatValue:[value intValue]];
            break;
        case MMFloatUserValueType:
            [self setFloatValue:[value floatValue]];
            break;
        case MMBoolUserValueType:
            [self setBoolValue:[value intValue]];
            break;
        case MMColorUserValueType:
            [self setColor:[NSColor colorWithPropertyList:value]];
            break;
        case MMCurveUserValueType:
            [self setCurve:[Curve curveWithPropertyList:value]];
            break;
        case MMGradientUserValueType:
            [self setCurve:[Curve curveWithPropertyList:value]];
            break;
        case MMImageUserValueType:
            [self setImage:[[[NSImage alloc] 
                initByReferencingFile:value] autorelease]];
            break;
        }
    }
    return self;
}
#endif

- (void) dealloc {
    [_name release];
    if ([self isMemberOfClass:[MMUserValue class]] &&
        (_info.type != USERVAL_CURVE) &&
        (_info.type != USERVAL_GRADIENT) &&
        (_info.type == USERVAL_IMAGE))
        free_uservals(&_value, &_info);
//    NSLog(@"FREEUSERVAL %p %@", self, self);
    [super dealloc];
}

- (id)copyWithZone:(NSZone *)zone {
    return [[MMUserValue allocWithZone:zone] 
        initWithCInfo:&_info];
}


- (NSData *)dataUsingEncoding:(MMUserValueEncoding)encoding {
    return nil; 	/* fix me */
}

- (MMUserValueType)type 	{ return _info.type; }
- (NSString *)name 		{ return _name; }

- (NSString *)typeName {
    return [[self class] nameForType:[self type]];
}

- (void) resetToDefault {
    set_userval_to_default(&_value, &_info, NULL);
}


- (BOOL)isEqual:(id)object {
    if ([object isKindOfClass:[self class]]) {
        MMUserValue *other = (MMUserValue *)object;
        if ([other type] == [self type]) {
            BOOL valueEqual = NO;
            BOOL infoEqual = YES;
        
            switch ([self type]) {
            case MMIntUserValueType:
                valueEqual = ((int)[self floatValue] == (int)[other floatValue]);
                infoEqual = ((int)[self minValue] == (int)[other minValue]) &&
                    ((int)[self maxValue] == (int)[other maxValue]);
                break;
                
            case MMFloatUserValueType:
                valueEqual = ([self floatValue] == [other floatValue]);
                infoEqual = ([self minValue] == [other minValue]) &&
                    ([self maxValue] == [other maxValue]);
                break;
                
            case MMBoolUserValueType:
                valueEqual = ([self boolValue] == [other boolValue]);
                break;
                
            case MMColorUserValueType:
                valueEqual = [[self color] isEqual:[other color]];
                break;
                
            case MMCurveUserValueType:
            case MMGradientUserValueType:
               valueEqual = [[self curve] isEqual:[other curve]];
                break;

            case MMImageUserValueType:
                valueEqual = [[self image] isEqual:[other image]];
                break;
            }
            return (valueEqual && infoEqual);
        }
    } 
    return NO;
}

- (NSString *)description { 
    return [[self propertyList] description]; 
}


/* int/float */
- (float) minValue
{
    if (_info.type == USERVAL_INT_CONST)
	return _info.v.int_const.min;
    else if (_info.type == USERVAL_FLOAT_CONST)
	return _info.v.float_const.min;
    assert(0);
    return 0.0;
}

- (float) maxValue
{
    if (_info.type == USERVAL_INT_CONST)
	return _info.v.int_const.max;
    else if (_info.type == USERVAL_FLOAT_CONST)
	return _info.v.float_const.max;
    assert(0);
    return 0.0;
}

- (int) numberOfTickMarks
{
    return 11;
}


- (float) floatValue
{
    if (_info.type == USERVAL_INT_CONST)
	return _value.v.int_const;
    else if (_info.type == USERVAL_FLOAT_CONST)
	return _value.v.float_const;
    assert(0);
    return 0.0;
}

- (void) setFloatValue: (float) val
{
    val = MAX([self minValue], MIN([self maxValue], val));
    if (_info.type == USERVAL_INT_CONST)
	_value.v.int_const = (int)rint(val);
    else if (_info.type == USERVAL_FLOAT_CONST)
	_value.v.float_const = val;
    else
	assert(0);
}

/* bool */
- (BOOL) boolValue
{
    assert(_info.type == USERVAL_BOOL_CONST);

    return _value.v.bool_const == 0.0 ? NO : YES;
}

- (void) setBoolValue: (BOOL) val
{
    assert(_info.type == USERVAL_BOOL_CONST);

    _value.v.bool_const = val ? 1.0 : 0.0;
}

/* color */
- (NSColor*) color
{
    assert(_info.type == USERVAL_COLOR);
    return [NSColor colorWithDeviceRed: 
        RED(_value.v.color.value)/255.0
        green: GREEN(_value.v.color.value)/255.0
        blue: BLUE(_value.v.color.value)/255.0
        alpha: ALPHA(_value.v.color.value)/255.0];
}

- (void) setColor: (NSColor*) val
{
    float color_data[4];
    assert(_info.type == USERVAL_COLOR);

    [val getRed:&color_data[0] 
        green:&color_data[1] 
        blue:&color_data[2] 
        alpha:&color_data[3]];
    _value.v.color.value = MAKE_RGBA_COLOR(
        color_data[0]*255.0,
        color_data[1]*255.0,
        color_data[2]*255.0,
        color_data[3]*255.0);
}

/* curve / gradient */

- (Curve *)curve			{ assert(0); return nil; }
- (void)setCurve:(Curve *) val		{ assert(0); }

/* image */

- (NSImage *)image			{ assert(0); return nil; }
- (void)setImage: (NSImage *) val	{ assert(0); }

- (id)initWithName:(NSString *)name
    type:(MMUserValueType)type
    string:(NSString *)value		{ assert(0); return nil; }

@end


@implementation MMUserValue (Expression)

+ (id)userValueWithCInfo:(userval_info_t *)info {
    return [[[self alloc] 
        initWithCInfo:info] autorelease];
}


- (id)_initWithCInfo:(userval_info_t *)info {
    self = [super init];

    _info = *info;
    _info.next = 0;
    _name = [[NSString stringWithCString: _info.name] retain];
    // if (_info.dirty_hack)
    instantiate_userval(&_value, &_info, NULL);
//    NSLog(@"INSTANTIATE %p", self);
    return self;
}

- (id)initWithCInfo:(userval_info_t *)info {
    if ((info->type == USERVAL_CURVE) ||
        (info->type == USERVAL_GRADIENT)) {
        [self autorelease];
        self = [[MMCurveUserValue alloc] _initWithCInfo:info];
    } else if (info->type == USERVAL_IMAGE) {
        [self autorelease];
        self = [[MMImageUserValue alloc] _initWithCInfo:info];
    } else {
        self = [self _initWithCInfo:info];
    }
    return self;
}

- (userval_info_t *)cInfo		{ return &_info; }

- (void) copyToCValue:(userval_t *)val {
    copy_userval(val, &_value, _info.type);
}


@end


@implementation MMCurveUserValue 

- (void) resetToDefault {
    [_curve release];
    _curve = [[Curve alloc] init];
    [_curve addVector:MakeVector5D(0, 0, 0, 0, 0)];
    [_curve addVector:MakeVector5D(1, 1, 1, 1, 1)];
}

- (id)_initWithCInfo:(userval_info_t*)info {
    self = [super _initWithCInfo:info];
    if (self) {
        _curve = nil;
        [self resetToDefault];
    }
    return self;
}

- (void) dealloc {
    [_curve release];
    [super dealloc];
}

- (id)copyWithZone:(NSZone *)zone {
    MMCurveUserValue *copy = [[MMCurveUserValue 
        allocWithZone:zone] 
        initWithCInfo:[self cInfo]];
    [copy setCurve:[[_curve copyWithZone:zone] autorelease]];
    return copy;
}

- (void) copyToCValue: (userval_t*) val {
    if ([self type] == MMCurveUserValueType) {
        [_curve render:NSMakeRect(0,0,1,1)
            toMemory:val->v.curve.values 
            count:USER_CURVE_POINTS 
            components:1
            asFloats:YES];
    } else if ([self type] == MMGradientUserValueType) {
	unsigned char *rgba_points;
	color_t *color_points;
	int i;

        [_curve render:NSMakeRect(0,0,1,1)
            toMemory:(float *)val->v.gradient.values 
            count:USER_GRADIENT_POINTS 
            components:4
            asFloats:NO];

	rgba_points = (unsigned char*)val->v.gradient.values;
	color_points = val->v.gradient.values;
	for (i = 0; i < USER_GRADIENT_POINTS; ++i) {
	    color_t color = MAKE_RGBA_COLOR_UNSAFE(rgba_points[0], rgba_points[1],
						   rgba_points[2], rgba_points[3]);
	    *color_points = color;
	    
	    rgba_points += 4;
	    ++color_points;
	}
    } else assert(0);
}

- (Curve *)curve			{ return _curve; }

- (void)setCurve:(Curve *)val {  
    [val retain];
    [_curve release];
    _curve = val;
}

@end


@implementation MMImageUserValue 

- (id)initWithCInfo:(userval_info_t *)info {
    self = [super _initWithCInfo:info];
    _image = [[NSImage alloc] init];
    return self;
}

- (void) dealloc {
    [_image release];
    [super dealloc];
}

- (id)copyWithZone:(NSZone *)zone {
    MMImageUserValue *copy = [[MMImageUserValue 
        allocWithZone:zone] 
        initWithCInfo:[self cInfo]];
    [copy setImage:_image];
    return copy;
}

- (void) copyToCValue:(userval_t *)val {
    static unsigned char emptyImage[] = {0,0,0,0};
    
    if ([self type] == MMImageUserValueType) {
		int width = 1;
		int height = 1;
		unsigned char *data = emptyImage;
		int rowStride = 0;
        NSBitmapImageRep *imageRep = 
            [_image properBitmapImageRep];
		input_drawable_t *drawable;
		
        if (_image && imageRep) {
            NSSize size = [imageRep size];
			width = size.width;
			height = size.height;
			data = [imageRep bitmapData];
			rowStride = [imageRep bytesPerRow];
		}

		drawable = alloc_input_drawable(INPUT_DRAWABLE_OPENSTEP, width, height);

		drawable->v.openstep.row_stride = rowStride;
		drawable->v.openstep.data = data;

		assign_image_userval_drawable([self cInfo], val, drawable);
    } else assert(0);
}

- (NSImage *)image			{ return _image; }

- (void)setImage: (NSImage *)val {  
    [[val retain] setFlipped:NO];
    [_image release];
    _image = val;
}


@end

