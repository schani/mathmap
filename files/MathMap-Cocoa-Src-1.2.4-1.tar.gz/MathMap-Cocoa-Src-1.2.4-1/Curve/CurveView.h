//
//  CurveView.h
//
//  Created by Herbert Pötzl on Wed Mar 13 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <AppKit/AppKit.h>

#import "Curve.h"

typedef	unsigned char Color4D[4];

typedef	unsigned int AnimationState;

enum _animation_state {
    STATE_UNDEFINED = 0,
    STATE_EXPANDED = 1,
    STATE_COMPACT = 2,
    STATE_BLENDING = 3,
    STATE_EXPANDING = 4,
    STATE_COMPACTING = 5
};


@interface CurveView : NSControl {
    IBOutlet id delegate;
    Curve *_curve;
    float * _valueLine;
    Color4D * _colorLine;
    unsigned _components;
    
    BOOL _isContinuous;
    SEL _action;
    id _target;
    
    NSRect _curveRect;
    NSRect _barRect;
    NSRect _axisRect;
    
    AnimationState _animState;
    NSTimer *_animTimer;
    NSDate *_animStart;
    BOOL _resizeAnimation;
    BOOL _blendAnimation;
    float _blend;

    BOOL _lineDataValid;
    BOOL _fillArea;
    BOOL _allowReorder;
    
    NSBezierPath *_curvePath;
    NSImage *_fillImage;
    NSImage *_handleImage;
    NSImage *_markerImage;

    NSPoint _mouseDownLocation;
    Vector5D _mouseDownVector;
    CurvePoint *_activeCurvePoint;
	CurvePoint *_suspendedPoint;
    BOOL _activeIsHandle;
	BOOL _activeCanMove;
}

- (void)setIsExpanded:(BOOL)flag;
- (BOOL)isExpanded;

- (BOOL)isContinuous;
- (void)setContinuous:(BOOL)flag;

- (BOOL)fillsArea;
- (void)setFillsArea:(BOOL)flag;

- (BOOL)allowsReorder;
- (void)setAllowsReorder:(BOOL)flag;

- (int)components;
- (void)setComponents:(int)num;

- (IBAction)toggleExpand:(id)sender;

- (void)recalcLineData:(NSRect)range;

- (void)recalcLineData;
- (void)recalcBezierPath;

- (Curve *)curve;
- (void) setCurve: (Curve *)curve;

@end


@interface  NSObject (CurveViewDelegate)

- (void)curveView:(CurveView *)aView 
    didAdjustSize:(NSSize)oldSize;

@end
