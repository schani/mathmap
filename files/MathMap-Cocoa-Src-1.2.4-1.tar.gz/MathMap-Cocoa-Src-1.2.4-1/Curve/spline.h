#ifndef __SPLINE_H__
#define __SPLINE_H__

typedef struct
{
    float x;
    float y;
    float y2;
} spline_point_t;

void calc_spline (int num_points, spline_point_t *ps, float y_min, float y_max,
		  float x_min, float x_max,
		  int num_samples, float *xs, float *ys);

#endif
