//
//  Curve.m
//
//  Created by Herbert Pötzl on Sat Mar 16 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "Curve.h"

#import "spline.h"

static void
LinearInterpolation(Vector5D *vec, Vector5D *v1, Vector5D *v2, float mix)
{
    int index;
    for (index=0; index<5; index++)
        (vec->v)[index] = (v1->v)[index]*(1.0-mix) + (v2->v)[index]*(mix);
}


#define	CPNEXT(p)	((p)?(p)->next:NULL)
#define	CPPREV(p)	((p)?(p)->prev:NULL)

#define	IDENT(p,q)	(fabs(CPPOS(p)-CPPOS(q)) < MINDIST)


@implementation Curve (Private)

- (CurvePoint *)curvePointList		{ return _curvePoints; }

- (CurvePoint *)predecessorForPosition:(float)pos 
    getIndex:(int *)index {
    CurvePoint *cp = _curvePoints;
    
    while (cp && (cp->next)) {
        if (pos < CPPOS(cp->next)) break; 
        cp = cp->next;
        if (index) (*index)++;
    }
    if (cp && (CPPOS(cp) <= pos))
        return cp;
    return NULL;
}


- (CurvePoint *)curvePointAtIndex:(int)index {
    CurvePoint *cp = _curvePoints;
    
    while (index && cp) {
        cp = cp->next;
        index--;
    }
    return cp;
}

- (CurvePoint *)curvePointWithVector:(Vector5D *)vector {
    CurvePoint *new;
    
    new = NSZoneMalloc([self zone], sizeof(CurvePoint));
    CopyVector5D(&new->vector, vector);
    new->prev = NULL;
    new->next = NULL;
    return new;
}

- (void)freeCurvePoint:(CurvePoint *)point {
    if (point->next || point->prev)
        [self removeCurvePoint:point];
    NSZoneFree([self zone], point);
}

- (CurvePoint *)addCurvePoint:(CurvePoint *)newPoint {
    int index;
    CurvePoint *point = [self 
        predecessorForPosition: CPPOS(newPoint) 
        getIndex:&index];
	
    newPoint->prev = point;
    if (point) {
        newPoint->next = point->next;
        point->next = newPoint;
    } else {
        newPoint->next = _curvePoints;
        _curvePoints = newPoint;
    }
    
	if (newPoint->next) 
        newPoint->next->prev = newPoint;
    _numPoints++;
	
	if (point && IDENT(point, newPoint)) {
		[self removeCurvePoint:point];
		return point;
	}
    return NULL;
}

- (CurvePoint *)removeCurvePoint:(CurvePoint *)point {
    if (_curvePoints == point) {
        _curvePoints = point->next;
    } else {
        if (point->prev)
            point->prev->next = point->next;
    }
    if (point->next)
        point->next->prev = point->prev;
    point->prev = NULL;
    point->next = NULL;
    _numPoints--;
    return point;
}

- (NSRect)rangeAroundPoint:(CurvePoint *)point	{ 
    float min, max;
    min = (point->prev)?CPPOS(point->prev):CPPOS(point);
    max = (point->next)?CPPOS(point->next):CPPOS(point);
    // NSLog(@"  range around point %p  [%f,%f]", point, min, max);
    return NSMakeRect(min, 0, max-min, 1.0);
}

@end


@implementation Curve

+ (id)curve {
    return [[[Curve alloc] init] autorelease];
}

- (void)encodeWithCoder:(NSCoder *)coder
{
    CurvePoint *cp = _curvePoints;
    [coder encodeValueOfObjCType:@encode(unsigned) at:&_interpol];
    [coder encodeValueOfObjCType:@encode(unsigned) at:&_numPoints];
    
    while (cp) {
        [coder encodeArrayOfObjCType:@encode(float) 
            count:5 at:&cp->vector.v];
        cp = cp->next;
    }
}


- (id)initWithCoder:(NSCoder *)coder {
    Vector5D vector;
    unsigned count;
    
    [coder decodeValueOfObjCType:@encode(unsigned) at:&_interpol];
    [coder decodeValueOfObjCType:@encode(unsigned) at:&count];
    _curvePoints = NULL;
    _numPoints = 0;

    while (count--) {
        [coder decodeArrayOfObjCType:@encode(float) 
            count:5 at:&vector.v];
        [self addVector:vector];
    }
    return self;
}



- (id)init {
    self = [super init];
    if (self) {
        _curvePoints = NULL;
        _numPoints = 0;
        _interpol = InterpolTypeSpline;
    }
    return self;
}

- (void)dealloc {
    CurvePoint *cp = _curvePoints;
    while (cp) {
        CurvePoint *np = cp->next;
        [self freeCurvePoint:cp];
        cp = np;
    }
    [super dealloc];
}

- (id)copyWithZone:(NSZone *)zone {
    Curve *copy = [[Curve allocWithZone:zone] init];
    CurvePoint *cp = _curvePoints;

    [copy setInterpolationType:_interpol];
    while (cp) {
        CurvePoint *np = cp->next;
        [copy addVector:cp->vector];
        cp = np;
    }
    return copy;
}

- (void)setInterpolationType:(InterpolType)type {
    _interpol = type;
}

- (InterpolType)interpolationType	{ return _interpol; }


- (void)addVector:(Vector5D)vector {
    [self addCurvePoint:
        [self curvePointWithVector:&vector]];
	/* FIXME: handle vector collisions */
}

- (void)removeVectorAt:(int)index {
    CurvePoint *cp = [self curvePointAtIndex:index];
    [self freeCurvePoint:[self removeCurvePoint:cp]];
}

- (unsigned)count		{ return _numPoints; }

- (Vector5D)vectorAtIndex:(int)index {
    CurvePoint *cp = [self curvePointAtIndex:index];
    return cp->vector;
}

- (void)render:(NSRect)aRect
    toMemory:(void *)memory 
    count:(int)count 
    components:(int)num
    asFloats:(BOOL)flag
{
    CurvePoint *cp = _curvePoints;
    float *fmem;
    unsigned char *cmem;

    fmem = (float *)memory;
    cmem = (unsigned char *)memory;

    if (_interpol == InterpolTypeLinear || _numPoints < 3) {
	float pos, delta;

	pos = NSMinX(aRect);
	delta = NSWidth(aRect)/count;

        while (count--) {
            Vector5D *v1, *v2, v;
            float mix;
            int index;
    
            while ((cp->next) && (CPPOS(cp->next) <= pos)) 
                cp = cp->next; 
            v1 = &(cp->vector);
            v2 = (cp->next)?&(cp->next->vector):v1;
                
            mix = (pos - (v1->v)[0])/((v2->v)[0]-(v1->v[0]));        
            LinearInterpolation(&v, v1, v2, mix);

            if (flag) {
                for (index=1; index<num; index++)
                    *fmem++ = v.v[index];
                *fmem++ = v.v[4];
            } else {
                for (index=1; index<num; index++)
                    *cmem++ = v.v[index]*255.0;
                *cmem++ = v.v[4] * 255.0;
            }
            pos += delta;
        }
    } 
    else if (_interpol == InterpolTypeSpline) {
	int num_points = [self count];
	spline_point_t ps[num_points];
	int i;
	int comp;
	float *ys = (float*)malloc(sizeof (float) * count);

	for (comp = 0; comp < num; ++comp)
	{
	    int index = (comp == num - 1) ? 4 : (comp + 1);
	    int j;

	    for (i = 0; i < num_points; ++i)
	    {
		CurvePoint *cp = [self curvePointAtIndex: i];

		ps[i].x = CPPOS(cp);
		ps[i].y = cp->vector.v[index];
	    }

	    calc_spline(num_points, ps, 0.0, 1.0, NSMinX(aRect), NSMaxX(aRect), count, NULL, ys);

	    for (j = 0; j < count; ++j)
	    {
		int result_index = j * num + comp;

		if (flag)
		    fmem[result_index] = ys[j];
		else
		    cmem[result_index] = ys[j] * 255.0;
	    }
	}

	free(ys);
    }
    else
	assert(0);
}

@end
