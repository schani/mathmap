//
//  CurveView.m
//
//  Created by Herbert Pötzl on Wed Mar 13 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import "CurveView.h"
#import "NSExtensions.h"


#define	EXPANDED_HEIGHT		256.0
#define	COMPACT_HEIGHT 		 20.0
#define	AXIS_HEIGHT		      8.0
#define	ACTIVE_INSETX		  1.0
#define	ACTIVE_INSETY		  4.0

#define	HAS_ALPHA		((_components == 2) || (_components == 4))
#define	SHOWS_CURVE		((_animState != STATE_COMPACT) &&		\
                                 (_animState != STATE_UNDEFINED))
#define	CHANGES_SIZE	((_animState == STATE_COMPACING) ||		\
                                 (_animState == STATE_EXPANDING))


#define	LINEVAL(x)		(_valueLine[_components*((x)+1)-1])

#define	ISBOUND(p)		(((p)->next) || ((p)->prev))
#define	ISFREE(p)		(!ISBOUND(p))

#define	CLAMP(x,a,b)	MIN((b),MAX((a),(x)))

Vector5D*
Vector5DFromColor4D (Vector5D *vec, Color4D *color)
{
    int index;
    float alpha = (*color)[3]/255.0;
    if (alpha > 0.0) {
        for (index=0; index<3; index++) {
            float val = (*color)[index]/255.0;
            (vec->v)[index+1] = MIN(1.0, val/alpha);
        }
    } else {
        (vec->v)[1] = (vec->v)[2] = (vec->v)[3] = 0.0;
    }
    (vec->v)[4] = alpha;
    return vec;
}

Color4D*
Color4DFromVector5D (Color4D *color, Vector5D *vec, int components)
{
    float value = (vec->v[4])*255.0;
    switch (components) {
    case 1:
        (*color)[0] = (*color)[1] = (*color)[2] = value;
        (*color)[3] = 255.0;
        break;
    case 2:
        (*color)[0] = (*color)[1] = (*color)[2] = (vec->v[1])*value;
        (*color)[3] = value;
        break;
    case 3:
        value = 255.0;
    case 4:
        (*color)[0] = (vec->v[1])*value;
        (*color)[1] = (vec->v[2])*value;
        (*color)[2] = (vec->v[3])*value;
        (*color)[3] = value;
        break;
    }
    return color;
}


@implementation CurveView

- (void)recalcLayout
{
    int value;
    NSRect active = NSInsetRect([self bounds], 
        ACTIVE_INSETX, ACTIVE_INSETY);
    
    NSDivideRect(active, &_axisRect, &active, 1.0, NSMaxXEdge);
    value = AXIS_HEIGHT + _blend * 4.0;
    NSDivideRect(active, &_axisRect, &active, value, NSMinYEdge);
    value = COMPACT_HEIGHT * (1.0 - _blend);
    NSDivideRect(active, &_barRect, &_curveRect, value, NSMinYEdge);
}


- (void)resizeLineData {
    unsigned width = NSWidth(_curveRect);
    unsigned size;
    NSBitmapImageRep *rep;
    
    size = width * sizeof(Color4D);
    if (_colorLine) 
        _colorLine = NSZoneRealloc([self zone], 
            _colorLine, size);
    else _colorLine = NSZoneMalloc([self zone], size);

    size = width * sizeof(float) * _components;
    if (_valueLine) 
        _valueLine = NSZoneRealloc([self zone], 
            _valueLine, size);
    else _valueLine = NSZoneMalloc([self zone], size);
    
    [_fillImage release];
    rep = [[NSBitmapImageRep alloc] 
        initWithBitmapDataPlanes:(unsigned char **)&_colorLine 
        pixelsWide:width pixelsHigh:1 bitsPerSample:8 samplesPerPixel:4 
        hasAlpha:YES isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace 
        bytesPerRow:0 bitsPerPixel:0];
    _fillImage = [[NSImage alloc] 
        initWithSize:NSMakeSize(width,1)];
    [_fillImage addRepresentation:rep];
    _lineDataValid = NO;
}


- (void)adjustFrameSize {
    if (_animState != STATE_BLENDING) {
        NSRect frame = [self frame];
        NSSize oldSize = frame.size;
        float newHeight = COMPACT_HEIGHT + 
            (EXPANDED_HEIGHT - COMPACT_HEIGHT) * _blend +
            ACTIVE_INSETY*2 + AXIS_HEIGHT;

        if (frame.size.height != newHeight) {
            frame.size.height = newHeight;
            [self setFrameSize:frame.size];
            if ([delegate respondsToSelector:
                @selector(curveView:didAdjustSize:)]) {
                [delegate curveView:self didAdjustSize:oldSize];
            }
        }
    }
}


- (id)finishInit {
    _colorLine = NULL;
    _valueLine = NULL;
    _animTimer = nil;
    _blend = (_animState == STATE_EXPANDED)?1.0:0.0;
    _lineDataValid = NO;
    _resizeAnimation = NO;
    _isContinuous = NO;

    _curvePath = nil;
    _fillImage = [[NSImage alloc]
        initWithSize:NSMakeSize(0,0)];
    _markerImage = [[NSImage 
        imageNamed:@"MarkerImage"] retain];
    _handleImage = [[NSImage 
        imageNamed:@"HandleImage"] retain];
        
	_suspendedPoint = NULL;
    _activeCurvePoint = NULL;
    _activeIsHandle = NO;
    _activeCanMove = NO;

    [self registerForDraggedTypes:
        [NSArray arrayWithObject: NSColorPboardType]];
        
    [self adjustFrameSize];
    [self recalcLayout];
    [self resizeLineData];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)coder
{
    [super encodeWithCoder:coder];
    [coder encodeConditionalObject:delegate];
    [coder encodeObject:_curve];
    [coder encodeValueOfObjCType:@encode(unsigned) at:&_components];
    [coder encodeValueOfObjCType:@encode(unsigned) at:&_animState];
    [coder encodeValueOfObjCType:@encode(BOOL) at:&_fillArea];
    [coder encodeValueOfObjCType:@encode(BOOL) at:&_allowReorder];
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    delegate = [[coder decodeObject] retain];
    _curve = [[coder decodeObject] retain];
    [coder decodeValueOfObjCType:@encode(unsigned) at:&_components];
    [coder decodeValueOfObjCType:@encode(unsigned) at:&_animState];
    [coder decodeValueOfObjCType:@encode(BOOL) at:&_fillArea];
    [coder decodeValueOfObjCType:@encode(BOOL) at:&_allowReorder];
    [self finishInit];
    return self;
}


- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _curve = [[Curve alloc] init];
        [_curve addVector:MakeVector5D(0, 0, 0, 0, 0)];
        [_curve addVector:MakeVector5D(1, 1, 0, 1, 1)];
        
        _components = 4;
        _animState = STATE_EXPANDED;
        _fillArea = YES;
        _allowReorder = YES;
        [self finishInit];
    }
    return self;
}

- (void)dealloc {
    [_curve release];
    NSZoneFree([self zone], _valueLine);
    NSZoneFree([self zone], _colorLine);

    if (_animTimer) 
        [_animTimer release];
    if (_animStart) 
        [_animStart release];

    [_curvePath release];
    [_fillImage release];
    [_handleImage release];
    [_markerImage release];
    [super dealloc];
}

- (Curve *)curve			{ return _curve; }

- (void)setCurve:(Curve *)curve {  
    [curve retain];
    [_curve release];
    _curve = curve;
    _lineDataValid = NO;
    [self setNeedsDisplay:YES];
}


- (BOOL)isExpanded			{ return (_animState == STATE_EXPANDED); }

- (void)setIsExpanded:(BOOL)flag {
    if (flag) {
        _animState = STATE_EXPANDED;
        _blend = 1.0;
    } else {
        _animState = STATE_COMPACT;
        _blend = 0.0;
    }
    [self adjustFrameSize];
}

- (BOOL)isContinuous			{ return _isContinuous; }

- (void)setContinuous:(BOOL)flag {
    _isContinuous = flag;
}

- (BOOL)fillsArea			{ return _fillArea; }

- (void)setFillsArea:(BOOL)flag {
    _fillArea = flag;
}

- (BOOL)allowsReorder			{ return _allowReorder; }

- (void)setAllowsReorder:(BOOL)flag {
    _allowReorder = flag;
}

- (int)components			{ return _components; }

- (void)setComponents:(int)num {
    _components = CLAMP(num, 1, 4);
}

- (void)setTarget:(id)anObject {
    _target = anObject;
}

- (id)target				{ return _target; }

- (void)setAction:(SEL)aSelector {
    _action = aSelector;
}

- (SEL)action				{ return _action; }


- (void)setFrameSize: (NSSize) newSize
{
    NSRect oldFrame = [self frame];
    [super setFrameSize: newSize];
    [self recalcLayout];
    if (NSWidth(oldFrame) != newSize.width) {
        [self resizeLineData];
    }
}

- (NSRect)handleRectForCurvePoint:(CurvePoint *)point {
    NSRect handleRect;
    NSSize handleSize = [_handleImage size];
    float x = (point->vector.v[0]) * NSWidth(_curveRect);
    float y = (point->vector.v[4]) * NSHeight(_curveRect);
    
    handleRect.origin.x = NSMinX(_curveRect) +
        (x - 3);
    handleRect.origin.y = NSMinY(_curveRect) +
        (y - handleSize.height/2.0);
    handleRect.size = handleSize;
    return handleRect;
}

- (NSRect)markerRectForCurvePoint:(CurvePoint *)point {
    NSRect markerRect;
    NSSize markerSize = [_markerImage size];
    float x = (point->vector.v[0]) * NSWidth(_curveRect);
    
    markerRect.origin.x = NSMinX(_curveRect) +
        (x - 4);
    markerRect.origin.y = 1.0;
    markerRect.size = markerSize;
    return markerRect;
}


- (void)drawMarker:(NSRect)rect {
    CurvePoint *cp = [_curve curvePointList];
    
    while (cp) {
        if (SHOWS_CURVE) {
            NSRect handleRect = [self 
                handleRectForCurvePoint:cp];
            [_handleImage compositeToPoint:handleRect.origin 
                operation:NSCompositeSourceOver
                fraction:_blend];
        }
        if (YES || (cp->next && cp->prev)) {
            NSRect markerRect = [self 
                markerRectForCurvePoint:cp];
            [_markerImage compositeToPoint:markerRect.origin 
                operation:NSCompositeSourceOver];
        }
        cp = cp->next;
    }
}


- (void)drawRect:(NSRect)rect {
    NSAffineTransform *curveTrans = nil;
    NSBezierPath *path;
    
    if (!_lineDataValid)
        [self recalcLineData];
    
    [[NSColor lightGrayColor] set];
    NSFrameRect([self bounds]);
    // [self drawGrid];
                
    if (SHOWS_CURVE) {
        curveTrans = [NSAffineTransform transform];
        [curveTrans translateXBy:NSMinX(_curveRect) yBy:NSMinY(_curveRect)];
        [curveTrans scaleXBy:1.0 yBy:NSHeight(_curveRect)];

        path = [[_curvePath copy] autorelease];
        [path transformUsingAffineTransform:curveTrans];
        [path lineToPoint:NSMakePoint(NSMaxX(_barRect), NSMinY(_barRect))];
        [path lineToPoint:NSMakePoint(NSMinX(_barRect), NSMinY(_barRect))];
    } else {
        path = [NSBezierPath bezierPathWithRect:_barRect];
    }
    
    [NSGraphicsContext saveGraphicsState];
    [path addClip];
    
    if ((_fillArea || !SHOWS_CURVE)) {
        if (HAS_ALPHA) {
            [[NSColor checkerBoard] set];
            NSRectFill(NSUnionRect(_barRect, _curveRect));
        }
        [_fillImage drawInRect:NSUnionRect(_barRect, _curveRect) 
            fromRect:NSMakeRect(0,0, NSWidth(_barRect), 1) 
            operation:NSCompositeSourceOver 
            fraction:(_fillArea)?1.0:(1.0 - _blend)];
    }
    [NSGraphicsContext restoreGraphicsState];
    if (SHOWS_CURVE) {
        [[NSColor colorWithDeviceWhite:0.0 alpha:_blend] set];
        path = [[_curvePath copy] autorelease];
        [path transformUsingAffineTransform:curveTrans];
        [path stroke];
    }
    [self drawMarker:rect];
}


- (void)recalcColorLine:(int)pos :(int)count {
    Color4D *clp = _colorLine + pos;
    float *flp = _valueLine + pos*_components;
    int index;
    
    while (count--) {
        Vector5D vector;
        for (index=1; index<_components; index++)
            vector.v[index] = *flp++;
        vector.v[4] = *flp++;
        Color4DFromVector5D (clp, &vector, _components);
        clp++;
    }
}

- (void)recalcLineData:(NSRect)range  {
    int width = NSWidth(_curveRect);
    int pos = CLAMP(floor(NSMinX(range)*width), 0, width - 1);
    int count = CLAMP(ceil(NSWidth(range)*width)+1, 0, width - pos);
    NSRect rect = NSMakeRect(pos*1.0/width, 0, count*1.0/width, 1);

    // NSLog(@"render [%f,%f] ...", NSMinX(rect), NSMaxX(rect));
    [_curve render:rect	toMemory:(_valueLine + pos*_components)
        count:count components:_components asFloats:YES];
    [self recalcColorLine:pos :count];
    [self recalcBezierPath];
}


- (void)recalcLineData {
    if (!_lineDataValid) {
        [self recalcLineData:NSMakeRect(0,0,1,1)];
        _lineDataValid = YES;
    }
}

- (void)recalcBezierPath {
    int pos, width = NSWidth(_curveRect);
    
    if (_curvePath) [_curvePath release];
    _curvePath = [[NSBezierPath bezierPath] retain];
    
    [_curvePath setLineWidth:1.0];
    [_curvePath moveToPoint:NSMakePoint(0, LINEVAL(0))];
    for (pos=0; pos<width; pos++) {
        [_curvePath lineToPoint:NSMakePoint(pos, LINEVAL(pos))];
    }
    [_curvePath lineToPoint:NSMakePoint(width, LINEVAL(width-1))];
}


- (void)animate:(NSTimer *)timer {
    NSTimeInterval ti =	- [_animStart timeIntervalSinceNow];
    float delta = MIN(ti/0.8, 1.0);

    switch (_animState) {
    case STATE_BLENDING:
    case STATE_EXPANDING:
        //_blend += 0.1;
        _blend = delta;
        if (_blend >= 1.0) {
            [timer invalidate];
            _blend = 1.0;
            _animState = STATE_EXPANDED;
        }
        break;
    
    case STATE_COMPACTING:
        //_blend -= 0.1;
        _blend = 1.0 - delta;
        if (_blend <= 0.0) {
            [timer invalidate];
            _blend = 0.0;
            _animState = STATE_COMPACT;
        }
        break;
    }
    [self adjustFrameSize];
}


- (void)toggleExpand:(id)sender {
    if (_resizeAnimation) {
        if (SHOWS_CURVE)
            _animState = STATE_COMPACTING;
        else _animState = STATE_EXPANDING;
        
        [_animTimer invalidate];
        [_animTimer release];
        _animTimer = [[NSTimer 
            scheduledTimerWithTimeInterval:0.02
            target:self selector:@selector(animate:) 
            userInfo:nil repeats:YES] retain];
        [_animStart release];
        _animStart = [[NSDate date] retain];
        [_animTimer fire];
    } else {
        if (SHOWS_CURVE) {
            _animState = STATE_COMPACT;
            _blend = 0.0;
        } else {
            _animState = STATE_EXPANDED;
            _blend = 1.0;
        }
        [self performSelector:@selector(adjustFrameSize) 
            withObject:nil afterDelay:0.0];
    }
}




- (CurvePoint *)bestHandleMatch:(NSPoint)location {
    CurvePoint *cp, *best = nil;
    float mindist = 4*4 * 2;
    
    cp = [_curve curvePointList];
    while (cp) {
        NSRect rect = [self handleRectForCurvePoint:cp];
        float xd = NSMidX(rect) - location.x;
        float yd = NSMidY(rect) - location.y;
        float dist = xd*xd + yd*yd;
        
        if (dist < mindist) {
            best = cp;
            mindist = dist;
        }
        cp = cp->next;
    }
    return best;
}

- (CurvePoint *)bestMarkerMatch:(NSPoint)location {
    CurvePoint *cp, *best = nil;
    float mindist = 5*5 * 2;
    
    cp = [_curve curvePointList];
    cp = cp->next;
    while (cp->next) {
        NSRect rect = [self markerRectForCurvePoint:cp];
        float xd = NSMidX(rect) - location.x;
        float yd = NSMidY(rect) - location.y;
        float dist = xd*xd + yd*yd;
        
        if (dist < mindist) {
            best = cp;
            mindist = dist;
        }
        cp = cp->next;
    }
    return best;
}


- (NSPoint)curveLocation:(NSPoint)location {
    NSPoint cl;
    
    cl.x = (location.x - NSMinX(_curveRect))/NSWidth(_curveRect);
    cl.x = CLAMP(cl.x, 0.0, 1.0);
    cl.y = (location.y - NSMinY(_curveRect))/NSHeight(_curveRect);
    cl.y = CLAMP(cl.y, 0.0, 1.0);
    return cl;
}

- (NSPoint)barLocation:(NSPoint)location {
    NSPoint cl;
    
    cl.x = (location.x - NSMinX(_barRect))/NSWidth(_barRect);
    cl.x = CLAMP(cl.x, 0.0, 1.0);
    cl.y = (location.y - NSMinY(_barRect))/NSHeight(_barRect);
    cl.y = CLAMP(cl.y, 0.0, 1.0);
    return cl;
}

- (void)updateDirtyRange:(NSRect)range {
    [self recalcLineData:range];
    [self setNeedsDisplay:YES];
    [_target performSelector:_action 
        withObject:self afterDelay:0.0];
}


- (void)mouseDown:(NSEvent *)theEvent {
    CurvePoint *cp = NULL, *sp = NULL;
    _mouseDownLocation = [self 
        convertPoint: [theEvent locationInWindow] fromView: nil];

    if (_mouseDownLocation.y > NSMinY(_curveRect) - 5.0) {
        cp = [self bestHandleMatch:_mouseDownLocation];
        if (cp) _activeIsHandle = YES;
        else {
            NSPoint cl = [self curveLocation:_mouseDownLocation];
            int index = cl.x*NSWidth(_curveRect);
            Color4D *color = &_colorLine[index];
            Vector5D vector;
            
            Vector5DFromColor4D(&vector, color);
            vector.v[0] = cl.x;
            vector.v[4] = cl.y;
            cp = [_curve curvePointWithVector:&vector];
            sp = [_curve addCurvePoint:cp];
            [self updateDirtyRange:[_curve rangeAroundPoint:cp]];
            _activeIsHandle = YES;
        }
    }
	
    if (NSPointInRect(_mouseDownLocation, _barRect)) {
        NSPoint cl = [self barLocation:_mouseDownLocation];
        int index = cl.x*NSWidth(_curveRect);
        Color4D *color = &_colorLine[index];
        Vector5D vector;
        
        Vector5DFromColor4D(&vector, color);
        vector.v[0] = cl.x;
        cp = [_curve curvePointWithVector:&vector];
        sp = [_curve addCurvePoint:cp];
        [self updateDirtyRange:[_curve rangeAroundPoint:cp]];
        _activeIsHandle = NO;
    }
	
    if (_mouseDownLocation.y < NSMinY(_barRect)) { 
        cp = [self bestMarkerMatch:_mouseDownLocation];
        if (cp) _activeIsHandle = NO;
    }
	_suspendedPoint = sp;
    _activeCurvePoint = cp;
    _activeCanMove = cp ? ISFREE(cp) || (cp->prev && cp->next) : NO;

    if (cp) CopyVector5D (&_mouseDownVector, &cp->vector);
}


- (void)mouseDragged:(NSEvent *)theEvent {
    NSPoint location = [self convertPoint: 
        [theEvent locationInWindow] fromView: nil];
    if ([theEvent deltaX] == 0 && [theEvent deltaY] == 0)
	return;
    if (_activeCurvePoint) {
        NSRect activeRect, dirty = NSZeroRect;
        float newx, newy;
        float dx = location.x - _mouseDownLocation.x;
        float dy = location.y - _mouseDownLocation.y;
        BOOL allowRemove = _activeCanMove;
        
        if (_activeIsHandle) 
            activeRect = _curveRect;
        else
            activeRect = NSMakeRect(
                NSMinX(_barRect), 0,
                NSWidth(_barRect), NSMinY(_barRect));
        activeRect = NSInsetRect(activeRect, -16, -16);
		            
        if (NSPointInRect(location, activeRect)) {
            newx = _mouseDownVector.v[0] + 
                (_activeCanMove ? (dx/NSWidth(_curveRect)) : 0.0);
            if (_activeIsHandle) {
                newy = _mouseDownVector.v[4] + dy/NSHeight(_curveRect);
                newy = CLAMP(newy, 0.0, 1.0);
            } else newy = _mouseDownVector.v[4];
            _activeCurvePoint->vector.v[4] = newy;

            if (ISFREE(_activeCurvePoint)) {
				newx = CLAMP(newx, 0.0, 1.0);
                CPPOS(_activeCurvePoint) = newx;
                _suspendedPoint = [_curve addCurvePoint:_activeCurvePoint];
                dirty = [_curve rangeAroundPoint:_activeCurvePoint];
            } else {
                newx = rint(newx*NSWidth(_curveRect))/NSWidth(_curveRect);
                if (_allowReorder) {
					newx = CLAMP(newx, 0.0, 1.0);
                } else {
                    newx = CLAMP(newx,
						_activeCurvePoint->prev?
                        CPPOS(_activeCurvePoint->prev) : 0.0, 
                        _activeCurvePoint->next?
                        CPPOS(_activeCurvePoint->next) : 1.0);
                }
                dirty = [_curve rangeAroundPoint:_activeCurvePoint];
                [_curve removeCurvePoint:_activeCurvePoint];
				if (_suspendedPoint) {
					NSAssert([_curve addCurvePoint:_suspendedPoint] == NULL,
						@"duplicate point");
					_suspendedPoint = NULL;
				}
                CPPOS(_activeCurvePoint) = newx;
                _suspendedPoint = [_curve addCurvePoint:_activeCurvePoint];
                dirty = NSUnionRect(dirty, 
                    [_curve rangeAroundPoint:_activeCurvePoint]);
            }            
			[self updateDirtyRange:dirty];
        } 
		else if (ISBOUND(_activeCurvePoint) && allowRemove) { 
			dirty = [_curve rangeAroundPoint:_activeCurvePoint];
			[_curve removeCurvePoint:_activeCurvePoint];
			if (_suspendedPoint) {
				NSAssert([_curve addCurvePoint:_suspendedPoint] == NULL,
					@"duplicate point");
				_suspendedPoint = NULL;
			}
			[self updateDirtyRange:dirty];
		}
    }
}

- (void)mouseUp:(NSEvent *)theEvent {
    if (_activeCurvePoint && ISFREE(_activeCurvePoint)) {
        [_curve freeCurvePoint:_activeCurvePoint];
        _activeCurvePoint = NULL;
    }
	if (_suspendedPoint) {
		[_curve freeCurvePoint:_suspendedPoint];
		_suspendedPoint = NULL;
	}
    [_target performSelector:_action 
        withObject:self afterDelay:0.0];
}

- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender {
    Vector5D vector;
    NSPoint location = [self convertPoint: 
        [sender draggingLocation] fromView: nil];
    NSColor *color = [NSColor 
        colorFromPasteboard:[sender draggingPasteboard]];
    CurvePoint *cp, *sp;
    
    [color getRed:&vector.v[1] green:&vector.v[2] 
        blue:&vector.v[3] alpha:&vector.v[4]];
    vector.v[0] = CLAMP(location.x/NSWidth(_curveRect), 0.0, 1.0);
    cp = [_curve curvePointWithVector:&vector];
    sp = [_curve addCurvePoint:cp];
    _activeIsHandle = YES;
    _activeCurvePoint = cp;
	_suspendedPoint = sp;

    [self updateDirtyRange:[_curve rangeAroundPoint:cp]];
    return NSDragOperationGeneric;
}

- (NSDragOperation)draggingUpdated:(id <NSDraggingInfo>)sender {
    NSRect activeRect, dirty = NSZeroRect;
    NSPoint location = [self convertPoint: 
        [sender draggingLocation] fromView: nil];
    
    activeRect = NSUnionRect(
        NSInsetRect(_curveRect, -16, -16),
        NSInsetRect(_barRect, -16, -16));

    dirty = [_curve rangeAroundPoint:_activeCurvePoint];
    [_curve removeCurvePoint:_activeCurvePoint];
	if (_suspendedPoint) {
		NSAssert([_curve addCurvePoint:_suspendedPoint] == NULL,
			@"duplicate point");
		_suspendedPoint = NULL;
	}
    CPPOS(_activeCurvePoint) =
		CLAMP(location.x/NSWidth(_curveRect), 0.0, 1.0);
    _suspendedPoint = [_curve addCurvePoint:_activeCurvePoint];
    dirty = NSUnionRect(dirty, 
        [_curve rangeAroundPoint:_activeCurvePoint]);
    [self updateDirtyRange:dirty];
    return NSDragOperationGeneric;
}

- (void)draggingExited:(id <NSDraggingInfo>)sender {
    NSRect dirty = NSZeroRect;
    dirty = [_curve rangeAroundPoint:_activeCurvePoint];
    [_curve removeCurvePoint:_activeCurvePoint];
    _activeCurvePoint = nil;
	if (_suspendedPoint) {
		NSAssert([_curve addCurvePoint:_suspendedPoint] == NULL,
			@"duplicate point");
		_suspendedPoint = NULL;
	}
    [self updateDirtyRange:dirty];
}

- (BOOL)prepareForDragOperation:(id <NSDraggingInfo>)sender {
    return YES;
}

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender {
    return YES;
}

- (void)concludeDragOperation:(id <NSDraggingInfo>)sender {

}


@end
