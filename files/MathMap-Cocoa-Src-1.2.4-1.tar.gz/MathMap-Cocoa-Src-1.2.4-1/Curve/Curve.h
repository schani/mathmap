//
//  Curve.h
//
//  Created by Herbert Pötzl on Sat Mar 16 2002.
//  Copyright (c) 2002-2008 H.Pötzl. 
//
//  This file is part of MathMap.
//
//  MathMap is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  MathMap is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with MathMap; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

#import <AppKit/AppKit.h>

#define	MINDIST		(1.0/10000.0)

struct _Vector5D {
    float v[5];
};

typedef struct _Vector5D Vector5D; 

typedef	unsigned InterpolType;

enum	{
    InterpolTypeLinear = 1,
    InterpolTypeSpline = 2,
//    InterpolTypeCatmullRom = 3
};


static __inline__
Vector5D*
CopyVector5D (Vector5D *dst, Vector5D *src)
{
    int index;
    for (index=0; index<5; index++)
        (dst->v)[index] = (src->v)[index];
    return dst;
}

static __inline__
Vector5D
MakeVector5D(float a, float b, float c, float d, float e) {
    Vector5D vector;
    
    vector.v[0] = a;
    vector.v[1] = b;
    vector.v[2] = c;
    vector.v[3] = d;
    vector.v[4] = e;
    return vector;
}	



typedef struct _CurvePoint CurvePoint;

@interface Curve : NSObject <NSCopying, NSCoding> {
    CurvePoint *_curvePoints;
    unsigned _numPoints;
    InterpolType _interpol;
}

+ (id)curve;

- (void)setInterpolationType:(InterpolType)type;
- (InterpolType)interpolationType;

- (void)addVector:(Vector5D)vector;
- (void)removeVectorAt:(int)index;

- (unsigned)count;
- (Vector5D)vectorAtIndex:(int)index;

- (void)render:(NSRect)aRect
    toMemory:(void *)memory 
    count:(int)count 
    components:(int)num
    asFloats:(BOOL)flag;

@end


struct _CurvePoint {
        Vector5D vector;
        CurvePoint *next;
        CurvePoint *prev;
};

#define	CPPOS(p)	((p)->vector.v[0])
#define	CPVAL(p)	((p)->vector.v[4])


@interface Curve (Private)

- (CurvePoint *)curvePointList;
- (CurvePoint *)curvePointAtIndex:(int)index;

- (CurvePoint *)curvePointWithVector:(Vector5D *)vector;
- (void)freeCurvePoint:(CurvePoint *)point;

- (CurvePoint *)addCurvePoint:(CurvePoint *)newPoint;
- (CurvePoint *)removeCurvePoint:(CurvePoint *)point;

- (NSRect)rangeAroundPoint:(CurvePoint *)point;

@end
