#include <assert.h>

#include "spline.h"

static void
precalc (int len, spline_point_t *ps)
{
    int i, k;

    if (len < 2)
	return;

    /* sanity check */
    for (i = 0; i < len - 1; ++i)
	assert(ps [i].x <= ps [i+1].x);

    float b [len - 1];

    /* lower natural boundary condition */
    ps [0].y2 = b [0] = 0.0;
		
    for (i = 1; i < len - 1; ++i) {
	float sig = (ps [i].x - ps [i-1].x) / (ps [i+1].x - ps [i-1].x);
	float p = sig * ps [i-1].y2 + 2;

	ps [i].y2 = (sig - 1) / p;
	b [i] = (ps [i+1].y - ps [i].y) / (ps [i+1].x - ps [i].x)
	    - (ps [i].y - ps [i-1].y) / (ps [i].x - ps [i-1].x);
	b [i] = (6 * b [i] / (ps [i+1].x - ps [i-1].x) - sig * b [i-1]) / p;
    }
		
    /* upper natural boundary condition */
    ps [len-1].y2 = 0.0;
    for (k = len - 2; k >= 0; --k)
	ps [k].y2 = ps [k].y2 * ps [k+1].y2 + b [k];
}

static float
apply (spline_point_t *ps, float u, int i)
{
    float h = ps [i+1].x - ps [i].x;
    float a = (ps [i+1].x - u) / h;
    float b = (u - ps [i].x) / h;
    float y = a * ps [i].y + b * ps [i+1].y
	+ ((a*a*a - a) * ps [i].y2
	   + (b*b*b - b) * ps [i+1].y2) * (h*h)/6;

    return y;
}

static inline float
clamp (float x, float min, float max)
{
    if (x < min)
	return min;
    if (x > max)
	return max;
    return x;
}

void
calc_spline (int len, spline_point_t *ps, float y_min, float y_max,
	     float x_min, float x_max,
	     int num_samples, float *xs, float *ys)
{
    int i, j = 0;

    precalc(len, ps);

    for (i = 0; i < num_samples; ++i) {
	float u = x_min + (x_max - x_min) * (float)i / (float)(num_samples - 1);

	if (xs)
	    xs [i] = u;

	if (len >= 2) {
	    while (j < len - 2 && ps [j+1].x < u)
		++j;
				
	    ys [i] = clamp (apply (ps, u, j), y_min, y_max);
	} else if (len == 1)
	    ys [i] = clamp (ps [0].y, y_min, y_max);
	else
	    ys [i] = y_min;
    }
}
