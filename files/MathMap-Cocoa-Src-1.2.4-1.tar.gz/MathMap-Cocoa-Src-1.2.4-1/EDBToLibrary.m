//
//  EDBToLibrary.m
//  MathMap
//
//  Created by Mark Probst on 3/1/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "mathmap/expression_db.h"
#import "mathmap/mathmap.h"

#import "MMTreeNode.h"

int main (int argc, char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    expression_db_t *edb;
    MMTreeNode *tree_node;

    if (argc != 2)
    {
	fprintf(stderr, "Usage: EDBToLibrary <edb-path>\n");
	return 1;
    }

    init_tags();
    init_builtins();
    init_macros();
    init_noise();
    init_compiler();

    edb = read_expression_db(argv[1]);
    edb = make_expression_db_group("Root", edb);

    tree_node = [[[MMTreeNode alloc] initFromExpressionDB: edb] autorelease];

    printf("%s\n", [[tree_node description] cStringUsingEncoding: NSASCIIStringEncoding]);
    
    [pool drain];
    return 0;
}
