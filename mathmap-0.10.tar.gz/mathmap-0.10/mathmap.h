/* -*- c -*- */

#ifndef __MATHMAP_H__
#define __MATHMAP_H__

extern char error_string[];
extern int auto_preview;

void dialog_update_preview (void);

#endif
