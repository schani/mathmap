void gen_add_ri (FILE*, int*, int*, int);
    void builtin_add_ri (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0] + stack[stackp - 1].data[0];
    stack[stackp - 2].data[1] = stack[stackp - 2].data[1] + stack[stackp - 1].data[1];
        stackp -= 1;
    }

void gen_add_1 (FILE*, int*, int*, int);
    void builtin_add_1 (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0] + stack[stackp - 1].data[0];
        stackp -= 1;
    }

void gen_add_s (FILE*, int*, int*, int);
    void builtin_add_s (postfix_arg *arg)
    {
        {
        int i_1;

        for (i_1 = 0; i_1 < stack[stackp - 2].length; ++i_1)
        {
            stack[stackp - 2].data[i_1] = stack[stackp - 2].data[i_1] + stack[stackp - 1].data[0];
        }
    }
        stackp -= 1;
    }

void gen_add_n (FILE*, int*, int*, int);
    void builtin_add_n (postfix_arg *arg)
    {
        {
        int i_2;

        for (i_2 = 0; i_2 < stack[stackp - 2].length; ++i_2)
        {
            stack[stackp - 2].data[i_2] = stack[stackp - 2].data[i_2] + stack[stackp - 1].data[i_2];
        }
    }
        stackp -= 1;
    }

void gen_sub_ri (FILE*, int*, int*, int);
    void builtin_sub_ri (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0] + stack[stackp - 1].data[0];
    stack[stackp - 2].data[1] = stack[stackp - 2].data[1] + stack[stackp - 1].data[1];
        stackp -= 1;
    }

void gen_sub_1 (FILE*, int*, int*, int);
    void builtin_sub_1 (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0] - stack[stackp - 1].data[0];
        stackp -= 1;
    }

void gen_sub_s (FILE*, int*, int*, int);
    void builtin_sub_s (postfix_arg *arg)
    {
        {
        int i_3;

        for (i_3 = 0; i_3 < stack[stackp - 2].length; ++i_3)
        {
            stack[stackp - 2].data[i_3] = stack[stackp - 2].data[i_3] - stack[stackp - 1].data[0];
        }
    }
        stackp -= 1;
    }

void gen_sub_n (FILE*, int*, int*, int);
    void builtin_sub_n (postfix_arg *arg)
    {
        {
        int i_4;

        for (i_4 = 0; i_4 < stack[stackp - 2].length; ++i_4)
        {
            stack[stackp - 2].data[i_4] = stack[stackp - 2].data[i_4] - stack[stackp - 1].data[i_4];
        }
    }
        stackp -= 1;
    }

void gen_mul_ri (FILE*, int*, int*, int);
    void builtin_mul_ri (postfix_arg *arg)
    {
        float r1 = stack[stackp - 2].data[0];
    float r2 = stack[stackp - 1].data[0];
    float c1 = stack[stackp - 2].data[1];
    float c2 = stack[stackp - 1].data[1];

    stack[stackp - 2].data[0] = r1 * r2 - c1 * c2;
    stack[stackp - 2].data[1] = r1 * c2 + r2 * c1;
        stackp -= 1;
    }


void gen_mul_m2x2 (FILE*, int*, int*, int);
    void builtin_mul_m2x2 (postfix_arg *arg)
    {
        float a00 = stack[stackp - 2].data[0] * stack[stackp - 1].data[0]+stack[stackp - 2].data[1] * stack[stackp - 1].data[2];
float a01 = stack[stackp - 2].data[0] * stack[stackp - 1].data[1]+stack[stackp - 2].data[1] * stack[stackp - 1].data[3];
float a10 = stack[stackp - 2].data[2] * stack[stackp - 1].data[0]+stack[stackp - 2].data[3] * stack[stackp - 1].data[2];
float a11 = stack[stackp - 2].data[2] * stack[stackp - 1].data[1]+stack[stackp - 2].data[3] * stack[stackp - 1].data[3];

    stack[stackp - 2].data[0] = a00;
stack[stackp - 2].data[1] = a01;
stack[stackp - 2].data[2] = a10;
stack[stackp - 2].data[3] = a11;

        stackp -= 1;
    }

void gen_mul_m3x3 (FILE*, int*, int*, int);
    void builtin_mul_m3x3 (postfix_arg *arg)
    {
        float a00 = stack[stackp - 2].data[0] * stack[stackp - 1].data[0]+stack[stackp - 2].data[1] * stack[stackp - 1].data[3]+stack[stackp - 2].data[2] * stack[stackp - 1].data[6];
float a01 = stack[stackp - 2].data[0] * stack[stackp - 1].data[1]+stack[stackp - 2].data[1] * stack[stackp - 1].data[4]+stack[stackp - 2].data[2] * stack[stackp - 1].data[7];
float a02 = stack[stackp - 2].data[0] * stack[stackp - 1].data[2]+stack[stackp - 2].data[1] * stack[stackp - 1].data[5]+stack[stackp - 2].data[2] * stack[stackp - 1].data[8];
float a10 = stack[stackp - 2].data[3] * stack[stackp - 1].data[0]+stack[stackp - 2].data[4] * stack[stackp - 1].data[3]+stack[stackp - 2].data[5] * stack[stackp - 1].data[6];
float a11 = stack[stackp - 2].data[3] * stack[stackp - 1].data[1]+stack[stackp - 2].data[4] * stack[stackp - 1].data[4]+stack[stackp - 2].data[5] * stack[stackp - 1].data[7];
float a12 = stack[stackp - 2].data[3] * stack[stackp - 1].data[2]+stack[stackp - 2].data[4] * stack[stackp - 1].data[5]+stack[stackp - 2].data[5] * stack[stackp - 1].data[8];
float a20 = stack[stackp - 2].data[6] * stack[stackp - 1].data[0]+stack[stackp - 2].data[7] * stack[stackp - 1].data[3]+stack[stackp - 2].data[8] * stack[stackp - 1].data[6];
float a21 = stack[stackp - 2].data[6] * stack[stackp - 1].data[1]+stack[stackp - 2].data[7] * stack[stackp - 1].data[4]+stack[stackp - 2].data[8] * stack[stackp - 1].data[7];
float a22 = stack[stackp - 2].data[6] * stack[stackp - 1].data[2]+stack[stackp - 2].data[7] * stack[stackp - 1].data[5]+stack[stackp - 2].data[8] * stack[stackp - 1].data[8];

    stack[stackp - 2].data[0] = a00;
stack[stackp - 2].data[1] = a01;
stack[stackp - 2].data[2] = a02;
stack[stackp - 2].data[3] = a10;
stack[stackp - 2].data[4] = a11;
stack[stackp - 2].data[5] = a12;
stack[stackp - 2].data[6] = a20;
stack[stackp - 2].data[7] = a21;
stack[stackp - 2].data[8] = a22;

        stackp -= 1;
    }


void gen_mul_v2m2x2 (FILE*, int*, int*, int);
    void builtin_mul_v2m2x2 (postfix_arg *arg)
    {
        float a0 = stack[stackp - 2].data[0] * stack[stackp - 1].data[0]+stack[stackp - 2].data[1] * stack[stackp - 1].data[2];
float a1 = stack[stackp - 2].data[0] * stack[stackp - 1].data[1]+stack[stackp - 2].data[1] * stack[stackp - 1].data[3];

    stack[stackp - 2].data[0] = a0;
stack[stackp - 2].data[1] = a1;

        stackp -= 1;
    }

void gen_mul_v3m3x3 (FILE*, int*, int*, int);
    void builtin_mul_v3m3x3 (postfix_arg *arg)
    {
        float a0 = stack[stackp - 2].data[0] * stack[stackp - 1].data[0]+stack[stackp - 2].data[1] * stack[stackp - 1].data[3]+stack[stackp - 2].data[2] * stack[stackp - 1].data[6];
float a1 = stack[stackp - 2].data[0] * stack[stackp - 1].data[1]+stack[stackp - 2].data[1] * stack[stackp - 1].data[4]+stack[stackp - 2].data[2] * stack[stackp - 1].data[7];
float a2 = stack[stackp - 2].data[0] * stack[stackp - 1].data[2]+stack[stackp - 2].data[1] * stack[stackp - 1].data[5]+stack[stackp - 2].data[2] * stack[stackp - 1].data[8];

    stack[stackp - 2].data[0] = a0;
stack[stackp - 2].data[1] = a1;
stack[stackp - 2].data[2] = a2;

        stackp -= 1;
    }


void gen_mul_m2x2v2 (FILE*, int*, int*, int);
    void builtin_mul_m2x2v2 (postfix_arg *arg)
    {
        float a0 = stack[stackp - 2].data[0] * stack[stackp - 1].data[0]+stack[stackp - 2].data[1] * stack[stackp - 1].data[1];
float a1 = stack[stackp - 2].data[2] * stack[stackp - 1].data[0]+stack[stackp - 2].data[3] * stack[stackp - 1].data[1];

    stack[stackp - 2].data[0] = a0;
stack[stackp - 2].data[1] = a1;

        stackp -= 1;
    }

void gen_mul_m3x3v3 (FILE*, int*, int*, int);
    void builtin_mul_m3x3v3 (postfix_arg *arg)
    {
        float a0 = stack[stackp - 2].data[0] * stack[stackp - 1].data[0]+stack[stackp - 2].data[1] * stack[stackp - 1].data[1]+stack[stackp - 2].data[2] * stack[stackp - 1].data[2];
float a1 = stack[stackp - 2].data[3] * stack[stackp - 1].data[0]+stack[stackp - 2].data[4] * stack[stackp - 1].data[1]+stack[stackp - 2].data[5] * stack[stackp - 1].data[2];
float a2 = stack[stackp - 2].data[6] * stack[stackp - 1].data[0]+stack[stackp - 2].data[7] * stack[stackp - 1].data[1]+stack[stackp - 2].data[8] * stack[stackp - 1].data[2];

    stack[stackp - 2].data[0] = a0;
stack[stackp - 2].data[1] = a1;
stack[stackp - 2].data[2] = a2;

        stackp -= 1;
    }

void gen_mul_1 (FILE*, int*, int*, int);
    void builtin_mul_1 (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0] * stack[stackp - 1].data[0];
        stackp -= 1;
    }

void gen_mul_s (FILE*, int*, int*, int);
    void builtin_mul_s (postfix_arg *arg)
    {
        {
        int i_5;

        for (i_5 = 0; i_5 < stack[stackp - 2].length; ++i_5)
        {
            stack[stackp - 2].data[i_5] = stack[stackp - 2].data[i_5] * stack[stackp - 1].data[0];
        }
    }
        stackp -= 1;
    }

void gen_mul_n (FILE*, int*, int*, int);
    void builtin_mul_n (postfix_arg *arg)
    {
        {
        int i_6;

        for (i_6 = 0; i_6 < stack[stackp - 2].length; ++i_6)
        {
            stack[stackp - 2].data[i_6] = stack[stackp - 2].data[i_6] * stack[stackp - 1].data[i_6];
        }
    }
        stackp -= 1;
    }

void gen_div_ri (FILE*, int*, int*, int);
    void builtin_div_ri (postfix_arg *arg)
    {
        float r1 = stack[stackp - 2].data[0];
    float r2 = stack[stackp - 1].data[0];
    float c1 = stack[stackp - 2].data[1];
    float c2 = stack[stackp - 1].data[1];

    if (r2 == 0 && c2 == 0)
    {
        stack[stackp - 2].data[0] = 0;
        stack[stackp - 2].data[1] = 0;
    }
    else
    {
        stack[stackp - 2].data[0] = (r1 * r2 + c1 * c2) / (r2 * r2 + c2 * c2);
        stack[stackp - 2].data[1] = (-r1 * c2 + r2 * c1) / (r2 * r2 + c2 * c2);
    }
        stackp -= 1;
    }

void gen_div_1 (FILE*, int*, int*, int);
    void builtin_div_1 (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] == 0)
        stack[stackp - 2].data[0] = 0.0;
    else
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0] / stack[stackp - 1].data[0];
        stackp -= 1;
    }

void gen_div_s (FILE*, int*, int*, int);
    void builtin_div_s (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] == 0)
        {
        int i_7;

        for (i_7 = 0; i_7 < stack[stackp - 2].length; ++i_7)
        {
            stack[stackp - 2].data[i_7] = 0.0;
        }
    }
    else
        {
        int i_8;

        for (i_8 = 0; i_8 < stack[stackp - 2].length; ++i_8)
        {
            stack[stackp - 2].data[i_8] = stack[stackp - 2].data[i_8] / stack[stackp - 1].data[0];
        }
    }
        stackp -= 1;
    }

void gen_div_n (FILE*, int*, int*, int);
    void builtin_div_n (postfix_arg *arg)
    {
        {
        int i_9;

        for (i_9 = 0; i_9 < stack[stackp - 2].length; ++i_9)
        {
            if (stack[stackp - 1].data[i_9] == 0)
            stack[stackp - 2].data[i_9] = 0.0;
        else
            stack[stackp - 2].data[i_9] = stack[stackp - 2].data[i_9] / stack[stackp - 1].data[i_9];
        }
    }
        stackp -= 1;
    }

void gen_mod_1 (FILE*, int*, int*, int);
    void builtin_mod_1 (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] == 0)
        stack[stackp - 2].data[0] = 0.0;
    else
        stack[stackp - 2].data[0] = fmod(stack[stackp - 2].data[0], stack[stackp - 1].data[0]);
        stackp -= 1;
    }

void gen_mod_s (FILE*, int*, int*, int);
    void builtin_mod_s (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] == 0)
        {
        int i_10;

        for (i_10 = 0; i_10 < stack[stackp - 2].length; ++i_10)
        {
            stack[stackp - 2].data[i_10] = 0.0;
        }
    }
    else
        {
        int i_11;

        for (i_11 = 0; i_11 < stack[stackp - 2].length; ++i_11)
        {
            stack[stackp - 2].data[i_11] = fmod(stack[stackp - 2].data[i_11], stack[stackp - 1].data[0]);
        }
    }
        stackp -= 1;
    }

void gen_mod_n (FILE*, int*, int*, int);
    void builtin_mod_n (postfix_arg *arg)
    {
        {
        int i_12;

        for (i_12 = 0; i_12 < stack[stackp - 2].length; ++i_12)
        {
            if (stack[stackp - 1].data[i_12] == 0)
            stack[stackp - 2].data[i_12] = 0.0;
        else
            stack[stackp - 2].data[i_12] = fmod(stack[stackp - 2].data[i_12], stack[stackp - 1].data[i_12]);
        }
    }
        stackp -= 1;
    }

void gen_pmod (FILE*, int*, int*, int);
    void builtin_pmod (postfix_arg *arg)
    {
        float mod = fmod(stack[stackp - 2].data[0], stack[stackp - 1].data[0]);

    if (stack[stackp - 2].data[0] < 0)
        mod += stack[stackp - 1].data[0];

    stack[stackp - 2].data[0] = mod;
        stackp -= 1;
    }

void gen_dotp (FILE*, int*, int*, int);
    void builtin_dotp (postfix_arg *arg)
    {
        float sum = 0.0;

    {
        int i_13;

        for (i_13 = 0; i_13 < stack[stackp - 2].length; ++i_13)
        {
            sum += stack[stackp - 2].data[i_13] * stack[stackp - 1].data[i_13];
        }
    }
    stack[stackp - 2].data[0] = sum;
    stack[stackp - 2].length = 1;
        stackp -= 1;
    }

void gen_crossp (FILE*, int*, int*, int);
    void builtin_crossp (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = stack[stackp - 2].data[1] * stack[stackp - 1].data[2] - stack[stackp - 2].data[2] * stack[stackp - 1].data[1];
    stack[stackp - 2].data[1] = stack[stackp - 2].data[2] * stack[stackp - 1].data[0] - stack[stackp - 2].data[0] * stack[stackp - 1].data[2];
    stack[stackp - 2].data[2] = stack[stackp - 2].data[0] * stack[stackp - 1].data[1] - stack[stackp - 2].data[1] * stack[stackp - 1].data[0];
        stackp -= 1;
    }

void gen_det_m2x2 (FILE*, int*, int*, int);
    void builtin_det_m2x2 (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = stack[stackp - 1].data[0] * stack[stackp - 1].data[3] - stack[stackp - 1].data[1] * stack[stackp - 1].data[2];
        stackp -= 0;
    }

void gen_det_m3x3 (FILE*, int*, int*, int);
    void builtin_det_m3x3 (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = stack[stackp - 1].data[0] * stack[stackp - 1].data[4] * stack[stackp - 1].data[8]
                 + stack[stackp - 1].data[1] * stack[stackp - 1].data[5] * stack[stackp - 1].data[6]
                 + stack[stackp - 1].data[2] * stack[stackp - 1].data[3] + stack[stackp - 1].data[7]
                 - stack[stackp - 1].data[2] * stack[stackp - 1].data[4] + stack[stackp - 1].data[6]
                 - stack[stackp - 1].data[0] * stack[stackp - 1].data[5] + stack[stackp - 1].data[7]
                 - stack[stackp - 1].data[1] * stack[stackp - 1].data[3] + stack[stackp - 1].data[8];
        stackp -= 0;
    }

void gen_normalize (FILE*, int*, int*, int);
    void builtin_normalize (postfix_arg *arg)
    {
        float l = 0.0;

    {
        int i_14;

        for (i_14 = 0; i_14 < stack[stackp - 1].length; ++i_14)
        {
            l += stack[stackp - 1].data[i_14] * stack[stackp - 1].data[i_14];
        }
    }
    l = sqrt(l);
    {
        int i_15;

        for (i_15 = 0; i_15 < stack[stackp - 1].length; ++i_15)
        {
            if (l == 0)
            stack[stackp - 1].data[i_15] = 0.0;
        else
            stack[stackp - 1].data[i_15] = stack[stackp - 1].data[i_15] / l;
        }
    }
        stackp -= 0;
    }

void gen_neg (FILE*, int*, int*, int);
    void builtin_neg (postfix_arg *arg)
    {
        {
        int i_16;

        for (i_16 = 0; i_16 < stack[stackp - 1].length; ++i_16)
        {
            stack[stackp - 1].data[i_16] = -stack[stackp - 1].data[i_16];
        }
    }
        stackp -= 0;
    }

void gen_sin (FILE*, int*, int*, int);
    void builtin_sin (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = sin(stack[stackp - 1].data[0] * M_PI / 180.0);
        stackp -= 0;
    }

void gen_cos (FILE*, int*, int*, int);
    void builtin_cos (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = cos(stack[stackp - 1].data[0] * M_PI / 180.0);
        stackp -= 0;
    }

void gen_tan (FILE*, int*, int*, int);
    void builtin_tan (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = tan(stack[stackp - 1].data[0] * M_PI / 180.0);
        stackp -= 0;
    }

void gen_asin (FILE*, int*, int*, int);
    void builtin_asin (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] < -1.0 || stack[stackp - 1].data[0] > 1.0)
    {
        stack[stackp - 1].data[0] = 0.0;
    }
    else
    {
        stack[stackp - 1].data[0] = asin(stack[stackp - 1].data[0]) * 180.0 / M_PI;
    }
        stackp -= 0;
    }

void gen_acos (FILE*, int*, int*, int);
    void builtin_acos (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] < -1.0 || stack[stackp - 1].data[0] > 1.0)
    {
        stack[stackp - 1].data[0] = 0.0;
    }
    else
    {
        stack[stackp - 1].data[0] = acos(stack[stackp - 1].data[0]) * 180.0 / M_PI;
    }
        stackp -= 0;
    }

void gen_atan (FILE*, int*, int*, int);
    void builtin_atan (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = atan(stack[stackp - 1].data[0]) * 180.0 / M_PI;
        stackp -= 0;
    }

void gen_atan2 (FILE*, int*, int*, int);
    void builtin_atan2 (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = atan2(stack[stackp - 2].data[0],stack[stackp - 1].data[0]) * 180.0 / M_PI;
        stackp -= 1;
    }

void gen_pow_1 (FILE*, int*, int*, int);
    void builtin_pow_1 (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = pow(stack[stackp - 2].data[0], stack[stackp - 1].data[0]);
        stackp -= 1;
    }

void gen_pow_s (FILE*, int*, int*, int);
    void builtin_pow_s (postfix_arg *arg)
    {
        {
        int i_17;

        for (i_17 = 0; i_17 < stack[stackp - 2].length; ++i_17)
        {
            stack[stackp - 2].data[i_17] = pow(stack[stackp - 2].data[i_17], stack[stackp - 1].data[0]);
        }
    }
        stackp -= 1;
    }

void gen_abs_ri (FILE*, int*, int*, int);
    void builtin_abs_ri (postfix_arg *arg)
    {
        float r = stack[stackp - 1].data[0];
    float i = stack[stackp - 1].data[1];

    stack[stackp - 1].data[0] = sqrt(r * r + i * i);
    stack[stackp - 1].length = 1;
        stackp -= 0;
    }

void gen_abs_1 (FILE*, int*, int*, int);
    void builtin_abs_1 (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = fabs(stack[stackp - 1].data[0]);
        stackp -= 0;
    }

void gen_abs_n (FILE*, int*, int*, int);
    void builtin_abs_n (postfix_arg *arg)
    {
        {
        int i_18;

        for (i_18 = 0; i_18 < stack[stackp - 1].length; ++i_18)
        {
            stack[stackp - 1].data[i_18] = fabs(stack[stackp - 1].data[i_18]);
        }
    }
        stackp -= 0;
    }

void gen_floor (FILE*, int*, int*, int);
    void builtin_floor (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = floor(stack[stackp - 1].data[0]);
        stackp -= 0;
    }

void gen_sign_1 (FILE*, int*, int*, int);
    void builtin_sign_1 (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] < 0)
        stack[stackp - 1].data[0] = -1.0;
    else if (stack[stackp - 1].data[0] > 0)
        stack[stackp - 1].data[0] = 1.0;
    else
        stack[stackp - 1].data[0] = 0.0;
        stackp -= 0;
    }

void gen_sign_n (FILE*, int*, int*, int);
    void builtin_sign_n (postfix_arg *arg)
    {
        {
        int i_19;

        for (i_19 = 0; i_19 < stack[stackp - 1].length; ++i_19)
        {
            if (stack[stackp - 1].data[i_19] < 0)
            stack[stackp - 1].data[i_19] = -1.0;
        else if (stack[stackp - 1].data[i_19] > 0)
            stack[stackp - 1].data[i_19] = 1.0;
        else
            stack[stackp - 1].data[i_19] = 0.0;
        }
    }
        stackp -= 0;
    }

void gen_min_1 (FILE*, int*, int*, int);
    void builtin_min_1 (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] < stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0];
    else
        stack[stackp - 2].data[0] = stack[stackp - 1].data[0];
        stackp -= 1;
    }

void gen_min_n (FILE*, int*, int*, int);
    void builtin_min_n (postfix_arg *arg)
    {
        {
        int i_20;

        for (i_20 = 0; i_20 < stack[stackp - 2].length; ++i_20)
        {
            if (stack[stackp - 2].data[i_20] < stack[stackp - 1].data[i_20])
            stack[stackp - 2].data[i_20] = stack[stackp - 2].data[i_20];
        else
            stack[stackp - 2].data[i_20] = stack[stackp - 1].data[i_20];
        }
    }
        stackp -= 1;
    }

void gen_max_1 (FILE*, int*, int*, int);
    void builtin_max_1 (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] > stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = stack[stackp - 2].data[0];
    else
        stack[stackp - 2].data[0] = stack[stackp - 1].data[0];
        stackp -= 1;
    }

void gen_max_n (FILE*, int*, int*, int);
    void builtin_max_n (postfix_arg *arg)
    {
        {
        int i_21;

        for (i_21 = 0; i_21 < stack[stackp - 2].length; ++i_21)
        {
            if (stack[stackp - 2].data[i_21] > stack[stackp - 1].data[i_21])
            stack[stackp - 2].data[i_21] = stack[stackp - 2].data[i_21];
        else
            stack[stackp - 2].data[i_21] = stack[stackp - 1].data[i_21];
        }
    }
        stackp -= 1;
    }

void gen_sum (FILE*, int*, int*, int);
    void builtin_sum (postfix_arg *arg)
    {
        float sum = 0.0;

    {
        int i_22;

        for (i_22 = 0; i_22 < stack[stackp - 1].length; ++i_22)
        {
            sum += stack[stackp - 1].data[i_22];
        }
    }
    stack[stackp - 1].data[0] = sum;
        stackp -= 0;
    }

void gen_not (FILE*, int*, int*, int);
    void builtin_not (postfix_arg *arg)
    {
        if (stack[stackp - 1].data[0] != 0)
        stack[stackp - 1].data[0] = 0.0;
    else
        stack[stackp - 1].data[0] = 1.0;
        stackp -= 0;
    }

void gen_or (FILE*, int*, int*, int);
    void builtin_or (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] || stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_and (FILE*, int*, int*, int);
    void builtin_and (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] && stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_equal (FILE*, int*, int*, int);
    void builtin_equal (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] == stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_less (FILE*, int*, int*, int);
    void builtin_less (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] < stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_greater (FILE*, int*, int*, int);
    void builtin_greater (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] > stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_lessequal (FILE*, int*, int*, int);
    void builtin_lessequal (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] <= stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_greaterequal (FILE*, int*, int*, int);
    void builtin_greaterequal (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] >= stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_notequal (FILE*, int*, int*, int);
    void builtin_notequal (postfix_arg *arg)
    {
        if (stack[stackp - 2].data[0] != stack[stackp - 1].data[0])
        stack[stackp - 2].data[0] = 1.0;
    else
        stack[stackp - 2].data[0] = 0.0;
        stackp -= 1;
    }

void gen_inintv (FILE*, int*, int*, int);
    void builtin_inintv (postfix_arg *arg)
    {
        if (stack[stackp - 3].data[0] >= stack[stackp - 2].data[0] && stack[stackp - 3].data[0] <= stack[stackp - 1].data[0])
        stack[stackp - 3].data[0] = 1.0;
    else
        stack[stackp - 3].data[0] = 0.0;
        stackp -= 2;
    }

void gen_rand (FILE*, int*, int*, int);
    void builtin_rand (postfix_arg *arg)
    {
        stack[stackp - 2].data[0] = (random() / (double)0x7fffffff) * (stack[stackp - 1].data[0] - stack[stackp - 2].data[0]) + stack[stackp - 2].data[0];
        stackp -= 1;
    }

void gen_origValXY (FILE*, int*, int*, int);
    void builtin_origValXY (postfix_arg *arg)
    {
        unsigned char pixel[4];

    getOrigValPixel(stack[stackp - 1].data[0],stack[stackp - 1].data[1],pixel);

    {
        int i_23;

        for (i_23 = 0; i_23 < 4; ++i_23)
        {
            stack[stackp - 1].data[i_23] = pixel[i_23] / 255.0;
        }
    }
    stack[stackp - 1].length = 4;
        stackp -= 0;
    }

void gen_origValXYIntersample (FILE*, int*, int*, int);
    void builtin_origValXYIntersample (postfix_arg *arg)
    {
        unsigned char pixel[4];

    getOrigValIntersamplePixel(stack[stackp - 1].data[0],stack[stackp - 1].data[1],pixel);

    {
        int i_24;

        for (i_24 = 0; i_24 < 4; ++i_24)
        {
            stack[stackp - 1].data[i_24] = pixel[i_24] / 255.0;
        }
    }
    stack[stackp - 1].length = 4;
        stackp -= 0;
    }

void gen_gray (FILE*, int*, int*, int);
    void builtin_gray (postfix_arg *arg)
    {
        stack[stackp - 1].data[0] = 0.299 * stack[stackp - 1].data[0] + 0.587 * stack[stackp - 1].data[1] + 0.114 * stack[stackp - 1].data[2];
    stack[stackp - 1].length = 1;
        stackp -= 0;
    }

void gen_curve (FILE*, int*, int*, int);
    void builtin_curve (postfix_arg *arg)
    {
        int index = stack[stackp - 1].data[0] * (user_curve_points - 1);

    if (index < 0)
        index = 0;
    else if (index >=  user_curve_points)
        index = user_curve_points - 1;

    stack[stackp - 1].data[0] = user_curve_values[index];
        stackp -= 0;
    }

void gen_gradient (FILE*, int*, int*, int);
    void builtin_gradient (postfix_arg *arg)
    {
        int index = stack[stackp - 1].data[0] * (num_gradient_samples - 1);

    if (index < 0)
        index = 0;
    else if (index >= num_gradient_samples)
        index = num_gradient_samples - 1;

    {
        int i_25;

        for (i_25 = 0; i_25 < 4; ++i_25)
        {
            stack[stackp - 1].data[i_25] = gradient_samples[index].data[i_25];
        }
    }
    stack[stackp - 1].length = 4;
        stackp -= 0;
    }

void gen_bertl (FILE*, int*, int*, int);
    void builtin_bertl (postfix_arg *arg)
    {
        float x = stack[stackp - 1].data[0];

    stack[stackp - 1].data[0] = (sin(x) + sin(x * 5) / 5 + sin(x * 13) / 13 + sin(x * 17) / 17) / (1.0 + 1.0 / 5.0 + 1.0 / 13.0 + 1.0 / 17.0);
        stackp -= 0;
    }

void gen_toXY (FILE*, int*, int*, int);
    void builtin_toXY (postfix_arg *arg)
    {
        double x, y;

    x = cos(stack[stackp - 1].data[1] * M_PI / 180) * stack[stackp - 1].data[0];
    y = sin(stack[stackp - 1].data[1] * M_PI / 180) * stack[stackp - 1].data[0];

    stack[stackp - 1].data[0] = x;
    stack[stackp - 1].data[1] = y;
        stackp -= 0;
    }

void gen_toRA (FILE*, int*, int*, int);
    void builtin_toRA (postfix_arg *arg)
    {
        double x, y, r, a;

    x = stack[stackp - 1].data[0];
    y = stack[stackp - 1].data[1];

    r = sqrt(x * x + y * y);
    if (r == 0)
        a = 0.0;
    else
        a = acos(x / r) * 180 / M_PI;

    if (y < 0)
        a = 360 - a;

    stack[stackp - 1].data[0] = r;
    stack[stackp - 1].data[1] = a;
        stackp -= 0;
    }


void
init_builtins (void)
{
register_overloaded_builtin("__add", "ri:2=ri:2,ri:2",
                                   builtin_add_ri,
                                   gen_add_ri);
register_overloaded_builtin("__add", "T:1=T:1,T:1",
                                   builtin_add_1,
                                   gen_add_1);
register_overloaded_builtin("__add", "T:L=T:L,_:1",
                                   builtin_add_s,
                                   gen_add_s);
register_overloaded_builtin("__add", "T:L=T:L,T:L",
                                   builtin_add_n,
                                   gen_add_n);
register_overloaded_builtin("__sub", "ri:2=ri:2,ri:2",
                                   builtin_sub_ri,
                                   gen_sub_ri);
register_overloaded_builtin("__sub", "T:1=T:1,T:1",
                                   builtin_sub_1,
                                   gen_sub_1);
register_overloaded_builtin("__sub", "T:L=T:L,_:1",
                                   builtin_sub_s,
                                   gen_sub_s);
register_overloaded_builtin("__sub", "T:L=T:L,T:L",
                                   builtin_sub_n,
                                   gen_sub_n);
register_overloaded_builtin("__mul", "ri:2=ri:2,ri:2",
                                   builtin_mul_ri,
                                   gen_mul_ri);
register_overloaded_builtin("__mul", "m2x2:4=m2x2:4,m2x2:4",
                                   builtin_mul_m2x2,
                                   gen_mul_m2x2);
register_overloaded_builtin("__mul", "m3x3:9=m3x3:9,m3x3:9",
                                   builtin_mul_m3x3,
                                   gen_mul_m3x3);
register_overloaded_builtin("__mul", "T:2=T:2,m2x2:4",
                                   builtin_mul_v2m2x2,
                                   gen_mul_v2m2x2);
register_overloaded_builtin("__mul", "T:3=T:3,m3x3:9",
                                   builtin_mul_v3m3x3,
                                   gen_mul_v3m3x3);
register_overloaded_builtin("__mul", "T:2=m2x2:4,T:2",
                                   builtin_mul_m2x2v2,
                                   gen_mul_m2x2v2);
register_overloaded_builtin("__mul", "T:3=m3x3:9,T:3",
                                   builtin_mul_m3x3v3,
                                   gen_mul_m3x3v3);
register_overloaded_builtin("__mul", "T:1=T:1,T:1",
                                   builtin_mul_1,
                                   gen_mul_1);
register_overloaded_builtin("__mul", "T:L=T:L,_:1",
                                   builtin_mul_s,
                                   gen_mul_s);
register_overloaded_builtin("__mul", "T:L=T:L,T:L",
                                   builtin_mul_n,
                                   gen_mul_n);
register_overloaded_builtin("__div", "ri:2=ri:2,ri:2",
                                   builtin_div_ri,
                                   gen_div_ri);
register_overloaded_builtin("__div", "T:1=T:1,T:1",
                                   builtin_div_1,
                                   gen_div_1);
register_overloaded_builtin("__div", "T:L=T:L,_:1",
                                   builtin_div_s,
                                   gen_div_s);
register_overloaded_builtin("__div", "T:L=T:L,T:L",
                                   builtin_div_n,
                                   gen_div_n);
register_overloaded_builtin("__mod", "T:1=T:1,T:1",
                                   builtin_mod_1,
                                   gen_mod_1);
register_overloaded_builtin("__mod", "T:L=T:L,_:1",
                                   builtin_mod_s,
                                   gen_mod_s);
register_overloaded_builtin("__mod", "T:L=T:L,T:L",
                                   builtin_mod_n,
                                   gen_mod_n);
register_overloaded_builtin("pmod", "T:1=T:1,T:1",
                                   builtin_pmod,
                                   gen_pmod);
register_overloaded_builtin("dotp", "nil:1=T:L,T:L",
                                   builtin_dotp,
                                   gen_dotp);
register_overloaded_builtin("crossp", "T:3=T:3,T:3",
                                   builtin_crossp,
                                   gen_crossp);
register_overloaded_builtin("det", "nil:1=m2x2:4",
                                   builtin_det_m2x2,
                                   gen_det_m2x2);
register_overloaded_builtin("det", "nil:1=m3x3:9",
                                   builtin_det_m3x3,
                                   gen_det_m3x3);
register_overloaded_builtin("normalize", "T:L=T:L",
                                   builtin_normalize,
                                   gen_normalize);
register_overloaded_builtin("__neg", "T:L=T:L",
                                   builtin_neg,
                                   gen_neg);
register_overloaded_builtin("sin", "T:1=T:1",
                                   builtin_sin,
                                   gen_sin);
register_overloaded_builtin("cos", "T:1=T:1",
                                   builtin_cos,
                                   gen_cos);
register_overloaded_builtin("tan", "T:1=T:1",
                                   builtin_tan,
                                   gen_tan);
register_overloaded_builtin("asin", "T:1=T:1",
                                   builtin_asin,
                                   gen_asin);
register_overloaded_builtin("acos", "T:1=T:1",
                                   builtin_acos,
                                   gen_acos);
register_overloaded_builtin("atan", "T:1=T:1",
                                   builtin_atan,
                                   gen_atan);
register_overloaded_builtin("atan", "T:1=T:1,T:1",
                                   builtin_atan2,
                                   gen_atan2);
register_overloaded_builtin("__pow", "T:1=T:1,T:1",
                                   builtin_pow_1,
                                   gen_pow_1);
register_overloaded_builtin("__pow", "T:L=T:L,_:1",
                                   builtin_pow_s,
                                   gen_pow_s);
register_overloaded_builtin("abs", "nil:1=ri:2",
                                   builtin_abs_ri,
                                   gen_abs_ri);
register_overloaded_builtin("abs", "T:1=T:1",
                                   builtin_abs_1,
                                   gen_abs_1);
register_overloaded_builtin("abs", "T:L=T:L",
                                   builtin_abs_n,
                                   gen_abs_n);
register_overloaded_builtin("floor", "T:1=T:1",
                                   builtin_floor,
                                   gen_floor);
register_overloaded_builtin("sign", "T:1=T:1",
                                   builtin_sign_1,
                                   gen_sign_1);
register_overloaded_builtin("sign", "T:L=T:L",
                                   builtin_sign_n,
                                   gen_sign_n);
register_overloaded_builtin("min", "T:1=T:1,T:1",
                                   builtin_min_1,
                                   gen_min_1);
register_overloaded_builtin("min", "T:L=T:L,T:L",
                                   builtin_min_n,
                                   gen_min_n);
register_overloaded_builtin("max", "T:1=T:1,T:1",
                                   builtin_max_1,
                                   gen_max_1);
register_overloaded_builtin("max", "T:L=T:L,T:L",
                                   builtin_max_n,
                                   gen_max_n);
register_overloaded_builtin("sum", "T:1=T:L",
                                   builtin_sum,
                                   gen_sum);
register_overloaded_builtin("__not", "T:1=T:1",
                                   builtin_not,
                                   gen_not);
register_overloaded_builtin("__or", "T:1=T:1,T:1",
                                   builtin_or,
                                   gen_or);
register_overloaded_builtin("__and", "T:1=T:1,T:1",
                                   builtin_and,
                                   gen_and);
register_overloaded_builtin("__equal", "T:1=T:1,T:1",
                                   builtin_equal,
                                   gen_equal);
register_overloaded_builtin("__less", "T:1=T:1,T:1",
                                   builtin_less,
                                   gen_less);
register_overloaded_builtin("__greater", "T:1=T:1,T:1",
                                   builtin_greater,
                                   gen_greater);
register_overloaded_builtin("__lessequal", "T:1=T:1,T:1",
                                   builtin_lessequal,
                                   gen_lessequal);
register_overloaded_builtin("__greaterequal", "T:1=T:1,T:1",
                                   builtin_greaterequal,
                                   gen_greaterequal);
register_overloaded_builtin("__notequal", "T:1=T:1,T:1",
                                   builtin_notequal,
                                   gen_notequal);
register_overloaded_builtin("inintv", "T:1=T:1,T:1,T:1",
                                   builtin_inintv,
                                   gen_inintv);
register_overloaded_builtin("rand", "T:1=T:1,T:1",
                                   builtin_rand,
                                   gen_rand);
register_overloaded_builtin("origVal", "rgba:4=xy:2",
                                   builtin_origValXY,
                                   gen_origValXY);
register_overloaded_builtin("origValIntersample", "rgba:4=xy:2",
                                   builtin_origValXYIntersample,
                                   gen_origValXYIntersample);
register_overloaded_builtin("gray", "nil:1=rgba:4",
                                   builtin_gray,
                                   gen_gray);
register_overloaded_builtin("curve", "T:1=T:1",
                                   builtin_curve,
                                   gen_curve);
register_overloaded_builtin("gradient", "rgba:4=_:1",
                                   builtin_gradient,
                                   gen_gradient);
register_overloaded_builtin("bertl", "T:1=T:1",
                                   builtin_bertl,
                                   gen_bertl);
register_overloaded_builtin("toXY", "xy:2=ra:2",
                                   builtin_toXY,
                                   gen_toXY);
register_overloaded_builtin("toRA", "ra:2=xy:2",
                                   builtin_toRA,
                                   gen_toRA);

}
