#ifndef __ARGSCANNER_H__
#define __ARGSCANNER_H__

void scan_args_from_string (char *string);
void end_scanning_args_from_string (void);

#endif
