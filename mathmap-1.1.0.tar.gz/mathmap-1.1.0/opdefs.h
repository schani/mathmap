#define OP_NOP 0
#define OP_ADD 1
#define OP_SUB 2
#define OP_NEG 3
#define OP_MUL 4
#define OP_DIV 5
#define OP_MOD 6
#define OP_ABS 7
#define OP_MIN 8
#define OP_MAX 9
#define OP_SQRT 10
#define OP_HYPOT 11
#define OP_SIN 12
#define OP_COS 13
#define OP_TAN 14
#define OP_ASIN 15
#define OP_ACOS 16
#define OP_ATAN 17
#define OP_ATAN2 18
#define OP_POW 19
#define OP_EXP 20
#define OP_LOG 21
#define OP_SINH 22
#define OP_COSH 23
#define OP_TANH 24
#define OP_ASINH 25
#define OP_ACOSH 26
#define OP_ATANH 27
#define OP_GAMMA 28
#define OP_FLOOR 29
#define OP_EQ 30
#define OP_LESS 31
#define OP_LEQ 32
#define OP_NOT 33
#define OP_PRINT 34
#define OP_NEWLINE 35
#define OP_START_DEBUG_TUPLE 36
#define OP_SET_DEBUG_TUPLE_DATA 37
#define OP_ORIG_VAL 38
#define OP_RED 39
#define OP_GREEN 40
#define OP_BLUE 41
#define OP_ALPHA 42
#define OP_COMPLEX 43
#define OP_C_REAL 44
#define OP_C_IMAG 45
#define OP_C_SQRT 46
#define OP_C_SIN 47
#define OP_C_COS 48
#define OP_C_TAN 49
#define OP_C_ASIN 50
#define OP_C_ACOS 51
#define OP_C_ATAN 52
#define OP_C_POW 53
#define OP_C_EXP 54
#define OP_C_LOG 55
#define OP_C_ARG 56
#define OP_C_SINH 57
#define OP_C_COSH 58
#define OP_C_TANH 59
#define OP_C_ASINH 60
#define OP_C_ACOSH 61
#define OP_C_ATANH 62
#define OP_C_GAMMA 63
#define OP_MAKE_M2X2 64
#define OP_MAKE_M3X3 65
#define OP_FREE_MATRIX 66
#define OP_MAKE_V2 67
#define OP_MAKE_V3 68
#define OP_FREE_VECTOR 69
#define OP_VECTOR_NTH 70
#define OP_SOLVE_LINEAR_2 71
#define OP_SOLVE_LINEAR_3 72
#define OP_SOLVE_POLY_2 73
#define OP_SOLVE_POLY_3 74
#define OP_NOISE 75
#define OP_RAND 76
#define OP_USERVAL_INT 77
#define OP_USERVAL_FLOAT 78
#define OP_USERVAL_BOOL 79
#define OP_USERVAL_CURVE 80
#define OP_USERVAL_COLOR 81
#define OP_USERVAL_GRADIENT 82
#define OP_MAKE_COLOR 83
#define OP_OUTPUT_COLOR 84

#define NUM_OPS 85

static void
init_ops (void)
{
    init_op(OP_NOP, "NOP", 0, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_ADD, "ADD", 2, TYPE_PROP_MAX, 0, 1, 1);
    init_op(OP_SUB, "SUB", 2, TYPE_PROP_MAX, 0, 1, 1);
    init_op(OP_NEG, "NEG", 1, TYPE_PROP_MAX, 0, 1, 1);
    init_op(OP_MUL, "MUL", 2, TYPE_PROP_MAX, 0, 1, 1);
    init_op(OP_DIV, "DIV", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_MOD, "MOD", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ABS, "fabs", 1, TYPE_PROP_MAX_FLOAT, 0, 1, 1);
    init_op(OP_MIN, "MIN", 2, TYPE_PROP_MAX_FLOAT, 0, 1, 1);
    init_op(OP_MAX, "MAX", 2, TYPE_PROP_MAX_FLOAT, 0, 1, 1);
    init_op(OP_SQRT, "sqrt", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_HYPOT, "hypot", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_SIN, "sin", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_COS, "cos", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_TAN, "tan", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ASIN, "asin", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ACOS, "acos", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ATAN, "atan", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ATAN2, "atan2", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_POW, "pow", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_EXP, "exp", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_LOG, "log", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_SINH, "sinh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_COSH, "cosh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_TANH, "tanh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ASINH, "asinh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ACOSH, "acosh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_ATANH, "atanh", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_GAMMA, "GAMMA", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_FLOOR, "floor", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_EQ, "EQ", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_LESS, "LESS", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_LEQ, "LEQ", 2, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_NOT, "NOT", 1, TYPE_PROP_CONST, TYPE_INT, 1, 1);
    init_op(OP_PRINT, "PRINT_FLOAT", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_NEWLINE, "NEWLINE", 0, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_START_DEBUG_TUPLE, "START_DEBUG_TUPLE", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_SET_DEBUG_TUPLE_DATA, "SET_DEBUG_TUPLE_DATA", 2, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_ORIG_VAL, "ORIG_VAL", 4, TYPE_PROP_CONST, TYPE_COLOR, 1, 0);
    init_op(OP_RED, "RED_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0);
    init_op(OP_GREEN, "GREEN_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0);
    init_op(OP_BLUE, "BLUE_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0);
    init_op(OP_ALPHA, "ALPHA_FLOAT", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0);
    init_op(OP_COMPLEX, "COMPLEX", 2, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_REAL, "crealf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_C_IMAG, "cimagf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_C_SQRT, "csqrtf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_SIN, "csinf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_COS, "ccosf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_TAN, "ctanf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_ASIN, "casinf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_ACOS, "cacosf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_ATAN, "catanf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_POW, "cpowf", 2, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_EXP, "cexpf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_LOG, "clogf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_ARG, "cargf", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_C_SINH, "csinhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_COSH, "ccoshf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_TANH, "ctanhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_ASINH, "casinhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_ACOSH, "cacoshf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_ATANH, "catanhf", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_C_GAMMA, "cgamma", 1, TYPE_PROP_CONST, TYPE_COMPLEX, 1, 1);
    init_op(OP_MAKE_M2X2, "MAKE_M2X2", 4, TYPE_PROP_CONST, TYPE_MATRIX, 0, 0);
    init_op(OP_MAKE_M3X3, "MAKE_M3X3", 9, TYPE_PROP_CONST, TYPE_MATRIX, 0, 0);
    init_op(OP_FREE_MATRIX, "FREE_MATRIX", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_MAKE_V2, "MAKE_V2", 2, TYPE_PROP_CONST, TYPE_VECTOR, 0, 0);
    init_op(OP_MAKE_V3, "MAKE_V3", 3, TYPE_PROP_CONST, TYPE_VECTOR, 0, 0);
    init_op(OP_FREE_VECTOR, "FREE_VECTOR", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0);
    init_op(OP_VECTOR_NTH, "VECTOR_NTH", 2, TYPE_PROP_CONST, TYPE_FLOAT, 0, 0);
    init_op(OP_SOLVE_LINEAR_2, "SOLVE_LINEAR_2", 2, TYPE_PROP_CONST, TYPE_VECTOR, 0, 0);
    init_op(OP_SOLVE_LINEAR_3, "SOLVE_LINEAR_3", 2, TYPE_PROP_CONST, TYPE_VECTOR, 0, 0);
    init_op(OP_SOLVE_POLY_2, "SOLVE_POLY_2", 3, TYPE_PROP_CONST, TYPE_VECTOR, 0, 0);
    init_op(OP_SOLVE_POLY_3, "SOLVE_POLY_3", 4, TYPE_PROP_CONST, TYPE_VECTOR, 0, 0);
    init_op(OP_NOISE, "noise", 3, TYPE_PROP_CONST, TYPE_FLOAT, 1, 1);
    init_op(OP_RAND, "RAND", 2, TYPE_PROP_CONST, TYPE_FLOAT, 0, 0);
    init_op(OP_USERVAL_INT, "USERVAL_INT_ACCESS", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0);
    init_op(OP_USERVAL_FLOAT, "USERVAL_FLOAT_ACCESS", 1, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0);
    init_op(OP_USERVAL_BOOL, "USERVAL_BOOL_ACCESS", 1, TYPE_PROP_CONST, TYPE_INT, 1, 0);
    init_op(OP_USERVAL_CURVE, "USERVAL_CURVE_ACCESS", 2, TYPE_PROP_CONST, TYPE_FLOAT, 1, 0);
    init_op(OP_USERVAL_COLOR, "USERVAL_COLOR_ACCESS", 1, TYPE_PROP_CONST, TYPE_COLOR, 1, 0);
    init_op(OP_USERVAL_GRADIENT, "USERVAL_GRADIENT_ACCESS", 2, TYPE_PROP_CONST, TYPE_COLOR, 1, 0);
    init_op(OP_MAKE_COLOR, "MAKE_COLOR", 4, TYPE_PROP_CONST, TYPE_COLOR, 1, 1);
    init_op(OP_OUTPUT_COLOR, "OUTPUT_COLOR", 1, TYPE_PROP_CONST, TYPE_INT, 0, 0);
}

static primary_t
fold_rhs (rhs_t *rhs)
{
assert(rhs_is_foldable(rhs));
switch(rhs->v.op.op->index)
{
case OP_NOP :
return make_int_const_primary(NOP());
case OP_ADD :
switch (rhs->v.op.args[0].type) {
case PRIMARY_INT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_int_const_primary(ADD((int)rhs->v.op.args[0].v.int_const, (int)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.int_const, (float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.int_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
case PRIMARY_FLOAT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(ADD((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.float_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
case PRIMARY_COMPLEX_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(ADD((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SUB :
switch (rhs->v.op.args[0].type) {
case PRIMARY_INT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_int_const_primary(SUB((int)rhs->v.op.args[0].v.int_const, (int)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.int_const, (float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.int_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
case PRIMARY_FLOAT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(SUB((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.float_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
case PRIMARY_COMPLEX_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(SUB((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_NEG :
switch (rhs->v.op.args[0].type) {
case PRIMARY_INT_CONST :
return make_int_const_primary(NEG((int)rhs->v.op.args[0].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(NEG((float)rhs->v.op.args[0].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(NEG((complex float)rhs->v.op.args[0].v.complex_const));
default : assert(0); break;
}
case OP_MUL :
switch (rhs->v.op.args[0].type) {
case PRIMARY_INT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_int_const_primary(MUL((int)rhs->v.op.args[0].v.int_const, (int)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.int_const, (float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.int_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
case PRIMARY_FLOAT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(MUL((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.float_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
case PRIMARY_COMPLEX_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.float_const));
case PRIMARY_COMPLEX_CONST :
return make_complex_const_primary(MUL((complex float)rhs->v.op.args[0].v.complex_const, (complex float)rhs->v.op.args[1].v.complex_const));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_DIV :
return make_float_const_primary(DIV(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_MOD :
return make_float_const_primary(MOD(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_ABS :
switch (rhs->v.op.args[0].type) {
case PRIMARY_INT_CONST :
return make_int_const_primary(fabs((int)rhs->v.op.args[0].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(fabs((float)rhs->v.op.args[0].v.float_const));
default : assert(0); break;
}
case OP_MIN :
switch (rhs->v.op.args[0].type) {
case PRIMARY_INT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_int_const_primary(MIN((int)rhs->v.op.args[0].v.int_const, (int)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.int_const, (float)rhs->v.op.args[1].v.float_const));
default : assert(0); break;
}
case PRIMARY_FLOAT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(MIN((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.float_const));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_MAX :
switch (rhs->v.op.args[0].type) {
case PRIMARY_INT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_int_const_primary(MAX((int)rhs->v.op.args[0].v.int_const, (int)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.int_const, (float)rhs->v.op.args[1].v.float_const));
default : assert(0); break;
}
case PRIMARY_FLOAT_CONST :
switch (rhs->v.op.args[1].type) {
case PRIMARY_INT_CONST :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.int_const));
case PRIMARY_FLOAT_CONST :
return make_float_const_primary(MAX((float)rhs->v.op.args[0].v.float_const, (float)rhs->v.op.args[1].v.float_const));
default : assert(0); break;
}
default : assert(0); break;
}
case OP_SQRT :
return make_float_const_primary(sqrt(OP_CONST_FLOAT_VAL(0)));
case OP_HYPOT :
return make_float_const_primary(hypot(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_SIN :
return make_float_const_primary(sin(OP_CONST_FLOAT_VAL(0)));
case OP_COS :
return make_float_const_primary(cos(OP_CONST_FLOAT_VAL(0)));
case OP_TAN :
return make_float_const_primary(tan(OP_CONST_FLOAT_VAL(0)));
case OP_ASIN :
return make_float_const_primary(asin(OP_CONST_FLOAT_VAL(0)));
case OP_ACOS :
return make_float_const_primary(acos(OP_CONST_FLOAT_VAL(0)));
case OP_ATAN :
return make_float_const_primary(atan(OP_CONST_FLOAT_VAL(0)));
case OP_ATAN2 :
return make_float_const_primary(atan2(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_POW :
return make_float_const_primary(pow(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_EXP :
return make_float_const_primary(exp(OP_CONST_FLOAT_VAL(0)));
case OP_LOG :
return make_float_const_primary(log(OP_CONST_FLOAT_VAL(0)));
case OP_SINH :
return make_float_const_primary(sinh(OP_CONST_FLOAT_VAL(0)));
case OP_COSH :
return make_float_const_primary(cosh(OP_CONST_FLOAT_VAL(0)));
case OP_TANH :
return make_float_const_primary(tanh(OP_CONST_FLOAT_VAL(0)));
case OP_ASINH :
return make_float_const_primary(asinh(OP_CONST_FLOAT_VAL(0)));
case OP_ACOSH :
return make_float_const_primary(acosh(OP_CONST_FLOAT_VAL(0)));
case OP_ATANH :
return make_float_const_primary(atanh(OP_CONST_FLOAT_VAL(0)));
case OP_GAMMA :
return make_float_const_primary(GAMMA(OP_CONST_FLOAT_VAL(0)));
case OP_FLOOR :
return make_int_const_primary(floor(OP_CONST_FLOAT_VAL(0)));
case OP_EQ :
return make_int_const_primary(EQ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_LESS :
return make_int_const_primary(LESS(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_LEQ :
return make_int_const_primary(LEQ(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_NOT :
return make_int_const_primary(NOT(OP_CONST_FLOAT_VAL(0)));
case OP_COMPLEX :
return make_complex_const_primary(COMPLEX(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_C_REAL :
return make_float_const_primary(crealf(OP_CONST_FLOAT_VAL(0)));
case OP_C_IMAG :
return make_float_const_primary(cimagf(OP_CONST_FLOAT_VAL(0)));
case OP_C_SQRT :
return make_complex_const_primary(csqrtf(OP_CONST_FLOAT_VAL(0)));
case OP_C_SIN :
return make_complex_const_primary(csinf(OP_CONST_FLOAT_VAL(0)));
case OP_C_COS :
return make_complex_const_primary(ccosf(OP_CONST_FLOAT_VAL(0)));
case OP_C_TAN :
return make_complex_const_primary(ctanf(OP_CONST_FLOAT_VAL(0)));
case OP_C_ASIN :
return make_complex_const_primary(casinf(OP_CONST_FLOAT_VAL(0)));
case OP_C_ACOS :
return make_complex_const_primary(cacosf(OP_CONST_FLOAT_VAL(0)));
case OP_C_ATAN :
return make_complex_const_primary(catanf(OP_CONST_FLOAT_VAL(0)));
case OP_C_POW :
return make_complex_const_primary(cpowf(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1)));
case OP_C_EXP :
return make_complex_const_primary(cexpf(OP_CONST_FLOAT_VAL(0)));
case OP_C_LOG :
return make_complex_const_primary(clogf(OP_CONST_FLOAT_VAL(0)));
case OP_C_ARG :
return make_float_const_primary(cargf(OP_CONST_FLOAT_VAL(0)));
case OP_C_SINH :
return make_complex_const_primary(csinhf(OP_CONST_FLOAT_VAL(0)));
case OP_C_COSH :
return make_complex_const_primary(ccoshf(OP_CONST_FLOAT_VAL(0)));
case OP_C_TANH :
return make_complex_const_primary(ctanhf(OP_CONST_FLOAT_VAL(0)));
case OP_C_ASINH :
return make_complex_const_primary(casinhf(OP_CONST_FLOAT_VAL(0)));
case OP_C_ACOSH :
return make_complex_const_primary(cacoshf(OP_CONST_FLOAT_VAL(0)));
case OP_C_ATANH :
return make_complex_const_primary(catanhf(OP_CONST_FLOAT_VAL(0)));
case OP_C_GAMMA :
return make_complex_const_primary(cgamma(OP_CONST_FLOAT_VAL(0)));
case OP_NOISE :
return make_float_const_primary(noise(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2)));
case OP_MAKE_COLOR :
return make_color_const_primary(MAKE_COLOR(OP_CONST_FLOAT_VAL(0), OP_CONST_FLOAT_VAL(1), OP_CONST_FLOAT_VAL(2), OP_CONST_FLOAT_VAL(3)));
default : assert(0);
}
}

