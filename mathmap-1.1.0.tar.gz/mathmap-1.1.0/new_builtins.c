static void
builtin_merd (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_0;

{
float tmp_1;
tmp_1 = STK[STKP - 1].v.tuple.number;
tmp_0 = START_DEBUG_TUPLE(tmp_1);
}

{
int tmp_2;
for (tmp_2 = 0; tmp_2 < STK[STKP - 1].v.tuple.length; ++tmp_2)
{
{
int tmp_3;

{
float tmp_4;
float tmp_5;
tmp_4 = tmp_2;
tmp_5 = STK[STKP - 1].v.tuple.data[tmp_2];
tmp_3 = SET_DEBUG_TUPLE_DATA(tmp_4, tmp_5);
}

result[tmp_2] = STK[STKP - 1].v.tuple.data[tmp_2];
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].v.tuple.length; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = STK[STKP - 1].v.tuple.length;
STKP -= 0;
}

static void
gen_merd (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_6;

tmp_6 = make_temporary();
{
compvar_t *tmp_7;
tmp_7 = make_temporary();
emit_assign(make_lhs(tmp_7), make_int_const_rhs(argnumbers[0]));
emit_assign(make_lhs(tmp_6), make_op_rhs(OP_START_DEBUG_TUPLE, make_compvar_primary(tmp_7)));
}

{
int tmp_8;
for (tmp_8 = 0; tmp_8 < arglengths[0]; ++tmp_8)
{
{
compvar_t *tmp_9;

tmp_9 = make_temporary();
{
compvar_t *tmp_10, *tmp_11;
tmp_10 = make_temporary();
emit_assign(make_lhs(tmp_10), make_int_const_rhs(tmp_8));
tmp_11 = args[0][tmp_8];
emit_assign(make_lhs(tmp_9), make_op_rhs(OP_SET_DEBUG_TUPLE_DATA, make_compvar_primary(tmp_10), make_compvar_primary(tmp_11)));
}

emit_assign(make_lhs(result[tmp_8]), make_compvar_rhs(args[0][tmp_8]));
}
}
}
}
}

static void
builtin_print (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_12;
for (tmp_12 = 0; tmp_12 < STK[STKP - 1].v.tuple.length; ++tmp_12)
{
{
float tmp_13;
tmp_13 = STK[STKP - 1].v.tuple.data[tmp_12];
PRINT_FLOAT(tmp_13);
}
}
}
NEWLINE();
result[0] = 0;
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_print (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_14;
for (tmp_14 = 0; tmp_14 < arglengths[0]; ++tmp_14)
{
{
compvar_t *tmp_15, *tmp_16 = make_temporary();
tmp_15 = args[0][tmp_14];
emit_assign(make_lhs(tmp_16), make_op_rhs(OP_PRINT, make_compvar_primary(tmp_15)));
}
}
}
{
compvar_t *tmp_17 = make_temporary();
emit_assign(make_lhs(tmp_17), make_op_rhs(OP_NEWLINE));
}
{
int tmp_18;
for (tmp_18 = 0; tmp_18 < 1; ++tmp_18)
{
switch (tmp_18)
{
case 0 :
emit_assign(make_lhs(result[tmp_18]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
}

static void
builtin_add_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_19;
float tmp_20;
tmp_19 = STK[STKP - 2].v.tuple.data[0];
tmp_20 = STK[STKP - 1].v.tuple.data[0];
result[0] = ADD(tmp_19, tmp_20);
}
{
float tmp_21;
float tmp_22;
tmp_21 = STK[STKP - 2].v.tuple.data[1];
tmp_22 = STK[STKP - 1].v.tuple.data[1];
result[1] = ADD(tmp_21, tmp_22);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_add_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_23;
for (tmp_23 = 0; tmp_23 < 2; ++tmp_23)
{
{
compvar_t *tmp_24, *tmp_25;
tmp_24 = args[0][tmp_23];
tmp_25 = args[1][tmp_23];
emit_assign(make_lhs(result[tmp_23]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_24), make_compvar_primary(tmp_25)));
}
}
}
}

static void
builtin_add_ri_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_26;
float tmp_27;
tmp_26 = STK[STKP - 2].v.tuple.data[0];
tmp_27 = STK[STKP - 1].v.tuple.data[0];
result[0] = ADD(tmp_26, tmp_27);
}
{
float tmp_28;
float tmp_29;
tmp_28 = STK[STKP - 2].v.tuple.data[1];
tmp_29 = 0;
result[1] = ADD(tmp_28, tmp_29);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_add_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_30;
for (tmp_30 = 0; tmp_30 < 2; ++tmp_30)
{
{
compvar_t *tmp_31, *tmp_32;
tmp_31 = args[0][tmp_30];
switch (tmp_30)
{
case 0 :
tmp_32 = args[1][0];
break;
case 1 :
tmp_32 = make_temporary();
emit_assign(make_lhs(tmp_32), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_30]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_31), make_compvar_primary(tmp_32)));
}
}
}
}

static void
builtin_add_1_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_33;
float tmp_34;
tmp_33 = STK[STKP - 1].v.tuple.data[0];
tmp_34 = STK[STKP - 2].v.tuple.data[0];
result[0] = ADD(tmp_33, tmp_34);
}
{
float tmp_35;
float tmp_36;
tmp_35 = STK[STKP - 1].v.tuple.data[1];
tmp_36 = 0;
result[1] = ADD(tmp_35, tmp_36);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_add_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_37;
for (tmp_37 = 0; tmp_37 < 2; ++tmp_37)
{
{
compvar_t *tmp_38, *tmp_39;
tmp_38 = args[1][tmp_37];
switch (tmp_37)
{
case 0 :
tmp_39 = args[0][0];
break;
case 1 :
tmp_39 = make_temporary();
emit_assign(make_lhs(tmp_39), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_37]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_38), make_compvar_primary(tmp_39)));
}
}
}
}

static void
builtin_add_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_40;
float tmp_41;
tmp_40 = STK[STKP - 2].v.tuple.data[0];
tmp_41 = STK[STKP - 1].v.tuple.data[0];
result[0] = ADD(tmp_40, tmp_41);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_add_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_42;
for (tmp_42 = 0; tmp_42 < 1; ++tmp_42)
{
{
compvar_t *tmp_43, *tmp_44;
tmp_43 = args[0][tmp_42];
tmp_44 = args[1][tmp_42];
emit_assign(make_lhs(result[tmp_42]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_43), make_compvar_primary(tmp_44)));
}
}
}
}

static void
builtin_add_s (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_45;
for (tmp_45 = 0; tmp_45 < STK[STKP - 2].v.tuple.length; ++tmp_45)
{
{
float tmp_46;
float tmp_47;
tmp_46 = STK[STKP - 2].v.tuple.data[tmp_45];
tmp_47 = STK[STKP - 1].v.tuple.data[0];
result[tmp_45] = ADD(tmp_46, tmp_47);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_add_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_48;
for (tmp_48 = 0; tmp_48 < arglengths[0]; ++tmp_48)
{
{
compvar_t *tmp_49, *tmp_50;
tmp_49 = args[0][tmp_48];
tmp_50 = args[1][0];
emit_assign(make_lhs(result[tmp_48]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_49), make_compvar_primary(tmp_50)));
}
}
}
}

static void
builtin_add_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_51;
for (tmp_51 = 0; tmp_51 < STK[STKP - 2].v.tuple.length; ++tmp_51)
{
{
float tmp_52;
float tmp_53;
tmp_52 = STK[STKP - 2].v.tuple.data[tmp_51];
tmp_53 = STK[STKP - 1].v.tuple.data[tmp_51];
result[tmp_51] = ADD(tmp_52, tmp_53);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_add_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_54;
for (tmp_54 = 0; tmp_54 < arglengths[0]; ++tmp_54)
{
{
compvar_t *tmp_55, *tmp_56;
tmp_55 = args[0][tmp_54];
tmp_56 = args[1][tmp_54];
emit_assign(make_lhs(result[tmp_54]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_55), make_compvar_primary(tmp_56)));
}
}
}
}

static void
builtin_sub_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_57;
float tmp_58;
tmp_57 = STK[STKP - 2].v.tuple.data[0];
tmp_58 = STK[STKP - 1].v.tuple.data[0];
result[0] = SUB(tmp_57, tmp_58);
}
{
float tmp_59;
float tmp_60;
tmp_59 = STK[STKP - 2].v.tuple.data[1];
tmp_60 = STK[STKP - 1].v.tuple.data[1];
result[1] = SUB(tmp_59, tmp_60);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_sub_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_61;
for (tmp_61 = 0; tmp_61 < 2; ++tmp_61)
{
{
compvar_t *tmp_62, *tmp_63;
tmp_62 = args[0][tmp_61];
tmp_63 = args[1][tmp_61];
emit_assign(make_lhs(result[tmp_61]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_62), make_compvar_primary(tmp_63)));
}
}
}
}

static void
builtin_sub_ri_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_64;
float tmp_65;
tmp_64 = STK[STKP - 2].v.tuple.data[0];
tmp_65 = STK[STKP - 1].v.tuple.data[0];
result[0] = SUB(tmp_64, tmp_65);
}
{
float tmp_66;
float tmp_67;
tmp_66 = STK[STKP - 2].v.tuple.data[1];
tmp_67 = 0;
result[1] = SUB(tmp_66, tmp_67);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_sub_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_68;
for (tmp_68 = 0; tmp_68 < 2; ++tmp_68)
{
{
compvar_t *tmp_69, *tmp_70;
tmp_69 = args[0][tmp_68];
switch (tmp_68)
{
case 0 :
tmp_70 = args[1][0];
break;
case 1 :
tmp_70 = make_temporary();
emit_assign(make_lhs(tmp_70), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_68]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_69), make_compvar_primary(tmp_70)));
}
}
}
}

static void
builtin_sub_1_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_71;
float tmp_72;
tmp_71 = STK[STKP - 2].v.tuple.data[0];
tmp_72 = STK[STKP - 1].v.tuple.data[0];
result[0] = SUB(tmp_71, tmp_72);
}
{
float tmp_73;
float tmp_74;
tmp_73 = 0;
tmp_74 = STK[STKP - 1].v.tuple.data[1];
result[1] = SUB(tmp_73, tmp_74);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_sub_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_75;
for (tmp_75 = 0; tmp_75 < 2; ++tmp_75)
{
{
compvar_t *tmp_76, *tmp_77;
switch (tmp_75)
{
case 0 :
tmp_76 = args[0][0];
break;
case 1 :
tmp_76 = make_temporary();
emit_assign(make_lhs(tmp_76), make_int_const_rhs(0));
break;
default :
assert(0);
}
tmp_77 = args[1][tmp_75];
emit_assign(make_lhs(result[tmp_75]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_76), make_compvar_primary(tmp_77)));
}
}
}
}

static void
builtin_sub_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_78;
float tmp_79;
tmp_78 = STK[STKP - 2].v.tuple.data[0];
tmp_79 = STK[STKP - 1].v.tuple.data[0];
result[0] = SUB(tmp_78, tmp_79);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_sub_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_80;
for (tmp_80 = 0; tmp_80 < 1; ++tmp_80)
{
{
compvar_t *tmp_81, *tmp_82;
tmp_81 = args[0][tmp_80];
tmp_82 = args[1][tmp_80];
emit_assign(make_lhs(result[tmp_80]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_81), make_compvar_primary(tmp_82)));
}
}
}
}

static void
builtin_sub_s (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_83;
for (tmp_83 = 0; tmp_83 < STK[STKP - 2].v.tuple.length; ++tmp_83)
{
{
float tmp_84;
float tmp_85;
tmp_84 = STK[STKP - 2].v.tuple.data[tmp_83];
tmp_85 = STK[STKP - 1].v.tuple.data[0];
result[tmp_83] = SUB(tmp_84, tmp_85);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_sub_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_86;
for (tmp_86 = 0; tmp_86 < arglengths[0]; ++tmp_86)
{
{
compvar_t *tmp_87, *tmp_88;
tmp_87 = args[0][tmp_86];
tmp_88 = args[1][0];
emit_assign(make_lhs(result[tmp_86]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_87), make_compvar_primary(tmp_88)));
}
}
}
}

static void
builtin_sub_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_89;
for (tmp_89 = 0; tmp_89 < STK[STKP - 2].v.tuple.length; ++tmp_89)
{
{
float tmp_90;
float tmp_91;
tmp_90 = STK[STKP - 2].v.tuple.data[tmp_89];
tmp_91 = STK[STKP - 1].v.tuple.data[tmp_89];
result[tmp_89] = SUB(tmp_90, tmp_91);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_sub_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_92;
for (tmp_92 = 0; tmp_92 < arglengths[0]; ++tmp_92)
{
{
compvar_t *tmp_93, *tmp_94;
tmp_93 = args[0][tmp_92];
tmp_94 = args[1][tmp_92];
emit_assign(make_lhs(result[tmp_92]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_93), make_compvar_primary(tmp_94)));
}
}
}
}

static void
builtin_neg (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_95;
for (tmp_95 = 0; tmp_95 < STK[STKP - 1].v.tuple.length; ++tmp_95)
{
{
float tmp_96;
tmp_96 = STK[STKP - 1].v.tuple.data[tmp_95];
result[tmp_95] = NEG(tmp_96);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].v.tuple.length; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = STK[STKP - 1].v.tuple.length;
STKP -= 0;
}

static void
gen_neg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_97;
for (tmp_97 = 0; tmp_97 < arglengths[0]; ++tmp_97)
{
{
compvar_t *tmp_98;
tmp_98 = args[0][tmp_97];
emit_assign(make_lhs(result[tmp_97]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_98)));
}
}
}
}

static void
builtin_mul_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_99;
float tmp_100;
{
float tmp_101;
float tmp_102;
tmp_101 = STK[STKP - 2].v.tuple.data[0];
tmp_102 = STK[STKP - 1].v.tuple.data[0];
tmp_99 = MUL(tmp_101, tmp_102);
}
{
float tmp_103;
float tmp_104;
tmp_103 = STK[STKP - 2].v.tuple.data[1];
tmp_104 = STK[STKP - 1].v.tuple.data[1];
tmp_100 = MUL(tmp_103, tmp_104);
}
result[0] = SUB(tmp_99, tmp_100);
}
{
float tmp_105;
float tmp_106;
{
float tmp_107;
float tmp_108;
tmp_107 = STK[STKP - 2].v.tuple.data[0];
tmp_108 = STK[STKP - 1].v.tuple.data[1];
tmp_105 = MUL(tmp_107, tmp_108);
}
{
float tmp_109;
float tmp_110;
tmp_109 = STK[STKP - 1].v.tuple.data[0];
tmp_110 = STK[STKP - 2].v.tuple.data[1];
tmp_106 = MUL(tmp_109, tmp_110);
}
result[1] = ADD(tmp_105, tmp_106);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_mul_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_111;
for (tmp_111 = 0; tmp_111 < 2; ++tmp_111)
{
switch (tmp_111)
{
case 0 :
{
compvar_t *tmp_112, *tmp_113;
tmp_112 = make_temporary();
{
compvar_t *tmp_114, *tmp_115;
tmp_114 = args[0][0];
tmp_115 = args[1][0];
emit_assign(make_lhs(tmp_112), make_op_rhs(OP_MUL, make_compvar_primary(tmp_114), make_compvar_primary(tmp_115)));
}
tmp_113 = make_temporary();
{
compvar_t *tmp_116, *tmp_117;
tmp_116 = args[0][1];
tmp_117 = args[1][1];
emit_assign(make_lhs(tmp_113), make_op_rhs(OP_MUL, make_compvar_primary(tmp_116), make_compvar_primary(tmp_117)));
}
emit_assign(make_lhs(result[tmp_111]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_112), make_compvar_primary(tmp_113)));
}
break;
case 1 :
{
compvar_t *tmp_118, *tmp_119;
tmp_118 = make_temporary();
{
compvar_t *tmp_120, *tmp_121;
tmp_120 = args[0][0];
tmp_121 = args[1][1];
emit_assign(make_lhs(tmp_118), make_op_rhs(OP_MUL, make_compvar_primary(tmp_120), make_compvar_primary(tmp_121)));
}
tmp_119 = make_temporary();
{
compvar_t *tmp_122, *tmp_123;
tmp_122 = args[1][0];
tmp_123 = args[0][1];
emit_assign(make_lhs(tmp_119), make_op_rhs(OP_MUL, make_compvar_primary(tmp_122), make_compvar_primary(tmp_123)));
}
emit_assign(make_lhs(result[tmp_111]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_118), make_compvar_primary(tmp_119)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_1_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_124;
float tmp_125;
tmp_124 = STK[STKP - 2].v.tuple.data[0];
tmp_125 = STK[STKP - 1].v.tuple.data[0];
result[0] = MUL(tmp_124, tmp_125);
}
{
float tmp_126;
float tmp_127;
tmp_126 = STK[STKP - 2].v.tuple.data[0];
tmp_127 = STK[STKP - 1].v.tuple.data[1];
result[1] = MUL(tmp_126, tmp_127);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_mul_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_128;
for (tmp_128 = 0; tmp_128 < 2; ++tmp_128)
{
{
compvar_t *tmp_129, *tmp_130;
tmp_129 = args[0][0];
tmp_130 = args[1][tmp_128];
emit_assign(make_lhs(result[tmp_128]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_129), make_compvar_primary(tmp_130)));
}
}
}
}

static void
builtin_mul_m2x2 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_131;
float tmp_132;
{
float tmp_133;
float tmp_134;
tmp_133 = STK[STKP - 2].v.tuple.data[0];
tmp_134 = STK[STKP - 1].v.tuple.data[0];
tmp_131 = MUL(tmp_133, tmp_134);
}
{
float tmp_135;
float tmp_136;
tmp_135 = STK[STKP - 2].v.tuple.data[1];
tmp_136 = STK[STKP - 1].v.tuple.data[2];
tmp_132 = MUL(tmp_135, tmp_136);
}
result[0] = ADD(tmp_131, tmp_132);
}
{
float tmp_137;
float tmp_138;
{
float tmp_139;
float tmp_140;
tmp_139 = STK[STKP - 2].v.tuple.data[0];
tmp_140 = STK[STKP - 1].v.tuple.data[1];
tmp_137 = MUL(tmp_139, tmp_140);
}
{
float tmp_141;
float tmp_142;
tmp_141 = STK[STKP - 2].v.tuple.data[1];
tmp_142 = STK[STKP - 1].v.tuple.data[3];
tmp_138 = MUL(tmp_141, tmp_142);
}
result[1] = ADD(tmp_137, tmp_138);
}
{
float tmp_143;
float tmp_144;
{
float tmp_145;
float tmp_146;
tmp_145 = STK[STKP - 2].v.tuple.data[2];
tmp_146 = STK[STKP - 1].v.tuple.data[0];
tmp_143 = MUL(tmp_145, tmp_146);
}
{
float tmp_147;
float tmp_148;
tmp_147 = STK[STKP - 2].v.tuple.data[3];
tmp_148 = STK[STKP - 1].v.tuple.data[2];
tmp_144 = MUL(tmp_147, tmp_148);
}
result[2] = ADD(tmp_143, tmp_144);
}
{
float tmp_149;
float tmp_150;
{
float tmp_151;
float tmp_152;
tmp_151 = STK[STKP - 2].v.tuple.data[2];
tmp_152 = STK[STKP - 1].v.tuple.data[1];
tmp_149 = MUL(tmp_151, tmp_152);
}
{
float tmp_153;
float tmp_154;
tmp_153 = STK[STKP - 2].v.tuple.data[3];
tmp_154 = STK[STKP - 1].v.tuple.data[3];
tmp_150 = MUL(tmp_153, tmp_154);
}
result[3] = ADD(tmp_149, tmp_150);
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 4;
STKP -= 1;
}

static void
gen_mul_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_155;
for (tmp_155 = 0; tmp_155 < 4; ++tmp_155)
{
switch (tmp_155)
{
case 0 :
{
compvar_t *tmp_156, *tmp_157;
tmp_156 = make_temporary();
{
compvar_t *tmp_158, *tmp_159;
tmp_158 = args[0][0];
tmp_159 = args[1][0];
emit_assign(make_lhs(tmp_156), make_op_rhs(OP_MUL, make_compvar_primary(tmp_158), make_compvar_primary(tmp_159)));
}
tmp_157 = make_temporary();
{
compvar_t *tmp_160, *tmp_161;
tmp_160 = args[0][1];
tmp_161 = args[1][2];
emit_assign(make_lhs(tmp_157), make_op_rhs(OP_MUL, make_compvar_primary(tmp_160), make_compvar_primary(tmp_161)));
}
emit_assign(make_lhs(result[tmp_155]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_156), make_compvar_primary(tmp_157)));
}
break;
case 1 :
{
compvar_t *tmp_162, *tmp_163;
tmp_162 = make_temporary();
{
compvar_t *tmp_164, *tmp_165;
tmp_164 = args[0][0];
tmp_165 = args[1][1];
emit_assign(make_lhs(tmp_162), make_op_rhs(OP_MUL, make_compvar_primary(tmp_164), make_compvar_primary(tmp_165)));
}
tmp_163 = make_temporary();
{
compvar_t *tmp_166, *tmp_167;
tmp_166 = args[0][1];
tmp_167 = args[1][3];
emit_assign(make_lhs(tmp_163), make_op_rhs(OP_MUL, make_compvar_primary(tmp_166), make_compvar_primary(tmp_167)));
}
emit_assign(make_lhs(result[tmp_155]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_162), make_compvar_primary(tmp_163)));
}
break;
case 2 :
{
compvar_t *tmp_168, *tmp_169;
tmp_168 = make_temporary();
{
compvar_t *tmp_170, *tmp_171;
tmp_170 = args[0][2];
tmp_171 = args[1][0];
emit_assign(make_lhs(tmp_168), make_op_rhs(OP_MUL, make_compvar_primary(tmp_170), make_compvar_primary(tmp_171)));
}
tmp_169 = make_temporary();
{
compvar_t *tmp_172, *tmp_173;
tmp_172 = args[0][3];
tmp_173 = args[1][2];
emit_assign(make_lhs(tmp_169), make_op_rhs(OP_MUL, make_compvar_primary(tmp_172), make_compvar_primary(tmp_173)));
}
emit_assign(make_lhs(result[tmp_155]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_168), make_compvar_primary(tmp_169)));
}
break;
case 3 :
{
compvar_t *tmp_174, *tmp_175;
tmp_174 = make_temporary();
{
compvar_t *tmp_176, *tmp_177;
tmp_176 = args[0][2];
tmp_177 = args[1][1];
emit_assign(make_lhs(tmp_174), make_op_rhs(OP_MUL, make_compvar_primary(tmp_176), make_compvar_primary(tmp_177)));
}
tmp_175 = make_temporary();
{
compvar_t *tmp_178, *tmp_179;
tmp_178 = args[0][3];
tmp_179 = args[1][3];
emit_assign(make_lhs(tmp_175), make_op_rhs(OP_MUL, make_compvar_primary(tmp_178), make_compvar_primary(tmp_179)));
}
emit_assign(make_lhs(result[tmp_155]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_174), make_compvar_primary(tmp_175)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_m3x3 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_180;
float tmp_181;
{
float tmp_182;
float tmp_183;
{
float tmp_184;
float tmp_185;
tmp_184 = STK[STKP - 2].v.tuple.data[0];
tmp_185 = STK[STKP - 1].v.tuple.data[0];
tmp_182 = MUL(tmp_184, tmp_185);
}
{
float tmp_186;
float tmp_187;
tmp_186 = STK[STKP - 2].v.tuple.data[1];
tmp_187 = STK[STKP - 1].v.tuple.data[3];
tmp_183 = MUL(tmp_186, tmp_187);
}
tmp_180 = ADD(tmp_182, tmp_183);
}
{
float tmp_188;
float tmp_189;
tmp_188 = STK[STKP - 2].v.tuple.data[2];
tmp_189 = STK[STKP - 1].v.tuple.data[6];
tmp_181 = MUL(tmp_188, tmp_189);
}
result[0] = ADD(tmp_180, tmp_181);
}
{
float tmp_190;
float tmp_191;
{
float tmp_192;
float tmp_193;
{
float tmp_194;
float tmp_195;
tmp_194 = STK[STKP - 2].v.tuple.data[0];
tmp_195 = STK[STKP - 1].v.tuple.data[1];
tmp_192 = MUL(tmp_194, tmp_195);
}
{
float tmp_196;
float tmp_197;
tmp_196 = STK[STKP - 2].v.tuple.data[1];
tmp_197 = STK[STKP - 1].v.tuple.data[4];
tmp_193 = MUL(tmp_196, tmp_197);
}
tmp_190 = ADD(tmp_192, tmp_193);
}
{
float tmp_198;
float tmp_199;
tmp_198 = STK[STKP - 2].v.tuple.data[2];
tmp_199 = STK[STKP - 1].v.tuple.data[7];
tmp_191 = MUL(tmp_198, tmp_199);
}
result[1] = ADD(tmp_190, tmp_191);
}
{
float tmp_200;
float tmp_201;
{
float tmp_202;
float tmp_203;
{
float tmp_204;
float tmp_205;
tmp_204 = STK[STKP - 2].v.tuple.data[0];
tmp_205 = STK[STKP - 1].v.tuple.data[2];
tmp_202 = MUL(tmp_204, tmp_205);
}
{
float tmp_206;
float tmp_207;
tmp_206 = STK[STKP - 2].v.tuple.data[1];
tmp_207 = STK[STKP - 1].v.tuple.data[5];
tmp_203 = MUL(tmp_206, tmp_207);
}
tmp_200 = ADD(tmp_202, tmp_203);
}
{
float tmp_208;
float tmp_209;
tmp_208 = STK[STKP - 2].v.tuple.data[2];
tmp_209 = STK[STKP - 1].v.tuple.data[8];
tmp_201 = MUL(tmp_208, tmp_209);
}
result[2] = ADD(tmp_200, tmp_201);
}
{
float tmp_210;
float tmp_211;
{
float tmp_212;
float tmp_213;
{
float tmp_214;
float tmp_215;
tmp_214 = STK[STKP - 2].v.tuple.data[3];
tmp_215 = STK[STKP - 1].v.tuple.data[0];
tmp_212 = MUL(tmp_214, tmp_215);
}
{
float tmp_216;
float tmp_217;
tmp_216 = STK[STKP - 2].v.tuple.data[4];
tmp_217 = STK[STKP - 1].v.tuple.data[3];
tmp_213 = MUL(tmp_216, tmp_217);
}
tmp_210 = ADD(tmp_212, tmp_213);
}
{
float tmp_218;
float tmp_219;
tmp_218 = STK[STKP - 2].v.tuple.data[5];
tmp_219 = STK[STKP - 1].v.tuple.data[6];
tmp_211 = MUL(tmp_218, tmp_219);
}
result[3] = ADD(tmp_210, tmp_211);
}
{
float tmp_220;
float tmp_221;
{
float tmp_222;
float tmp_223;
{
float tmp_224;
float tmp_225;
tmp_224 = STK[STKP - 2].v.tuple.data[3];
tmp_225 = STK[STKP - 1].v.tuple.data[1];
tmp_222 = MUL(tmp_224, tmp_225);
}
{
float tmp_226;
float tmp_227;
tmp_226 = STK[STKP - 2].v.tuple.data[4];
tmp_227 = STK[STKP - 1].v.tuple.data[4];
tmp_223 = MUL(tmp_226, tmp_227);
}
tmp_220 = ADD(tmp_222, tmp_223);
}
{
float tmp_228;
float tmp_229;
tmp_228 = STK[STKP - 2].v.tuple.data[5];
tmp_229 = STK[STKP - 1].v.tuple.data[7];
tmp_221 = MUL(tmp_228, tmp_229);
}
result[4] = ADD(tmp_220, tmp_221);
}
{
float tmp_230;
float tmp_231;
{
float tmp_232;
float tmp_233;
{
float tmp_234;
float tmp_235;
tmp_234 = STK[STKP - 2].v.tuple.data[3];
tmp_235 = STK[STKP - 1].v.tuple.data[2];
tmp_232 = MUL(tmp_234, tmp_235);
}
{
float tmp_236;
float tmp_237;
tmp_236 = STK[STKP - 2].v.tuple.data[4];
tmp_237 = STK[STKP - 1].v.tuple.data[5];
tmp_233 = MUL(tmp_236, tmp_237);
}
tmp_230 = ADD(tmp_232, tmp_233);
}
{
float tmp_238;
float tmp_239;
tmp_238 = STK[STKP - 2].v.tuple.data[5];
tmp_239 = STK[STKP - 1].v.tuple.data[8];
tmp_231 = MUL(tmp_238, tmp_239);
}
result[5] = ADD(tmp_230, tmp_231);
}
{
float tmp_240;
float tmp_241;
{
float tmp_242;
float tmp_243;
{
float tmp_244;
float tmp_245;
tmp_244 = STK[STKP - 2].v.tuple.data[6];
tmp_245 = STK[STKP - 1].v.tuple.data[0];
tmp_242 = MUL(tmp_244, tmp_245);
}
{
float tmp_246;
float tmp_247;
tmp_246 = STK[STKP - 2].v.tuple.data[7];
tmp_247 = STK[STKP - 1].v.tuple.data[3];
tmp_243 = MUL(tmp_246, tmp_247);
}
tmp_240 = ADD(tmp_242, tmp_243);
}
{
float tmp_248;
float tmp_249;
tmp_248 = STK[STKP - 2].v.tuple.data[8];
tmp_249 = STK[STKP - 1].v.tuple.data[6];
tmp_241 = MUL(tmp_248, tmp_249);
}
result[6] = ADD(tmp_240, tmp_241);
}
{
float tmp_250;
float tmp_251;
{
float tmp_252;
float tmp_253;
{
float tmp_254;
float tmp_255;
tmp_254 = STK[STKP - 2].v.tuple.data[6];
tmp_255 = STK[STKP - 1].v.tuple.data[1];
tmp_252 = MUL(tmp_254, tmp_255);
}
{
float tmp_256;
float tmp_257;
tmp_256 = STK[STKP - 2].v.tuple.data[7];
tmp_257 = STK[STKP - 1].v.tuple.data[4];
tmp_253 = MUL(tmp_256, tmp_257);
}
tmp_250 = ADD(tmp_252, tmp_253);
}
{
float tmp_258;
float tmp_259;
tmp_258 = STK[STKP - 2].v.tuple.data[8];
tmp_259 = STK[STKP - 1].v.tuple.data[7];
tmp_251 = MUL(tmp_258, tmp_259);
}
result[7] = ADD(tmp_250, tmp_251);
}
{
float tmp_260;
float tmp_261;
{
float tmp_262;
float tmp_263;
{
float tmp_264;
float tmp_265;
tmp_264 = STK[STKP - 2].v.tuple.data[6];
tmp_265 = STK[STKP - 1].v.tuple.data[2];
tmp_262 = MUL(tmp_264, tmp_265);
}
{
float tmp_266;
float tmp_267;
tmp_266 = STK[STKP - 2].v.tuple.data[7];
tmp_267 = STK[STKP - 1].v.tuple.data[5];
tmp_263 = MUL(tmp_266, tmp_267);
}
tmp_260 = ADD(tmp_262, tmp_263);
}
{
float tmp_268;
float tmp_269;
tmp_268 = STK[STKP - 2].v.tuple.data[8];
tmp_269 = STK[STKP - 1].v.tuple.data[8];
tmp_261 = MUL(tmp_268, tmp_269);
}
result[8] = ADD(tmp_260, tmp_261);
}
{
int i;
for (i = 0; i < 9; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 9;
STKP -= 1;
}

static void
gen_mul_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_270;
for (tmp_270 = 0; tmp_270 < 9; ++tmp_270)
{
switch (tmp_270)
{
case 0 :
{
compvar_t *tmp_271, *tmp_272;
tmp_271 = make_temporary();
{
compvar_t *tmp_273, *tmp_274;
tmp_273 = make_temporary();
{
compvar_t *tmp_275, *tmp_276;
tmp_275 = args[0][0];
tmp_276 = args[1][0];
emit_assign(make_lhs(tmp_273), make_op_rhs(OP_MUL, make_compvar_primary(tmp_275), make_compvar_primary(tmp_276)));
}
tmp_274 = make_temporary();
{
compvar_t *tmp_277, *tmp_278;
tmp_277 = args[0][1];
tmp_278 = args[1][3];
emit_assign(make_lhs(tmp_274), make_op_rhs(OP_MUL, make_compvar_primary(tmp_277), make_compvar_primary(tmp_278)));
}
emit_assign(make_lhs(tmp_271), make_op_rhs(OP_ADD, make_compvar_primary(tmp_273), make_compvar_primary(tmp_274)));
}
tmp_272 = make_temporary();
{
compvar_t *tmp_279, *tmp_280;
tmp_279 = args[0][2];
tmp_280 = args[1][6];
emit_assign(make_lhs(tmp_272), make_op_rhs(OP_MUL, make_compvar_primary(tmp_279), make_compvar_primary(tmp_280)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_271), make_compvar_primary(tmp_272)));
}
break;
case 1 :
{
compvar_t *tmp_281, *tmp_282;
tmp_281 = make_temporary();
{
compvar_t *tmp_283, *tmp_284;
tmp_283 = make_temporary();
{
compvar_t *tmp_285, *tmp_286;
tmp_285 = args[0][0];
tmp_286 = args[1][1];
emit_assign(make_lhs(tmp_283), make_op_rhs(OP_MUL, make_compvar_primary(tmp_285), make_compvar_primary(tmp_286)));
}
tmp_284 = make_temporary();
{
compvar_t *tmp_287, *tmp_288;
tmp_287 = args[0][1];
tmp_288 = args[1][4];
emit_assign(make_lhs(tmp_284), make_op_rhs(OP_MUL, make_compvar_primary(tmp_287), make_compvar_primary(tmp_288)));
}
emit_assign(make_lhs(tmp_281), make_op_rhs(OP_ADD, make_compvar_primary(tmp_283), make_compvar_primary(tmp_284)));
}
tmp_282 = make_temporary();
{
compvar_t *tmp_289, *tmp_290;
tmp_289 = args[0][2];
tmp_290 = args[1][7];
emit_assign(make_lhs(tmp_282), make_op_rhs(OP_MUL, make_compvar_primary(tmp_289), make_compvar_primary(tmp_290)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_281), make_compvar_primary(tmp_282)));
}
break;
case 2 :
{
compvar_t *tmp_291, *tmp_292;
tmp_291 = make_temporary();
{
compvar_t *tmp_293, *tmp_294;
tmp_293 = make_temporary();
{
compvar_t *tmp_295, *tmp_296;
tmp_295 = args[0][0];
tmp_296 = args[1][2];
emit_assign(make_lhs(tmp_293), make_op_rhs(OP_MUL, make_compvar_primary(tmp_295), make_compvar_primary(tmp_296)));
}
tmp_294 = make_temporary();
{
compvar_t *tmp_297, *tmp_298;
tmp_297 = args[0][1];
tmp_298 = args[1][5];
emit_assign(make_lhs(tmp_294), make_op_rhs(OP_MUL, make_compvar_primary(tmp_297), make_compvar_primary(tmp_298)));
}
emit_assign(make_lhs(tmp_291), make_op_rhs(OP_ADD, make_compvar_primary(tmp_293), make_compvar_primary(tmp_294)));
}
tmp_292 = make_temporary();
{
compvar_t *tmp_299, *tmp_300;
tmp_299 = args[0][2];
tmp_300 = args[1][8];
emit_assign(make_lhs(tmp_292), make_op_rhs(OP_MUL, make_compvar_primary(tmp_299), make_compvar_primary(tmp_300)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_291), make_compvar_primary(tmp_292)));
}
break;
case 3 :
{
compvar_t *tmp_301, *tmp_302;
tmp_301 = make_temporary();
{
compvar_t *tmp_303, *tmp_304;
tmp_303 = make_temporary();
{
compvar_t *tmp_305, *tmp_306;
tmp_305 = args[0][3];
tmp_306 = args[1][0];
emit_assign(make_lhs(tmp_303), make_op_rhs(OP_MUL, make_compvar_primary(tmp_305), make_compvar_primary(tmp_306)));
}
tmp_304 = make_temporary();
{
compvar_t *tmp_307, *tmp_308;
tmp_307 = args[0][4];
tmp_308 = args[1][3];
emit_assign(make_lhs(tmp_304), make_op_rhs(OP_MUL, make_compvar_primary(tmp_307), make_compvar_primary(tmp_308)));
}
emit_assign(make_lhs(tmp_301), make_op_rhs(OP_ADD, make_compvar_primary(tmp_303), make_compvar_primary(tmp_304)));
}
tmp_302 = make_temporary();
{
compvar_t *tmp_309, *tmp_310;
tmp_309 = args[0][5];
tmp_310 = args[1][6];
emit_assign(make_lhs(tmp_302), make_op_rhs(OP_MUL, make_compvar_primary(tmp_309), make_compvar_primary(tmp_310)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_301), make_compvar_primary(tmp_302)));
}
break;
case 4 :
{
compvar_t *tmp_311, *tmp_312;
tmp_311 = make_temporary();
{
compvar_t *tmp_313, *tmp_314;
tmp_313 = make_temporary();
{
compvar_t *tmp_315, *tmp_316;
tmp_315 = args[0][3];
tmp_316 = args[1][1];
emit_assign(make_lhs(tmp_313), make_op_rhs(OP_MUL, make_compvar_primary(tmp_315), make_compvar_primary(tmp_316)));
}
tmp_314 = make_temporary();
{
compvar_t *tmp_317, *tmp_318;
tmp_317 = args[0][4];
tmp_318 = args[1][4];
emit_assign(make_lhs(tmp_314), make_op_rhs(OP_MUL, make_compvar_primary(tmp_317), make_compvar_primary(tmp_318)));
}
emit_assign(make_lhs(tmp_311), make_op_rhs(OP_ADD, make_compvar_primary(tmp_313), make_compvar_primary(tmp_314)));
}
tmp_312 = make_temporary();
{
compvar_t *tmp_319, *tmp_320;
tmp_319 = args[0][5];
tmp_320 = args[1][7];
emit_assign(make_lhs(tmp_312), make_op_rhs(OP_MUL, make_compvar_primary(tmp_319), make_compvar_primary(tmp_320)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_311), make_compvar_primary(tmp_312)));
}
break;
case 5 :
{
compvar_t *tmp_321, *tmp_322;
tmp_321 = make_temporary();
{
compvar_t *tmp_323, *tmp_324;
tmp_323 = make_temporary();
{
compvar_t *tmp_325, *tmp_326;
tmp_325 = args[0][3];
tmp_326 = args[1][2];
emit_assign(make_lhs(tmp_323), make_op_rhs(OP_MUL, make_compvar_primary(tmp_325), make_compvar_primary(tmp_326)));
}
tmp_324 = make_temporary();
{
compvar_t *tmp_327, *tmp_328;
tmp_327 = args[0][4];
tmp_328 = args[1][5];
emit_assign(make_lhs(tmp_324), make_op_rhs(OP_MUL, make_compvar_primary(tmp_327), make_compvar_primary(tmp_328)));
}
emit_assign(make_lhs(tmp_321), make_op_rhs(OP_ADD, make_compvar_primary(tmp_323), make_compvar_primary(tmp_324)));
}
tmp_322 = make_temporary();
{
compvar_t *tmp_329, *tmp_330;
tmp_329 = args[0][5];
tmp_330 = args[1][8];
emit_assign(make_lhs(tmp_322), make_op_rhs(OP_MUL, make_compvar_primary(tmp_329), make_compvar_primary(tmp_330)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_321), make_compvar_primary(tmp_322)));
}
break;
case 6 :
{
compvar_t *tmp_331, *tmp_332;
tmp_331 = make_temporary();
{
compvar_t *tmp_333, *tmp_334;
tmp_333 = make_temporary();
{
compvar_t *tmp_335, *tmp_336;
tmp_335 = args[0][6];
tmp_336 = args[1][0];
emit_assign(make_lhs(tmp_333), make_op_rhs(OP_MUL, make_compvar_primary(tmp_335), make_compvar_primary(tmp_336)));
}
tmp_334 = make_temporary();
{
compvar_t *tmp_337, *tmp_338;
tmp_337 = args[0][7];
tmp_338 = args[1][3];
emit_assign(make_lhs(tmp_334), make_op_rhs(OP_MUL, make_compvar_primary(tmp_337), make_compvar_primary(tmp_338)));
}
emit_assign(make_lhs(tmp_331), make_op_rhs(OP_ADD, make_compvar_primary(tmp_333), make_compvar_primary(tmp_334)));
}
tmp_332 = make_temporary();
{
compvar_t *tmp_339, *tmp_340;
tmp_339 = args[0][8];
tmp_340 = args[1][6];
emit_assign(make_lhs(tmp_332), make_op_rhs(OP_MUL, make_compvar_primary(tmp_339), make_compvar_primary(tmp_340)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_331), make_compvar_primary(tmp_332)));
}
break;
case 7 :
{
compvar_t *tmp_341, *tmp_342;
tmp_341 = make_temporary();
{
compvar_t *tmp_343, *tmp_344;
tmp_343 = make_temporary();
{
compvar_t *tmp_345, *tmp_346;
tmp_345 = args[0][6];
tmp_346 = args[1][1];
emit_assign(make_lhs(tmp_343), make_op_rhs(OP_MUL, make_compvar_primary(tmp_345), make_compvar_primary(tmp_346)));
}
tmp_344 = make_temporary();
{
compvar_t *tmp_347, *tmp_348;
tmp_347 = args[0][7];
tmp_348 = args[1][4];
emit_assign(make_lhs(tmp_344), make_op_rhs(OP_MUL, make_compvar_primary(tmp_347), make_compvar_primary(tmp_348)));
}
emit_assign(make_lhs(tmp_341), make_op_rhs(OP_ADD, make_compvar_primary(tmp_343), make_compvar_primary(tmp_344)));
}
tmp_342 = make_temporary();
{
compvar_t *tmp_349, *tmp_350;
tmp_349 = args[0][8];
tmp_350 = args[1][7];
emit_assign(make_lhs(tmp_342), make_op_rhs(OP_MUL, make_compvar_primary(tmp_349), make_compvar_primary(tmp_350)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_341), make_compvar_primary(tmp_342)));
}
break;
case 8 :
{
compvar_t *tmp_351, *tmp_352;
tmp_351 = make_temporary();
{
compvar_t *tmp_353, *tmp_354;
tmp_353 = make_temporary();
{
compvar_t *tmp_355, *tmp_356;
tmp_355 = args[0][6];
tmp_356 = args[1][2];
emit_assign(make_lhs(tmp_353), make_op_rhs(OP_MUL, make_compvar_primary(tmp_355), make_compvar_primary(tmp_356)));
}
tmp_354 = make_temporary();
{
compvar_t *tmp_357, *tmp_358;
tmp_357 = args[0][7];
tmp_358 = args[1][5];
emit_assign(make_lhs(tmp_354), make_op_rhs(OP_MUL, make_compvar_primary(tmp_357), make_compvar_primary(tmp_358)));
}
emit_assign(make_lhs(tmp_351), make_op_rhs(OP_ADD, make_compvar_primary(tmp_353), make_compvar_primary(tmp_354)));
}
tmp_352 = make_temporary();
{
compvar_t *tmp_359, *tmp_360;
tmp_359 = args[0][8];
tmp_360 = args[1][8];
emit_assign(make_lhs(tmp_352), make_op_rhs(OP_MUL, make_compvar_primary(tmp_359), make_compvar_primary(tmp_360)));
}
emit_assign(make_lhs(result[tmp_270]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_351), make_compvar_primary(tmp_352)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_v2m2x2 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_361;
float tmp_362;
{
float tmp_363;
float tmp_364;
tmp_363 = STK[STKP - 2].v.tuple.data[0];
tmp_364 = STK[STKP - 1].v.tuple.data[0];
tmp_361 = MUL(tmp_363, tmp_364);
}
{
float tmp_365;
float tmp_366;
tmp_365 = STK[STKP - 2].v.tuple.data[1];
tmp_366 = STK[STKP - 1].v.tuple.data[2];
tmp_362 = MUL(tmp_365, tmp_366);
}
result[0] = ADD(tmp_361, tmp_362);
}
{
float tmp_367;
float tmp_368;
{
float tmp_369;
float tmp_370;
tmp_369 = STK[STKP - 2].v.tuple.data[0];
tmp_370 = STK[STKP - 1].v.tuple.data[1];
tmp_367 = MUL(tmp_369, tmp_370);
}
{
float tmp_371;
float tmp_372;
tmp_371 = STK[STKP - 2].v.tuple.data[1];
tmp_372 = STK[STKP - 1].v.tuple.data[3];
tmp_368 = MUL(tmp_371, tmp_372);
}
result[1] = ADD(tmp_367, tmp_368);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_mul_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_373;
for (tmp_373 = 0; tmp_373 < 2; ++tmp_373)
{
switch (tmp_373)
{
case 0 :
{
compvar_t *tmp_374, *tmp_375;
tmp_374 = make_temporary();
{
compvar_t *tmp_376, *tmp_377;
tmp_376 = args[0][0];
tmp_377 = args[1][0];
emit_assign(make_lhs(tmp_374), make_op_rhs(OP_MUL, make_compvar_primary(tmp_376), make_compvar_primary(tmp_377)));
}
tmp_375 = make_temporary();
{
compvar_t *tmp_378, *tmp_379;
tmp_378 = args[0][1];
tmp_379 = args[1][2];
emit_assign(make_lhs(tmp_375), make_op_rhs(OP_MUL, make_compvar_primary(tmp_378), make_compvar_primary(tmp_379)));
}
emit_assign(make_lhs(result[tmp_373]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_374), make_compvar_primary(tmp_375)));
}
break;
case 1 :
{
compvar_t *tmp_380, *tmp_381;
tmp_380 = make_temporary();
{
compvar_t *tmp_382, *tmp_383;
tmp_382 = args[0][0];
tmp_383 = args[1][1];
emit_assign(make_lhs(tmp_380), make_op_rhs(OP_MUL, make_compvar_primary(tmp_382), make_compvar_primary(tmp_383)));
}
tmp_381 = make_temporary();
{
compvar_t *tmp_384, *tmp_385;
tmp_384 = args[0][1];
tmp_385 = args[1][3];
emit_assign(make_lhs(tmp_381), make_op_rhs(OP_MUL, make_compvar_primary(tmp_384), make_compvar_primary(tmp_385)));
}
emit_assign(make_lhs(result[tmp_373]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_380), make_compvar_primary(tmp_381)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_v3m3x3 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_386;
float tmp_387;
{
float tmp_388;
float tmp_389;
{
float tmp_390;
float tmp_391;
tmp_390 = STK[STKP - 2].v.tuple.data[0];
tmp_391 = STK[STKP - 1].v.tuple.data[0];
tmp_388 = MUL(tmp_390, tmp_391);
}
{
float tmp_392;
float tmp_393;
tmp_392 = STK[STKP - 2].v.tuple.data[1];
tmp_393 = STK[STKP - 1].v.tuple.data[3];
tmp_389 = MUL(tmp_392, tmp_393);
}
tmp_386 = ADD(tmp_388, tmp_389);
}
{
float tmp_394;
float tmp_395;
tmp_394 = STK[STKP - 2].v.tuple.data[2];
tmp_395 = STK[STKP - 1].v.tuple.data[6];
tmp_387 = MUL(tmp_394, tmp_395);
}
result[0] = ADD(tmp_386, tmp_387);
}
{
float tmp_396;
float tmp_397;
{
float tmp_398;
float tmp_399;
{
float tmp_400;
float tmp_401;
tmp_400 = STK[STKP - 2].v.tuple.data[0];
tmp_401 = STK[STKP - 1].v.tuple.data[1];
tmp_398 = MUL(tmp_400, tmp_401);
}
{
float tmp_402;
float tmp_403;
tmp_402 = STK[STKP - 2].v.tuple.data[1];
tmp_403 = STK[STKP - 1].v.tuple.data[4];
tmp_399 = MUL(tmp_402, tmp_403);
}
tmp_396 = ADD(tmp_398, tmp_399);
}
{
float tmp_404;
float tmp_405;
tmp_404 = STK[STKP - 2].v.tuple.data[2];
tmp_405 = STK[STKP - 1].v.tuple.data[7];
tmp_397 = MUL(tmp_404, tmp_405);
}
result[1] = ADD(tmp_396, tmp_397);
}
{
float tmp_406;
float tmp_407;
{
float tmp_408;
float tmp_409;
{
float tmp_410;
float tmp_411;
tmp_410 = STK[STKP - 2].v.tuple.data[0];
tmp_411 = STK[STKP - 1].v.tuple.data[2];
tmp_408 = MUL(tmp_410, tmp_411);
}
{
float tmp_412;
float tmp_413;
tmp_412 = STK[STKP - 2].v.tuple.data[1];
tmp_413 = STK[STKP - 1].v.tuple.data[5];
tmp_409 = MUL(tmp_412, tmp_413);
}
tmp_406 = ADD(tmp_408, tmp_409);
}
{
float tmp_414;
float tmp_415;
tmp_414 = STK[STKP - 2].v.tuple.data[2];
tmp_415 = STK[STKP - 1].v.tuple.data[8];
tmp_407 = MUL(tmp_414, tmp_415);
}
result[2] = ADD(tmp_406, tmp_407);
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 3;
STKP -= 1;
}

static void
gen_mul_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_416;
for (tmp_416 = 0; tmp_416 < 3; ++tmp_416)
{
switch (tmp_416)
{
case 0 :
{
compvar_t *tmp_417, *tmp_418;
tmp_417 = make_temporary();
{
compvar_t *tmp_419, *tmp_420;
tmp_419 = make_temporary();
{
compvar_t *tmp_421, *tmp_422;
tmp_421 = args[0][0];
tmp_422 = args[1][0];
emit_assign(make_lhs(tmp_419), make_op_rhs(OP_MUL, make_compvar_primary(tmp_421), make_compvar_primary(tmp_422)));
}
tmp_420 = make_temporary();
{
compvar_t *tmp_423, *tmp_424;
tmp_423 = args[0][1];
tmp_424 = args[1][3];
emit_assign(make_lhs(tmp_420), make_op_rhs(OP_MUL, make_compvar_primary(tmp_423), make_compvar_primary(tmp_424)));
}
emit_assign(make_lhs(tmp_417), make_op_rhs(OP_ADD, make_compvar_primary(tmp_419), make_compvar_primary(tmp_420)));
}
tmp_418 = make_temporary();
{
compvar_t *tmp_425, *tmp_426;
tmp_425 = args[0][2];
tmp_426 = args[1][6];
emit_assign(make_lhs(tmp_418), make_op_rhs(OP_MUL, make_compvar_primary(tmp_425), make_compvar_primary(tmp_426)));
}
emit_assign(make_lhs(result[tmp_416]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_417), make_compvar_primary(tmp_418)));
}
break;
case 1 :
{
compvar_t *tmp_427, *tmp_428;
tmp_427 = make_temporary();
{
compvar_t *tmp_429, *tmp_430;
tmp_429 = make_temporary();
{
compvar_t *tmp_431, *tmp_432;
tmp_431 = args[0][0];
tmp_432 = args[1][1];
emit_assign(make_lhs(tmp_429), make_op_rhs(OP_MUL, make_compvar_primary(tmp_431), make_compvar_primary(tmp_432)));
}
tmp_430 = make_temporary();
{
compvar_t *tmp_433, *tmp_434;
tmp_433 = args[0][1];
tmp_434 = args[1][4];
emit_assign(make_lhs(tmp_430), make_op_rhs(OP_MUL, make_compvar_primary(tmp_433), make_compvar_primary(tmp_434)));
}
emit_assign(make_lhs(tmp_427), make_op_rhs(OP_ADD, make_compvar_primary(tmp_429), make_compvar_primary(tmp_430)));
}
tmp_428 = make_temporary();
{
compvar_t *tmp_435, *tmp_436;
tmp_435 = args[0][2];
tmp_436 = args[1][7];
emit_assign(make_lhs(tmp_428), make_op_rhs(OP_MUL, make_compvar_primary(tmp_435), make_compvar_primary(tmp_436)));
}
emit_assign(make_lhs(result[tmp_416]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_427), make_compvar_primary(tmp_428)));
}
break;
case 2 :
{
compvar_t *tmp_437, *tmp_438;
tmp_437 = make_temporary();
{
compvar_t *tmp_439, *tmp_440;
tmp_439 = make_temporary();
{
compvar_t *tmp_441, *tmp_442;
tmp_441 = args[0][0];
tmp_442 = args[1][2];
emit_assign(make_lhs(tmp_439), make_op_rhs(OP_MUL, make_compvar_primary(tmp_441), make_compvar_primary(tmp_442)));
}
tmp_440 = make_temporary();
{
compvar_t *tmp_443, *tmp_444;
tmp_443 = args[0][1];
tmp_444 = args[1][5];
emit_assign(make_lhs(tmp_440), make_op_rhs(OP_MUL, make_compvar_primary(tmp_443), make_compvar_primary(tmp_444)));
}
emit_assign(make_lhs(tmp_437), make_op_rhs(OP_ADD, make_compvar_primary(tmp_439), make_compvar_primary(tmp_440)));
}
tmp_438 = make_temporary();
{
compvar_t *tmp_445, *tmp_446;
tmp_445 = args[0][2];
tmp_446 = args[1][8];
emit_assign(make_lhs(tmp_438), make_op_rhs(OP_MUL, make_compvar_primary(tmp_445), make_compvar_primary(tmp_446)));
}
emit_assign(make_lhs(result[tmp_416]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_437), make_compvar_primary(tmp_438)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_m2x2v2 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_447;
float tmp_448;
{
float tmp_449;
float tmp_450;
tmp_449 = STK[STKP - 2].v.tuple.data[0];
tmp_450 = STK[STKP - 1].v.tuple.data[0];
tmp_447 = MUL(tmp_449, tmp_450);
}
{
float tmp_451;
float tmp_452;
tmp_451 = STK[STKP - 2].v.tuple.data[1];
tmp_452 = STK[STKP - 1].v.tuple.data[1];
tmp_448 = MUL(tmp_451, tmp_452);
}
result[0] = ADD(tmp_447, tmp_448);
}
{
float tmp_453;
float tmp_454;
{
float tmp_455;
float tmp_456;
tmp_455 = STK[STKP - 2].v.tuple.data[2];
tmp_456 = STK[STKP - 1].v.tuple.data[0];
tmp_453 = MUL(tmp_455, tmp_456);
}
{
float tmp_457;
float tmp_458;
tmp_457 = STK[STKP - 2].v.tuple.data[3];
tmp_458 = STK[STKP - 1].v.tuple.data[1];
tmp_454 = MUL(tmp_457, tmp_458);
}
result[1] = ADD(tmp_453, tmp_454);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_mul_m2x2v2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_459;
for (tmp_459 = 0; tmp_459 < 2; ++tmp_459)
{
switch (tmp_459)
{
case 0 :
{
compvar_t *tmp_460, *tmp_461;
tmp_460 = make_temporary();
{
compvar_t *tmp_462, *tmp_463;
tmp_462 = args[0][0];
tmp_463 = args[1][0];
emit_assign(make_lhs(tmp_460), make_op_rhs(OP_MUL, make_compvar_primary(tmp_462), make_compvar_primary(tmp_463)));
}
tmp_461 = make_temporary();
{
compvar_t *tmp_464, *tmp_465;
tmp_464 = args[0][1];
tmp_465 = args[1][1];
emit_assign(make_lhs(tmp_461), make_op_rhs(OP_MUL, make_compvar_primary(tmp_464), make_compvar_primary(tmp_465)));
}
emit_assign(make_lhs(result[tmp_459]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_460), make_compvar_primary(tmp_461)));
}
break;
case 1 :
{
compvar_t *tmp_466, *tmp_467;
tmp_466 = make_temporary();
{
compvar_t *tmp_468, *tmp_469;
tmp_468 = args[0][2];
tmp_469 = args[1][0];
emit_assign(make_lhs(tmp_466), make_op_rhs(OP_MUL, make_compvar_primary(tmp_468), make_compvar_primary(tmp_469)));
}
tmp_467 = make_temporary();
{
compvar_t *tmp_470, *tmp_471;
tmp_470 = args[0][3];
tmp_471 = args[1][1];
emit_assign(make_lhs(tmp_467), make_op_rhs(OP_MUL, make_compvar_primary(tmp_470), make_compvar_primary(tmp_471)));
}
emit_assign(make_lhs(result[tmp_459]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_466), make_compvar_primary(tmp_467)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_m3x3v3 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_472;
float tmp_473;
{
float tmp_474;
float tmp_475;
{
float tmp_476;
float tmp_477;
tmp_476 = STK[STKP - 2].v.tuple.data[0];
tmp_477 = STK[STKP - 1].v.tuple.data[0];
tmp_474 = MUL(tmp_476, tmp_477);
}
{
float tmp_478;
float tmp_479;
tmp_478 = STK[STKP - 2].v.tuple.data[1];
tmp_479 = STK[STKP - 1].v.tuple.data[1];
tmp_475 = MUL(tmp_478, tmp_479);
}
tmp_472 = ADD(tmp_474, tmp_475);
}
{
float tmp_480;
float tmp_481;
tmp_480 = STK[STKP - 2].v.tuple.data[2];
tmp_481 = STK[STKP - 1].v.tuple.data[2];
tmp_473 = MUL(tmp_480, tmp_481);
}
result[0] = ADD(tmp_472, tmp_473);
}
{
float tmp_482;
float tmp_483;
{
float tmp_484;
float tmp_485;
{
float tmp_486;
float tmp_487;
tmp_486 = STK[STKP - 2].v.tuple.data[3];
tmp_487 = STK[STKP - 1].v.tuple.data[0];
tmp_484 = MUL(tmp_486, tmp_487);
}
{
float tmp_488;
float tmp_489;
tmp_488 = STK[STKP - 2].v.tuple.data[4];
tmp_489 = STK[STKP - 1].v.tuple.data[1];
tmp_485 = MUL(tmp_488, tmp_489);
}
tmp_482 = ADD(tmp_484, tmp_485);
}
{
float tmp_490;
float tmp_491;
tmp_490 = STK[STKP - 2].v.tuple.data[5];
tmp_491 = STK[STKP - 1].v.tuple.data[2];
tmp_483 = MUL(tmp_490, tmp_491);
}
result[1] = ADD(tmp_482, tmp_483);
}
{
float tmp_492;
float tmp_493;
{
float tmp_494;
float tmp_495;
{
float tmp_496;
float tmp_497;
tmp_496 = STK[STKP - 2].v.tuple.data[6];
tmp_497 = STK[STKP - 1].v.tuple.data[0];
tmp_494 = MUL(tmp_496, tmp_497);
}
{
float tmp_498;
float tmp_499;
tmp_498 = STK[STKP - 2].v.tuple.data[7];
tmp_499 = STK[STKP - 1].v.tuple.data[1];
tmp_495 = MUL(tmp_498, tmp_499);
}
tmp_492 = ADD(tmp_494, tmp_495);
}
{
float tmp_500;
float tmp_501;
tmp_500 = STK[STKP - 2].v.tuple.data[8];
tmp_501 = STK[STKP - 1].v.tuple.data[2];
tmp_493 = MUL(tmp_500, tmp_501);
}
result[2] = ADD(tmp_492, tmp_493);
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 3;
STKP -= 1;
}

static void
gen_mul_m3x3v3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_502;
for (tmp_502 = 0; tmp_502 < 3; ++tmp_502)
{
switch (tmp_502)
{
case 0 :
{
compvar_t *tmp_503, *tmp_504;
tmp_503 = make_temporary();
{
compvar_t *tmp_505, *tmp_506;
tmp_505 = make_temporary();
{
compvar_t *tmp_507, *tmp_508;
tmp_507 = args[0][0];
tmp_508 = args[1][0];
emit_assign(make_lhs(tmp_505), make_op_rhs(OP_MUL, make_compvar_primary(tmp_507), make_compvar_primary(tmp_508)));
}
tmp_506 = make_temporary();
{
compvar_t *tmp_509, *tmp_510;
tmp_509 = args[0][1];
tmp_510 = args[1][1];
emit_assign(make_lhs(tmp_506), make_op_rhs(OP_MUL, make_compvar_primary(tmp_509), make_compvar_primary(tmp_510)));
}
emit_assign(make_lhs(tmp_503), make_op_rhs(OP_ADD, make_compvar_primary(tmp_505), make_compvar_primary(tmp_506)));
}
tmp_504 = make_temporary();
{
compvar_t *tmp_511, *tmp_512;
tmp_511 = args[0][2];
tmp_512 = args[1][2];
emit_assign(make_lhs(tmp_504), make_op_rhs(OP_MUL, make_compvar_primary(tmp_511), make_compvar_primary(tmp_512)));
}
emit_assign(make_lhs(result[tmp_502]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_503), make_compvar_primary(tmp_504)));
}
break;
case 1 :
{
compvar_t *tmp_513, *tmp_514;
tmp_513 = make_temporary();
{
compvar_t *tmp_515, *tmp_516;
tmp_515 = make_temporary();
{
compvar_t *tmp_517, *tmp_518;
tmp_517 = args[0][3];
tmp_518 = args[1][0];
emit_assign(make_lhs(tmp_515), make_op_rhs(OP_MUL, make_compvar_primary(tmp_517), make_compvar_primary(tmp_518)));
}
tmp_516 = make_temporary();
{
compvar_t *tmp_519, *tmp_520;
tmp_519 = args[0][4];
tmp_520 = args[1][1];
emit_assign(make_lhs(tmp_516), make_op_rhs(OP_MUL, make_compvar_primary(tmp_519), make_compvar_primary(tmp_520)));
}
emit_assign(make_lhs(tmp_513), make_op_rhs(OP_ADD, make_compvar_primary(tmp_515), make_compvar_primary(tmp_516)));
}
tmp_514 = make_temporary();
{
compvar_t *tmp_521, *tmp_522;
tmp_521 = args[0][5];
tmp_522 = args[1][2];
emit_assign(make_lhs(tmp_514), make_op_rhs(OP_MUL, make_compvar_primary(tmp_521), make_compvar_primary(tmp_522)));
}
emit_assign(make_lhs(result[tmp_502]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_513), make_compvar_primary(tmp_514)));
}
break;
case 2 :
{
compvar_t *tmp_523, *tmp_524;
tmp_523 = make_temporary();
{
compvar_t *tmp_525, *tmp_526;
tmp_525 = make_temporary();
{
compvar_t *tmp_527, *tmp_528;
tmp_527 = args[0][6];
tmp_528 = args[1][0];
emit_assign(make_lhs(tmp_525), make_op_rhs(OP_MUL, make_compvar_primary(tmp_527), make_compvar_primary(tmp_528)));
}
tmp_526 = make_temporary();
{
compvar_t *tmp_529, *tmp_530;
tmp_529 = args[0][7];
tmp_530 = args[1][1];
emit_assign(make_lhs(tmp_526), make_op_rhs(OP_MUL, make_compvar_primary(tmp_529), make_compvar_primary(tmp_530)));
}
emit_assign(make_lhs(tmp_523), make_op_rhs(OP_ADD, make_compvar_primary(tmp_525), make_compvar_primary(tmp_526)));
}
tmp_524 = make_temporary();
{
compvar_t *tmp_531, *tmp_532;
tmp_531 = args[0][8];
tmp_532 = args[1][2];
emit_assign(make_lhs(tmp_524), make_op_rhs(OP_MUL, make_compvar_primary(tmp_531), make_compvar_primary(tmp_532)));
}
emit_assign(make_lhs(result[tmp_502]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_523), make_compvar_primary(tmp_524)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_533;
float tmp_534;
tmp_533 = STK[STKP - 2].v.tuple.data[0];
tmp_534 = STK[STKP - 1].v.tuple.data[0];
result[0] = MUL(tmp_533, tmp_534);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_mul_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_535;
for (tmp_535 = 0; tmp_535 < 1; ++tmp_535)
{
switch (tmp_535)
{
case 0 :
{
compvar_t *tmp_536, *tmp_537;
tmp_536 = args[0][0];
tmp_537 = args[1][0];
emit_assign(make_lhs(result[tmp_535]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_536), make_compvar_primary(tmp_537)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_mul_s (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_538;
for (tmp_538 = 0; tmp_538 < STK[STKP - 2].v.tuple.length; ++tmp_538)
{
{
float tmp_539;
float tmp_540;
tmp_539 = STK[STKP - 2].v.tuple.data[tmp_538];
tmp_540 = STK[STKP - 1].v.tuple.data[0];
result[tmp_538] = MUL(tmp_539, tmp_540);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_mul_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_541;
for (tmp_541 = 0; tmp_541 < arglengths[0]; ++tmp_541)
{
{
compvar_t *tmp_542, *tmp_543;
tmp_542 = args[0][tmp_541];
tmp_543 = args[1][0];
emit_assign(make_lhs(result[tmp_541]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_542), make_compvar_primary(tmp_543)));
}
}
}
}

static void
builtin_mul_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_544;
for (tmp_544 = 0; tmp_544 < STK[STKP - 2].v.tuple.length; ++tmp_544)
{
{
float tmp_545;
float tmp_546;
tmp_545 = STK[STKP - 2].v.tuple.data[tmp_544];
tmp_546 = STK[STKP - 1].v.tuple.data[tmp_544];
result[tmp_544] = MUL(tmp_545, tmp_546);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_mul_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_547;
for (tmp_547 = 0; tmp_547 < arglengths[0]; ++tmp_547)
{
{
compvar_t *tmp_548, *tmp_549;
tmp_548 = args[0][tmp_547];
tmp_549 = args[1][tmp_547];
emit_assign(make_lhs(result[tmp_547]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_548), make_compvar_primary(tmp_549)));
}
}
}
}

static void
builtin_div_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_550;
{
float tmp_551;
float tmp_552;
tmp_551 = STK[STKP - 1].v.tuple.data[0];
tmp_552 = 0;
tmp_550 = EQ(tmp_551, tmp_552);
}
if (tmp_550)
{
{
float tmp_553;
float tmp_554;
tmp_553 = STK[STKP - 1].v.tuple.data[1];
tmp_554 = 0;
tmp_550 = EQ(tmp_553, tmp_554);
}
}
if (tmp_550)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_555;

{
float tmp_556 = 0.0, tmp_557;
{
float tmp_558;
float tmp_559;
tmp_558 = STK[STKP - 1].v.tuple.data[0];
tmp_559 = STK[STKP - 1].v.tuple.data[0];
tmp_557 = MUL(tmp_558, tmp_559);
}
tmp_556 += tmp_557;
{
float tmp_560;
float tmp_561;
tmp_560 = STK[STKP - 1].v.tuple.data[1];
tmp_561 = STK[STKP - 1].v.tuple.data[1];
tmp_557 = MUL(tmp_560, tmp_561);
}
tmp_556 += tmp_557;
tmp_555 = tmp_556;
}

{
float tmp_562;
float tmp_563;
{
float tmp_564 = 0.0, tmp_565;
{
float tmp_566;
float tmp_567;
tmp_566 = STK[STKP - 2].v.tuple.data[0];
tmp_567 = STK[STKP - 1].v.tuple.data[0];
tmp_565 = MUL(tmp_566, tmp_567);
}
tmp_564 += tmp_565;
{
float tmp_568;
float tmp_569;
tmp_568 = STK[STKP - 2].v.tuple.data[1];
tmp_569 = STK[STKP - 1].v.tuple.data[1];
tmp_565 = MUL(tmp_568, tmp_569);
}
tmp_564 += tmp_565;
tmp_562 = tmp_564;
}
tmp_563 = tmp_555;
result[0] = DIV(tmp_562, tmp_563);
}
{
float tmp_570;
float tmp_571;
{
float tmp_572;
float tmp_573;
{
float tmp_574;
float tmp_575;
{
float tmp_576;
tmp_576 = STK[STKP - 2].v.tuple.data[0];
tmp_574 = NEG(tmp_576);
}
tmp_575 = STK[STKP - 1].v.tuple.data[1];
tmp_572 = MUL(tmp_574, tmp_575);
}
{
float tmp_577;
float tmp_578;
tmp_577 = STK[STKP - 1].v.tuple.data[0];
tmp_578 = STK[STKP - 2].v.tuple.data[1];
tmp_573 = MUL(tmp_577, tmp_578);
}
tmp_570 = ADD(tmp_572, tmp_573);
}
tmp_571 = tmp_555;
result[1] = DIV(tmp_570, tmp_571);
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_div_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_579;
tmp_579 = make_temporary();
{
compvar_t *tmp_580, *tmp_581;
tmp_580 = args[1][0];
tmp_581 = make_temporary();
emit_assign(make_lhs(tmp_581), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_579), make_op_rhs(OP_EQ, make_compvar_primary(tmp_580), make_compvar_primary(tmp_581)));
}
start_if_cond(make_compvar_rhs(tmp_579));
{
compvar_t *tmp_582, *tmp_583;
tmp_582 = args[1][1];
tmp_583 = make_temporary();
emit_assign(make_lhs(tmp_583), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_579), make_op_rhs(OP_EQ, make_compvar_primary(tmp_582), make_compvar_primary(tmp_583)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_579));
{
int tmp_584;
for (tmp_584 = 0; tmp_584 < 2; ++tmp_584)
{
switch (tmp_584)
{
case 0 :
emit_assign(make_lhs(result[tmp_584]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_584]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_585;

if (2 == 1)
{
tmp_585 = make_temporary();
{
compvar_t *tmp_589, *tmp_590;
tmp_589 = args[1][0];
tmp_590 = args[1][0];
emit_assign(make_lhs(tmp_585), make_op_rhs(OP_MUL, make_compvar_primary(tmp_589), make_compvar_primary(tmp_590)));
}

}
else
{
compvar_t *tmp_586, *tmp_587;
int tmp_588;
tmp_585 = make_temporary();
tmp_586 = make_temporary();
{
compvar_t *tmp_591, *tmp_592;
tmp_591 = args[1][0];
tmp_592 = args[1][0];
emit_assign(make_lhs(tmp_586), make_op_rhs(OP_MUL, make_compvar_primary(tmp_591), make_compvar_primary(tmp_592)));
}
tmp_587 = make_temporary();
{
compvar_t *tmp_593, *tmp_594;
tmp_593 = args[1][1];
tmp_594 = args[1][1];
emit_assign(make_lhs(tmp_587), make_op_rhs(OP_MUL, make_compvar_primary(tmp_593), make_compvar_primary(tmp_594)));
}
emit_assign(make_lhs(tmp_585), make_op_rhs(OP_ADD, make_compvar_primary(tmp_586), make_compvar_primary(tmp_587)));
for (tmp_588 = 2; tmp_588 < 2; ++tmp_588)
{
tmp_586 = make_temporary();
{
compvar_t *tmp_595, *tmp_596;
tmp_595 = args[1][tmp_588];
tmp_596 = args[1][tmp_588];
emit_assign(make_lhs(tmp_586), make_op_rhs(OP_MUL, make_compvar_primary(tmp_595), make_compvar_primary(tmp_596)));
}
emit_assign(make_lhs(tmp_585), make_op_rhs(OP_ADD, make_compvar_primary(tmp_585), make_compvar_primary(tmp_586)));
}
}

{
int tmp_597;
for (tmp_597 = 0; tmp_597 < 2; ++tmp_597)
{
switch (tmp_597)
{
case 0 :
{
compvar_t *tmp_598, *tmp_599;
if (2 == 1)
{
tmp_598 = make_temporary();
{
compvar_t *tmp_603, *tmp_604;
tmp_603 = args[0][0];
tmp_604 = args[1][0];
emit_assign(make_lhs(tmp_598), make_op_rhs(OP_MUL, make_compvar_primary(tmp_603), make_compvar_primary(tmp_604)));
}

}
else
{
compvar_t *tmp_600, *tmp_601;
int tmp_602;
tmp_598 = make_temporary();
tmp_600 = make_temporary();
{
compvar_t *tmp_605, *tmp_606;
tmp_605 = args[0][0];
tmp_606 = args[1][0];
emit_assign(make_lhs(tmp_600), make_op_rhs(OP_MUL, make_compvar_primary(tmp_605), make_compvar_primary(tmp_606)));
}
tmp_601 = make_temporary();
{
compvar_t *tmp_607, *tmp_608;
tmp_607 = args[0][1];
tmp_608 = args[1][1];
emit_assign(make_lhs(tmp_601), make_op_rhs(OP_MUL, make_compvar_primary(tmp_607), make_compvar_primary(tmp_608)));
}
emit_assign(make_lhs(tmp_598), make_op_rhs(OP_ADD, make_compvar_primary(tmp_600), make_compvar_primary(tmp_601)));
for (tmp_602 = 2; tmp_602 < 2; ++tmp_602)
{
tmp_600 = make_temporary();
{
compvar_t *tmp_609, *tmp_610;
tmp_609 = args[0][tmp_602];
tmp_610 = args[1][tmp_602];
emit_assign(make_lhs(tmp_600), make_op_rhs(OP_MUL, make_compvar_primary(tmp_609), make_compvar_primary(tmp_610)));
}
emit_assign(make_lhs(tmp_598), make_op_rhs(OP_ADD, make_compvar_primary(tmp_598), make_compvar_primary(tmp_600)));
}
}
tmp_599 = tmp_585;
emit_assign(make_lhs(result[tmp_597]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_598), make_compvar_primary(tmp_599)));
}
break;
case 1 :
{
compvar_t *tmp_611, *tmp_612;
tmp_611 = make_temporary();
{
compvar_t *tmp_613, *tmp_614;
tmp_613 = make_temporary();
{
compvar_t *tmp_615, *tmp_616;
tmp_615 = make_temporary();
{
compvar_t *tmp_617;
tmp_617 = args[0][0];
emit_assign(make_lhs(tmp_615), make_op_rhs(OP_NEG, make_compvar_primary(tmp_617)));
}
tmp_616 = args[1][1];
emit_assign(make_lhs(tmp_613), make_op_rhs(OP_MUL, make_compvar_primary(tmp_615), make_compvar_primary(tmp_616)));
}
tmp_614 = make_temporary();
{
compvar_t *tmp_618, *tmp_619;
tmp_618 = args[1][0];
tmp_619 = args[0][1];
emit_assign(make_lhs(tmp_614), make_op_rhs(OP_MUL, make_compvar_primary(tmp_618), make_compvar_primary(tmp_619)));
}
emit_assign(make_lhs(tmp_611), make_op_rhs(OP_ADD, make_compvar_primary(tmp_613), make_compvar_primary(tmp_614)));
}
tmp_612 = tmp_585;
emit_assign(make_lhs(result[tmp_597]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_611), make_compvar_primary(tmp_612)));
}
break;
default :
assert(0);
}
}
}
}
end_if_cond();
}
}

static void
builtin_div_1_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_620;

{
float tmp_621 = 0.0, tmp_622;
{
float tmp_623;
float tmp_624;
tmp_623 = STK[STKP - 1].v.tuple.data[0];
tmp_624 = STK[STKP - 1].v.tuple.data[0];
tmp_622 = MUL(tmp_623, tmp_624);
}
tmp_621 += tmp_622;
{
float tmp_625;
float tmp_626;
tmp_625 = STK[STKP - 1].v.tuple.data[1];
tmp_626 = STK[STKP - 1].v.tuple.data[1];
tmp_622 = MUL(tmp_625, tmp_626);
}
tmp_621 += tmp_622;
tmp_620 = tmp_621;
}

{
int tmp_627;
{
float tmp_628;
float tmp_629;
tmp_628 = tmp_620;
tmp_629 = 0;
tmp_627 = EQ(tmp_628, tmp_629);
}
if (tmp_627)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_630;
float tmp_631;
{
float tmp_632;
float tmp_633;
tmp_632 = STK[STKP - 2].v.tuple.data[0];
tmp_633 = STK[STKP - 1].v.tuple.data[0];
tmp_630 = MUL(tmp_632, tmp_633);
}
tmp_631 = tmp_620;
result[0] = DIV(tmp_630, tmp_631);
}
{
float tmp_634;
{
float tmp_635;
float tmp_636;
{
float tmp_637;
float tmp_638;
tmp_637 = STK[STKP - 2].v.tuple.data[0];
tmp_638 = STK[STKP - 1].v.tuple.data[1];
tmp_635 = MUL(tmp_637, tmp_638);
}
tmp_636 = tmp_620;
tmp_634 = DIV(tmp_635, tmp_636);
}
result[1] = NEG(tmp_634);
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_div_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_639;

if (2 == 1)
{
tmp_639 = make_temporary();
{
compvar_t *tmp_643, *tmp_644;
tmp_643 = args[1][0];
tmp_644 = args[1][0];
emit_assign(make_lhs(tmp_639), make_op_rhs(OP_MUL, make_compvar_primary(tmp_643), make_compvar_primary(tmp_644)));
}

}
else
{
compvar_t *tmp_640, *tmp_641;
int tmp_642;
tmp_639 = make_temporary();
tmp_640 = make_temporary();
{
compvar_t *tmp_645, *tmp_646;
tmp_645 = args[1][0];
tmp_646 = args[1][0];
emit_assign(make_lhs(tmp_640), make_op_rhs(OP_MUL, make_compvar_primary(tmp_645), make_compvar_primary(tmp_646)));
}
tmp_641 = make_temporary();
{
compvar_t *tmp_647, *tmp_648;
tmp_647 = args[1][1];
tmp_648 = args[1][1];
emit_assign(make_lhs(tmp_641), make_op_rhs(OP_MUL, make_compvar_primary(tmp_647), make_compvar_primary(tmp_648)));
}
emit_assign(make_lhs(tmp_639), make_op_rhs(OP_ADD, make_compvar_primary(tmp_640), make_compvar_primary(tmp_641)));
for (tmp_642 = 2; tmp_642 < 2; ++tmp_642)
{
tmp_640 = make_temporary();
{
compvar_t *tmp_649, *tmp_650;
tmp_649 = args[1][tmp_642];
tmp_650 = args[1][tmp_642];
emit_assign(make_lhs(tmp_640), make_op_rhs(OP_MUL, make_compvar_primary(tmp_649), make_compvar_primary(tmp_650)));
}
emit_assign(make_lhs(tmp_639), make_op_rhs(OP_ADD, make_compvar_primary(tmp_639), make_compvar_primary(tmp_640)));
}
}

{
compvar_t *tmp_651;
tmp_651 = make_temporary();
{
compvar_t *tmp_652, *tmp_653;
tmp_652 = tmp_639;
tmp_653 = make_temporary();
emit_assign(make_lhs(tmp_653), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_651), make_op_rhs(OP_EQ, make_compvar_primary(tmp_652), make_compvar_primary(tmp_653)));
}
start_if_cond(make_compvar_rhs(tmp_651));
{
int tmp_654;
for (tmp_654 = 0; tmp_654 < 2; ++tmp_654)
{
switch (tmp_654)
{
case 0 :
emit_assign(make_lhs(result[tmp_654]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_654]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_655;
for (tmp_655 = 0; tmp_655 < 2; ++tmp_655)
{
switch (tmp_655)
{
case 0 :
{
compvar_t *tmp_656, *tmp_657;
tmp_656 = make_temporary();
{
compvar_t *tmp_658, *tmp_659;
tmp_658 = args[0][0];
tmp_659 = args[1][0];
emit_assign(make_lhs(tmp_656), make_op_rhs(OP_MUL, make_compvar_primary(tmp_658), make_compvar_primary(tmp_659)));
}
tmp_657 = tmp_639;
emit_assign(make_lhs(result[tmp_655]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_656), make_compvar_primary(tmp_657)));
}
break;
case 1 :
{
compvar_t *tmp_660;
tmp_660 = make_temporary();
{
compvar_t *tmp_661, *tmp_662;
tmp_661 = make_temporary();
{
compvar_t *tmp_663, *tmp_664;
tmp_663 = args[0][0];
tmp_664 = args[1][1];
emit_assign(make_lhs(tmp_661), make_op_rhs(OP_MUL, make_compvar_primary(tmp_663), make_compvar_primary(tmp_664)));
}
tmp_662 = tmp_639;
emit_assign(make_lhs(tmp_660), make_op_rhs(OP_DIV, make_compvar_primary(tmp_661), make_compvar_primary(tmp_662)));
}
emit_assign(make_lhs(result[tmp_655]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_660)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
}

static void
builtin_div_v2m2x2 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
gsl_matrix * tmp_665;
gsl_vector * tmp_670;

{
float tmp_666;
float tmp_667;
float tmp_668;
float tmp_669;
tmp_666 = STK[STKP - 1].v.tuple.data[0];
tmp_667 = STK[STKP - 1].v.tuple.data[1];
tmp_668 = STK[STKP - 1].v.tuple.data[2];
tmp_669 = STK[STKP - 1].v.tuple.data[3];
tmp_665 = MAKE_M2X2(tmp_666, tmp_667, tmp_668, tmp_669);
}

{
float tmp_671;
float tmp_672;
tmp_671 = STK[STKP - 2].v.tuple.data[0];
tmp_672 = STK[STKP - 2].v.tuple.data[1];
tmp_670 = MAKE_V2(tmp_671, tmp_672);
}

{
gsl_vector * tmp_673;

{
gsl_matrix * tmp_674;
gsl_vector * tmp_675;
tmp_674 = tmp_665;
tmp_675 = tmp_670;
tmp_673 = SOLVE_LINEAR_2(tmp_674, tmp_675);
}

{
float tmp_676;
gsl_vector * tmp_677;
tmp_676 = 0;
tmp_677 = tmp_673;
result[0] = VECTOR_NTH(tmp_676, tmp_677);
}
{
float tmp_678;
gsl_vector * tmp_679;
tmp_678 = 1;
tmp_679 = tmp_673;
result[1] = VECTOR_NTH(tmp_678, tmp_679);
}
{
int tmp_680;
{
gsl_vector * tmp_681;
tmp_681 = tmp_673;
tmp_680 = FREE_VECTOR(tmp_681);
}
}
{
int tmp_682;
{
gsl_vector * tmp_683;
tmp_683 = tmp_670;
tmp_682 = FREE_VECTOR(tmp_683);
}
}
{
int tmp_684;
{
gsl_matrix * tmp_685;
tmp_685 = tmp_665;
tmp_684 = FREE_MATRIX(tmp_685);
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_div_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_686;
compvar_t *tmp_691;

tmp_686 = make_temporary();
{
compvar_t *tmp_687, *tmp_688, *tmp_689, *tmp_690;
tmp_687 = args[1][0];
tmp_688 = args[1][1];
tmp_689 = args[1][2];
tmp_690 = args[1][3];
emit_assign(make_lhs(tmp_686), make_op_rhs(OP_MAKE_M2X2, make_compvar_primary(tmp_687), make_compvar_primary(tmp_688), make_compvar_primary(tmp_689), make_compvar_primary(tmp_690)));
}

tmp_691 = make_temporary();
{
compvar_t *tmp_692, *tmp_693;
tmp_692 = args[0][0];
tmp_693 = args[0][1];
emit_assign(make_lhs(tmp_691), make_op_rhs(OP_MAKE_V2, make_compvar_primary(tmp_692), make_compvar_primary(tmp_693)));
}

{
compvar_t *tmp_694;

tmp_694 = make_temporary();
{
compvar_t *tmp_695, *tmp_696;
tmp_695 = tmp_686;
tmp_696 = tmp_691;
emit_assign(make_lhs(tmp_694), make_op_rhs(OP_SOLVE_LINEAR_2, make_compvar_primary(tmp_695), make_compvar_primary(tmp_696)));
}

{
int tmp_697;
for (tmp_697 = 0; tmp_697 < 2; ++tmp_697)
{
switch (tmp_697)
{
case 0 :
{
compvar_t *tmp_698, *tmp_699;
tmp_698 = make_temporary();
emit_assign(make_lhs(tmp_698), make_int_const_rhs(0));
tmp_699 = tmp_694;
emit_assign(make_lhs(result[tmp_697]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_698), make_compvar_primary(tmp_699)));
}
break;
case 1 :
{
compvar_t *tmp_700, *tmp_701;
tmp_700 = make_temporary();
emit_assign(make_lhs(tmp_700), make_int_const_rhs(1));
tmp_701 = tmp_694;
emit_assign(make_lhs(result[tmp_697]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_700), make_compvar_primary(tmp_701)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_702;
tmp_702 = make_temporary();
{
compvar_t *tmp_703;
tmp_703 = tmp_694;
emit_assign(make_lhs(tmp_702), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_703)));
}
}
{
compvar_t *tmp_704;
tmp_704 = make_temporary();
{
compvar_t *tmp_705;
tmp_705 = tmp_691;
emit_assign(make_lhs(tmp_704), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_705)));
}
}
{
compvar_t *tmp_706;
tmp_706 = make_temporary();
{
compvar_t *tmp_707;
tmp_707 = tmp_686;
emit_assign(make_lhs(tmp_706), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_707)));
}
}
}
}
}

static void
builtin_div_v3m3x3 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
gsl_matrix * tmp_708;
gsl_vector * tmp_718;

{
float tmp_709;
float tmp_710;
float tmp_711;
float tmp_712;
float tmp_713;
float tmp_714;
float tmp_715;
float tmp_716;
float tmp_717;
tmp_709 = STK[STKP - 1].v.tuple.data[0];
tmp_710 = STK[STKP - 1].v.tuple.data[1];
tmp_711 = STK[STKP - 1].v.tuple.data[2];
tmp_712 = STK[STKP - 1].v.tuple.data[3];
tmp_713 = STK[STKP - 1].v.tuple.data[4];
tmp_714 = STK[STKP - 1].v.tuple.data[5];
tmp_715 = STK[STKP - 1].v.tuple.data[6];
tmp_716 = STK[STKP - 1].v.tuple.data[7];
tmp_717 = STK[STKP - 1].v.tuple.data[8];
tmp_708 = MAKE_M3X3(tmp_709, tmp_710, tmp_711, tmp_712, tmp_713, tmp_714, tmp_715, tmp_716, tmp_717);
}

{
float tmp_719;
float tmp_720;
float tmp_721;
tmp_719 = STK[STKP - 2].v.tuple.data[0];
tmp_720 = STK[STKP - 2].v.tuple.data[1];
tmp_721 = STK[STKP - 2].v.tuple.data[2];
tmp_718 = MAKE_V3(tmp_719, tmp_720, tmp_721);
}

{
gsl_vector * tmp_722;

{
gsl_matrix * tmp_723;
gsl_vector * tmp_724;
tmp_723 = tmp_708;
tmp_724 = tmp_718;
tmp_722 = SOLVE_LINEAR_3(tmp_723, tmp_724);
}

{
float tmp_725;
gsl_vector * tmp_726;
tmp_725 = 0;
tmp_726 = tmp_722;
result[0] = VECTOR_NTH(tmp_725, tmp_726);
}
{
float tmp_727;
gsl_vector * tmp_728;
tmp_727 = 1;
tmp_728 = tmp_722;
result[1] = VECTOR_NTH(tmp_727, tmp_728);
}
{
float tmp_729;
gsl_vector * tmp_730;
tmp_729 = 2;
tmp_730 = tmp_722;
result[2] = VECTOR_NTH(tmp_729, tmp_730);
}
{
int tmp_731;
{
gsl_vector * tmp_732;
tmp_732 = tmp_722;
tmp_731 = FREE_VECTOR(tmp_732);
}
}
{
int tmp_733;
{
gsl_vector * tmp_734;
tmp_734 = tmp_718;
tmp_733 = FREE_VECTOR(tmp_734);
}
}
{
int tmp_735;
{
gsl_matrix * tmp_736;
tmp_736 = tmp_708;
tmp_735 = FREE_MATRIX(tmp_736);
}
}
}
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 3;
STKP -= 1;
}

static void
gen_div_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_737;
compvar_t *tmp_747;

tmp_737 = make_temporary();
{
compvar_t *tmp_738, *tmp_739, *tmp_740, *tmp_741, *tmp_742, *tmp_743, *tmp_744, *tmp_745, *tmp_746;
tmp_738 = args[1][0];
tmp_739 = args[1][1];
tmp_740 = args[1][2];
tmp_741 = args[1][3];
tmp_742 = args[1][4];
tmp_743 = args[1][5];
tmp_744 = args[1][6];
tmp_745 = args[1][7];
tmp_746 = args[1][8];
emit_assign(make_lhs(tmp_737), make_op_rhs(OP_MAKE_M3X3, make_compvar_primary(tmp_738), make_compvar_primary(tmp_739), make_compvar_primary(tmp_740), make_compvar_primary(tmp_741), make_compvar_primary(tmp_742), make_compvar_primary(tmp_743), make_compvar_primary(tmp_744), make_compvar_primary(tmp_745), make_compvar_primary(tmp_746)));
}

tmp_747 = make_temporary();
{
compvar_t *tmp_748, *tmp_749, *tmp_750;
tmp_748 = args[0][0];
tmp_749 = args[0][1];
tmp_750 = args[0][2];
emit_assign(make_lhs(tmp_747), make_op_rhs(OP_MAKE_V3, make_compvar_primary(tmp_748), make_compvar_primary(tmp_749), make_compvar_primary(tmp_750)));
}

{
compvar_t *tmp_751;

tmp_751 = make_temporary();
{
compvar_t *tmp_752, *tmp_753;
tmp_752 = tmp_737;
tmp_753 = tmp_747;
emit_assign(make_lhs(tmp_751), make_op_rhs(OP_SOLVE_LINEAR_3, make_compvar_primary(tmp_752), make_compvar_primary(tmp_753)));
}

{
int tmp_754;
for (tmp_754 = 0; tmp_754 < 3; ++tmp_754)
{
switch (tmp_754)
{
case 0 :
{
compvar_t *tmp_755, *tmp_756;
tmp_755 = make_temporary();
emit_assign(make_lhs(tmp_755), make_int_const_rhs(0));
tmp_756 = tmp_751;
emit_assign(make_lhs(result[tmp_754]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_755), make_compvar_primary(tmp_756)));
}
break;
case 1 :
{
compvar_t *tmp_757, *tmp_758;
tmp_757 = make_temporary();
emit_assign(make_lhs(tmp_757), make_int_const_rhs(1));
tmp_758 = tmp_751;
emit_assign(make_lhs(result[tmp_754]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_757), make_compvar_primary(tmp_758)));
}
break;
case 2 :
{
compvar_t *tmp_759, *tmp_760;
tmp_759 = make_temporary();
emit_assign(make_lhs(tmp_759), make_int_const_rhs(2));
tmp_760 = tmp_751;
emit_assign(make_lhs(result[tmp_754]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_759), make_compvar_primary(tmp_760)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_761;
tmp_761 = make_temporary();
{
compvar_t *tmp_762;
tmp_762 = tmp_751;
emit_assign(make_lhs(tmp_761), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_762)));
}
}
{
compvar_t *tmp_763;
tmp_763 = make_temporary();
{
compvar_t *tmp_764;
tmp_764 = tmp_747;
emit_assign(make_lhs(tmp_763), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_764)));
}
}
{
compvar_t *tmp_765;
tmp_765 = make_temporary();
{
compvar_t *tmp_766;
tmp_766 = tmp_737;
emit_assign(make_lhs(tmp_765), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_766)));
}
}
}
}
}

static void
builtin_div_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_767;
{
float tmp_768;
float tmp_769;
tmp_768 = STK[STKP - 1].v.tuple.data[0];
tmp_769 = 0;
tmp_767 = EQ(tmp_768, tmp_769);
}
if (tmp_767)
{
result[0] = 0;
}
else
{
{
float tmp_770;
float tmp_771;
tmp_770 = STK[STKP - 2].v.tuple.data[0];
tmp_771 = STK[STKP - 1].v.tuple.data[0];
result[0] = DIV(tmp_770, tmp_771);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_div_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_772;
tmp_772 = make_temporary();
{
compvar_t *tmp_773, *tmp_774;
tmp_773 = args[1][0];
tmp_774 = make_temporary();
emit_assign(make_lhs(tmp_774), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_772), make_op_rhs(OP_EQ, make_compvar_primary(tmp_773), make_compvar_primary(tmp_774)));
}
start_if_cond(make_compvar_rhs(tmp_772));
{
int tmp_775;
for (tmp_775 = 0; tmp_775 < 1; ++tmp_775)
{
switch (tmp_775)
{
case 0 :
emit_assign(make_lhs(result[tmp_775]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_776;
for (tmp_776 = 0; tmp_776 < 1; ++tmp_776)
{
{
compvar_t *tmp_777, *tmp_778;
tmp_777 = args[0][tmp_776];
tmp_778 = args[1][tmp_776];
emit_assign(make_lhs(result[tmp_776]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_777), make_compvar_primary(tmp_778)));
}
}
}
end_if_cond();
}
}

static void
builtin_div_s (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_779;
{
float tmp_780;
float tmp_781;
tmp_780 = STK[STKP - 1].v.tuple.data[0];
tmp_781 = 0;
tmp_779 = EQ(tmp_780, tmp_781);
}
if (tmp_779)
{
{
int tmp_782;
for (tmp_782 = 0; tmp_782 < STK[STKP - 2].v.tuple.length; ++tmp_782)
{
result[tmp_782] = 0;
}
}
}
else
{
{
int tmp_783;
for (tmp_783 = 0; tmp_783 < STK[STKP - 2].v.tuple.length; ++tmp_783)
{
{
float tmp_784;
float tmp_785;
tmp_784 = STK[STKP - 2].v.tuple.data[tmp_783];
tmp_785 = STK[STKP - 1].v.tuple.data[0];
result[tmp_783] = DIV(tmp_784, tmp_785);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_div_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_786;
tmp_786 = make_temporary();
{
compvar_t *tmp_787, *tmp_788;
tmp_787 = args[1][0];
tmp_788 = make_temporary();
emit_assign(make_lhs(tmp_788), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_786), make_op_rhs(OP_EQ, make_compvar_primary(tmp_787), make_compvar_primary(tmp_788)));
}
start_if_cond(make_compvar_rhs(tmp_786));
{
int tmp_789;
for (tmp_789 = 0; tmp_789 < arglengths[0]; ++tmp_789)
{
emit_assign(make_lhs(result[tmp_789]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_790;
for (tmp_790 = 0; tmp_790 < arglengths[0]; ++tmp_790)
{
{
compvar_t *tmp_791, *tmp_792;
tmp_791 = args[0][tmp_790];
tmp_792 = args[1][0];
emit_assign(make_lhs(result[tmp_790]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_791), make_compvar_primary(tmp_792)));
}
}
}
end_if_cond();
}
}

static void
builtin_div_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_793;
for (tmp_793 = 0; tmp_793 < STK[STKP - 1].v.tuple.length; ++tmp_793)
{
{
int tmp_794;
{
float tmp_795;
float tmp_796;
tmp_795 = STK[STKP - 1].v.tuple.data[tmp_793];
tmp_796 = 0;
tmp_794 = EQ(tmp_795, tmp_796);
}
if (tmp_794)
{
result[tmp_793] = 0;
}
else
{
{
float tmp_797;
float tmp_798;
tmp_797 = STK[STKP - 2].v.tuple.data[tmp_793];
tmp_798 = STK[STKP - 1].v.tuple.data[tmp_793];
result[tmp_793] = DIV(tmp_797, tmp_798);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_div_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_799;
for (tmp_799 = 0; tmp_799 < arglengths[1]; ++tmp_799)
{
{
compvar_t *tmp_800;
tmp_800 = make_temporary();
{
compvar_t *tmp_801, *tmp_802;
tmp_801 = args[1][tmp_799];
tmp_802 = make_temporary();
emit_assign(make_lhs(tmp_802), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_800), make_op_rhs(OP_EQ, make_compvar_primary(tmp_801), make_compvar_primary(tmp_802)));
}
start_if_cond(make_compvar_rhs(tmp_800));
emit_assign(make_lhs(result[tmp_799]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_803, *tmp_804;
tmp_803 = args[0][tmp_799];
tmp_804 = args[1][tmp_799];
emit_assign(make_lhs(result[tmp_799]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_803), make_compvar_primary(tmp_804)));
}
end_if_cond();
}
}
}
}

static void
builtin_mod_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_805;
{
float tmp_806;
float tmp_807;
tmp_806 = STK[STKP - 1].v.tuple.data[0];
tmp_807 = 0;
tmp_805 = EQ(tmp_806, tmp_807);
}
if (tmp_805)
{
result[0] = 0;
}
else
{
{
float tmp_808;
float tmp_809;
tmp_808 = STK[STKP - 2].v.tuple.data[0];
tmp_809 = STK[STKP - 1].v.tuple.data[0];
result[0] = MOD(tmp_808, tmp_809);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_mod_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_810;
tmp_810 = make_temporary();
{
compvar_t *tmp_811, *tmp_812;
tmp_811 = args[1][0];
tmp_812 = make_temporary();
emit_assign(make_lhs(tmp_812), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_810), make_op_rhs(OP_EQ, make_compvar_primary(tmp_811), make_compvar_primary(tmp_812)));
}
start_if_cond(make_compvar_rhs(tmp_810));
{
int tmp_813;
for (tmp_813 = 0; tmp_813 < 1; ++tmp_813)
{
switch (tmp_813)
{
case 0 :
emit_assign(make_lhs(result[tmp_813]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_814;
for (tmp_814 = 0; tmp_814 < 1; ++tmp_814)
{
{
compvar_t *tmp_815, *tmp_816;
tmp_815 = args[0][tmp_814];
tmp_816 = args[1][tmp_814];
emit_assign(make_lhs(result[tmp_814]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_815), make_compvar_primary(tmp_816)));
}
}
}
end_if_cond();
}
}

static void
builtin_mod_s (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_817;
{
float tmp_818;
float tmp_819;
tmp_818 = STK[STKP - 1].v.tuple.data[0];
tmp_819 = 0;
tmp_817 = EQ(tmp_818, tmp_819);
}
if (tmp_817)
{
{
int tmp_820;
for (tmp_820 = 0; tmp_820 < STK[STKP - 2].v.tuple.length; ++tmp_820)
{
result[tmp_820] = 0;
}
}
}
else
{
{
int tmp_821;
for (tmp_821 = 0; tmp_821 < STK[STKP - 2].v.tuple.length; ++tmp_821)
{
{
float tmp_822;
float tmp_823;
tmp_822 = STK[STKP - 2].v.tuple.data[tmp_821];
tmp_823 = STK[STKP - 1].v.tuple.data[0];
result[tmp_821] = MOD(tmp_822, tmp_823);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_mod_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_824;
tmp_824 = make_temporary();
{
compvar_t *tmp_825, *tmp_826;
tmp_825 = args[1][0];
tmp_826 = make_temporary();
emit_assign(make_lhs(tmp_826), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_824), make_op_rhs(OP_EQ, make_compvar_primary(tmp_825), make_compvar_primary(tmp_826)));
}
start_if_cond(make_compvar_rhs(tmp_824));
{
int tmp_827;
for (tmp_827 = 0; tmp_827 < arglengths[0]; ++tmp_827)
{
emit_assign(make_lhs(result[tmp_827]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_828;
for (tmp_828 = 0; tmp_828 < arglengths[0]; ++tmp_828)
{
{
compvar_t *tmp_829, *tmp_830;
tmp_829 = args[0][tmp_828];
tmp_830 = args[1][0];
emit_assign(make_lhs(result[tmp_828]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_829), make_compvar_primary(tmp_830)));
}
}
}
end_if_cond();
}
}

static void
builtin_mod_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_831;
for (tmp_831 = 0; tmp_831 < STK[STKP - 1].v.tuple.length; ++tmp_831)
{
{
int tmp_832;
{
float tmp_833;
float tmp_834;
tmp_833 = STK[STKP - 1].v.tuple.data[tmp_831];
tmp_834 = 0;
tmp_832 = EQ(tmp_833, tmp_834);
}
if (tmp_832)
{
result[tmp_831] = 0;
}
else
{
{
float tmp_835;
float tmp_836;
tmp_835 = STK[STKP - 2].v.tuple.data[tmp_831];
tmp_836 = STK[STKP - 1].v.tuple.data[tmp_831];
result[tmp_831] = MOD(tmp_835, tmp_836);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_mod_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_837;
for (tmp_837 = 0; tmp_837 < arglengths[1]; ++tmp_837)
{
{
compvar_t *tmp_838;
tmp_838 = make_temporary();
{
compvar_t *tmp_839, *tmp_840;
tmp_839 = args[1][tmp_837];
tmp_840 = make_temporary();
emit_assign(make_lhs(tmp_840), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_838), make_op_rhs(OP_EQ, make_compvar_primary(tmp_839), make_compvar_primary(tmp_840)));
}
start_if_cond(make_compvar_rhs(tmp_838));
emit_assign(make_lhs(result[tmp_837]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_841, *tmp_842;
tmp_841 = args[0][tmp_837];
tmp_842 = args[1][tmp_837];
emit_assign(make_lhs(result[tmp_837]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_841), make_compvar_primary(tmp_842)));
}
end_if_cond();
}
}
}
}

static void
builtin_pmod (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_843;

{
float tmp_844;
float tmp_845;
tmp_844 = STK[STKP - 2].v.tuple.data[0];
tmp_845 = STK[STKP - 1].v.tuple.data[0];
tmp_843 = MOD(tmp_844, tmp_845);
}

{
int tmp_846;
{
float tmp_847;
float tmp_848;
tmp_847 = STK[STKP - 2].v.tuple.data[0];
tmp_848 = 0;
tmp_846 = LESS(tmp_847, tmp_848);
}
if (tmp_846)
{
{
float tmp_849;
float tmp_850;
tmp_849 = tmp_843;
tmp_850 = STK[STKP - 1].v.tuple.data[0];
result[0] = ADD(tmp_849, tmp_850);
}
}
else
{
result[0] = tmp_843;
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_pmod (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_851;

tmp_851 = make_temporary();
{
compvar_t *tmp_852, *tmp_853;
tmp_852 = args[0][0];
tmp_853 = args[1][0];
emit_assign(make_lhs(tmp_851), make_op_rhs(OP_MOD, make_compvar_primary(tmp_852), make_compvar_primary(tmp_853)));
}

{
compvar_t *tmp_854;
tmp_854 = make_temporary();
{
compvar_t *tmp_855, *tmp_856;
tmp_855 = args[0][0];
tmp_856 = make_temporary();
emit_assign(make_lhs(tmp_856), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_854), make_op_rhs(OP_LESS, make_compvar_primary(tmp_855), make_compvar_primary(tmp_856)));
}
start_if_cond(make_compvar_rhs(tmp_854));
{
int tmp_857;
for (tmp_857 = 0; tmp_857 < 1; ++tmp_857)
{
switch (tmp_857)
{
case 0 :
{
compvar_t *tmp_858, *tmp_859;
tmp_858 = tmp_851;
tmp_859 = args[1][0];
emit_assign(make_lhs(result[tmp_857]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_858), make_compvar_primary(tmp_859)));
}
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_860;
for (tmp_860 = 0; tmp_860 < 1; ++tmp_860)
{
switch (tmp_860)
{
case 0 :
emit_assign(make_lhs(result[tmp_860]), make_compvar_rhs(tmp_851));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
}

static void
builtin_sqrt_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_861;

{
complex float tmp_862;
{
float tmp_863;
float tmp_864;
tmp_863 = STK[STKP - 1].v.tuple.data[0];
tmp_864 = STK[STKP - 1].v.tuple.data[1];
tmp_862 = COMPLEX(tmp_863, tmp_864);
}
tmp_861 = csqrtf(tmp_862);
}

{
complex float tmp_865;
tmp_865 = tmp_861;
result[0] = crealf(tmp_865);
}
{
complex float tmp_866;
tmp_866 = tmp_861;
result[1] = cimagf(tmp_866);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_sqrt_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_867;

tmp_867 = make_temporary();
{
compvar_t *tmp_868;
tmp_868 = make_temporary();
{
compvar_t *tmp_869, *tmp_870;
tmp_869 = args[0][0];
tmp_870 = args[0][1];
emit_assign(make_lhs(tmp_868), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_869), make_compvar_primary(tmp_870)));
}
emit_assign(make_lhs(tmp_867), make_op_rhs(OP_C_SQRT, make_compvar_primary(tmp_868)));
}

{
int tmp_871;
for (tmp_871 = 0; tmp_871 < 2; ++tmp_871)
{
switch (tmp_871)
{
case 0 :
{
compvar_t *tmp_872;
tmp_872 = tmp_867;
emit_assign(make_lhs(result[tmp_871]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_872)));
}
break;
case 1 :
{
compvar_t *tmp_873;
tmp_873 = tmp_867;
emit_assign(make_lhs(result[tmp_871]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_873)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_sqrt_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_874;
tmp_874 = STK[STKP - 1].v.tuple.data[0];
result[0] = sqrt(tmp_874);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_sqrt_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_875;
for (tmp_875 = 0; tmp_875 < 1; ++tmp_875)
{
switch (tmp_875)
{
case 0 :
{
compvar_t *tmp_876;
tmp_876 = args[0][0];
emit_assign(make_lhs(result[tmp_875]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_876)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_sum (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_879;
float tmp_877 = 0.0, tmp_878;
for (tmp_879 = 0; tmp_879 < STK[STKP - 1].v.tuple.length; ++tmp_879)
{
tmp_878 = STK[STKP - 1].v.tuple.data[tmp_879];

tmp_877 += tmp_878;
}
result[0] = tmp_877;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_sum (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_880;
for (tmp_880 = 0; tmp_880 < 1; ++tmp_880)
{
switch (tmp_880)
{
case 0 :
if (arglengths[0] == 1)
{
emit_assign(make_lhs(result[tmp_880]), make_compvar_rhs(args[0][0]));

}
else
{
compvar_t *tmp_881, *tmp_882;
int tmp_883;
tmp_881 = args[0][0];
tmp_882 = args[0][1];
emit_assign(make_lhs(result[tmp_880]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_881), make_compvar_primary(tmp_882)));
for (tmp_883 = 2; tmp_883 < arglengths[0]; ++tmp_883)
{
tmp_881 = args[0][tmp_883];
emit_assign(make_lhs(result[tmp_880]), make_op_rhs(OP_ADD, make_compvar_primary(result[tmp_880]), make_compvar_primary(tmp_881)));
}
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_dotp (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_886;
float tmp_884 = 0.0, tmp_885;
for (tmp_886 = 0; tmp_886 < STK[STKP - 2].v.tuple.length; ++tmp_886)
{
{
float tmp_887;
float tmp_888;
tmp_887 = STK[STKP - 2].v.tuple.data[tmp_886];
tmp_888 = STK[STKP - 1].v.tuple.data[tmp_886];
tmp_885 = MUL(tmp_887, tmp_888);
}

tmp_884 += tmp_885;
}
result[0] = tmp_884;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_dotp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_889;
for (tmp_889 = 0; tmp_889 < 1; ++tmp_889)
{
switch (tmp_889)
{
case 0 :
if (arglengths[0] == 1)
{
{
compvar_t *tmp_893, *tmp_894;
tmp_893 = args[0][0];
tmp_894 = args[1][0];
emit_assign(make_lhs(result[tmp_889]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_893), make_compvar_primary(tmp_894)));
}

}
else
{
compvar_t *tmp_890, *tmp_891;
int tmp_892;
tmp_890 = make_temporary();
{
compvar_t *tmp_895, *tmp_896;
tmp_895 = args[0][0];
tmp_896 = args[1][0];
emit_assign(make_lhs(tmp_890), make_op_rhs(OP_MUL, make_compvar_primary(tmp_895), make_compvar_primary(tmp_896)));
}
tmp_891 = make_temporary();
{
compvar_t *tmp_897, *tmp_898;
tmp_897 = args[0][1];
tmp_898 = args[1][1];
emit_assign(make_lhs(tmp_891), make_op_rhs(OP_MUL, make_compvar_primary(tmp_897), make_compvar_primary(tmp_898)));
}
emit_assign(make_lhs(result[tmp_889]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_890), make_compvar_primary(tmp_891)));
for (tmp_892 = 2; tmp_892 < arglengths[0]; ++tmp_892)
{
tmp_890 = make_temporary();
{
compvar_t *tmp_899, *tmp_900;
tmp_899 = args[0][tmp_892];
tmp_900 = args[1][tmp_892];
emit_assign(make_lhs(tmp_890), make_op_rhs(OP_MUL, make_compvar_primary(tmp_899), make_compvar_primary(tmp_900)));
}
emit_assign(make_lhs(result[tmp_889]), make_op_rhs(OP_ADD, make_compvar_primary(result[tmp_889]), make_compvar_primary(tmp_890)));
}
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_crossp (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_901;
float tmp_902;
{
float tmp_903;
float tmp_904;
tmp_903 = STK[STKP - 2].v.tuple.data[1];
tmp_904 = STK[STKP - 1].v.tuple.data[2];
tmp_901 = MUL(tmp_903, tmp_904);
}
{
float tmp_905;
float tmp_906;
tmp_905 = STK[STKP - 2].v.tuple.data[2];
tmp_906 = STK[STKP - 1].v.tuple.data[1];
tmp_902 = MUL(tmp_905, tmp_906);
}
result[0] = SUB(tmp_901, tmp_902);
}
{
float tmp_907;
float tmp_908;
{
float tmp_909;
float tmp_910;
tmp_909 = STK[STKP - 2].v.tuple.data[2];
tmp_910 = STK[STKP - 1].v.tuple.data[0];
tmp_907 = MUL(tmp_909, tmp_910);
}
{
float tmp_911;
float tmp_912;
tmp_911 = STK[STKP - 2].v.tuple.data[0];
tmp_912 = STK[STKP - 1].v.tuple.data[2];
tmp_908 = MUL(tmp_911, tmp_912);
}
result[1] = SUB(tmp_907, tmp_908);
}
{
float tmp_913;
float tmp_914;
{
float tmp_915;
float tmp_916;
tmp_915 = STK[STKP - 2].v.tuple.data[0];
tmp_916 = STK[STKP - 1].v.tuple.data[1];
tmp_913 = MUL(tmp_915, tmp_916);
}
{
float tmp_917;
float tmp_918;
tmp_917 = STK[STKP - 2].v.tuple.data[1];
tmp_918 = STK[STKP - 1].v.tuple.data[0];
tmp_914 = MUL(tmp_917, tmp_918);
}
result[2] = SUB(tmp_913, tmp_914);
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 3;
STKP -= 1;
}

static void
gen_crossp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_919;
for (tmp_919 = 0; tmp_919 < 3; ++tmp_919)
{
switch (tmp_919)
{
case 0 :
{
compvar_t *tmp_920, *tmp_921;
tmp_920 = make_temporary();
{
compvar_t *tmp_922, *tmp_923;
tmp_922 = args[0][1];
tmp_923 = args[1][2];
emit_assign(make_lhs(tmp_920), make_op_rhs(OP_MUL, make_compvar_primary(tmp_922), make_compvar_primary(tmp_923)));
}
tmp_921 = make_temporary();
{
compvar_t *tmp_924, *tmp_925;
tmp_924 = args[0][2];
tmp_925 = args[1][1];
emit_assign(make_lhs(tmp_921), make_op_rhs(OP_MUL, make_compvar_primary(tmp_924), make_compvar_primary(tmp_925)));
}
emit_assign(make_lhs(result[tmp_919]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_920), make_compvar_primary(tmp_921)));
}
break;
case 1 :
{
compvar_t *tmp_926, *tmp_927;
tmp_926 = make_temporary();
{
compvar_t *tmp_928, *tmp_929;
tmp_928 = args[0][2];
tmp_929 = args[1][0];
emit_assign(make_lhs(tmp_926), make_op_rhs(OP_MUL, make_compvar_primary(tmp_928), make_compvar_primary(tmp_929)));
}
tmp_927 = make_temporary();
{
compvar_t *tmp_930, *tmp_931;
tmp_930 = args[0][0];
tmp_931 = args[1][2];
emit_assign(make_lhs(tmp_927), make_op_rhs(OP_MUL, make_compvar_primary(tmp_930), make_compvar_primary(tmp_931)));
}
emit_assign(make_lhs(result[tmp_919]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_926), make_compvar_primary(tmp_927)));
}
break;
case 2 :
{
compvar_t *tmp_932, *tmp_933;
tmp_932 = make_temporary();
{
compvar_t *tmp_934, *tmp_935;
tmp_934 = args[0][0];
tmp_935 = args[1][1];
emit_assign(make_lhs(tmp_932), make_op_rhs(OP_MUL, make_compvar_primary(tmp_934), make_compvar_primary(tmp_935)));
}
tmp_933 = make_temporary();
{
compvar_t *tmp_936, *tmp_937;
tmp_936 = args[0][1];
tmp_937 = args[1][0];
emit_assign(make_lhs(tmp_933), make_op_rhs(OP_MUL, make_compvar_primary(tmp_936), make_compvar_primary(tmp_937)));
}
emit_assign(make_lhs(result[tmp_919]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_932), make_compvar_primary(tmp_933)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_det_m2x2 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_938;
float tmp_939;
{
float tmp_940;
float tmp_941;
tmp_940 = STK[STKP - 1].v.tuple.data[0];
tmp_941 = STK[STKP - 1].v.tuple.data[3];
tmp_938 = MUL(tmp_940, tmp_941);
}
{
float tmp_942;
float tmp_943;
tmp_942 = STK[STKP - 1].v.tuple.data[1];
tmp_943 = STK[STKP - 1].v.tuple.data[2];
tmp_939 = MUL(tmp_942, tmp_943);
}
result[0] = SUB(tmp_938, tmp_939);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_det_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_944;
for (tmp_944 = 0; tmp_944 < 1; ++tmp_944)
{
switch (tmp_944)
{
case 0 :
{
compvar_t *tmp_945, *tmp_946;
tmp_945 = make_temporary();
{
compvar_t *tmp_947, *tmp_948;
tmp_947 = args[0][0];
tmp_948 = args[0][3];
emit_assign(make_lhs(tmp_945), make_op_rhs(OP_MUL, make_compvar_primary(tmp_947), make_compvar_primary(tmp_948)));
}
tmp_946 = make_temporary();
{
compvar_t *tmp_949, *tmp_950;
tmp_949 = args[0][1];
tmp_950 = args[0][2];
emit_assign(make_lhs(tmp_946), make_op_rhs(OP_MUL, make_compvar_primary(tmp_949), make_compvar_primary(tmp_950)));
}
emit_assign(make_lhs(result[tmp_944]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_945), make_compvar_primary(tmp_946)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_det_m3x3 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_951;
float tmp_952;
{
float tmp_953;
float tmp_954;
{
float tmp_955;
float tmp_956;
{
float tmp_957;
float tmp_958;
{
float tmp_959;
float tmp_960;
tmp_959 = STK[STKP - 1].v.tuple.data[0];
tmp_960 = STK[STKP - 1].v.tuple.data[4];
tmp_957 = MUL(tmp_959, tmp_960);
}
tmp_958 = STK[STKP - 1].v.tuple.data[8];
tmp_955 = MUL(tmp_957, tmp_958);
}
{
float tmp_961;
float tmp_962;
{
float tmp_963;
float tmp_964;
tmp_963 = STK[STKP - 1].v.tuple.data[1];
tmp_964 = STK[STKP - 1].v.tuple.data[5];
tmp_961 = MUL(tmp_963, tmp_964);
}
tmp_962 = STK[STKP - 1].v.tuple.data[6];
tmp_956 = MUL(tmp_961, tmp_962);
}
tmp_953 = ADD(tmp_955, tmp_956);
}
{
float tmp_965;
float tmp_966;
{
float tmp_967;
float tmp_968;
tmp_967 = STK[STKP - 1].v.tuple.data[2];
tmp_968 = STK[STKP - 1].v.tuple.data[3];
tmp_965 = MUL(tmp_967, tmp_968);
}
tmp_966 = STK[STKP - 1].v.tuple.data[7];
tmp_954 = MUL(tmp_965, tmp_966);
}
tmp_951 = ADD(tmp_953, tmp_954);
}
{
float tmp_969;
float tmp_970;
{
float tmp_971;
float tmp_972;
{
float tmp_973;
float tmp_974;
{
float tmp_975;
float tmp_976;
tmp_975 = STK[STKP - 1].v.tuple.data[2];
tmp_976 = STK[STKP - 1].v.tuple.data[4];
tmp_973 = MUL(tmp_975, tmp_976);
}
tmp_974 = STK[STKP - 1].v.tuple.data[6];
tmp_971 = MUL(tmp_973, tmp_974);
}
{
float tmp_977;
float tmp_978;
{
float tmp_979;
float tmp_980;
tmp_979 = STK[STKP - 1].v.tuple.data[0];
tmp_980 = STK[STKP - 1].v.tuple.data[5];
tmp_977 = MUL(tmp_979, tmp_980);
}
tmp_978 = STK[STKP - 1].v.tuple.data[7];
tmp_972 = MUL(tmp_977, tmp_978);
}
tmp_969 = ADD(tmp_971, tmp_972);
}
{
float tmp_981;
float tmp_982;
{
float tmp_983;
float tmp_984;
tmp_983 = STK[STKP - 1].v.tuple.data[1];
tmp_984 = STK[STKP - 1].v.tuple.data[3];
tmp_981 = MUL(tmp_983, tmp_984);
}
tmp_982 = STK[STKP - 1].v.tuple.data[8];
tmp_970 = MUL(tmp_981, tmp_982);
}
tmp_952 = ADD(tmp_969, tmp_970);
}
result[0] = SUB(tmp_951, tmp_952);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_det_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_985;
for (tmp_985 = 0; tmp_985 < 1; ++tmp_985)
{
switch (tmp_985)
{
case 0 :
{
compvar_t *tmp_986, *tmp_987;
tmp_986 = make_temporary();
{
compvar_t *tmp_988, *tmp_989;
tmp_988 = make_temporary();
{
compvar_t *tmp_990, *tmp_991;
tmp_990 = make_temporary();
{
compvar_t *tmp_992, *tmp_993;
tmp_992 = make_temporary();
{
compvar_t *tmp_994, *tmp_995;
tmp_994 = args[0][0];
tmp_995 = args[0][4];
emit_assign(make_lhs(tmp_992), make_op_rhs(OP_MUL, make_compvar_primary(tmp_994), make_compvar_primary(tmp_995)));
}
tmp_993 = args[0][8];
emit_assign(make_lhs(tmp_990), make_op_rhs(OP_MUL, make_compvar_primary(tmp_992), make_compvar_primary(tmp_993)));
}
tmp_991 = make_temporary();
{
compvar_t *tmp_996, *tmp_997;
tmp_996 = make_temporary();
{
compvar_t *tmp_998, *tmp_999;
tmp_998 = args[0][1];
tmp_999 = args[0][5];
emit_assign(make_lhs(tmp_996), make_op_rhs(OP_MUL, make_compvar_primary(tmp_998), make_compvar_primary(tmp_999)));
}
tmp_997 = args[0][6];
emit_assign(make_lhs(tmp_991), make_op_rhs(OP_MUL, make_compvar_primary(tmp_996), make_compvar_primary(tmp_997)));
}
emit_assign(make_lhs(tmp_988), make_op_rhs(OP_ADD, make_compvar_primary(tmp_990), make_compvar_primary(tmp_991)));
}
tmp_989 = make_temporary();
{
compvar_t *tmp_1000, *tmp_1001;
tmp_1000 = make_temporary();
{
compvar_t *tmp_1002, *tmp_1003;
tmp_1002 = args[0][2];
tmp_1003 = args[0][3];
emit_assign(make_lhs(tmp_1000), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1002), make_compvar_primary(tmp_1003)));
}
tmp_1001 = args[0][7];
emit_assign(make_lhs(tmp_989), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1000), make_compvar_primary(tmp_1001)));
}
emit_assign(make_lhs(tmp_986), make_op_rhs(OP_ADD, make_compvar_primary(tmp_988), make_compvar_primary(tmp_989)));
}
tmp_987 = make_temporary();
{
compvar_t *tmp_1004, *tmp_1005;
tmp_1004 = make_temporary();
{
compvar_t *tmp_1006, *tmp_1007;
tmp_1006 = make_temporary();
{
compvar_t *tmp_1008, *tmp_1009;
tmp_1008 = make_temporary();
{
compvar_t *tmp_1010, *tmp_1011;
tmp_1010 = args[0][2];
tmp_1011 = args[0][4];
emit_assign(make_lhs(tmp_1008), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1010), make_compvar_primary(tmp_1011)));
}
tmp_1009 = args[0][6];
emit_assign(make_lhs(tmp_1006), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1008), make_compvar_primary(tmp_1009)));
}
tmp_1007 = make_temporary();
{
compvar_t *tmp_1012, *tmp_1013;
tmp_1012 = make_temporary();
{
compvar_t *tmp_1014, *tmp_1015;
tmp_1014 = args[0][0];
tmp_1015 = args[0][5];
emit_assign(make_lhs(tmp_1012), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1014), make_compvar_primary(tmp_1015)));
}
tmp_1013 = args[0][7];
emit_assign(make_lhs(tmp_1007), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1012), make_compvar_primary(tmp_1013)));
}
emit_assign(make_lhs(tmp_1004), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1006), make_compvar_primary(tmp_1007)));
}
tmp_1005 = make_temporary();
{
compvar_t *tmp_1016, *tmp_1017;
tmp_1016 = make_temporary();
{
compvar_t *tmp_1018, *tmp_1019;
tmp_1018 = args[0][1];
tmp_1019 = args[0][3];
emit_assign(make_lhs(tmp_1016), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1018), make_compvar_primary(tmp_1019)));
}
tmp_1017 = args[0][8];
emit_assign(make_lhs(tmp_1005), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1016), make_compvar_primary(tmp_1017)));
}
emit_assign(make_lhs(tmp_987), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1004), make_compvar_primary(tmp_1005)));
}
emit_assign(make_lhs(result[tmp_985]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_986), make_compvar_primary(tmp_987)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_normalize (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1020;

{
int tmp_1023;
float tmp_1021 = 0.0, tmp_1022;
for (tmp_1023 = 0; tmp_1023 < STK[STKP - 1].v.tuple.length; ++tmp_1023)
{
{
float tmp_1024;
float tmp_1025;
tmp_1024 = STK[STKP - 1].v.tuple.data[tmp_1023];
tmp_1025 = STK[STKP - 1].v.tuple.data[tmp_1023];
tmp_1022 = MUL(tmp_1024, tmp_1025);
}

tmp_1021 += tmp_1022;
}
tmp_1020 = tmp_1021;
}

{
int tmp_1026;
{
float tmp_1027;
float tmp_1028;
tmp_1027 = tmp_1020;
tmp_1028 = 0;
tmp_1026 = EQ(tmp_1027, tmp_1028);
}
if (tmp_1026)
{
{
int tmp_1029;
for (tmp_1029 = 0; tmp_1029 < STK[STKP - 1].v.tuple.length; ++tmp_1029)
{
result[tmp_1029] = 0;
}
}
}
else
{
{
int tmp_1030;
for (tmp_1030 = 0; tmp_1030 < STK[STKP - 1].v.tuple.length; ++tmp_1030)
{
{
float tmp_1031;
float tmp_1032;
tmp_1031 = STK[STKP - 1].v.tuple.data[tmp_1030];
{
float tmp_1033;
tmp_1033 = tmp_1020;
tmp_1032 = sqrt(tmp_1033);
}
result[tmp_1030] = DIV(tmp_1031, tmp_1032);
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].v.tuple.length; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = STK[STKP - 1].v.tuple.length;
STKP -= 0;
}

static void
gen_normalize (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1034;

if (arglengths[0] == 1)
{
tmp_1034 = make_temporary();
{
compvar_t *tmp_1038, *tmp_1039;
tmp_1038 = args[0][0];
tmp_1039 = args[0][0];
emit_assign(make_lhs(tmp_1034), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1038), make_compvar_primary(tmp_1039)));
}

}
else
{
compvar_t *tmp_1035, *tmp_1036;
int tmp_1037;
tmp_1034 = make_temporary();
tmp_1035 = make_temporary();
{
compvar_t *tmp_1040, *tmp_1041;
tmp_1040 = args[0][0];
tmp_1041 = args[0][0];
emit_assign(make_lhs(tmp_1035), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1040), make_compvar_primary(tmp_1041)));
}
tmp_1036 = make_temporary();
{
compvar_t *tmp_1042, *tmp_1043;
tmp_1042 = args[0][1];
tmp_1043 = args[0][1];
emit_assign(make_lhs(tmp_1036), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1042), make_compvar_primary(tmp_1043)));
}
emit_assign(make_lhs(tmp_1034), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1035), make_compvar_primary(tmp_1036)));
for (tmp_1037 = 2; tmp_1037 < arglengths[0]; ++tmp_1037)
{
tmp_1035 = make_temporary();
{
compvar_t *tmp_1044, *tmp_1045;
tmp_1044 = args[0][tmp_1037];
tmp_1045 = args[0][tmp_1037];
emit_assign(make_lhs(tmp_1035), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1044), make_compvar_primary(tmp_1045)));
}
emit_assign(make_lhs(tmp_1034), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1034), make_compvar_primary(tmp_1035)));
}
}

{
compvar_t *tmp_1046;
tmp_1046 = make_temporary();
{
compvar_t *tmp_1047, *tmp_1048;
tmp_1047 = tmp_1034;
tmp_1048 = make_temporary();
emit_assign(make_lhs(tmp_1048), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1046), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1047), make_compvar_primary(tmp_1048)));
}
start_if_cond(make_compvar_rhs(tmp_1046));
{
int tmp_1049;
for (tmp_1049 = 0; tmp_1049 < arglengths[0]; ++tmp_1049)
{
emit_assign(make_lhs(result[tmp_1049]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_1050;
for (tmp_1050 = 0; tmp_1050 < arglengths[0]; ++tmp_1050)
{
{
compvar_t *tmp_1051, *tmp_1052;
tmp_1051 = args[0][tmp_1050];
tmp_1052 = make_temporary();
{
compvar_t *tmp_1053;
tmp_1053 = tmp_1034;
emit_assign(make_lhs(tmp_1052), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_1053)));
}
emit_assign(make_lhs(result[tmp_1050]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1051), make_compvar_primary(tmp_1052)));
}
}
}
end_if_cond();
}
}
}

static void
builtin_abs_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1054;
float tmp_1055;
tmp_1054 = STK[STKP - 1].v.tuple.data[0];
tmp_1055 = STK[STKP - 1].v.tuple.data[1];
result[0] = hypot(tmp_1054, tmp_1055);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_abs_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1056;
for (tmp_1056 = 0; tmp_1056 < 1; ++tmp_1056)
{
switch (tmp_1056)
{
case 0 :
{
compvar_t *tmp_1057, *tmp_1058;
tmp_1057 = args[0][0];
tmp_1058 = args[0][1];
emit_assign(make_lhs(result[tmp_1056]), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_1057), make_compvar_primary(tmp_1058)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_abs_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1059;
tmp_1059 = STK[STKP - 1].v.tuple.data[0];
result[0] = fabs(tmp_1059);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_abs_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1060;
for (tmp_1060 = 0; tmp_1060 < 1; ++tmp_1060)
{
{
compvar_t *tmp_1061;
tmp_1061 = args[0][tmp_1060];
emit_assign(make_lhs(result[tmp_1060]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_1061)));
}
}
}
}

static void
builtin_abs_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1062;
for (tmp_1062 = 0; tmp_1062 < STK[STKP - 1].v.tuple.length; ++tmp_1062)
{
{
float tmp_1063;
tmp_1063 = STK[STKP - 1].v.tuple.data[tmp_1062];
result[tmp_1062] = fabs(tmp_1063);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].v.tuple.length; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = STK[STKP - 1].v.tuple.length;
STKP -= 0;
}

static void
gen_abs_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1064;
for (tmp_1064 = 0; tmp_1064 < arglengths[0]; ++tmp_1064)
{
{
compvar_t *tmp_1065;
tmp_1065 = args[0][tmp_1064];
emit_assign(make_lhs(result[tmp_1064]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_1065)));
}
}
}
}

static void
builtin_deg2rad (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1066;
float tmp_1067;
tmp_1066 = STK[STKP - 1].v.tuple.data[0];
tmp_1067 = 0.017453292;
result[0] = MUL(tmp_1066, tmp_1067);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_deg2rad (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1068;
for (tmp_1068 = 0; tmp_1068 < 1; ++tmp_1068)
{
switch (tmp_1068)
{
case 0 :
{
compvar_t *tmp_1069, *tmp_1070;
tmp_1069 = args[0][0];
tmp_1070 = make_temporary();
emit_assign(make_lhs(tmp_1070), make_float_const_rhs(0.017453292));
emit_assign(make_lhs(result[tmp_1068]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1069), make_compvar_primary(tmp_1070)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_rad2deg (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1071;
float tmp_1072;
tmp_1071 = STK[STKP - 1].v.tuple.data[0];
tmp_1072 = 57.29578;
result[0] = MUL(tmp_1071, tmp_1072);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_rad2deg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1073;
for (tmp_1073 = 0; tmp_1073 < 1; ++tmp_1073)
{
switch (tmp_1073)
{
case 0 :
{
compvar_t *tmp_1074, *tmp_1075;
tmp_1074 = args[0][0];
tmp_1075 = make_temporary();
emit_assign(make_lhs(tmp_1075), make_float_const_rhs(57.29578));
emit_assign(make_lhs(result[tmp_1073]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1074), make_compvar_primary(tmp_1075)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_sin_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1076;

{
complex float tmp_1077;
{
float tmp_1078;
float tmp_1079;
tmp_1078 = STK[STKP - 1].v.tuple.data[0];
tmp_1079 = STK[STKP - 1].v.tuple.data[1];
tmp_1077 = COMPLEX(tmp_1078, tmp_1079);
}
tmp_1076 = csinf(tmp_1077);
}

{
complex float tmp_1080;
tmp_1080 = tmp_1076;
result[0] = crealf(tmp_1080);
}
{
complex float tmp_1081;
tmp_1081 = tmp_1076;
result[1] = cimagf(tmp_1081);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_sin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1082;

tmp_1082 = make_temporary();
{
compvar_t *tmp_1083;
tmp_1083 = make_temporary();
{
compvar_t *tmp_1084, *tmp_1085;
tmp_1084 = args[0][0];
tmp_1085 = args[0][1];
emit_assign(make_lhs(tmp_1083), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1084), make_compvar_primary(tmp_1085)));
}
emit_assign(make_lhs(tmp_1082), make_op_rhs(OP_C_SIN, make_compvar_primary(tmp_1083)));
}

{
int tmp_1086;
for (tmp_1086 = 0; tmp_1086 < 2; ++tmp_1086)
{
switch (tmp_1086)
{
case 0 :
{
compvar_t *tmp_1087;
tmp_1087 = tmp_1082;
emit_assign(make_lhs(result[tmp_1086]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1087)));
}
break;
case 1 :
{
compvar_t *tmp_1088;
tmp_1088 = tmp_1082;
emit_assign(make_lhs(result[tmp_1086]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1088)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_sin (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1089;
tmp_1089 = STK[STKP - 1].v.tuple.data[0];
result[0] = sin(tmp_1089);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_sin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1090;
for (tmp_1090 = 0; tmp_1090 < 1; ++tmp_1090)
{
switch (tmp_1090)
{
case 0 :
{
compvar_t *tmp_1091;
tmp_1091 = args[0][0];
emit_assign(make_lhs(result[tmp_1090]), make_op_rhs(OP_SIN, make_compvar_primary(tmp_1091)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_cos_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1092;

{
complex float tmp_1093;
{
float tmp_1094;
float tmp_1095;
tmp_1094 = STK[STKP - 1].v.tuple.data[0];
tmp_1095 = STK[STKP - 1].v.tuple.data[1];
tmp_1093 = COMPLEX(tmp_1094, tmp_1095);
}
tmp_1092 = ccosf(tmp_1093);
}

{
complex float tmp_1096;
tmp_1096 = tmp_1092;
result[0] = crealf(tmp_1096);
}
{
complex float tmp_1097;
tmp_1097 = tmp_1092;
result[1] = cimagf(tmp_1097);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_cos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1098;

tmp_1098 = make_temporary();
{
compvar_t *tmp_1099;
tmp_1099 = make_temporary();
{
compvar_t *tmp_1100, *tmp_1101;
tmp_1100 = args[0][0];
tmp_1101 = args[0][1];
emit_assign(make_lhs(tmp_1099), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1100), make_compvar_primary(tmp_1101)));
}
emit_assign(make_lhs(tmp_1098), make_op_rhs(OP_C_COS, make_compvar_primary(tmp_1099)));
}

{
int tmp_1102;
for (tmp_1102 = 0; tmp_1102 < 2; ++tmp_1102)
{
switch (tmp_1102)
{
case 0 :
{
compvar_t *tmp_1103;
tmp_1103 = tmp_1098;
emit_assign(make_lhs(result[tmp_1102]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1103)));
}
break;
case 1 :
{
compvar_t *tmp_1104;
tmp_1104 = tmp_1098;
emit_assign(make_lhs(result[tmp_1102]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1104)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_cos (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1105;
tmp_1105 = STK[STKP - 1].v.tuple.data[0];
result[0] = cos(tmp_1105);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_cos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1106;
for (tmp_1106 = 0; tmp_1106 < 1; ++tmp_1106)
{
switch (tmp_1106)
{
case 0 :
{
compvar_t *tmp_1107;
tmp_1107 = args[0][0];
emit_assign(make_lhs(result[tmp_1106]), make_op_rhs(OP_COS, make_compvar_primary(tmp_1107)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_tan_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1108;

{
complex float tmp_1109;
{
float tmp_1110;
float tmp_1111;
tmp_1110 = STK[STKP - 1].v.tuple.data[0];
tmp_1111 = STK[STKP - 1].v.tuple.data[1];
tmp_1109 = COMPLEX(tmp_1110, tmp_1111);
}
tmp_1108 = ctanf(tmp_1109);
}

{
complex float tmp_1112;
tmp_1112 = tmp_1108;
result[0] = crealf(tmp_1112);
}
{
complex float tmp_1113;
tmp_1113 = tmp_1108;
result[1] = cimagf(tmp_1113);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_tan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1114;

tmp_1114 = make_temporary();
{
compvar_t *tmp_1115;
tmp_1115 = make_temporary();
{
compvar_t *tmp_1116, *tmp_1117;
tmp_1116 = args[0][0];
tmp_1117 = args[0][1];
emit_assign(make_lhs(tmp_1115), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1116), make_compvar_primary(tmp_1117)));
}
emit_assign(make_lhs(tmp_1114), make_op_rhs(OP_C_TAN, make_compvar_primary(tmp_1115)));
}

{
int tmp_1118;
for (tmp_1118 = 0; tmp_1118 < 2; ++tmp_1118)
{
switch (tmp_1118)
{
case 0 :
{
compvar_t *tmp_1119;
tmp_1119 = tmp_1114;
emit_assign(make_lhs(result[tmp_1118]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1119)));
}
break;
case 1 :
{
compvar_t *tmp_1120;
tmp_1120 = tmp_1114;
emit_assign(make_lhs(result[tmp_1118]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1120)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_tan (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1121;
tmp_1121 = STK[STKP - 1].v.tuple.data[0];
result[0] = tan(tmp_1121);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_tan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1122;
for (tmp_1122 = 0; tmp_1122 < 1; ++tmp_1122)
{
switch (tmp_1122)
{
case 0 :
{
compvar_t *tmp_1123;
tmp_1123 = args[0][0];
emit_assign(make_lhs(result[tmp_1122]), make_op_rhs(OP_TAN, make_compvar_primary(tmp_1123)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_asin_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1124;

{
complex float tmp_1125;
{
float tmp_1126;
float tmp_1127;
tmp_1126 = STK[STKP - 1].v.tuple.data[0];
tmp_1127 = STK[STKP - 1].v.tuple.data[1];
tmp_1125 = COMPLEX(tmp_1126, tmp_1127);
}
tmp_1124 = casinf(tmp_1125);
}

{
complex float tmp_1128;
tmp_1128 = tmp_1124;
result[0] = crealf(tmp_1128);
}
{
complex float tmp_1129;
tmp_1129 = tmp_1124;
result[1] = cimagf(tmp_1129);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_asin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1130;

tmp_1130 = make_temporary();
{
compvar_t *tmp_1131;
tmp_1131 = make_temporary();
{
compvar_t *tmp_1132, *tmp_1133;
tmp_1132 = args[0][0];
tmp_1133 = args[0][1];
emit_assign(make_lhs(tmp_1131), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1132), make_compvar_primary(tmp_1133)));
}
emit_assign(make_lhs(tmp_1130), make_op_rhs(OP_C_ASIN, make_compvar_primary(tmp_1131)));
}

{
int tmp_1134;
for (tmp_1134 = 0; tmp_1134 < 2; ++tmp_1134)
{
switch (tmp_1134)
{
case 0 :
{
compvar_t *tmp_1135;
tmp_1135 = tmp_1130;
emit_assign(make_lhs(result[tmp_1134]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1135)));
}
break;
case 1 :
{
compvar_t *tmp_1136;
tmp_1136 = tmp_1130;
emit_assign(make_lhs(result[tmp_1134]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1136)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_asin (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1137;
{
float tmp_1138;
float tmp_1139;
tmp_1138 = STK[STKP - 1].v.tuple.data[0];
tmp_1139 = -1;
tmp_1137 = LESS(tmp_1138, tmp_1139);
}
if (!tmp_1137)
{
{
float tmp_1140;
float tmp_1141;
tmp_1140 = 1;
tmp_1141 = STK[STKP - 1].v.tuple.data[0];
tmp_1137 = LESS(tmp_1140, tmp_1141);
}
}
if (tmp_1137)
{
result[0] = 0;
}
else
{
{
float tmp_1142;
tmp_1142 = STK[STKP - 1].v.tuple.data[0];
result[0] = asin(tmp_1142);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_asin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1143;
tmp_1143 = make_temporary();
{
compvar_t *tmp_1144, *tmp_1145;
tmp_1144 = args[0][0];
tmp_1145 = make_temporary();
emit_assign(make_lhs(tmp_1145), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_1143), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1144), make_compvar_primary(tmp_1145)));
}
start_if_cond(make_compvar_rhs(tmp_1143));
switch_if_branch();
{
compvar_t *tmp_1146, *tmp_1147;
tmp_1146 = make_temporary();
emit_assign(make_lhs(tmp_1146), make_int_const_rhs(1));
tmp_1147 = args[0][0];
emit_assign(make_lhs(tmp_1143), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1146), make_compvar_primary(tmp_1147)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1143));
{
int tmp_1148;
for (tmp_1148 = 0; tmp_1148 < 1; ++tmp_1148)
{
switch (tmp_1148)
{
case 0 :
emit_assign(make_lhs(result[tmp_1148]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1149;
for (tmp_1149 = 0; tmp_1149 < 1; ++tmp_1149)
{
switch (tmp_1149)
{
case 0 :
{
compvar_t *tmp_1150;
tmp_1150 = args[0][0];
emit_assign(make_lhs(result[tmp_1149]), make_op_rhs(OP_ASIN, make_compvar_primary(tmp_1150)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_acos_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1151;

{
complex float tmp_1152;
{
float tmp_1153;
float tmp_1154;
tmp_1153 = STK[STKP - 1].v.tuple.data[0];
tmp_1154 = STK[STKP - 1].v.tuple.data[1];
tmp_1152 = COMPLEX(tmp_1153, tmp_1154);
}
tmp_1151 = cacosf(tmp_1152);
}

{
complex float tmp_1155;
tmp_1155 = tmp_1151;
result[0] = crealf(tmp_1155);
}
{
complex float tmp_1156;
tmp_1156 = tmp_1151;
result[1] = cimagf(tmp_1156);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_acos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1157;

tmp_1157 = make_temporary();
{
compvar_t *tmp_1158;
tmp_1158 = make_temporary();
{
compvar_t *tmp_1159, *tmp_1160;
tmp_1159 = args[0][0];
tmp_1160 = args[0][1];
emit_assign(make_lhs(tmp_1158), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1159), make_compvar_primary(tmp_1160)));
}
emit_assign(make_lhs(tmp_1157), make_op_rhs(OP_C_ACOS, make_compvar_primary(tmp_1158)));
}

{
int tmp_1161;
for (tmp_1161 = 0; tmp_1161 < 2; ++tmp_1161)
{
switch (tmp_1161)
{
case 0 :
{
compvar_t *tmp_1162;
tmp_1162 = tmp_1157;
emit_assign(make_lhs(result[tmp_1161]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1162)));
}
break;
case 1 :
{
compvar_t *tmp_1163;
tmp_1163 = tmp_1157;
emit_assign(make_lhs(result[tmp_1161]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1163)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_acos (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1164;
{
float tmp_1165;
float tmp_1166;
tmp_1165 = STK[STKP - 1].v.tuple.data[0];
tmp_1166 = -1;
tmp_1164 = LESS(tmp_1165, tmp_1166);
}
if (!tmp_1164)
{
{
float tmp_1167;
float tmp_1168;
tmp_1167 = 1;
tmp_1168 = STK[STKP - 1].v.tuple.data[0];
tmp_1164 = LESS(tmp_1167, tmp_1168);
}
}
if (tmp_1164)
{
result[0] = 0;
}
else
{
{
float tmp_1169;
tmp_1169 = STK[STKP - 1].v.tuple.data[0];
result[0] = acos(tmp_1169);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_acos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1170;
tmp_1170 = make_temporary();
{
compvar_t *tmp_1171, *tmp_1172;
tmp_1171 = args[0][0];
tmp_1172 = make_temporary();
emit_assign(make_lhs(tmp_1172), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_1170), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1171), make_compvar_primary(tmp_1172)));
}
start_if_cond(make_compvar_rhs(tmp_1170));
switch_if_branch();
{
compvar_t *tmp_1173, *tmp_1174;
tmp_1173 = make_temporary();
emit_assign(make_lhs(tmp_1173), make_int_const_rhs(1));
tmp_1174 = args[0][0];
emit_assign(make_lhs(tmp_1170), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1173), make_compvar_primary(tmp_1174)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1170));
{
int tmp_1175;
for (tmp_1175 = 0; tmp_1175 < 1; ++tmp_1175)
{
switch (tmp_1175)
{
case 0 :
emit_assign(make_lhs(result[tmp_1175]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1176;
for (tmp_1176 = 0; tmp_1176 < 1; ++tmp_1176)
{
switch (tmp_1176)
{
case 0 :
{
compvar_t *tmp_1177;
tmp_1177 = args[0][0];
emit_assign(make_lhs(result[tmp_1176]), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_1177)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_atan_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1178;

{
complex float tmp_1179;
{
float tmp_1180;
float tmp_1181;
tmp_1180 = STK[STKP - 1].v.tuple.data[0];
tmp_1181 = STK[STKP - 1].v.tuple.data[1];
tmp_1179 = COMPLEX(tmp_1180, tmp_1181);
}
tmp_1178 = catanf(tmp_1179);
}

{
complex float tmp_1182;
tmp_1182 = tmp_1178;
result[0] = crealf(tmp_1182);
}
{
complex float tmp_1183;
tmp_1183 = tmp_1178;
result[1] = cimagf(tmp_1183);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_atan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1184;

tmp_1184 = make_temporary();
{
compvar_t *tmp_1185;
tmp_1185 = make_temporary();
{
compvar_t *tmp_1186, *tmp_1187;
tmp_1186 = args[0][0];
tmp_1187 = args[0][1];
emit_assign(make_lhs(tmp_1185), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1186), make_compvar_primary(tmp_1187)));
}
emit_assign(make_lhs(tmp_1184), make_op_rhs(OP_C_ATAN, make_compvar_primary(tmp_1185)));
}

{
int tmp_1188;
for (tmp_1188 = 0; tmp_1188 < 2; ++tmp_1188)
{
switch (tmp_1188)
{
case 0 :
{
compvar_t *tmp_1189;
tmp_1189 = tmp_1184;
emit_assign(make_lhs(result[tmp_1188]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1189)));
}
break;
case 1 :
{
compvar_t *tmp_1190;
tmp_1190 = tmp_1184;
emit_assign(make_lhs(result[tmp_1188]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1190)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_atan (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1191;
tmp_1191 = STK[STKP - 1].v.tuple.data[0];
result[0] = atan(tmp_1191);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_atan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1192;
for (tmp_1192 = 0; tmp_1192 < 1; ++tmp_1192)
{
switch (tmp_1192)
{
case 0 :
{
compvar_t *tmp_1193;
tmp_1193 = args[0][0];
emit_assign(make_lhs(result[tmp_1192]), make_op_rhs(OP_ATAN, make_compvar_primary(tmp_1193)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_atan2 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1194;
float tmp_1195;
tmp_1194 = STK[STKP - 2].v.tuple.data[0];
tmp_1195 = STK[STKP - 1].v.tuple.data[0];
result[0] = atan2(tmp_1194, tmp_1195);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_atan2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1196;
for (tmp_1196 = 0; tmp_1196 < 1; ++tmp_1196)
{
switch (tmp_1196)
{
case 0 :
{
compvar_t *tmp_1197, *tmp_1198;
tmp_1197 = args[0][0];
tmp_1198 = args[1][0];
emit_assign(make_lhs(result[tmp_1196]), make_op_rhs(OP_ATAN2, make_compvar_primary(tmp_1197), make_compvar_primary(tmp_1198)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_pow_ri_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1199;

{
complex float tmp_1200;
complex float tmp_1201;
{
float tmp_1202;
float tmp_1203;
tmp_1202 = STK[STKP - 2].v.tuple.data[0];
tmp_1203 = STK[STKP - 2].v.tuple.data[1];
tmp_1200 = COMPLEX(tmp_1202, tmp_1203);
}
{
float tmp_1204;
float tmp_1205;
tmp_1204 = STK[STKP - 1].v.tuple.data[0];
tmp_1205 = 0.0;
tmp_1201 = COMPLEX(tmp_1204, tmp_1205);
}
tmp_1199 = cpowf(tmp_1200, tmp_1201);
}

{
complex float tmp_1206;
tmp_1206 = tmp_1199;
result[0] = crealf(tmp_1206);
}
{
complex float tmp_1207;
tmp_1207 = tmp_1199;
result[1] = cimagf(tmp_1207);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_pow_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1208;

tmp_1208 = make_temporary();
{
compvar_t *tmp_1209, *tmp_1210;
tmp_1209 = make_temporary();
{
compvar_t *tmp_1211, *tmp_1212;
tmp_1211 = args[0][0];
tmp_1212 = args[0][1];
emit_assign(make_lhs(tmp_1209), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1211), make_compvar_primary(tmp_1212)));
}
tmp_1210 = make_temporary();
{
compvar_t *tmp_1213, *tmp_1214;
tmp_1213 = args[1][0];
tmp_1214 = make_temporary();
emit_assign(make_lhs(tmp_1214), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_1210), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1213), make_compvar_primary(tmp_1214)));
}
emit_assign(make_lhs(tmp_1208), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_1209), make_compvar_primary(tmp_1210)));
}

{
int tmp_1215;
for (tmp_1215 = 0; tmp_1215 < 2; ++tmp_1215)
{
switch (tmp_1215)
{
case 0 :
{
compvar_t *tmp_1216;
tmp_1216 = tmp_1208;
emit_assign(make_lhs(result[tmp_1215]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1216)));
}
break;
case 1 :
{
compvar_t *tmp_1217;
tmp_1217 = tmp_1208;
emit_assign(make_lhs(result[tmp_1215]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1217)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_pow_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1218;

{
complex float tmp_1219;
complex float tmp_1220;
{
float tmp_1221;
float tmp_1222;
tmp_1221 = STK[STKP - 2].v.tuple.data[0];
tmp_1222 = STK[STKP - 2].v.tuple.data[1];
tmp_1219 = COMPLEX(tmp_1221, tmp_1222);
}
{
float tmp_1223;
float tmp_1224;
tmp_1223 = STK[STKP - 1].v.tuple.data[0];
tmp_1224 = STK[STKP - 1].v.tuple.data[1];
tmp_1220 = COMPLEX(tmp_1223, tmp_1224);
}
tmp_1218 = cpowf(tmp_1219, tmp_1220);
}

{
complex float tmp_1225;
tmp_1225 = tmp_1218;
result[0] = crealf(tmp_1225);
}
{
complex float tmp_1226;
tmp_1226 = tmp_1218;
result[1] = cimagf(tmp_1226);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_pow_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1227;

tmp_1227 = make_temporary();
{
compvar_t *tmp_1228, *tmp_1229;
tmp_1228 = make_temporary();
{
compvar_t *tmp_1230, *tmp_1231;
tmp_1230 = args[0][0];
tmp_1231 = args[0][1];
emit_assign(make_lhs(tmp_1228), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1230), make_compvar_primary(tmp_1231)));
}
tmp_1229 = make_temporary();
{
compvar_t *tmp_1232, *tmp_1233;
tmp_1232 = args[1][0];
tmp_1233 = args[1][1];
emit_assign(make_lhs(tmp_1229), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1232), make_compvar_primary(tmp_1233)));
}
emit_assign(make_lhs(tmp_1227), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_1228), make_compvar_primary(tmp_1229)));
}

{
int tmp_1234;
for (tmp_1234 = 0; tmp_1234 < 2; ++tmp_1234)
{
switch (tmp_1234)
{
case 0 :
{
compvar_t *tmp_1235;
tmp_1235 = tmp_1227;
emit_assign(make_lhs(result[tmp_1234]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1235)));
}
break;
case 1 :
{
compvar_t *tmp_1236;
tmp_1236 = tmp_1227;
emit_assign(make_lhs(result[tmp_1234]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1236)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_pow_1_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1237;

{
complex float tmp_1238;
complex float tmp_1239;
{
float tmp_1240;
float tmp_1241;
tmp_1240 = STK[STKP - 2].v.tuple.data[0];
tmp_1241 = 0.0;
tmp_1238 = COMPLEX(tmp_1240, tmp_1241);
}
{
float tmp_1242;
float tmp_1243;
tmp_1242 = STK[STKP - 1].v.tuple.data[0];
tmp_1243 = STK[STKP - 1].v.tuple.data[1];
tmp_1239 = COMPLEX(tmp_1242, tmp_1243);
}
tmp_1237 = cpowf(tmp_1238, tmp_1239);
}

{
complex float tmp_1244;
tmp_1244 = tmp_1237;
result[0] = crealf(tmp_1244);
}
{
complex float tmp_1245;
tmp_1245 = tmp_1237;
result[1] = cimagf(tmp_1245);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 2;
STKP -= 1;
}

static void
gen_pow_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1246;

tmp_1246 = make_temporary();
{
compvar_t *tmp_1247, *tmp_1248;
tmp_1247 = make_temporary();
{
compvar_t *tmp_1249, *tmp_1250;
tmp_1249 = args[0][0];
tmp_1250 = make_temporary();
emit_assign(make_lhs(tmp_1250), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_1247), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1249), make_compvar_primary(tmp_1250)));
}
tmp_1248 = make_temporary();
{
compvar_t *tmp_1251, *tmp_1252;
tmp_1251 = args[1][0];
tmp_1252 = args[1][1];
emit_assign(make_lhs(tmp_1248), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1251), make_compvar_primary(tmp_1252)));
}
emit_assign(make_lhs(tmp_1246), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_1247), make_compvar_primary(tmp_1248)));
}

{
int tmp_1253;
for (tmp_1253 = 0; tmp_1253 < 2; ++tmp_1253)
{
switch (tmp_1253)
{
case 0 :
{
compvar_t *tmp_1254;
tmp_1254 = tmp_1246;
emit_assign(make_lhs(result[tmp_1253]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1254)));
}
break;
case 1 :
{
compvar_t *tmp_1255;
tmp_1255 = tmp_1246;
emit_assign(make_lhs(result[tmp_1253]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1255)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_pow_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1256;
{
float tmp_1257;
float tmp_1258;
tmp_1257 = STK[STKP - 1].v.tuple.data[0];
tmp_1258 = 0;
tmp_1256 = LEQ(tmp_1257, tmp_1258);
}
if (tmp_1256)
{
{
float tmp_1259;
float tmp_1260;
tmp_1259 = STK[STKP - 2].v.tuple.data[0];
tmp_1260 = 0;
tmp_1256 = EQ(tmp_1259, tmp_1260);
}
}
if (tmp_1256)
{
result[0] = 0;
}
else
{
{
float tmp_1261;
float tmp_1262;
tmp_1261 = STK[STKP - 2].v.tuple.data[0];
tmp_1262 = STK[STKP - 1].v.tuple.data[0];
result[0] = pow(tmp_1261, tmp_1262);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_pow_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1263;
tmp_1263 = make_temporary();
{
compvar_t *tmp_1264, *tmp_1265;
tmp_1264 = args[1][0];
tmp_1265 = make_temporary();
emit_assign(make_lhs(tmp_1265), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1263), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1264), make_compvar_primary(tmp_1265)));
}
start_if_cond(make_compvar_rhs(tmp_1263));
{
compvar_t *tmp_1266, *tmp_1267;
tmp_1266 = args[0][0];
tmp_1267 = make_temporary();
emit_assign(make_lhs(tmp_1267), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1263), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1266), make_compvar_primary(tmp_1267)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1263));
{
int tmp_1268;
for (tmp_1268 = 0; tmp_1268 < 1; ++tmp_1268)
{
switch (tmp_1268)
{
case 0 :
emit_assign(make_lhs(result[tmp_1268]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1269;
for (tmp_1269 = 0; tmp_1269 < 1; ++tmp_1269)
{
switch (tmp_1269)
{
case 0 :
{
compvar_t *tmp_1270, *tmp_1271;
tmp_1270 = args[0][0];
tmp_1271 = args[1][0];
emit_assign(make_lhs(result[tmp_1269]), make_op_rhs(OP_POW, make_compvar_primary(tmp_1270), make_compvar_primary(tmp_1271)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_pow_s (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1272;
for (tmp_1272 = 0; tmp_1272 < STK[STKP - 2].v.tuple.length; ++tmp_1272)
{
{
float tmp_1273;
{
float tmp_1274;
float tmp_1275;
tmp_1274 = STK[STKP - 1].v.tuple.data[0];
tmp_1275 = 0;
tmp_1273 = LEQ(tmp_1274, tmp_1275);
}
if (tmp_1273)
{
{
float tmp_1276;
float tmp_1277;
tmp_1276 = STK[STKP - 2].v.tuple.data[tmp_1272];
tmp_1277 = 0;
tmp_1273 = EQ(tmp_1276, tmp_1277);
}
}
if (tmp_1273)
{
result[tmp_1272] = 0;
}
else
{
{
float tmp_1278;
float tmp_1279;
tmp_1278 = STK[STKP - 2].v.tuple.data[tmp_1272];
tmp_1279 = STK[STKP - 1].v.tuple.data[0];
result[tmp_1272] = pow(tmp_1278, tmp_1279);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_pow_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1280;
for (tmp_1280 = 0; tmp_1280 < arglengths[0]; ++tmp_1280)
{
{
compvar_t *tmp_1281;
tmp_1281 = make_temporary();
{
compvar_t *tmp_1282, *tmp_1283;
tmp_1282 = args[1][0];
tmp_1283 = make_temporary();
emit_assign(make_lhs(tmp_1283), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1281), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1282), make_compvar_primary(tmp_1283)));
}
start_if_cond(make_compvar_rhs(tmp_1281));
{
compvar_t *tmp_1284, *tmp_1285;
tmp_1284 = args[0][tmp_1280];
tmp_1285 = make_temporary();
emit_assign(make_lhs(tmp_1285), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1281), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1284), make_compvar_primary(tmp_1285)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1281));
emit_assign(make_lhs(result[tmp_1280]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1286, *tmp_1287;
tmp_1286 = args[0][tmp_1280];
tmp_1287 = args[1][0];
emit_assign(make_lhs(result[tmp_1280]), make_op_rhs(OP_POW, make_compvar_primary(tmp_1286), make_compvar_primary(tmp_1287)));
}
end_if_cond();
}
}
}
}

static void
builtin_exp_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1288;

{
complex float tmp_1289;
{
float tmp_1290;
float tmp_1291;
tmp_1290 = STK[STKP - 1].v.tuple.data[0];
tmp_1291 = STK[STKP - 1].v.tuple.data[1];
tmp_1289 = COMPLEX(tmp_1290, tmp_1291);
}
tmp_1288 = cexpf(tmp_1289);
}

{
complex float tmp_1292;
tmp_1292 = tmp_1288;
result[0] = crealf(tmp_1292);
}
{
complex float tmp_1293;
tmp_1293 = tmp_1288;
result[1] = cimagf(tmp_1293);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_exp_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1294;

tmp_1294 = make_temporary();
{
compvar_t *tmp_1295;
tmp_1295 = make_temporary();
{
compvar_t *tmp_1296, *tmp_1297;
tmp_1296 = args[0][0];
tmp_1297 = args[0][1];
emit_assign(make_lhs(tmp_1295), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1296), make_compvar_primary(tmp_1297)));
}
emit_assign(make_lhs(tmp_1294), make_op_rhs(OP_C_EXP, make_compvar_primary(tmp_1295)));
}

{
int tmp_1298;
for (tmp_1298 = 0; tmp_1298 < 2; ++tmp_1298)
{
switch (tmp_1298)
{
case 0 :
{
compvar_t *tmp_1299;
tmp_1299 = tmp_1294;
emit_assign(make_lhs(result[tmp_1298]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1299)));
}
break;
case 1 :
{
compvar_t *tmp_1300;
tmp_1300 = tmp_1294;
emit_assign(make_lhs(result[tmp_1298]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1300)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_exp_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1301;
tmp_1301 = STK[STKP - 1].v.tuple.data[0];
result[0] = exp(tmp_1301);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_exp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1302;
for (tmp_1302 = 0; tmp_1302 < 1; ++tmp_1302)
{
switch (tmp_1302)
{
case 0 :
{
compvar_t *tmp_1303;
tmp_1303 = args[0][0];
emit_assign(make_lhs(result[tmp_1302]), make_op_rhs(OP_EXP, make_compvar_primary(tmp_1303)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_log_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1304;

{
complex float tmp_1305;
{
float tmp_1306;
float tmp_1307;
tmp_1306 = STK[STKP - 1].v.tuple.data[0];
tmp_1307 = STK[STKP - 1].v.tuple.data[1];
tmp_1305 = COMPLEX(tmp_1306, tmp_1307);
}
tmp_1304 = clogf(tmp_1305);
}

{
complex float tmp_1308;
tmp_1308 = tmp_1304;
result[0] = crealf(tmp_1308);
}
{
complex float tmp_1309;
tmp_1309 = tmp_1304;
result[1] = cimagf(tmp_1309);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_log_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1310;

tmp_1310 = make_temporary();
{
compvar_t *tmp_1311;
tmp_1311 = make_temporary();
{
compvar_t *tmp_1312, *tmp_1313;
tmp_1312 = args[0][0];
tmp_1313 = args[0][1];
emit_assign(make_lhs(tmp_1311), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1312), make_compvar_primary(tmp_1313)));
}
emit_assign(make_lhs(tmp_1310), make_op_rhs(OP_C_LOG, make_compvar_primary(tmp_1311)));
}

{
int tmp_1314;
for (tmp_1314 = 0; tmp_1314 < 2; ++tmp_1314)
{
switch (tmp_1314)
{
case 0 :
{
compvar_t *tmp_1315;
tmp_1315 = tmp_1310;
emit_assign(make_lhs(result[tmp_1314]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1315)));
}
break;
case 1 :
{
compvar_t *tmp_1316;
tmp_1316 = tmp_1310;
emit_assign(make_lhs(result[tmp_1314]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1316)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_log_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1317;
{
float tmp_1318;
float tmp_1319;
tmp_1318 = STK[STKP - 1].v.tuple.data[0];
tmp_1319 = 0;
tmp_1317 = LEQ(tmp_1318, tmp_1319);
}
if (tmp_1317)
{
result[0] = 0;
}
else
{
{
float tmp_1320;
tmp_1320 = STK[STKP - 1].v.tuple.data[0];
result[0] = log(tmp_1320);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_log_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1321;
tmp_1321 = make_temporary();
{
compvar_t *tmp_1322, *tmp_1323;
tmp_1322 = args[0][0];
tmp_1323 = make_temporary();
emit_assign(make_lhs(tmp_1323), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1321), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1322), make_compvar_primary(tmp_1323)));
}
start_if_cond(make_compvar_rhs(tmp_1321));
{
int tmp_1324;
for (tmp_1324 = 0; tmp_1324 < 1; ++tmp_1324)
{
switch (tmp_1324)
{
case 0 :
emit_assign(make_lhs(result[tmp_1324]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1325;
for (tmp_1325 = 0; tmp_1325 < 1; ++tmp_1325)
{
switch (tmp_1325)
{
case 0 :
{
compvar_t *tmp_1326;
tmp_1326 = args[0][0];
emit_assign(make_lhs(result[tmp_1325]), make_op_rhs(OP_LOG, make_compvar_primary(tmp_1326)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_arg_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1327;
{
float tmp_1328;
float tmp_1329;
tmp_1328 = STK[STKP - 1].v.tuple.data[0];
tmp_1329 = STK[STKP - 1].v.tuple.data[1];
tmp_1327 = COMPLEX(tmp_1328, tmp_1329);
}
result[0] = cargf(tmp_1327);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_arg_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1330;
for (tmp_1330 = 0; tmp_1330 < 1; ++tmp_1330)
{
switch (tmp_1330)
{
case 0 :
{
compvar_t *tmp_1331;
tmp_1331 = make_temporary();
{
compvar_t *tmp_1332, *tmp_1333;
tmp_1332 = args[0][0];
tmp_1333 = args[0][1];
emit_assign(make_lhs(tmp_1331), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1332), make_compvar_primary(tmp_1333)));
}
emit_assign(make_lhs(result[tmp_1330]), make_op_rhs(OP_C_ARG, make_compvar_primary(tmp_1331)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_conj_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
result[0] = STK[STKP - 1].v.tuple.data[0];
{
float tmp_1334;
tmp_1334 = STK[STKP - 1].v.tuple.data[1];
result[1] = NEG(tmp_1334);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_conj_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1335;
for (tmp_1335 = 0; tmp_1335 < 2; ++tmp_1335)
{
switch (tmp_1335)
{
case 0 :
emit_assign(make_lhs(result[tmp_1335]), make_compvar_rhs(args[0][0]));
break;
case 1 :
{
compvar_t *tmp_1336;
tmp_1336 = args[0][1];
emit_assign(make_lhs(result[tmp_1335]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_1336)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_sinh_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1337;

{
complex float tmp_1338;
{
float tmp_1339;
float tmp_1340;
tmp_1339 = STK[STKP - 1].v.tuple.data[0];
tmp_1340 = STK[STKP - 1].v.tuple.data[1];
tmp_1338 = COMPLEX(tmp_1339, tmp_1340);
}
tmp_1337 = csinhf(tmp_1338);
}

{
complex float tmp_1341;
tmp_1341 = tmp_1337;
result[0] = crealf(tmp_1341);
}
{
complex float tmp_1342;
tmp_1342 = tmp_1337;
result[1] = cimagf(tmp_1342);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_sinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1343;

tmp_1343 = make_temporary();
{
compvar_t *tmp_1344;
tmp_1344 = make_temporary();
{
compvar_t *tmp_1345, *tmp_1346;
tmp_1345 = args[0][0];
tmp_1346 = args[0][1];
emit_assign(make_lhs(tmp_1344), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1345), make_compvar_primary(tmp_1346)));
}
emit_assign(make_lhs(tmp_1343), make_op_rhs(OP_C_SINH, make_compvar_primary(tmp_1344)));
}

{
int tmp_1347;
for (tmp_1347 = 0; tmp_1347 < 2; ++tmp_1347)
{
switch (tmp_1347)
{
case 0 :
{
compvar_t *tmp_1348;
tmp_1348 = tmp_1343;
emit_assign(make_lhs(result[tmp_1347]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1348)));
}
break;
case 1 :
{
compvar_t *tmp_1349;
tmp_1349 = tmp_1343;
emit_assign(make_lhs(result[tmp_1347]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1349)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_sinh_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1350;
tmp_1350 = STK[STKP - 1].v.tuple.data[0];
result[0] = sinh(tmp_1350);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_sinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1351;
for (tmp_1351 = 0; tmp_1351 < 1; ++tmp_1351)
{
switch (tmp_1351)
{
case 0 :
{
compvar_t *tmp_1352;
tmp_1352 = args[0][0];
emit_assign(make_lhs(result[tmp_1351]), make_op_rhs(OP_SINH, make_compvar_primary(tmp_1352)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_cosh_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1353;

{
complex float tmp_1354;
{
float tmp_1355;
float tmp_1356;
tmp_1355 = STK[STKP - 1].v.tuple.data[0];
tmp_1356 = STK[STKP - 1].v.tuple.data[1];
tmp_1354 = COMPLEX(tmp_1355, tmp_1356);
}
tmp_1353 = ccoshf(tmp_1354);
}

{
complex float tmp_1357;
tmp_1357 = tmp_1353;
result[0] = crealf(tmp_1357);
}
{
complex float tmp_1358;
tmp_1358 = tmp_1353;
result[1] = cimagf(tmp_1358);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_cosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1359;

tmp_1359 = make_temporary();
{
compvar_t *tmp_1360;
tmp_1360 = make_temporary();
{
compvar_t *tmp_1361, *tmp_1362;
tmp_1361 = args[0][0];
tmp_1362 = args[0][1];
emit_assign(make_lhs(tmp_1360), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1361), make_compvar_primary(tmp_1362)));
}
emit_assign(make_lhs(tmp_1359), make_op_rhs(OP_C_COSH, make_compvar_primary(tmp_1360)));
}

{
int tmp_1363;
for (tmp_1363 = 0; tmp_1363 < 2; ++tmp_1363)
{
switch (tmp_1363)
{
case 0 :
{
compvar_t *tmp_1364;
tmp_1364 = tmp_1359;
emit_assign(make_lhs(result[tmp_1363]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1364)));
}
break;
case 1 :
{
compvar_t *tmp_1365;
tmp_1365 = tmp_1359;
emit_assign(make_lhs(result[tmp_1363]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1365)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_cosh_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1366;
tmp_1366 = STK[STKP - 1].v.tuple.data[0];
result[0] = cosh(tmp_1366);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_cosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1367;
for (tmp_1367 = 0; tmp_1367 < 1; ++tmp_1367)
{
switch (tmp_1367)
{
case 0 :
{
compvar_t *tmp_1368;
tmp_1368 = args[0][0];
emit_assign(make_lhs(result[tmp_1367]), make_op_rhs(OP_COSH, make_compvar_primary(tmp_1368)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_tanh_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1369;

{
complex float tmp_1370;
{
float tmp_1371;
float tmp_1372;
tmp_1371 = STK[STKP - 1].v.tuple.data[0];
tmp_1372 = STK[STKP - 1].v.tuple.data[1];
tmp_1370 = COMPLEX(tmp_1371, tmp_1372);
}
tmp_1369 = ctanhf(tmp_1370);
}

{
complex float tmp_1373;
tmp_1373 = tmp_1369;
result[0] = crealf(tmp_1373);
}
{
complex float tmp_1374;
tmp_1374 = tmp_1369;
result[1] = cimagf(tmp_1374);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_tanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1375;

tmp_1375 = make_temporary();
{
compvar_t *tmp_1376;
tmp_1376 = make_temporary();
{
compvar_t *tmp_1377, *tmp_1378;
tmp_1377 = args[0][0];
tmp_1378 = args[0][1];
emit_assign(make_lhs(tmp_1376), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1377), make_compvar_primary(tmp_1378)));
}
emit_assign(make_lhs(tmp_1375), make_op_rhs(OP_C_TANH, make_compvar_primary(tmp_1376)));
}

{
int tmp_1379;
for (tmp_1379 = 0; tmp_1379 < 2; ++tmp_1379)
{
switch (tmp_1379)
{
case 0 :
{
compvar_t *tmp_1380;
tmp_1380 = tmp_1375;
emit_assign(make_lhs(result[tmp_1379]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1380)));
}
break;
case 1 :
{
compvar_t *tmp_1381;
tmp_1381 = tmp_1375;
emit_assign(make_lhs(result[tmp_1379]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1381)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_tanh_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1382;
tmp_1382 = STK[STKP - 1].v.tuple.data[0];
result[0] = tanh(tmp_1382);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_tanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1383;
for (tmp_1383 = 0; tmp_1383 < 1; ++tmp_1383)
{
switch (tmp_1383)
{
case 0 :
{
compvar_t *tmp_1384;
tmp_1384 = args[0][0];
emit_assign(make_lhs(result[tmp_1383]), make_op_rhs(OP_TANH, make_compvar_primary(tmp_1384)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_asinh_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1385;

{
complex float tmp_1386;
{
float tmp_1387;
float tmp_1388;
tmp_1387 = STK[STKP - 1].v.tuple.data[0];
tmp_1388 = STK[STKP - 1].v.tuple.data[1];
tmp_1386 = COMPLEX(tmp_1387, tmp_1388);
}
tmp_1385 = casinhf(tmp_1386);
}

{
complex float tmp_1389;
tmp_1389 = tmp_1385;
result[0] = crealf(tmp_1389);
}
{
complex float tmp_1390;
tmp_1390 = tmp_1385;
result[1] = cimagf(tmp_1390);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_asinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1391;

tmp_1391 = make_temporary();
{
compvar_t *tmp_1392;
tmp_1392 = make_temporary();
{
compvar_t *tmp_1393, *tmp_1394;
tmp_1393 = args[0][0];
tmp_1394 = args[0][1];
emit_assign(make_lhs(tmp_1392), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1393), make_compvar_primary(tmp_1394)));
}
emit_assign(make_lhs(tmp_1391), make_op_rhs(OP_C_ASINH, make_compvar_primary(tmp_1392)));
}

{
int tmp_1395;
for (tmp_1395 = 0; tmp_1395 < 2; ++tmp_1395)
{
switch (tmp_1395)
{
case 0 :
{
compvar_t *tmp_1396;
tmp_1396 = tmp_1391;
emit_assign(make_lhs(result[tmp_1395]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1396)));
}
break;
case 1 :
{
compvar_t *tmp_1397;
tmp_1397 = tmp_1391;
emit_assign(make_lhs(result[tmp_1395]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1397)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_asinh_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1398;
tmp_1398 = STK[STKP - 1].v.tuple.data[0];
result[0] = asinh(tmp_1398);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_asinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1399;
for (tmp_1399 = 0; tmp_1399 < 1; ++tmp_1399)
{
switch (tmp_1399)
{
case 0 :
{
compvar_t *tmp_1400;
tmp_1400 = args[0][0];
emit_assign(make_lhs(result[tmp_1399]), make_op_rhs(OP_ASINH, make_compvar_primary(tmp_1400)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_acosh_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1401;

{
complex float tmp_1402;
{
float tmp_1403;
float tmp_1404;
tmp_1403 = STK[STKP - 1].v.tuple.data[0];
tmp_1404 = STK[STKP - 1].v.tuple.data[1];
tmp_1402 = COMPLEX(tmp_1403, tmp_1404);
}
tmp_1401 = cacoshf(tmp_1402);
}

{
complex float tmp_1405;
tmp_1405 = tmp_1401;
result[0] = crealf(tmp_1405);
}
{
complex float tmp_1406;
tmp_1406 = tmp_1401;
result[1] = cimagf(tmp_1406);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_acosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1407;

tmp_1407 = make_temporary();
{
compvar_t *tmp_1408;
tmp_1408 = make_temporary();
{
compvar_t *tmp_1409, *tmp_1410;
tmp_1409 = args[0][0];
tmp_1410 = args[0][1];
emit_assign(make_lhs(tmp_1408), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1409), make_compvar_primary(tmp_1410)));
}
emit_assign(make_lhs(tmp_1407), make_op_rhs(OP_C_ACOSH, make_compvar_primary(tmp_1408)));
}

{
int tmp_1411;
for (tmp_1411 = 0; tmp_1411 < 2; ++tmp_1411)
{
switch (tmp_1411)
{
case 0 :
{
compvar_t *tmp_1412;
tmp_1412 = tmp_1407;
emit_assign(make_lhs(result[tmp_1411]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1412)));
}
break;
case 1 :
{
compvar_t *tmp_1413;
tmp_1413 = tmp_1407;
emit_assign(make_lhs(result[tmp_1411]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1413)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_acosh_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1414;
tmp_1414 = STK[STKP - 1].v.tuple.data[0];
result[0] = acosh(tmp_1414);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_acosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1415;
for (tmp_1415 = 0; tmp_1415 < 1; ++tmp_1415)
{
switch (tmp_1415)
{
case 0 :
{
compvar_t *tmp_1416;
tmp_1416 = args[0][0];
emit_assign(make_lhs(result[tmp_1415]), make_op_rhs(OP_ACOSH, make_compvar_primary(tmp_1416)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_atanh_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1417;

{
complex float tmp_1418;
{
float tmp_1419;
float tmp_1420;
tmp_1419 = STK[STKP - 1].v.tuple.data[0];
tmp_1420 = STK[STKP - 1].v.tuple.data[1];
tmp_1418 = COMPLEX(tmp_1419, tmp_1420);
}
tmp_1417 = catanhf(tmp_1418);
}

{
complex float tmp_1421;
tmp_1421 = tmp_1417;
result[0] = crealf(tmp_1421);
}
{
complex float tmp_1422;
tmp_1422 = tmp_1417;
result[1] = cimagf(tmp_1422);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_atanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1423;

tmp_1423 = make_temporary();
{
compvar_t *tmp_1424;
tmp_1424 = make_temporary();
{
compvar_t *tmp_1425, *tmp_1426;
tmp_1425 = args[0][0];
tmp_1426 = args[0][1];
emit_assign(make_lhs(tmp_1424), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1425), make_compvar_primary(tmp_1426)));
}
emit_assign(make_lhs(tmp_1423), make_op_rhs(OP_C_ATANH, make_compvar_primary(tmp_1424)));
}

{
int tmp_1427;
for (tmp_1427 = 0; tmp_1427 < 2; ++tmp_1427)
{
switch (tmp_1427)
{
case 0 :
{
compvar_t *tmp_1428;
tmp_1428 = tmp_1423;
emit_assign(make_lhs(result[tmp_1427]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1428)));
}
break;
case 1 :
{
compvar_t *tmp_1429;
tmp_1429 = tmp_1423;
emit_assign(make_lhs(result[tmp_1427]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1429)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_atanh_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1430;
tmp_1430 = STK[STKP - 1].v.tuple.data[0];
result[0] = atanh(tmp_1430);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_atanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1431;
for (tmp_1431 = 0; tmp_1431 < 1; ++tmp_1431)
{
switch (tmp_1431)
{
case 0 :
{
compvar_t *tmp_1432;
tmp_1432 = args[0][0];
emit_assign(make_lhs(result[tmp_1431]), make_op_rhs(OP_ATANH, make_compvar_primary(tmp_1432)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_gamma_ri (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1433;

{
complex float tmp_1434;
{
float tmp_1435;
float tmp_1436;
tmp_1435 = STK[STKP - 1].v.tuple.data[0];
tmp_1436 = STK[STKP - 1].v.tuple.data[1];
tmp_1434 = COMPLEX(tmp_1435, tmp_1436);
}
tmp_1433 = cgamma(tmp_1434);
}

{
complex float tmp_1437;
tmp_1437 = tmp_1433;
result[0] = crealf(tmp_1437);
}
{
complex float tmp_1438;
tmp_1438 = tmp_1433;
result[1] = cimagf(tmp_1438);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_gamma_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1439;

tmp_1439 = make_temporary();
{
compvar_t *tmp_1440;
tmp_1440 = make_temporary();
{
compvar_t *tmp_1441, *tmp_1442;
tmp_1441 = args[0][0];
tmp_1442 = args[0][1];
emit_assign(make_lhs(tmp_1440), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1441), make_compvar_primary(tmp_1442)));
}
emit_assign(make_lhs(tmp_1439), make_op_rhs(OP_C_GAMMA, make_compvar_primary(tmp_1440)));
}

{
int tmp_1443;
for (tmp_1443 = 0; tmp_1443 < 2; ++tmp_1443)
{
switch (tmp_1443)
{
case 0 :
{
compvar_t *tmp_1444;
tmp_1444 = tmp_1439;
emit_assign(make_lhs(result[tmp_1443]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1444)));
}
break;
case 1 :
{
compvar_t *tmp_1445;
tmp_1445 = tmp_1439;
emit_assign(make_lhs(result[tmp_1443]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1445)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_gamma_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1446;
{
float tmp_1447;
float tmp_1448;
tmp_1447 = STK[STKP - 1].v.tuple.data[0];
tmp_1448 = 0;
tmp_1446 = LESS(tmp_1447, tmp_1448);
}
if (tmp_1446)
{
result[0] = 0;
}
else
{
{
float tmp_1449;
tmp_1449 = STK[STKP - 1].v.tuple.data[0];
result[0] = GAMMA(tmp_1449);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_gamma_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1450;
tmp_1450 = make_temporary();
{
compvar_t *tmp_1451, *tmp_1452;
tmp_1451 = args[0][0];
tmp_1452 = make_temporary();
emit_assign(make_lhs(tmp_1452), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1450), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1451), make_compvar_primary(tmp_1452)));
}
start_if_cond(make_compvar_rhs(tmp_1450));
{
int tmp_1453;
for (tmp_1453 = 0; tmp_1453 < 1; ++tmp_1453)
{
switch (tmp_1453)
{
case 0 :
emit_assign(make_lhs(result[tmp_1453]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1454;
for (tmp_1454 = 0; tmp_1454 < 1; ++tmp_1454)
{
switch (tmp_1454)
{
case 0 :
{
compvar_t *tmp_1455;
tmp_1455 = args[0][0];
emit_assign(make_lhs(result[tmp_1454]), make_op_rhs(OP_GAMMA, make_compvar_primary(tmp_1455)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_floor (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1456;
tmp_1456 = STK[STKP - 1].v.tuple.data[0];
result[0] = floor(tmp_1456);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_floor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1457;
for (tmp_1457 = 0; tmp_1457 < 1; ++tmp_1457)
{
switch (tmp_1457)
{
case 0 :
{
compvar_t *tmp_1458;
tmp_1458 = args[0][0];
emit_assign(make_lhs(result[tmp_1457]), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1458)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_sign_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1459;
for (tmp_1459 = 0; tmp_1459 < STK[STKP - 1].v.tuple.length; ++tmp_1459)
{
{
int tmp_1460;
{
float tmp_1461;
float tmp_1462;
tmp_1461 = STK[STKP - 1].v.tuple.data[tmp_1459];
tmp_1462 = 0;
tmp_1460 = LESS(tmp_1461, tmp_1462);
}
if (tmp_1460)
{
result[tmp_1459] = -1;
}
else
{
{
int tmp_1463;
{
float tmp_1464;
float tmp_1465;
tmp_1464 = 0;
tmp_1465 = STK[STKP - 1].v.tuple.data[tmp_1459];
tmp_1463 = LESS(tmp_1464, tmp_1465);
}
if (tmp_1463)
{
result[tmp_1459] = 1;
}
else
{
result[tmp_1459] = 0;
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].v.tuple.length; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = STK[STKP - 1].v.tuple.length;
STKP -= 0;
}

static void
gen_sign_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1466;
for (tmp_1466 = 0; tmp_1466 < arglengths[0]; ++tmp_1466)
{
{
compvar_t *tmp_1467;
tmp_1467 = make_temporary();
{
compvar_t *tmp_1468, *tmp_1469;
tmp_1468 = args[0][tmp_1466];
tmp_1469 = make_temporary();
emit_assign(make_lhs(tmp_1469), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1467), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1468), make_compvar_primary(tmp_1469)));
}
start_if_cond(make_compvar_rhs(tmp_1467));
emit_assign(make_lhs(result[tmp_1466]), make_int_const_rhs(-1));
switch_if_branch();
{
compvar_t *tmp_1470;
tmp_1470 = make_temporary();
{
compvar_t *tmp_1471, *tmp_1472;
tmp_1471 = make_temporary();
emit_assign(make_lhs(tmp_1471), make_int_const_rhs(0));
tmp_1472 = args[0][tmp_1466];
emit_assign(make_lhs(tmp_1470), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1471), make_compvar_primary(tmp_1472)));
}
start_if_cond(make_compvar_rhs(tmp_1470));
emit_assign(make_lhs(result[tmp_1466]), make_int_const_rhs(1));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1466]), make_int_const_rhs(0));
end_if_cond();
}
end_if_cond();
}
}
}
}

static void
builtin_min_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1473;
for (tmp_1473 = 0; tmp_1473 < STK[STKP - 2].v.tuple.length; ++tmp_1473)
{
{
int tmp_1474;
{
float tmp_1475;
float tmp_1476;
tmp_1475 = STK[STKP - 2].v.tuple.data[tmp_1473];
tmp_1476 = STK[STKP - 1].v.tuple.data[tmp_1473];
tmp_1474 = LESS(tmp_1475, tmp_1476);
}
if (tmp_1474)
{
result[tmp_1473] = STK[STKP - 2].v.tuple.data[tmp_1473];
}
else
{
result[tmp_1473] = STK[STKP - 1].v.tuple.data[tmp_1473];
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_min_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1477;
for (tmp_1477 = 0; tmp_1477 < arglengths[0]; ++tmp_1477)
{
{
compvar_t *tmp_1478;
tmp_1478 = make_temporary();
{
compvar_t *tmp_1479, *tmp_1480;
tmp_1479 = args[0][tmp_1477];
tmp_1480 = args[1][tmp_1477];
emit_assign(make_lhs(tmp_1478), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1479), make_compvar_primary(tmp_1480)));
}
start_if_cond(make_compvar_rhs(tmp_1478));
emit_assign(make_lhs(result[tmp_1477]), make_compvar_rhs(args[0][tmp_1477]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1477]), make_compvar_rhs(args[1][tmp_1477]));
end_if_cond();
}
}
}
}

static void
builtin_max_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1481;
for (tmp_1481 = 0; tmp_1481 < STK[STKP - 2].v.tuple.length; ++tmp_1481)
{
{
int tmp_1482;
{
float tmp_1483;
float tmp_1484;
tmp_1483 = STK[STKP - 2].v.tuple.data[tmp_1481];
tmp_1484 = STK[STKP - 1].v.tuple.data[tmp_1481];
tmp_1482 = LESS(tmp_1483, tmp_1484);
}
if (tmp_1482)
{
result[tmp_1481] = STK[STKP - 1].v.tuple.data[tmp_1481];
}
else
{
result[tmp_1481] = STK[STKP - 2].v.tuple.data[tmp_1481];
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 1;
}

static void
gen_max_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1485;
for (tmp_1485 = 0; tmp_1485 < arglengths[0]; ++tmp_1485)
{
{
compvar_t *tmp_1486;
tmp_1486 = make_temporary();
{
compvar_t *tmp_1487, *tmp_1488;
tmp_1487 = args[0][tmp_1485];
tmp_1488 = args[1][tmp_1485];
emit_assign(make_lhs(tmp_1486), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1487), make_compvar_primary(tmp_1488)));
}
start_if_cond(make_compvar_rhs(tmp_1486));
emit_assign(make_lhs(result[tmp_1485]), make_compvar_rhs(args[1][tmp_1485]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1485]), make_compvar_rhs(args[0][tmp_1485]));
end_if_cond();
}
}
}
}

static void
builtin_clamp (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1489;
for (tmp_1489 = 0; tmp_1489 < STK[STKP - 3].v.tuple.length; ++tmp_1489)
{
{
int tmp_1490;
{
float tmp_1491;
float tmp_1492;
tmp_1491 = STK[STKP - 3].v.tuple.data[tmp_1489];
tmp_1492 = STK[STKP - 2].v.tuple.data[tmp_1489];
tmp_1490 = LESS(tmp_1491, tmp_1492);
}
if (tmp_1490)
{
result[tmp_1489] = STK[STKP - 2].v.tuple.data[tmp_1489];
}
else
{
{
int tmp_1493;
{
float tmp_1494;
float tmp_1495;
tmp_1494 = STK[STKP - 1].v.tuple.data[tmp_1489];
tmp_1495 = STK[STKP - 3].v.tuple.data[tmp_1489];
tmp_1493 = LESS(tmp_1494, tmp_1495);
}
if (tmp_1493)
{
result[tmp_1489] = STK[STKP - 1].v.tuple.data[tmp_1489];
}
else
{
result[tmp_1489] = STK[STKP - 3].v.tuple.data[tmp_1489];
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 3].v.tuple.length; ++i)
STK[STKP - 3].v.tuple.data[i] = result[i];
}
STK[STKP - 3].v.tuple.length = STK[STKP - 3].v.tuple.length;
STKP -= 2;
}

static void
gen_clamp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1496;
for (tmp_1496 = 0; tmp_1496 < arglengths[0]; ++tmp_1496)
{
{
compvar_t *tmp_1497;
tmp_1497 = make_temporary();
{
compvar_t *tmp_1498, *tmp_1499;
tmp_1498 = args[0][tmp_1496];
tmp_1499 = args[1][tmp_1496];
emit_assign(make_lhs(tmp_1497), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1498), make_compvar_primary(tmp_1499)));
}
start_if_cond(make_compvar_rhs(tmp_1497));
emit_assign(make_lhs(result[tmp_1496]), make_compvar_rhs(args[1][tmp_1496]));
switch_if_branch();
{
compvar_t *tmp_1500;
tmp_1500 = make_temporary();
{
compvar_t *tmp_1501, *tmp_1502;
tmp_1501 = args[2][tmp_1496];
tmp_1502 = args[0][tmp_1496];
emit_assign(make_lhs(tmp_1500), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1501), make_compvar_primary(tmp_1502)));
}
start_if_cond(make_compvar_rhs(tmp_1500));
emit_assign(make_lhs(result[tmp_1496]), make_compvar_rhs(args[2][tmp_1496]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1496]), make_compvar_rhs(args[0][tmp_1496]));
end_if_cond();
}
end_if_cond();
}
}
}
}

static void
builtin_lerp_1 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1503;

{
float tmp_1504;
float tmp_1505;
tmp_1504 = 1;
tmp_1505 = STK[STKP - 3].v.tuple.data[0];
tmp_1503 = SUB(tmp_1504, tmp_1505);
}

{
int tmp_1506;
for (tmp_1506 = 0; tmp_1506 < STK[STKP - 2].v.tuple.length; ++tmp_1506)
{
{
float tmp_1507;
float tmp_1508;
{
float tmp_1509;
float tmp_1510;
tmp_1509 = tmp_1503;
tmp_1510 = STK[STKP - 2].v.tuple.data[tmp_1506];
tmp_1507 = MUL(tmp_1509, tmp_1510);
}
{
float tmp_1511;
float tmp_1512;
tmp_1511 = STK[STKP - 3].v.tuple.data[0];
tmp_1512 = STK[STKP - 1].v.tuple.data[tmp_1506];
tmp_1508 = MUL(tmp_1511, tmp_1512);
}
result[tmp_1506] = ADD(tmp_1507, tmp_1508);
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].v.tuple.length; ++i)
STK[STKP - 3].v.tuple.data[i] = result[i];
}
STK[STKP - 3].v.tuple.length = STK[STKP - 2].v.tuple.length;
STKP -= 2;
}

static void
gen_lerp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1513;

tmp_1513 = make_temporary();
{
compvar_t *tmp_1514, *tmp_1515;
tmp_1514 = make_temporary();
emit_assign(make_lhs(tmp_1514), make_int_const_rhs(1));
tmp_1515 = args[0][0];
emit_assign(make_lhs(tmp_1513), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1514), make_compvar_primary(tmp_1515)));
}

{
int tmp_1516;
for (tmp_1516 = 0; tmp_1516 < arglengths[1]; ++tmp_1516)
{
{
compvar_t *tmp_1517, *tmp_1518;
tmp_1517 = make_temporary();
{
compvar_t *tmp_1519, *tmp_1520;
tmp_1519 = tmp_1513;
tmp_1520 = args[1][tmp_1516];
emit_assign(make_lhs(tmp_1517), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1519), make_compvar_primary(tmp_1520)));
}
tmp_1518 = make_temporary();
{
compvar_t *tmp_1521, *tmp_1522;
tmp_1521 = args[0][0];
tmp_1522 = args[2][tmp_1516];
emit_assign(make_lhs(tmp_1518), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1521), make_compvar_primary(tmp_1522)));
}
emit_assign(make_lhs(result[tmp_1516]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1517), make_compvar_primary(tmp_1518)));
}
}
}
}
}

static void
builtin_lerp_n (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1523;
for (tmp_1523 = 0; tmp_1523 < STK[STKP - 2].v.tuple.length; ++tmp_1523)
{
{
float tmp_1524;
float tmp_1525;
{
float tmp_1526;
float tmp_1527;
{
float tmp_1528;
float tmp_1529;
tmp_1528 = 1;
tmp_1529 = STK[STKP - 3].v.tuple.data[tmp_1523];
tmp_1526 = SUB(tmp_1528, tmp_1529);
}
tmp_1527 = STK[STKP - 2].v.tuple.data[tmp_1523];
tmp_1524 = MUL(tmp_1526, tmp_1527);
}
{
float tmp_1530;
float tmp_1531;
tmp_1530 = STK[STKP - 3].v.tuple.data[tmp_1523];
tmp_1531 = STK[STKP - 1].v.tuple.data[tmp_1523];
tmp_1525 = MUL(tmp_1530, tmp_1531);
}
result[tmp_1523] = ADD(tmp_1524, tmp_1525);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 3].v.tuple.length; ++i)
STK[STKP - 3].v.tuple.data[i] = result[i];
}
STK[STKP - 3].v.tuple.length = STK[STKP - 3].v.tuple.length;
STKP -= 2;
}

static void
gen_lerp_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1532;
for (tmp_1532 = 0; tmp_1532 < arglengths[1]; ++tmp_1532)
{
{
compvar_t *tmp_1533, *tmp_1534;
tmp_1533 = make_temporary();
{
compvar_t *tmp_1535, *tmp_1536;
tmp_1535 = make_temporary();
{
compvar_t *tmp_1537, *tmp_1538;
tmp_1537 = make_temporary();
emit_assign(make_lhs(tmp_1537), make_int_const_rhs(1));
tmp_1538 = args[0][tmp_1532];
emit_assign(make_lhs(tmp_1535), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1537), make_compvar_primary(tmp_1538)));
}
tmp_1536 = args[1][tmp_1532];
emit_assign(make_lhs(tmp_1533), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1535), make_compvar_primary(tmp_1536)));
}
tmp_1534 = make_temporary();
{
compvar_t *tmp_1539, *tmp_1540;
tmp_1539 = args[0][tmp_1532];
tmp_1540 = args[2][tmp_1532];
emit_assign(make_lhs(tmp_1534), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1539), make_compvar_primary(tmp_1540)));
}
emit_assign(make_lhs(result[tmp_1532]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1533), make_compvar_primary(tmp_1534)));
}
}
}
}

static void
builtin_scale (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1541;
for (tmp_1541 = 0; tmp_1541 < STK[STKP - 5].v.tuple.length; ++tmp_1541)
{
{
float tmp_1542;

{
float tmp_1543;
float tmp_1544;
tmp_1543 = STK[STKP - 3].v.tuple.data[tmp_1541];
tmp_1544 = STK[STKP - 4].v.tuple.data[tmp_1541];
tmp_1542 = SUB(tmp_1543, tmp_1544);
}

{
int tmp_1545;
{
float tmp_1546;
float tmp_1547;
tmp_1546 = tmp_1542;
tmp_1547 = 0;
tmp_1545 = EQ(tmp_1546, tmp_1547);
}
if (tmp_1545)
{
result[tmp_1541] = 0;
}
else
{
{
float tmp_1548;
float tmp_1549;
{
float tmp_1550;
float tmp_1551;
{
float tmp_1552;
float tmp_1553;
{
float tmp_1554;
float tmp_1555;
tmp_1554 = STK[STKP - 5].v.tuple.data[tmp_1541];
tmp_1555 = STK[STKP - 4].v.tuple.data[tmp_1541];
tmp_1552 = SUB(tmp_1554, tmp_1555);
}
tmp_1553 = tmp_1542;
tmp_1550 = DIV(tmp_1552, tmp_1553);
}
{
float tmp_1556;
float tmp_1557;
tmp_1556 = STK[STKP - 1].v.tuple.data[tmp_1541];
tmp_1557 = STK[STKP - 2].v.tuple.data[tmp_1541];
tmp_1551 = SUB(tmp_1556, tmp_1557);
}
tmp_1548 = MUL(tmp_1550, tmp_1551);
}
tmp_1549 = STK[STKP - 2].v.tuple.data[tmp_1541];
result[tmp_1541] = ADD(tmp_1548, tmp_1549);
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 5].v.tuple.length; ++i)
STK[STKP - 5].v.tuple.data[i] = result[i];
}
STK[STKP - 5].v.tuple.length = STK[STKP - 5].v.tuple.length;
STKP -= 4;
}

static void
gen_scale (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1558;
for (tmp_1558 = 0; tmp_1558 < arglengths[0]; ++tmp_1558)
{
{
compvar_t *tmp_1559;

tmp_1559 = make_temporary();
{
compvar_t *tmp_1560, *tmp_1561;
tmp_1560 = args[2][tmp_1558];
tmp_1561 = args[1][tmp_1558];
emit_assign(make_lhs(tmp_1559), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1560), make_compvar_primary(tmp_1561)));
}

{
compvar_t *tmp_1562;
tmp_1562 = make_temporary();
{
compvar_t *tmp_1563, *tmp_1564;
tmp_1563 = tmp_1559;
tmp_1564 = make_temporary();
emit_assign(make_lhs(tmp_1564), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1562), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1563), make_compvar_primary(tmp_1564)));
}
start_if_cond(make_compvar_rhs(tmp_1562));
emit_assign(make_lhs(result[tmp_1558]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1565, *tmp_1566;
tmp_1565 = make_temporary();
{
compvar_t *tmp_1567, *tmp_1568;
tmp_1567 = make_temporary();
{
compvar_t *tmp_1569, *tmp_1570;
tmp_1569 = make_temporary();
{
compvar_t *tmp_1571, *tmp_1572;
tmp_1571 = args[0][tmp_1558];
tmp_1572 = args[1][tmp_1558];
emit_assign(make_lhs(tmp_1569), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1571), make_compvar_primary(tmp_1572)));
}
tmp_1570 = tmp_1559;
emit_assign(make_lhs(tmp_1567), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1569), make_compvar_primary(tmp_1570)));
}
tmp_1568 = make_temporary();
{
compvar_t *tmp_1573, *tmp_1574;
tmp_1573 = args[4][tmp_1558];
tmp_1574 = args[3][tmp_1558];
emit_assign(make_lhs(tmp_1568), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1573), make_compvar_primary(tmp_1574)));
}
emit_assign(make_lhs(tmp_1565), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1567), make_compvar_primary(tmp_1568)));
}
tmp_1566 = args[3][tmp_1558];
emit_assign(make_lhs(result[tmp_1558]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1565), make_compvar_primary(tmp_1566)));
}
end_if_cond();
}
}
}
}
}

static void
builtin_solve_poly_2 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
gsl_vector * tmp_1575;

{
float tmp_1576;
float tmp_1577;
float tmp_1578;
tmp_1576 = STK[STKP - 1].v.tuple.data[0];
tmp_1577 = STK[STKP - 1].v.tuple.data[1];
tmp_1578 = STK[STKP - 1].v.tuple.data[2];
tmp_1575 = SOLVE_POLY_2(tmp_1576, tmp_1577, tmp_1578);
}

{
float tmp_1579;
gsl_vector * tmp_1580;
tmp_1579 = 0;
tmp_1580 = tmp_1575;
result[0] = VECTOR_NTH(tmp_1579, tmp_1580);
}
{
float tmp_1581;
gsl_vector * tmp_1582;
tmp_1581 = 1;
tmp_1582 = tmp_1575;
result[1] = VECTOR_NTH(tmp_1581, tmp_1582);
}
{
int tmp_1583;
{
gsl_vector * tmp_1584;
tmp_1584 = tmp_1575;
tmp_1583 = FREE_VECTOR(tmp_1584);
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_solve_poly_2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1585;

tmp_1585 = make_temporary();
{
compvar_t *tmp_1586, *tmp_1587, *tmp_1588;
tmp_1586 = args[0][0];
tmp_1587 = args[0][1];
tmp_1588 = args[0][2];
emit_assign(make_lhs(tmp_1585), make_op_rhs(OP_SOLVE_POLY_2, make_compvar_primary(tmp_1586), make_compvar_primary(tmp_1587), make_compvar_primary(tmp_1588)));
}

{
int tmp_1589;
for (tmp_1589 = 0; tmp_1589 < 2; ++tmp_1589)
{
switch (tmp_1589)
{
case 0 :
{
compvar_t *tmp_1590, *tmp_1591;
tmp_1590 = make_temporary();
emit_assign(make_lhs(tmp_1590), make_int_const_rhs(0));
tmp_1591 = tmp_1585;
emit_assign(make_lhs(result[tmp_1589]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_1590), make_compvar_primary(tmp_1591)));
}
break;
case 1 :
{
compvar_t *tmp_1592, *tmp_1593;
tmp_1592 = make_temporary();
emit_assign(make_lhs(tmp_1592), make_int_const_rhs(1));
tmp_1593 = tmp_1585;
emit_assign(make_lhs(result[tmp_1589]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_1592), make_compvar_primary(tmp_1593)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_1594;
tmp_1594 = make_temporary();
{
compvar_t *tmp_1595;
tmp_1595 = tmp_1585;
emit_assign(make_lhs(tmp_1594), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_1595)));
}
}
}
}

static void
builtin_solve_poly_3 (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
gsl_vector * tmp_1596;

{
float tmp_1597;
float tmp_1598;
float tmp_1599;
float tmp_1600;
tmp_1597 = STK[STKP - 1].v.tuple.data[0];
tmp_1598 = STK[STKP - 1].v.tuple.data[1];
tmp_1599 = STK[STKP - 1].v.tuple.data[2];
tmp_1600 = STK[STKP - 1].v.tuple.data[3];
tmp_1596 = SOLVE_POLY_3(tmp_1597, tmp_1598, tmp_1599, tmp_1600);
}

{
float tmp_1601;
gsl_vector * tmp_1602;
tmp_1601 = 0;
tmp_1602 = tmp_1596;
result[0] = VECTOR_NTH(tmp_1601, tmp_1602);
}
{
float tmp_1603;
gsl_vector * tmp_1604;
tmp_1603 = 1;
tmp_1604 = tmp_1596;
result[1] = VECTOR_NTH(tmp_1603, tmp_1604);
}
{
float tmp_1605;
gsl_vector * tmp_1606;
tmp_1605 = 2;
tmp_1606 = tmp_1596;
result[2] = VECTOR_NTH(tmp_1605, tmp_1606);
}
{
int tmp_1607;
{
gsl_vector * tmp_1608;
tmp_1608 = tmp_1596;
tmp_1607 = FREE_VECTOR(tmp_1608);
}
}
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 3;
STKP -= 0;
}

static void
gen_solve_poly_3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1609;

tmp_1609 = make_temporary();
{
compvar_t *tmp_1610, *tmp_1611, *tmp_1612, *tmp_1613;
tmp_1610 = args[0][0];
tmp_1611 = args[0][1];
tmp_1612 = args[0][2];
tmp_1613 = args[0][3];
emit_assign(make_lhs(tmp_1609), make_op_rhs(OP_SOLVE_POLY_3, make_compvar_primary(tmp_1610), make_compvar_primary(tmp_1611), make_compvar_primary(tmp_1612), make_compvar_primary(tmp_1613)));
}

{
int tmp_1614;
for (tmp_1614 = 0; tmp_1614 < 3; ++tmp_1614)
{
switch (tmp_1614)
{
case 0 :
{
compvar_t *tmp_1615, *tmp_1616;
tmp_1615 = make_temporary();
emit_assign(make_lhs(tmp_1615), make_int_const_rhs(0));
tmp_1616 = tmp_1609;
emit_assign(make_lhs(result[tmp_1614]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_1615), make_compvar_primary(tmp_1616)));
}
break;
case 1 :
{
compvar_t *tmp_1617, *tmp_1618;
tmp_1617 = make_temporary();
emit_assign(make_lhs(tmp_1617), make_int_const_rhs(1));
tmp_1618 = tmp_1609;
emit_assign(make_lhs(result[tmp_1614]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_1617), make_compvar_primary(tmp_1618)));
}
break;
case 2 :
{
compvar_t *tmp_1619, *tmp_1620;
tmp_1619 = make_temporary();
emit_assign(make_lhs(tmp_1619), make_int_const_rhs(2));
tmp_1620 = tmp_1609;
emit_assign(make_lhs(result[tmp_1614]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_1619), make_compvar_primary(tmp_1620)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_1621;
tmp_1621 = make_temporary();
{
compvar_t *tmp_1622;
tmp_1622 = tmp_1609;
emit_assign(make_lhs(tmp_1621), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_1622)));
}
}
}
}

static void
builtin_not (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1623;
{
float tmp_1624;
float tmp_1625;
tmp_1624 = STK[STKP - 1].v.tuple.data[0];
tmp_1625 = 0;
tmp_1623 = EQ(tmp_1624, tmp_1625);
}
if (tmp_1623)
{
result[0] = 1;
}
else
{
result[0] = 0;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_not (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1626;
tmp_1626 = make_temporary();
{
compvar_t *tmp_1627, *tmp_1628;
tmp_1627 = args[0][0];
tmp_1628 = make_temporary();
emit_assign(make_lhs(tmp_1628), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1626), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1627), make_compvar_primary(tmp_1628)));
}
start_if_cond(make_compvar_rhs(tmp_1626));
{
int tmp_1629;
for (tmp_1629 = 0; tmp_1629 < 1; ++tmp_1629)
{
switch (tmp_1629)
{
case 0 :
emit_assign(make_lhs(result[tmp_1629]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1630;
for (tmp_1630 = 0; tmp_1630 < 1; ++tmp_1630)
{
switch (tmp_1630)
{
case 0 :
emit_assign(make_lhs(result[tmp_1630]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_or (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1631;
{
float tmp_1632;
float tmp_1633;
tmp_1632 = STK[STKP - 2].v.tuple.data[0];
tmp_1633 = 0;
tmp_1631 = EQ(tmp_1632, tmp_1633);
}
if (tmp_1631)
{
{
float tmp_1634;
float tmp_1635;
tmp_1634 = STK[STKP - 1].v.tuple.data[0];
tmp_1635 = 0;
tmp_1631 = EQ(tmp_1634, tmp_1635);
}
}
if (tmp_1631)
{
result[0] = 0;
}
else
{
result[0] = 1;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_or (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1636;
tmp_1636 = make_temporary();
{
compvar_t *tmp_1637, *tmp_1638;
tmp_1637 = args[0][0];
tmp_1638 = make_temporary();
emit_assign(make_lhs(tmp_1638), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1636), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1637), make_compvar_primary(tmp_1638)));
}
start_if_cond(make_compvar_rhs(tmp_1636));
{
compvar_t *tmp_1639, *tmp_1640;
tmp_1639 = args[1][0];
tmp_1640 = make_temporary();
emit_assign(make_lhs(tmp_1640), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1636), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1639), make_compvar_primary(tmp_1640)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1636));
{
int tmp_1641;
for (tmp_1641 = 0; tmp_1641 < 1; ++tmp_1641)
{
switch (tmp_1641)
{
case 0 :
emit_assign(make_lhs(result[tmp_1641]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1642;
for (tmp_1642 = 0; tmp_1642 < 1; ++tmp_1642)
{
switch (tmp_1642)
{
case 0 :
emit_assign(make_lhs(result[tmp_1642]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_and (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1643;
{
float tmp_1644;
float tmp_1645;
tmp_1644 = STK[STKP - 2].v.tuple.data[0];
tmp_1645 = 0;
tmp_1643 = EQ(tmp_1644, tmp_1645);
}
if (!tmp_1643)
{
{
float tmp_1646;
float tmp_1647;
tmp_1646 = STK[STKP - 1].v.tuple.data[0];
tmp_1647 = 0;
tmp_1643 = EQ(tmp_1646, tmp_1647);
}
}
if (tmp_1643)
{
result[0] = 0;
}
else
{
result[0] = 1;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_and (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1648;
tmp_1648 = make_temporary();
{
compvar_t *tmp_1649, *tmp_1650;
tmp_1649 = args[0][0];
tmp_1650 = make_temporary();
emit_assign(make_lhs(tmp_1650), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1648), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1649), make_compvar_primary(tmp_1650)));
}
start_if_cond(make_compvar_rhs(tmp_1648));
switch_if_branch();
{
compvar_t *tmp_1651, *tmp_1652;
tmp_1651 = args[1][0];
tmp_1652 = make_temporary();
emit_assign(make_lhs(tmp_1652), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1648), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1651), make_compvar_primary(tmp_1652)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1648));
{
int tmp_1653;
for (tmp_1653 = 0; tmp_1653 < 1; ++tmp_1653)
{
switch (tmp_1653)
{
case 0 :
emit_assign(make_lhs(result[tmp_1653]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1654;
for (tmp_1654 = 0; tmp_1654 < 1; ++tmp_1654)
{
switch (tmp_1654)
{
case 0 :
emit_assign(make_lhs(result[tmp_1654]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_xor (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1655;
{
float tmp_1656;
float tmp_1657;
tmp_1656 = STK[STKP - 2].v.tuple.data[0];
tmp_1657 = 0;
tmp_1655 = EQ(tmp_1656, tmp_1657);
}
tmp_1655 = !tmp_1655;
if (tmp_1655)
{
{
float tmp_1658;
float tmp_1659;
tmp_1658 = STK[STKP - 1].v.tuple.data[0];
tmp_1659 = 0;
tmp_1655 = EQ(tmp_1658, tmp_1659);
}
}
if (!tmp_1655)
{
{
float tmp_1660;
float tmp_1661;
tmp_1660 = STK[STKP - 1].v.tuple.data[0];
tmp_1661 = 0;
tmp_1655 = EQ(tmp_1660, tmp_1661);
}
tmp_1655 = !tmp_1655;
if (tmp_1655)
{
{
float tmp_1662;
float tmp_1663;
tmp_1662 = STK[STKP - 2].v.tuple.data[0];
tmp_1663 = 0;
tmp_1655 = EQ(tmp_1662, tmp_1663);
}
}
}
if (tmp_1655)
{
result[0] = 1;
}
else
{
result[0] = 0;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_xor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1664;
tmp_1664 = make_temporary();
{
compvar_t *tmp_1665, *tmp_1666;
tmp_1665 = args[0][0];
tmp_1666 = make_temporary();
emit_assign(make_lhs(tmp_1666), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1664), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1665), make_compvar_primary(tmp_1666)));
}
emit_assign(make_lhs(tmp_1664), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1664)));
start_if_cond(make_compvar_rhs(tmp_1664));
{
compvar_t *tmp_1667, *tmp_1668;
tmp_1667 = args[1][0];
tmp_1668 = make_temporary();
emit_assign(make_lhs(tmp_1668), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1664), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1667), make_compvar_primary(tmp_1668)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1664));
switch_if_branch();
{
compvar_t *tmp_1669, *tmp_1670;
tmp_1669 = args[1][0];
tmp_1670 = make_temporary();
emit_assign(make_lhs(tmp_1670), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1664), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1669), make_compvar_primary(tmp_1670)));
}
emit_assign(make_lhs(tmp_1664), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1664)));
start_if_cond(make_compvar_rhs(tmp_1664));
{
compvar_t *tmp_1671, *tmp_1672;
tmp_1671 = args[0][0];
tmp_1672 = make_temporary();
emit_assign(make_lhs(tmp_1672), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1664), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1671), make_compvar_primary(tmp_1672)));
}
switch_if_branch();
end_if_cond();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1664));
{
int tmp_1673;
for (tmp_1673 = 0; tmp_1673 < 1; ++tmp_1673)
{
switch (tmp_1673)
{
case 0 :
emit_assign(make_lhs(result[tmp_1673]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1674;
for (tmp_1674 = 0; tmp_1674 < 1; ++tmp_1674)
{
switch (tmp_1674)
{
case 0 :
emit_assign(make_lhs(result[tmp_1674]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_equal (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1675;
float tmp_1676;
tmp_1675 = STK[STKP - 2].v.tuple.data[0];
tmp_1676 = STK[STKP - 1].v.tuple.data[0];
result[0] = EQ(tmp_1675, tmp_1676);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_equal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1677;
for (tmp_1677 = 0; tmp_1677 < 1; ++tmp_1677)
{
switch (tmp_1677)
{
case 0 :
{
compvar_t *tmp_1678, *tmp_1679;
tmp_1678 = args[0][0];
tmp_1679 = args[1][0];
emit_assign(make_lhs(result[tmp_1677]), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1678), make_compvar_primary(tmp_1679)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_less (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1680;
float tmp_1681;
tmp_1680 = STK[STKP - 2].v.tuple.data[0];
tmp_1681 = STK[STKP - 1].v.tuple.data[0];
result[0] = LESS(tmp_1680, tmp_1681);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_less (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1682;
for (tmp_1682 = 0; tmp_1682 < 1; ++tmp_1682)
{
switch (tmp_1682)
{
case 0 :
{
compvar_t *tmp_1683, *tmp_1684;
tmp_1683 = args[0][0];
tmp_1684 = args[1][0];
emit_assign(make_lhs(result[tmp_1682]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1683), make_compvar_primary(tmp_1684)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_greater (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1685;
float tmp_1686;
tmp_1685 = STK[STKP - 1].v.tuple.data[0];
tmp_1686 = STK[STKP - 2].v.tuple.data[0];
result[0] = LESS(tmp_1685, tmp_1686);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_greater (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1687;
for (tmp_1687 = 0; tmp_1687 < 1; ++tmp_1687)
{
switch (tmp_1687)
{
case 0 :
{
compvar_t *tmp_1688, *tmp_1689;
tmp_1688 = args[1][0];
tmp_1689 = args[0][0];
emit_assign(make_lhs(result[tmp_1687]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1688), make_compvar_primary(tmp_1689)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_lessequal (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1690;
float tmp_1691;
tmp_1690 = STK[STKP - 2].v.tuple.data[0];
tmp_1691 = STK[STKP - 1].v.tuple.data[0];
result[0] = LEQ(tmp_1690, tmp_1691);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_lessequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1692;
for (tmp_1692 = 0; tmp_1692 < 1; ++tmp_1692)
{
switch (tmp_1692)
{
case 0 :
{
compvar_t *tmp_1693, *tmp_1694;
tmp_1693 = args[0][0];
tmp_1694 = args[1][0];
emit_assign(make_lhs(result[tmp_1692]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1693), make_compvar_primary(tmp_1694)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_greaterequal (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1695;
float tmp_1696;
tmp_1695 = STK[STKP - 1].v.tuple.data[0];
tmp_1696 = STK[STKP - 2].v.tuple.data[0];
result[0] = LEQ(tmp_1695, tmp_1696);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_greaterequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1697;
for (tmp_1697 = 0; tmp_1697 < 1; ++tmp_1697)
{
switch (tmp_1697)
{
case 0 :
{
compvar_t *tmp_1698, *tmp_1699;
tmp_1698 = args[1][0];
tmp_1699 = args[0][0];
emit_assign(make_lhs(result[tmp_1697]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1698), make_compvar_primary(tmp_1699)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_notequal (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1700;
{
float tmp_1701;
float tmp_1702;
tmp_1701 = STK[STKP - 2].v.tuple.data[0];
tmp_1702 = STK[STKP - 1].v.tuple.data[0];
tmp_1700 = EQ(tmp_1701, tmp_1702);
}
result[0] = NOT(tmp_1700);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_notequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1703;
for (tmp_1703 = 0; tmp_1703 < 1; ++tmp_1703)
{
switch (tmp_1703)
{
case 0 :
{
compvar_t *tmp_1704;
tmp_1704 = make_temporary();
{
compvar_t *tmp_1705, *tmp_1706;
tmp_1705 = args[0][0];
tmp_1706 = args[1][0];
emit_assign(make_lhs(tmp_1704), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1705), make_compvar_primary(tmp_1706)));
}
emit_assign(make_lhs(result[tmp_1703]), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1704)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_inintv (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1707;
{
float tmp_1708;
float tmp_1709;
tmp_1708 = STK[STKP - 2].v.tuple.data[0];
tmp_1709 = STK[STKP - 3].v.tuple.data[0];
tmp_1707 = LEQ(tmp_1708, tmp_1709);
}
if (tmp_1707)
{
{
float tmp_1710;
float tmp_1711;
tmp_1710 = STK[STKP - 3].v.tuple.data[0];
tmp_1711 = STK[STKP - 1].v.tuple.data[0];
tmp_1707 = LEQ(tmp_1710, tmp_1711);
}
}
if (tmp_1707)
{
result[0] = 1;
}
else
{
result[0] = 0;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 3].v.tuple.data[i] = result[i];
}
STK[STKP - 3].v.tuple.length = 1;
STKP -= 2;
}

static void
gen_inintv (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1712;
tmp_1712 = make_temporary();
{
compvar_t *tmp_1713, *tmp_1714;
tmp_1713 = args[1][0];
tmp_1714 = args[0][0];
emit_assign(make_lhs(tmp_1712), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1713), make_compvar_primary(tmp_1714)));
}
start_if_cond(make_compvar_rhs(tmp_1712));
{
compvar_t *tmp_1715, *tmp_1716;
tmp_1715 = args[0][0];
tmp_1716 = args[2][0];
emit_assign(make_lhs(tmp_1712), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1715), make_compvar_primary(tmp_1716)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1712));
{
int tmp_1717;
for (tmp_1717 = 0; tmp_1717 < 1; ++tmp_1717)
{
switch (tmp_1717)
{
case 0 :
emit_assign(make_lhs(result[tmp_1717]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1718;
for (tmp_1718 = 0; tmp_1718 < 1; ++tmp_1718)
{
switch (tmp_1718)
{
case 0 :
emit_assign(make_lhs(result[tmp_1718]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
builtin_origvalxy (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
color_t tmp_1719;

{
float tmp_1720;
float tmp_1721;
float tmp_1722;
float tmp_1723;
tmp_1720 = STK[STKP - 3].v.tuple.data[0];
tmp_1721 = STK[STKP - 3].v.tuple.data[1];
tmp_1722 = STK[STKP - 2].v.tuple.data[0];
tmp_1723 = STK[STKP - 1].v.tuple.data[0];
tmp_1719 = ORIG_VAL(tmp_1720, tmp_1721, tmp_1722, tmp_1723);
}

{
color_t tmp_1724;
tmp_1724 = tmp_1719;
result[0] = RED_FLOAT(tmp_1724);
}
{
color_t tmp_1725;
tmp_1725 = tmp_1719;
result[1] = GREEN_FLOAT(tmp_1725);
}
{
color_t tmp_1726;
tmp_1726 = tmp_1719;
result[2] = BLUE_FLOAT(tmp_1726);
}
{
color_t tmp_1727;
tmp_1727 = tmp_1719;
result[3] = ALPHA_FLOAT(tmp_1727);
}
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 3].v.tuple.data[i] = result[i];
}
STK[STKP - 3].v.tuple.length = 4;
STKP -= 2;
}

static void
gen_origvalxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1728;

tmp_1728 = make_temporary();
{
compvar_t *tmp_1729, *tmp_1730, *tmp_1731, *tmp_1732;
tmp_1729 = args[0][0];
tmp_1730 = args[0][1];
tmp_1731 = args[1][0];
tmp_1732 = args[2][0];
emit_assign(make_lhs(tmp_1728), make_op_rhs(OP_ORIG_VAL, make_compvar_primary(tmp_1729), make_compvar_primary(tmp_1730), make_compvar_primary(tmp_1731), make_compvar_primary(tmp_1732)));
}

{
int tmp_1733;
for (tmp_1733 = 0; tmp_1733 < 4; ++tmp_1733)
{
switch (tmp_1733)
{
case 0 :
{
compvar_t *tmp_1734;
tmp_1734 = tmp_1728;
emit_assign(make_lhs(result[tmp_1733]), make_op_rhs(OP_RED, make_compvar_primary(tmp_1734)));
}
break;
case 1 :
{
compvar_t *tmp_1735;
tmp_1735 = tmp_1728;
emit_assign(make_lhs(result[tmp_1733]), make_op_rhs(OP_GREEN, make_compvar_primary(tmp_1735)));
}
break;
case 2 :
{
compvar_t *tmp_1736;
tmp_1736 = tmp_1728;
emit_assign(make_lhs(result[tmp_1733]), make_op_rhs(OP_BLUE, make_compvar_primary(tmp_1736)));
}
break;
case 3 :
{
compvar_t *tmp_1737;
tmp_1737 = tmp_1728;
emit_assign(make_lhs(result[tmp_1733]), make_op_rhs(OP_ALPHA, make_compvar_primary(tmp_1737)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
builtin_gray (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1738;
float tmp_1739;
{
float tmp_1740;
float tmp_1741;
{
float tmp_1742;
float tmp_1743;
tmp_1742 = 0.299;
tmp_1743 = STK[STKP - 1].v.tuple.data[0];
tmp_1740 = MUL(tmp_1742, tmp_1743);
}
{
float tmp_1744;
float tmp_1745;
tmp_1744 = 0.587;
tmp_1745 = STK[STKP - 1].v.tuple.data[1];
tmp_1741 = MUL(tmp_1744, tmp_1745);
}
tmp_1738 = ADD(tmp_1740, tmp_1741);
}
{
float tmp_1746;
float tmp_1747;
tmp_1746 = 0.114;
tmp_1747 = STK[STKP - 1].v.tuple.data[2];
tmp_1739 = MUL(tmp_1746, tmp_1747);
}
result[0] = ADD(tmp_1738, tmp_1739);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_gray (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1748;
for (tmp_1748 = 0; tmp_1748 < 1; ++tmp_1748)
{
switch (tmp_1748)
{
case 0 :
{
compvar_t *tmp_1749, *tmp_1750;
tmp_1749 = make_temporary();
{
compvar_t *tmp_1751, *tmp_1752;
tmp_1751 = make_temporary();
{
compvar_t *tmp_1753, *tmp_1754;
tmp_1753 = make_temporary();
emit_assign(make_lhs(tmp_1753), make_float_const_rhs(0.299));
tmp_1754 = args[0][0];
emit_assign(make_lhs(tmp_1751), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1753), make_compvar_primary(tmp_1754)));
}
tmp_1752 = make_temporary();
{
compvar_t *tmp_1755, *tmp_1756;
tmp_1755 = make_temporary();
emit_assign(make_lhs(tmp_1755), make_float_const_rhs(0.587));
tmp_1756 = args[0][1];
emit_assign(make_lhs(tmp_1752), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1755), make_compvar_primary(tmp_1756)));
}
emit_assign(make_lhs(tmp_1749), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1751), make_compvar_primary(tmp_1752)));
}
tmp_1750 = make_temporary();
{
compvar_t *tmp_1757, *tmp_1758;
tmp_1757 = make_temporary();
emit_assign(make_lhs(tmp_1757), make_float_const_rhs(0.114));
tmp_1758 = args[0][2];
emit_assign(make_lhs(tmp_1750), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1757), make_compvar_primary(tmp_1758)));
}
emit_assign(make_lhs(result[tmp_1748]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1749), make_compvar_primary(tmp_1750)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_tohsva (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1759;
float tmp_1764;
float tmp_1769;

{
float tmp_1760;
float tmp_1761;
tmp_1760 = 0;
{
float tmp_1762;
float tmp_1763;
tmp_1762 = 1;
tmp_1763 = STK[STKP - 1].v.tuple.data[0];
tmp_1761 = MIN(tmp_1762, tmp_1763);
}
tmp_1759 = MAX(tmp_1760, tmp_1761);
}

{
float tmp_1765;
float tmp_1766;
tmp_1765 = 0;
{
float tmp_1767;
float tmp_1768;
tmp_1767 = 1;
tmp_1768 = STK[STKP - 1].v.tuple.data[1];
tmp_1766 = MIN(tmp_1767, tmp_1768);
}
tmp_1764 = MAX(tmp_1765, tmp_1766);
}

{
float tmp_1770;
float tmp_1771;
tmp_1770 = 0;
{
float tmp_1772;
float tmp_1773;
tmp_1772 = 1;
tmp_1773 = STK[STKP - 1].v.tuple.data[2];
tmp_1771 = MIN(tmp_1772, tmp_1773);
}
tmp_1769 = MAX(tmp_1770, tmp_1771);
}

{
float tmp_1774;
float tmp_1775;
tmp_1774 = 0;
{
float tmp_1776;
float tmp_1777;
tmp_1776 = 1;
tmp_1777 = STK[STKP - 1].v.tuple.data[3];
tmp_1775 = MIN(tmp_1776, tmp_1777);
}
result[3] = MAX(tmp_1774, tmp_1775);
}
{
float tmp_1778;
float tmp_1783;

{
float tmp_1779;
float tmp_1780;
tmp_1779 = tmp_1759;
{
float tmp_1781;
float tmp_1782;
tmp_1781 = tmp_1764;
tmp_1782 = tmp_1769;
tmp_1780 = MAX(tmp_1781, tmp_1782);
}
tmp_1778 = MAX(tmp_1779, tmp_1780);
}

{
float tmp_1784;
float tmp_1785;
tmp_1784 = tmp_1759;
{
float tmp_1786;
float tmp_1787;
tmp_1786 = tmp_1764;
tmp_1787 = tmp_1769;
tmp_1785 = MIN(tmp_1786, tmp_1787);
}
tmp_1783 = MIN(tmp_1784, tmp_1785);
}

result[2] = tmp_1778;
{
int tmp_1788;
{
float tmp_1789;
float tmp_1790;
tmp_1789 = tmp_1778;
tmp_1790 = 0;
tmp_1788 = EQ(tmp_1789, tmp_1790);
}
if (tmp_1788)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_1791;
float tmp_1794;

{
float tmp_1792;
float tmp_1793;
tmp_1792 = tmp_1778;
tmp_1793 = tmp_1783;
tmp_1791 = SUB(tmp_1792, tmp_1793);
}

tmp_1794 = 0;

{
float tmp_1795;
float tmp_1796;
tmp_1795 = tmp_1791;
tmp_1796 = tmp_1778;
result[1] = DIV(tmp_1795, tmp_1796);
}
{
int tmp_1797;
{
float tmp_1798;
float tmp_1799;
tmp_1798 = tmp_1759;
tmp_1799 = tmp_1778;
tmp_1797 = EQ(tmp_1798, tmp_1799);
}
if (tmp_1797)
{
{
float tmp_1800;
float tmp_1801;
{
float tmp_1802;
float tmp_1803;
tmp_1802 = tmp_1764;
tmp_1803 = tmp_1769;
tmp_1800 = SUB(tmp_1802, tmp_1803);
}
tmp_1801 = tmp_1791;
tmp_1794 = DIV(tmp_1800, tmp_1801);
}
}
else
{
{
int tmp_1804;
{
float tmp_1805;
float tmp_1806;
tmp_1805 = tmp_1764;
tmp_1806 = tmp_1778;
tmp_1804 = EQ(tmp_1805, tmp_1806);
}
if (tmp_1804)
{
{
float tmp_1807;
float tmp_1808;
tmp_1807 = 2;
{
float tmp_1809;
float tmp_1810;
{
float tmp_1811;
float tmp_1812;
tmp_1811 = tmp_1769;
tmp_1812 = tmp_1759;
tmp_1809 = SUB(tmp_1811, tmp_1812);
}
tmp_1810 = tmp_1791;
tmp_1808 = DIV(tmp_1809, tmp_1810);
}
tmp_1794 = ADD(tmp_1807, tmp_1808);
}
}
else
{
{
float tmp_1813;
float tmp_1814;
tmp_1813 = 4;
{
float tmp_1815;
float tmp_1816;
{
float tmp_1817;
float tmp_1818;
tmp_1817 = tmp_1759;
tmp_1818 = tmp_1764;
tmp_1815 = SUB(tmp_1817, tmp_1818);
}
tmp_1816 = tmp_1791;
tmp_1814 = DIV(tmp_1815, tmp_1816);
}
tmp_1794 = ADD(tmp_1813, tmp_1814);
}
}
}
}
}
{
float tmp_1819;
float tmp_1820;
tmp_1819 = tmp_1794;
tmp_1820 = 6.0;
tmp_1794 = DIV(tmp_1819, tmp_1820);
}
{
int tmp_1821;
{
float tmp_1822;
float tmp_1823;
tmp_1822 = tmp_1794;
tmp_1823 = 0;
tmp_1821 = LESS(tmp_1822, tmp_1823);
}
if (tmp_1821)
{
{
float tmp_1824;
float tmp_1825;
tmp_1824 = tmp_1794;
tmp_1825 = 1;
result[0] = ADD(tmp_1824, tmp_1825);
}
}
else
{
result[0] = tmp_1794;
}
}
}
}
}
}
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 4;
STKP -= 0;
}

static void
gen_tohsva (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1826;
compvar_t *tmp_1831;
compvar_t *tmp_1836;

tmp_1826 = make_temporary();
{
compvar_t *tmp_1827, *tmp_1828;
tmp_1827 = make_temporary();
emit_assign(make_lhs(tmp_1827), make_int_const_rhs(0));
tmp_1828 = make_temporary();
{
compvar_t *tmp_1829, *tmp_1830;
tmp_1829 = make_temporary();
emit_assign(make_lhs(tmp_1829), make_int_const_rhs(1));
tmp_1830 = args[0][0];
emit_assign(make_lhs(tmp_1828), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1829), make_compvar_primary(tmp_1830)));
}
emit_assign(make_lhs(tmp_1826), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1827), make_compvar_primary(tmp_1828)));
}

tmp_1831 = make_temporary();
{
compvar_t *tmp_1832, *tmp_1833;
tmp_1832 = make_temporary();
emit_assign(make_lhs(tmp_1832), make_int_const_rhs(0));
tmp_1833 = make_temporary();
{
compvar_t *tmp_1834, *tmp_1835;
tmp_1834 = make_temporary();
emit_assign(make_lhs(tmp_1834), make_int_const_rhs(1));
tmp_1835 = args[0][1];
emit_assign(make_lhs(tmp_1833), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1834), make_compvar_primary(tmp_1835)));
}
emit_assign(make_lhs(tmp_1831), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1832), make_compvar_primary(tmp_1833)));
}

tmp_1836 = make_temporary();
{
compvar_t *tmp_1837, *tmp_1838;
tmp_1837 = make_temporary();
emit_assign(make_lhs(tmp_1837), make_int_const_rhs(0));
tmp_1838 = make_temporary();
{
compvar_t *tmp_1839, *tmp_1840;
tmp_1839 = make_temporary();
emit_assign(make_lhs(tmp_1839), make_int_const_rhs(1));
tmp_1840 = args[0][2];
emit_assign(make_lhs(tmp_1838), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1839), make_compvar_primary(tmp_1840)));
}
emit_assign(make_lhs(tmp_1836), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1837), make_compvar_primary(tmp_1838)));
}

{
compvar_t *tmp_1841, *tmp_1842;
tmp_1841 = make_temporary();
emit_assign(make_lhs(tmp_1841), make_int_const_rhs(0));
tmp_1842 = make_temporary();
{
compvar_t *tmp_1843, *tmp_1844;
tmp_1843 = make_temporary();
emit_assign(make_lhs(tmp_1843), make_int_const_rhs(1));
tmp_1844 = args[0][3];
emit_assign(make_lhs(tmp_1842), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1843), make_compvar_primary(tmp_1844)));
}
emit_assign(make_lhs(result[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1841), make_compvar_primary(tmp_1842)));
}
{
compvar_t *tmp_1845;
compvar_t *tmp_1850;

tmp_1845 = make_temporary();
{
compvar_t *tmp_1846, *tmp_1847;
tmp_1846 = tmp_1826;
tmp_1847 = make_temporary();
{
compvar_t *tmp_1848, *tmp_1849;
tmp_1848 = tmp_1831;
tmp_1849 = tmp_1836;
emit_assign(make_lhs(tmp_1847), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1848), make_compvar_primary(tmp_1849)));
}
emit_assign(make_lhs(tmp_1845), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1846), make_compvar_primary(tmp_1847)));
}

tmp_1850 = make_temporary();
{
compvar_t *tmp_1851, *tmp_1852;
tmp_1851 = tmp_1826;
tmp_1852 = make_temporary();
{
compvar_t *tmp_1853, *tmp_1854;
tmp_1853 = tmp_1831;
tmp_1854 = tmp_1836;
emit_assign(make_lhs(tmp_1852), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1853), make_compvar_primary(tmp_1854)));
}
emit_assign(make_lhs(tmp_1850), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1851), make_compvar_primary(tmp_1852)));
}

emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1845));
{
compvar_t *tmp_1855;
tmp_1855 = make_temporary();
{
compvar_t *tmp_1856, *tmp_1857;
tmp_1856 = tmp_1845;
tmp_1857 = make_temporary();
emit_assign(make_lhs(tmp_1857), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1855), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1856), make_compvar_primary(tmp_1857)));
}
start_if_cond(make_compvar_rhs(tmp_1855));
emit_assign(make_lhs(result[0]), make_int_const_rhs(0));
emit_assign(make_lhs(result[1]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1858;
compvar_t *tmp_1861;

tmp_1858 = make_temporary();
{
compvar_t *tmp_1859, *tmp_1860;
tmp_1859 = tmp_1845;
tmp_1860 = tmp_1850;
emit_assign(make_lhs(tmp_1858), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1859), make_compvar_primary(tmp_1860)));
}

tmp_1861 = make_temporary();
emit_assign(make_lhs(tmp_1861), make_int_const_rhs(0));

{
compvar_t *tmp_1862, *tmp_1863;
tmp_1862 = tmp_1858;
tmp_1863 = tmp_1845;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1862), make_compvar_primary(tmp_1863)));
}
{
compvar_t *tmp_1864;
tmp_1864 = make_temporary();
{
compvar_t *tmp_1865, *tmp_1866;
tmp_1865 = tmp_1826;
tmp_1866 = tmp_1845;
emit_assign(make_lhs(tmp_1864), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1865), make_compvar_primary(tmp_1866)));
}
start_if_cond(make_compvar_rhs(tmp_1864));
{
compvar_t *tmp_1867, *tmp_1868;
tmp_1867 = make_temporary();
{
compvar_t *tmp_1869, *tmp_1870;
tmp_1869 = tmp_1831;
tmp_1870 = tmp_1836;
emit_assign(make_lhs(tmp_1867), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1869), make_compvar_primary(tmp_1870)));
}
tmp_1868 = tmp_1858;
emit_assign(make_lhs(tmp_1861), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1867), make_compvar_primary(tmp_1868)));
}
switch_if_branch();
{
compvar_t *tmp_1871;
tmp_1871 = make_temporary();
{
compvar_t *tmp_1872, *tmp_1873;
tmp_1872 = tmp_1831;
tmp_1873 = tmp_1845;
emit_assign(make_lhs(tmp_1871), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1872), make_compvar_primary(tmp_1873)));
}
start_if_cond(make_compvar_rhs(tmp_1871));
{
compvar_t *tmp_1874, *tmp_1875;
tmp_1874 = make_temporary();
emit_assign(make_lhs(tmp_1874), make_int_const_rhs(2));
tmp_1875 = make_temporary();
{
compvar_t *tmp_1876, *tmp_1877;
tmp_1876 = make_temporary();
{
compvar_t *tmp_1878, *tmp_1879;
tmp_1878 = tmp_1836;
tmp_1879 = tmp_1826;
emit_assign(make_lhs(tmp_1876), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1878), make_compvar_primary(tmp_1879)));
}
tmp_1877 = tmp_1858;
emit_assign(make_lhs(tmp_1875), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1876), make_compvar_primary(tmp_1877)));
}
emit_assign(make_lhs(tmp_1861), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1874), make_compvar_primary(tmp_1875)));
}
switch_if_branch();
{
compvar_t *tmp_1880, *tmp_1881;
tmp_1880 = make_temporary();
emit_assign(make_lhs(tmp_1880), make_int_const_rhs(4));
tmp_1881 = make_temporary();
{
compvar_t *tmp_1882, *tmp_1883;
tmp_1882 = make_temporary();
{
compvar_t *tmp_1884, *tmp_1885;
tmp_1884 = tmp_1826;
tmp_1885 = tmp_1831;
emit_assign(make_lhs(tmp_1882), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1884), make_compvar_primary(tmp_1885)));
}
tmp_1883 = tmp_1858;
emit_assign(make_lhs(tmp_1881), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1882), make_compvar_primary(tmp_1883)));
}
emit_assign(make_lhs(tmp_1861), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1880), make_compvar_primary(tmp_1881)));
}
end_if_cond();
}
end_if_cond();
}
{
compvar_t *tmp_1886, *tmp_1887;
tmp_1886 = tmp_1861;
tmp_1887 = make_temporary();
emit_assign(make_lhs(tmp_1887), make_float_const_rhs(6.0));
emit_assign(make_lhs(tmp_1861), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1886), make_compvar_primary(tmp_1887)));
}
{
compvar_t *tmp_1888;
tmp_1888 = make_temporary();
{
compvar_t *tmp_1889, *tmp_1890;
tmp_1889 = tmp_1861;
tmp_1890 = make_temporary();
emit_assign(make_lhs(tmp_1890), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1888), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1889), make_compvar_primary(tmp_1890)));
}
start_if_cond(make_compvar_rhs(tmp_1888));
{
compvar_t *tmp_1891, *tmp_1892;
tmp_1891 = tmp_1861;
tmp_1892 = make_temporary();
emit_assign(make_lhs(tmp_1892), make_int_const_rhs(1));
emit_assign(make_lhs(result[0]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1891), make_compvar_primary(tmp_1892)));
}
switch_if_branch();
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1861));
end_if_cond();
}
}
end_if_cond();
}
}
}
}

static void
builtin_torgba (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1893;
float tmp_1898;

{
float tmp_1894;
float tmp_1895;
tmp_1894 = 0;
{
float tmp_1896;
float tmp_1897;
tmp_1896 = 1;
tmp_1897 = STK[STKP - 1].v.tuple.data[1];
tmp_1895 = MIN(tmp_1896, tmp_1897);
}
tmp_1893 = MAX(tmp_1894, tmp_1895);
}

{
float tmp_1899;
float tmp_1900;
tmp_1899 = 0;
{
float tmp_1901;
float tmp_1902;
tmp_1901 = 1;
tmp_1902 = STK[STKP - 1].v.tuple.data[2];
tmp_1900 = MIN(tmp_1901, tmp_1902);
}
tmp_1898 = MAX(tmp_1899, tmp_1900);
}

{
float tmp_1903;
float tmp_1904;
tmp_1903 = 0;
{
float tmp_1905;
float tmp_1906;
tmp_1905 = 1;
tmp_1906 = STK[STKP - 1].v.tuple.data[3];
tmp_1904 = MIN(tmp_1905, tmp_1906);
}
result[3] = MAX(tmp_1903, tmp_1904);
}
{
int tmp_1907;
{
float tmp_1908;
float tmp_1909;
tmp_1908 = tmp_1893;
tmp_1909 = 0;
tmp_1907 = EQ(tmp_1908, tmp_1909);
}
if (tmp_1907)
{
result[0] = tmp_1898;
result[1] = tmp_1898;
result[2] = tmp_1898;
}
else
{
{
float tmp_1910;

{
float tmp_1911;
float tmp_1912;
tmp_1911 = 0;
tmp_1912 = STK[STKP - 1].v.tuple.data[0];
tmp_1910 = MAX(tmp_1911, tmp_1912);
}

{
int tmp_1913;
{
float tmp_1914;
float tmp_1915;
tmp_1914 = 1;
tmp_1915 = tmp_1910;
tmp_1913 = LEQ(tmp_1914, tmp_1915);
}
if (tmp_1913)
{
tmp_1910 = 0;
}
else
{
{
float tmp_1916;
float tmp_1917;
tmp_1916 = tmp_1910;
tmp_1917 = 6;
tmp_1910 = MUL(tmp_1916, tmp_1917);
}
}
}
{
int tmp_1918;

{
float tmp_1919;
tmp_1919 = tmp_1910;
tmp_1918 = floor(tmp_1919);
}

{
float tmp_1920;

{
float tmp_1921;
int tmp_1922;
tmp_1921 = tmp_1910;
tmp_1922 = tmp_1918;
tmp_1920 = SUB(tmp_1921, tmp_1922);
}

{
float tmp_1923;
float tmp_1928;
float tmp_1935;

{
float tmp_1924;
float tmp_1925;
tmp_1924 = tmp_1898;
{
float tmp_1926;
float tmp_1927;
tmp_1926 = 1;
tmp_1927 = tmp_1893;
tmp_1925 = SUB(tmp_1926, tmp_1927);
}
tmp_1923 = MUL(tmp_1924, tmp_1925);
}

{
float tmp_1929;
float tmp_1930;
tmp_1929 = tmp_1898;
{
float tmp_1931;
float tmp_1932;
tmp_1931 = 1;
{
float tmp_1933;
float tmp_1934;
tmp_1933 = tmp_1893;
tmp_1934 = tmp_1920;
tmp_1932 = MUL(tmp_1933, tmp_1934);
}
tmp_1930 = SUB(tmp_1931, tmp_1932);
}
tmp_1928 = MUL(tmp_1929, tmp_1930);
}

{
float tmp_1936;
float tmp_1937;
tmp_1936 = tmp_1898;
{
float tmp_1938;
float tmp_1939;
tmp_1938 = 1;
{
float tmp_1940;
float tmp_1941;
tmp_1940 = tmp_1893;
{
float tmp_1942;
float tmp_1943;
tmp_1942 = 1;
tmp_1943 = tmp_1920;
tmp_1941 = SUB(tmp_1942, tmp_1943);
}
tmp_1939 = MUL(tmp_1940, tmp_1941);
}
tmp_1937 = SUB(tmp_1938, tmp_1939);
}
tmp_1935 = MUL(tmp_1936, tmp_1937);
}

{
int tmp_1944;
{
int tmp_1945;
float tmp_1946;
tmp_1945 = tmp_1918;
tmp_1946 = 0;
tmp_1944 = EQ(tmp_1945, tmp_1946);
}
if (tmp_1944)
{
result[0] = tmp_1898;
result[1] = tmp_1935;
result[2] = tmp_1923;
}
else
{
{
int tmp_1947;
{
int tmp_1948;
float tmp_1949;
tmp_1948 = tmp_1918;
tmp_1949 = 1;
tmp_1947 = EQ(tmp_1948, tmp_1949);
}
if (tmp_1947)
{
result[0] = tmp_1928;
result[1] = tmp_1898;
result[2] = tmp_1923;
}
else
{
{
int tmp_1950;
{
int tmp_1951;
float tmp_1952;
tmp_1951 = tmp_1918;
tmp_1952 = 2;
tmp_1950 = EQ(tmp_1951, tmp_1952);
}
if (tmp_1950)
{
result[0] = tmp_1923;
result[1] = tmp_1898;
result[2] = tmp_1935;
}
else
{
{
int tmp_1953;
{
int tmp_1954;
float tmp_1955;
tmp_1954 = tmp_1918;
tmp_1955 = 3;
tmp_1953 = EQ(tmp_1954, tmp_1955);
}
if (tmp_1953)
{
result[0] = tmp_1923;
result[1] = tmp_1928;
result[2] = tmp_1898;
}
else
{
{
int tmp_1956;
{
int tmp_1957;
float tmp_1958;
tmp_1957 = tmp_1918;
tmp_1958 = 4;
tmp_1956 = EQ(tmp_1957, tmp_1958);
}
if (tmp_1956)
{
result[0] = tmp_1935;
result[1] = tmp_1923;
result[2] = tmp_1898;
}
else
{
result[0] = tmp_1898;
result[1] = tmp_1923;
result[2] = tmp_1928;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 4;
STKP -= 0;
}

static void
gen_torgba (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1959;
compvar_t *tmp_1964;

tmp_1959 = make_temporary();
{
compvar_t *tmp_1960, *tmp_1961;
tmp_1960 = make_temporary();
emit_assign(make_lhs(tmp_1960), make_int_const_rhs(0));
tmp_1961 = make_temporary();
{
compvar_t *tmp_1962, *tmp_1963;
tmp_1962 = make_temporary();
emit_assign(make_lhs(tmp_1962), make_int_const_rhs(1));
tmp_1963 = args[0][1];
emit_assign(make_lhs(tmp_1961), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1962), make_compvar_primary(tmp_1963)));
}
emit_assign(make_lhs(tmp_1959), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1960), make_compvar_primary(tmp_1961)));
}

tmp_1964 = make_temporary();
{
compvar_t *tmp_1965, *tmp_1966;
tmp_1965 = make_temporary();
emit_assign(make_lhs(tmp_1965), make_int_const_rhs(0));
tmp_1966 = make_temporary();
{
compvar_t *tmp_1967, *tmp_1968;
tmp_1967 = make_temporary();
emit_assign(make_lhs(tmp_1967), make_int_const_rhs(1));
tmp_1968 = args[0][2];
emit_assign(make_lhs(tmp_1966), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1967), make_compvar_primary(tmp_1968)));
}
emit_assign(make_lhs(tmp_1964), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1965), make_compvar_primary(tmp_1966)));
}

{
compvar_t *tmp_1969, *tmp_1970;
tmp_1969 = make_temporary();
emit_assign(make_lhs(tmp_1969), make_int_const_rhs(0));
tmp_1970 = make_temporary();
{
compvar_t *tmp_1971, *tmp_1972;
tmp_1971 = make_temporary();
emit_assign(make_lhs(tmp_1971), make_int_const_rhs(1));
tmp_1972 = args[0][3];
emit_assign(make_lhs(tmp_1970), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1971), make_compvar_primary(tmp_1972)));
}
emit_assign(make_lhs(result[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1969), make_compvar_primary(tmp_1970)));
}
{
compvar_t *tmp_1973;
tmp_1973 = make_temporary();
{
compvar_t *tmp_1974, *tmp_1975;
tmp_1974 = tmp_1959;
tmp_1975 = make_temporary();
emit_assign(make_lhs(tmp_1975), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1973), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1974), make_compvar_primary(tmp_1975)));
}
start_if_cond(make_compvar_rhs(tmp_1973));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1964));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1964));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1964));
switch_if_branch();
{
compvar_t *tmp_1976;

tmp_1976 = make_temporary();
{
compvar_t *tmp_1977, *tmp_1978;
tmp_1977 = make_temporary();
emit_assign(make_lhs(tmp_1977), make_int_const_rhs(0));
tmp_1978 = args[0][0];
emit_assign(make_lhs(tmp_1976), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1977), make_compvar_primary(tmp_1978)));
}

{
compvar_t *tmp_1979;
tmp_1979 = make_temporary();
{
compvar_t *tmp_1980, *tmp_1981;
tmp_1980 = make_temporary();
emit_assign(make_lhs(tmp_1980), make_int_const_rhs(1));
tmp_1981 = tmp_1976;
emit_assign(make_lhs(tmp_1979), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1980), make_compvar_primary(tmp_1981)));
}
start_if_cond(make_compvar_rhs(tmp_1979));
emit_assign(make_lhs(tmp_1976), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1982, *tmp_1983;
tmp_1982 = tmp_1976;
tmp_1983 = make_temporary();
emit_assign(make_lhs(tmp_1983), make_int_const_rhs(6));
emit_assign(make_lhs(tmp_1976), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1982), make_compvar_primary(tmp_1983)));
}
end_if_cond();
}
{
compvar_t *tmp_1984;

tmp_1984 = make_temporary();
{
compvar_t *tmp_1985;
tmp_1985 = tmp_1976;
emit_assign(make_lhs(tmp_1984), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1985)));
}

{
compvar_t *tmp_1986;

tmp_1986 = make_temporary();
{
compvar_t *tmp_1987, *tmp_1988;
tmp_1987 = tmp_1976;
tmp_1988 = tmp_1984;
emit_assign(make_lhs(tmp_1986), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1987), make_compvar_primary(tmp_1988)));
}

{
compvar_t *tmp_1989;
compvar_t *tmp_1994;
compvar_t *tmp_2001;

tmp_1989 = make_temporary();
{
compvar_t *tmp_1990, *tmp_1991;
tmp_1990 = tmp_1964;
tmp_1991 = make_temporary();
{
compvar_t *tmp_1992, *tmp_1993;
tmp_1992 = make_temporary();
emit_assign(make_lhs(tmp_1992), make_int_const_rhs(1));
tmp_1993 = tmp_1959;
emit_assign(make_lhs(tmp_1991), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1992), make_compvar_primary(tmp_1993)));
}
emit_assign(make_lhs(tmp_1989), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1990), make_compvar_primary(tmp_1991)));
}

tmp_1994 = make_temporary();
{
compvar_t *tmp_1995, *tmp_1996;
tmp_1995 = tmp_1964;
tmp_1996 = make_temporary();
{
compvar_t *tmp_1997, *tmp_1998;
tmp_1997 = make_temporary();
emit_assign(make_lhs(tmp_1997), make_int_const_rhs(1));
tmp_1998 = make_temporary();
{
compvar_t *tmp_1999, *tmp_2000;
tmp_1999 = tmp_1959;
tmp_2000 = tmp_1986;
emit_assign(make_lhs(tmp_1998), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1999), make_compvar_primary(tmp_2000)));
}
emit_assign(make_lhs(tmp_1996), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1997), make_compvar_primary(tmp_1998)));
}
emit_assign(make_lhs(tmp_1994), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1995), make_compvar_primary(tmp_1996)));
}

tmp_2001 = make_temporary();
{
compvar_t *tmp_2002, *tmp_2003;
tmp_2002 = tmp_1964;
tmp_2003 = make_temporary();
{
compvar_t *tmp_2004, *tmp_2005;
tmp_2004 = make_temporary();
emit_assign(make_lhs(tmp_2004), make_int_const_rhs(1));
tmp_2005 = make_temporary();
{
compvar_t *tmp_2006, *tmp_2007;
tmp_2006 = tmp_1959;
tmp_2007 = make_temporary();
{
compvar_t *tmp_2008, *tmp_2009;
tmp_2008 = make_temporary();
emit_assign(make_lhs(tmp_2008), make_int_const_rhs(1));
tmp_2009 = tmp_1986;
emit_assign(make_lhs(tmp_2007), make_op_rhs(OP_SUB, make_compvar_primary(tmp_2008), make_compvar_primary(tmp_2009)));
}
emit_assign(make_lhs(tmp_2005), make_op_rhs(OP_MUL, make_compvar_primary(tmp_2006), make_compvar_primary(tmp_2007)));
}
emit_assign(make_lhs(tmp_2003), make_op_rhs(OP_SUB, make_compvar_primary(tmp_2004), make_compvar_primary(tmp_2005)));
}
emit_assign(make_lhs(tmp_2001), make_op_rhs(OP_MUL, make_compvar_primary(tmp_2002), make_compvar_primary(tmp_2003)));
}

{
compvar_t *tmp_2010;
tmp_2010 = make_temporary();
{
compvar_t *tmp_2011, *tmp_2012;
tmp_2011 = tmp_1984;
tmp_2012 = make_temporary();
emit_assign(make_lhs(tmp_2012), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_2010), make_op_rhs(OP_EQ, make_compvar_primary(tmp_2011), make_compvar_primary(tmp_2012)));
}
start_if_cond(make_compvar_rhs(tmp_2010));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1964));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_2001));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1989));
switch_if_branch();
{
compvar_t *tmp_2013;
tmp_2013 = make_temporary();
{
compvar_t *tmp_2014, *tmp_2015;
tmp_2014 = tmp_1984;
tmp_2015 = make_temporary();
emit_assign(make_lhs(tmp_2015), make_int_const_rhs(1));
emit_assign(make_lhs(tmp_2013), make_op_rhs(OP_EQ, make_compvar_primary(tmp_2014), make_compvar_primary(tmp_2015)));
}
start_if_cond(make_compvar_rhs(tmp_2013));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1994));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1964));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1989));
switch_if_branch();
{
compvar_t *tmp_2016;
tmp_2016 = make_temporary();
{
compvar_t *tmp_2017, *tmp_2018;
tmp_2017 = tmp_1984;
tmp_2018 = make_temporary();
emit_assign(make_lhs(tmp_2018), make_int_const_rhs(2));
emit_assign(make_lhs(tmp_2016), make_op_rhs(OP_EQ, make_compvar_primary(tmp_2017), make_compvar_primary(tmp_2018)));
}
start_if_cond(make_compvar_rhs(tmp_2016));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1989));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1964));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_2001));
switch_if_branch();
{
compvar_t *tmp_2019;
tmp_2019 = make_temporary();
{
compvar_t *tmp_2020, *tmp_2021;
tmp_2020 = tmp_1984;
tmp_2021 = make_temporary();
emit_assign(make_lhs(tmp_2021), make_int_const_rhs(3));
emit_assign(make_lhs(tmp_2019), make_op_rhs(OP_EQ, make_compvar_primary(tmp_2020), make_compvar_primary(tmp_2021)));
}
start_if_cond(make_compvar_rhs(tmp_2019));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1989));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1994));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1964));
switch_if_branch();
{
compvar_t *tmp_2022;
tmp_2022 = make_temporary();
{
compvar_t *tmp_2023, *tmp_2024;
tmp_2023 = tmp_1984;
tmp_2024 = make_temporary();
emit_assign(make_lhs(tmp_2024), make_int_const_rhs(4));
emit_assign(make_lhs(tmp_2022), make_op_rhs(OP_EQ, make_compvar_primary(tmp_2023), make_compvar_primary(tmp_2024)));
}
start_if_cond(make_compvar_rhs(tmp_2022));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_2001));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1989));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1964));
switch_if_branch();
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1964));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1989));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1994));
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
}
}
}
}
end_if_cond();
}
}
}

static void
builtin_toxy (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_2025;
float tmp_2026;
{
float tmp_2027;
tmp_2027 = STK[STKP - 1].v.tuple.data[1];
tmp_2025 = cos(tmp_2027);
}
tmp_2026 = STK[STKP - 1].v.tuple.data[0];
result[0] = MUL(tmp_2025, tmp_2026);
}
{
float tmp_2028;
float tmp_2029;
{
float tmp_2030;
tmp_2030 = STK[STKP - 1].v.tuple.data[1];
tmp_2028 = sin(tmp_2030);
}
tmp_2029 = STK[STKP - 1].v.tuple.data[0];
result[1] = MUL(tmp_2028, tmp_2029);
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_toxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_2031;
for (tmp_2031 = 0; tmp_2031 < 2; ++tmp_2031)
{
switch (tmp_2031)
{
case 0 :
{
compvar_t *tmp_2032, *tmp_2033;
tmp_2032 = make_temporary();
{
compvar_t *tmp_2034;
tmp_2034 = args[0][1];
emit_assign(make_lhs(tmp_2032), make_op_rhs(OP_COS, make_compvar_primary(tmp_2034)));
}
tmp_2033 = args[0][0];
emit_assign(make_lhs(result[tmp_2031]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_2032), make_compvar_primary(tmp_2033)));
}
break;
case 1 :
{
compvar_t *tmp_2035, *tmp_2036;
tmp_2035 = make_temporary();
{
compvar_t *tmp_2037;
tmp_2037 = args[0][1];
emit_assign(make_lhs(tmp_2035), make_op_rhs(OP_SIN, make_compvar_primary(tmp_2037)));
}
tmp_2036 = args[0][0];
emit_assign(make_lhs(result[tmp_2031]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_2035), make_compvar_primary(tmp_2036)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_tora (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_2038;

{
float tmp_2039;
float tmp_2040;
tmp_2039 = STK[STKP - 1].v.tuple.data[0];
tmp_2040 = STK[STKP - 1].v.tuple.data[1];
tmp_2038 = hypot(tmp_2039, tmp_2040);
}

{
int tmp_2041;
{
float tmp_2042;
float tmp_2043;
tmp_2042 = tmp_2038;
tmp_2043 = 0;
tmp_2041 = EQ(tmp_2042, tmp_2043);
}
if (tmp_2041)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_2044;

{
float tmp_2045;
{
float tmp_2046;
float tmp_2047;
tmp_2046 = STK[STKP - 1].v.tuple.data[0];
tmp_2047 = tmp_2038;
tmp_2045 = DIV(tmp_2046, tmp_2047);
}
tmp_2044 = acos(tmp_2045);
}

result[0] = tmp_2038;
{
int tmp_2048;
{
float tmp_2049;
float tmp_2050;
tmp_2049 = STK[STKP - 1].v.tuple.data[1];
tmp_2050 = 0;
tmp_2048 = LESS(tmp_2049, tmp_2050);
}
if (tmp_2048)
{
{
float tmp_2051;
float tmp_2052;
{
float tmp_2053;
float tmp_2054;
tmp_2053 = 2;
tmp_2054 = M_PI;
tmp_2051 = MUL(tmp_2053, tmp_2054);
}
tmp_2052 = tmp_2044;
result[1] = SUB(tmp_2051, tmp_2052);
}
}
else
{
result[1] = tmp_2044;
}
}
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 2;
STKP -= 0;
}

static void
gen_tora (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_2055;

tmp_2055 = make_temporary();
{
compvar_t *tmp_2056, *tmp_2057;
tmp_2056 = args[0][0];
tmp_2057 = args[0][1];
emit_assign(make_lhs(tmp_2055), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_2056), make_compvar_primary(tmp_2057)));
}

{
compvar_t *tmp_2058;
tmp_2058 = make_temporary();
{
compvar_t *tmp_2059, *tmp_2060;
tmp_2059 = tmp_2055;
tmp_2060 = make_temporary();
emit_assign(make_lhs(tmp_2060), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_2058), make_op_rhs(OP_EQ, make_compvar_primary(tmp_2059), make_compvar_primary(tmp_2060)));
}
start_if_cond(make_compvar_rhs(tmp_2058));
{
int tmp_2061;
for (tmp_2061 = 0; tmp_2061 < 2; ++tmp_2061)
{
switch (tmp_2061)
{
case 0 :
emit_assign(make_lhs(result[tmp_2061]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_2061]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_2062;

tmp_2062 = make_temporary();
{
compvar_t *tmp_2063;
tmp_2063 = make_temporary();
{
compvar_t *tmp_2064, *tmp_2065;
tmp_2064 = args[0][0];
tmp_2065 = tmp_2055;
emit_assign(make_lhs(tmp_2063), make_op_rhs(OP_DIV, make_compvar_primary(tmp_2064), make_compvar_primary(tmp_2065)));
}
emit_assign(make_lhs(tmp_2062), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_2063)));
}

emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_2055));
{
compvar_t *tmp_2066;
tmp_2066 = make_temporary();
{
compvar_t *tmp_2067, *tmp_2068;
tmp_2067 = args[0][1];
tmp_2068 = make_temporary();
emit_assign(make_lhs(tmp_2068), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_2066), make_op_rhs(OP_LESS, make_compvar_primary(tmp_2067), make_compvar_primary(tmp_2068)));
}
start_if_cond(make_compvar_rhs(tmp_2066));
{
compvar_t *tmp_2069, *tmp_2070;
tmp_2069 = make_temporary();
{
compvar_t *tmp_2071, *tmp_2072;
tmp_2071 = make_temporary();
emit_assign(make_lhs(tmp_2071), make_int_const_rhs(2));
tmp_2072 = make_temporary();
emit_assign(make_lhs(tmp_2072), make_float_const_rhs(M_PI));
emit_assign(make_lhs(tmp_2069), make_op_rhs(OP_MUL, make_compvar_primary(tmp_2071), make_compvar_primary(tmp_2072)));
}
tmp_2070 = tmp_2062;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_2069), make_compvar_primary(tmp_2070)));
}
switch_if_branch();
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_2062));
end_if_cond();
}
}
end_if_cond();
}
}
}

static void
builtin_rand (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_2073;
float tmp_2074;
tmp_2073 = STK[STKP - 2].v.tuple.data[0];
tmp_2074 = STK[STKP - 1].v.tuple.data[0];
result[0] = RAND(tmp_2073, tmp_2074);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].v.tuple.data[i] = result[i];
}
STK[STKP - 2].v.tuple.length = 1;
STKP -= 1;
}

static void
gen_rand (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_2075;
for (tmp_2075 = 0; tmp_2075 < 1; ++tmp_2075)
{
switch (tmp_2075)
{
case 0 :
{
compvar_t *tmp_2076, *tmp_2077;
tmp_2076 = args[0][0];
tmp_2077 = args[1][0];
emit_assign(make_lhs(result[tmp_2075]), make_op_rhs(OP_RAND, make_compvar_primary(tmp_2076), make_compvar_primary(tmp_2077)));
}
break;
default :
assert(0);
}
}
}
}

static void
builtin_noise (mathmap_invocation_t *invocation, postfix_arg_t *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_2078;
float tmp_2079;
float tmp_2080;
tmp_2078 = STK[STKP - 1].v.tuple.data[0];
tmp_2079 = STK[STKP - 1].v.tuple.data[1];
tmp_2080 = STK[STKP - 1].v.tuple.data[2];
result[0] = noise(tmp_2078, tmp_2079, tmp_2080);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].v.tuple.data[i] = result[i];
}
STK[STKP - 1].v.tuple.length = 1;
STKP -= 0;
}

static void
gen_noise (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_2081;
for (tmp_2081 = 0; tmp_2081 < 1; ++tmp_2081)
{
switch (tmp_2081)
{
case 0 :
{
compvar_t *tmp_2082, *tmp_2083, *tmp_2084;
tmp_2082 = args[0][0];
tmp_2083 = args[0][1];
tmp_2084 = args[0][2];
emit_assign(make_lhs(result[tmp_2081]), make_op_rhs(OP_NOISE, make_compvar_primary(tmp_2082), make_compvar_primary(tmp_2083), make_compvar_primary(tmp_2084)));
}
break;
default :
assert(0);
}
}
}
}


void
init_builtins (void)
{
register_overloaded_builtin("merd", "((T L) (T L))", builtin_merd, gen_merd);
register_overloaded_builtin("print", "((nil 1) (_ _))", builtin_print, gen_print);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (ri 2))", builtin_add_ri, gen_add_ri);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (_ 1))", builtin_add_ri_1, gen_add_ri_1);
register_overloaded_builtin("__add", "((ri 2) (_ 1) (ri 2))", builtin_add_1_ri, gen_add_1_ri);
register_overloaded_builtin("__add", "((T 1) (T 1) (T 1))", builtin_add_1, gen_add_1);
register_overloaded_builtin("__add", "((T L) (T L) (_ 1))", builtin_add_s, gen_add_s);
register_overloaded_builtin("__add", "((T L) (T L) (T L))", builtin_add_n, gen_add_n);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (ri 2))", builtin_sub_ri, gen_sub_ri);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (_ 1))", builtin_sub_ri_1, gen_sub_ri_1);
register_overloaded_builtin("__sub", "((ri 2) (_ 1) (ri 2))", builtin_sub_1_ri, gen_sub_1_ri);
register_overloaded_builtin("__sub", "((T 1) (T 1) (T 1))", builtin_sub_1, gen_sub_1);
register_overloaded_builtin("__sub", "((T L) (T L) (_ 1))", builtin_sub_s, gen_sub_s);
register_overloaded_builtin("__sub", "((T L) (T L) (T L))", builtin_sub_n, gen_sub_n);
register_overloaded_builtin("__neg", "((T L) (T L))", builtin_neg, gen_neg);
register_overloaded_builtin("__mul", "((ri 2) (ri 2) (ri 2))", builtin_mul_ri, gen_mul_ri);
register_overloaded_builtin("__mul", "((ri 2) (_ 1) (ri 2))", builtin_mul_1_ri, gen_mul_1_ri);
register_overloaded_builtin("__mul", "((m2x2 4) (m2x2 4) (m2x2 4))", builtin_mul_m2x2, gen_mul_m2x2);
register_overloaded_builtin("__mul", "((m3x3 9) (m3x3 9) (m3x3 9))", builtin_mul_m3x3, gen_mul_m3x3);
register_overloaded_builtin("__mul", "((v2 2) (v2 2) (m2x2 4))", builtin_mul_v2m2x2, gen_mul_v2m2x2);
register_overloaded_builtin("__mul", "((v3 3) (v3 3) (m3x3 9))", builtin_mul_v3m3x3, gen_mul_v3m3x3);
register_overloaded_builtin("__mul", "((v2 2) (m2x2 4) (v2 2))", builtin_mul_m2x2v2, gen_mul_m2x2v2);
register_overloaded_builtin("__mul", "((v3 3) (m3x3 9) (v3 3))", builtin_mul_m3x3v3, gen_mul_m3x3v3);
register_overloaded_builtin("__mul", "((T 1) (T 1) (T 1))", builtin_mul_1, gen_mul_1);
register_overloaded_builtin("__mul", "((T L) (T L) (_ 1))", builtin_mul_s, gen_mul_s);
register_overloaded_builtin("__mul", "((T L) (T L) (T L))", builtin_mul_n, gen_mul_n);
register_overloaded_builtin("__div", "((ri 2) (ri 2) (ri 2))", builtin_div_ri, gen_div_ri);
register_overloaded_builtin("__div", "((ri 2) (T 1) (ri 2))", builtin_div_1_ri, gen_div_1_ri);
register_overloaded_builtin("__div", "((v2 2) (_ 2) (m2x2 4))", builtin_div_v2m2x2, gen_div_v2m2x2);
register_overloaded_builtin("__div", "((v3 3) (_ 3) (m3x3 9))", builtin_div_v3m3x3, gen_div_v3m3x3);
register_overloaded_builtin("__div", "((T 1) (T 1) (T 1))", builtin_div_1, gen_div_1);
register_overloaded_builtin("__div", "((T L) (T L) (_ 1))", builtin_div_s, gen_div_s);
register_overloaded_builtin("__div", "((T L) (T L) (T L))", builtin_div_n, gen_div_n);
register_overloaded_builtin("__mod", "((T 1) (T 1) (T 1))", builtin_mod_1, gen_mod_1);
register_overloaded_builtin("__mod", "((T L) (T L) (_ 1))", builtin_mod_s, gen_mod_s);
register_overloaded_builtin("__mod", "((T L) (T L) (T L))", builtin_mod_n, gen_mod_n);
register_overloaded_builtin("pmod", "((T 1) (T 1) (T 1))", builtin_pmod, gen_pmod);
register_overloaded_builtin("sqrt", "((ri 2) (ri 2))", builtin_sqrt_ri, gen_sqrt_ri);
register_overloaded_builtin("sqrt", "((T 1) (T 1))", builtin_sqrt_1, gen_sqrt_1);
register_overloaded_builtin("sum", "((T 1) (T L))", builtin_sum, gen_sum);
register_overloaded_builtin("dotp", "((nil 1) (T L) (T L))", builtin_dotp, gen_dotp);
register_overloaded_builtin("crossp", "((T 3) (T 3) (T 3))", builtin_crossp, gen_crossp);
register_overloaded_builtin("det", "((nil 1) (m2x2 4))", builtin_det_m2x2, gen_det_m2x2);
register_overloaded_builtin("det", "((nil 1) (m3x3 9))", builtin_det_m3x3, gen_det_m3x3);
register_overloaded_builtin("normalize", "((T L) (T L))", builtin_normalize, gen_normalize);
register_overloaded_builtin("abs", "((nil 1) (ri 2))", builtin_abs_ri, gen_abs_ri);
register_overloaded_builtin("abs", "((T 1) (T 1))", builtin_abs_1, gen_abs_1);
register_overloaded_builtin("abs", "((T L) (T L))", builtin_abs_n, gen_abs_n);
register_overloaded_builtin("deg2rad", "((nil 1) (_ 1))", builtin_deg2rad, gen_deg2rad);
register_overloaded_builtin("rad2deg", "((deg 1) (_ 1))", builtin_rad2deg, gen_rad2deg);
register_overloaded_builtin("sin", "((ri 2) (ri 2))", builtin_sin_ri, gen_sin_ri);
register_overloaded_builtin("sin", "((T 1) (T 1))", builtin_sin, gen_sin);
register_overloaded_builtin("cos", "((ri 2) (ri 2))", builtin_cos_ri, gen_cos_ri);
register_overloaded_builtin("cos", "((T 1) (T 1))", builtin_cos, gen_cos);
register_overloaded_builtin("tan", "((ri 2) (ri 2))", builtin_tan_ri, gen_tan_ri);
register_overloaded_builtin("tan", "((T 1) (T 1))", builtin_tan, gen_tan);
register_overloaded_builtin("asin", "((ri 2) (ri 2))", builtin_asin_ri, gen_asin_ri);
register_overloaded_builtin("asin", "((T 1) (T 1))", builtin_asin, gen_asin);
register_overloaded_builtin("acos", "((ri 2) (ri 2))", builtin_acos_ri, gen_acos_ri);
register_overloaded_builtin("acos", "((T 1) (T 1))", builtin_acos, gen_acos);
register_overloaded_builtin("atan", "((ri 2) (ri 2))", builtin_atan_ri, gen_atan_ri);
register_overloaded_builtin("atan", "((T 1) (T 1))", builtin_atan, gen_atan);
register_overloaded_builtin("atan", "((T 1) (T 1) (T 1))", builtin_atan2, gen_atan2);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (T 1))", builtin_pow_ri_1, gen_pow_ri_1);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (ri 2))", builtin_pow_ri, gen_pow_ri);
register_overloaded_builtin("__pow", "((ri 2) (T 1) (ri 2))", builtin_pow_1_ri, gen_pow_1_ri);
register_overloaded_builtin("__pow", "((T 1) (T 1) (T 1))", builtin_pow_1, gen_pow_1);
register_overloaded_builtin("__pow", "((T L) (T L) (_ 1))", builtin_pow_s, gen_pow_s);
register_overloaded_builtin("exp", "((ri 2) (ri 2))", builtin_exp_ri, gen_exp_ri);
register_overloaded_builtin("exp", "((T 1) (T 1))", builtin_exp_1, gen_exp_1);
register_overloaded_builtin("log", "((ri 2) (ri 2))", builtin_log_ri, gen_log_ri);
register_overloaded_builtin("log", "((T 1) (T 1))", builtin_log_1, gen_log_1);
register_overloaded_builtin("arg", "((nil 1) (ri 2))", builtin_arg_ri, gen_arg_ri);
register_overloaded_builtin("conj", "((ri 2) (ri 2))", builtin_conj_ri, gen_conj_ri);
register_overloaded_builtin("sinh", "((ri 2) (ri 2))", builtin_sinh_ri, gen_sinh_ri);
register_overloaded_builtin("sinh", "((T 1) (T 1))", builtin_sinh_1, gen_sinh_1);
register_overloaded_builtin("cosh", "((ri 2) (ri 2))", builtin_cosh_ri, gen_cosh_ri);
register_overloaded_builtin("cosh", "((T 1) (T 1))", builtin_cosh_1, gen_cosh_1);
register_overloaded_builtin("tanh", "((ri 2) (ri 2))", builtin_tanh_ri, gen_tanh_ri);
register_overloaded_builtin("tanh", "((T 1) (T 1))", builtin_tanh_1, gen_tanh_1);
register_overloaded_builtin("asinh", "((ri 2) (ri 2))", builtin_asinh_ri, gen_asinh_ri);
register_overloaded_builtin("asinh", "((T 1) (T 1))", builtin_asinh_1, gen_asinh_1);
register_overloaded_builtin("acosh", "((ri 2) (ri 2))", builtin_acosh_ri, gen_acosh_ri);
register_overloaded_builtin("acosh", "((T 1) (T 1))", builtin_acosh_1, gen_acosh_1);
register_overloaded_builtin("atanh", "((ri 2) (ri 2))", builtin_atanh_ri, gen_atanh_ri);
register_overloaded_builtin("atanh", "((T 1) (T 1))", builtin_atanh_1, gen_atanh_1);
register_overloaded_builtin("gamma", "((ri 2) (ri 2))", builtin_gamma_ri, gen_gamma_ri);
register_overloaded_builtin("gamma", "((T 1) (T 1))", builtin_gamma_1, gen_gamma_1);
register_overloaded_builtin("floor", "((T 1) (T 1))", builtin_floor, gen_floor);
register_overloaded_builtin("sign", "((T L) (T L))", builtin_sign_n, gen_sign_n);
register_overloaded_builtin("min", "((T L) (T L) (T L))", builtin_min_n, gen_min_n);
register_overloaded_builtin("max", "((T L) (T L) (T L))", builtin_max_n, gen_max_n);
register_overloaded_builtin("clamp", "((T L) (T L) (T L) (T L))", builtin_clamp, gen_clamp);
register_overloaded_builtin("lerp", "((T L) (_ 1) (T L) (T L))", builtin_lerp_1, gen_lerp_1);
register_overloaded_builtin("lerp", "((T L) (T L) (T L) (T L))", builtin_lerp_n, gen_lerp_n);
register_overloaded_builtin("scale", "((T L) (T L) (T L) (T L) (T L) (T L))", builtin_scale, gen_scale);
register_overloaded_builtin("solve", "((nil 2) (poly 3))", builtin_solve_poly_2, gen_solve_poly_2);
register_overloaded_builtin("solve", "((nil 3) (poly 4))", builtin_solve_poly_3, gen_solve_poly_3);
register_overloaded_builtin("__not", "((T 1) (T 1))", builtin_not, gen_not);
register_overloaded_builtin("__or", "((T 1) (T 1) (T 1))", builtin_or, gen_or);
register_overloaded_builtin("__and", "((T 1) (T 1) (T 1))", builtin_and, gen_and);
register_overloaded_builtin("__xor", "((T 1) (T 1) (T 1))", builtin_xor, gen_xor);
register_overloaded_builtin("__equal", "((T 1) (T 1) (T 1))", builtin_equal, gen_equal);
register_overloaded_builtin("__less", "((T 1) (T 1) (T 1))", builtin_less, gen_less);
register_overloaded_builtin("__greater", "((T 1) (T 1) (T 1))", builtin_greater, gen_greater);
register_overloaded_builtin("__lessequal", "((T 1) (T 1) (T 1))", builtin_lessequal, gen_lessequal);
register_overloaded_builtin("__greaterequal", "((T 1) (T 1) (T 1))", builtin_greaterequal, gen_greaterequal);
register_overloaded_builtin("__notequal", "((T 1) (T 1) (T 1))", builtin_notequal, gen_notequal);
register_overloaded_builtin("inintv", "((T 1) (T 1) (T 1) (T 1))", builtin_inintv, gen_inintv);
register_overloaded_builtin("origVal", "((rgba 4) (xy 2) (image 1) (nil 1))", builtin_origvalxy, gen_origvalxy);
register_overloaded_builtin("gray", "((nil 1) (rgba 4))", builtin_gray, gen_gray);
register_overloaded_builtin("toHSVA", "((hsva 4) (rgba 4))", builtin_tohsva, gen_tohsva);
register_overloaded_builtin("toRGBA", "((rgba 4) (hsva 4))", builtin_torgba, gen_torgba);
register_overloaded_builtin("toXY", "((xy 2) (ra 2))", builtin_toxy, gen_toxy);
register_overloaded_builtin("toRA", "((ra 2) (xy 2))", builtin_tora, gen_tora);
register_overloaded_builtin("rand", "((T 1) (T 1) (T 1))", builtin_rand, gen_rand);
register_overloaded_builtin("noise", "((nil 1) (_ 3))", builtin_noise, gen_noise);
}
