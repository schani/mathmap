/* -*- c -*- */

#ifndef __MATHMAP_H__
#define __MATHMAP_H__

extern char error_string[];

#endif
