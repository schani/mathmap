#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <libgimp/gimp.h>

#include "builtins.h"
#include "postfix.h"
#include "tags.h"
#include "overload.h"

extern gint preview_width, preview_height;
extern guchar *fast_image_source;
extern int imageWidth,
    imageHeight,
    outputBPP,
    previewing;
extern gint sel_x1, sel_y1,
    sel_width, sel_height;
extern double middleX,
    middleY;
extern unsigned char *imageData;
extern int intersamplingEnabled,
    oversamplingEnabled;
extern double user_curve_values[];
extern int user_curve_points;
extern tuple_t gradient_samples[];
extern int num_gradient_samples;

builtin *firstBuiltin = 0;

unsigned int
alpha_component (double val)
{
    unsigned int color = *(unsigned int*)&val;

    return color >> 24;
}

unsigned int
red_component (double val)
{
    unsigned int color = *(unsigned int*)&val;

    return (color >> 16) & 0xff;
}

unsigned int
green_component (double val)
{
    unsigned int color = *(unsigned int*)&val;

    return (color >> 8) & 0xff;
}

unsigned int
blue_component (double val)
{
    unsigned int color = *(unsigned int*)&val;

    return color & 0xff;
}

void
builtin_add_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	stack[stackp - 2].data[i] = stack[stackp - 2].data[i] + stack[stackp - 1].data[i];

    --stackp;
}

void
builtin_add_1 (postfix_arg *arg)
{
    stack[stackp - 2].data[0] = stack[stackp - 2].data[0] + stack[stackp - 1].data[0];
    --stackp;
}

void
builtin_add_s (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	stack[stackp - 2].data[i] = stack[stackp - 2].data[i] + stack[stackp - 1].data[0];

    --stackp;
}

void
builtin_add_ri (postfix_arg *arg)
{
    stack[stackp - 2].data[0] = stack[stackp - 2].data[0] + stack[stackp - 1].data[0];
    stack[stackp - 2].data[1] = stack[stackp - 2].data[1] + stack[stackp - 1].data[1];
    --stackp;
}

void
builtin_sub_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	stack[stackp - 2].data[i] = stack[stackp - 2].data[i] - stack[stackp - 1].data[i];

    --stackp;
}

void
builtin_sub_1 (postfix_arg *arg)
{
    stack[stackp - 2].data[0] = stack[stackp - 2].data[0] - stack[stackp - 1].data[0];
    --stackp;
}

void
builtin_sub_s (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	stack[stackp - 2].data[i] = stack[stackp - 2].data[i] - stack[stackp - 1].data[0];

    --stackp;
}

void
builtin_sub_ri (postfix_arg *arg)
{
    stack[stackp - 2].data[0] = stack[stackp - 2].data[0] - stack[stackp - 1].data[0];
    stack[stackp - 2].data[1] = stack[stackp - 2].data[1] - stack[stackp - 1].data[1];
    --stackp;
}

void
builtin_mul_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	stack[stackp - 2].data[i] = stack[stackp - 2].data[i] * stack[stackp - 1].data[i];

    --stackp;
}

void
builtin_mul_1 (postfix_arg *arg)
{
    stack[stackp - 2].data[0] = stack[stackp - 2].data[0] * stack[stackp - 1].data[0];
    --stackp;
}

void
builtin_mul_s (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	stack[stackp - 2].data[i] = stack[stackp - 2].data[i] * stack[stackp - 1].data[0];

    --stackp;
}

void
builtin_mul_ri (postfix_arg *arg)
{
    float r1 = stack[stackp - 2].data[0],
	r2 = stack[stackp - 1].data[0],
	c1 = stack[stackp - 2].data[1],
	c2 = stack[stackp - 1].data[1];

    stack[stackp - 2].data[0] = r1 * r2 - c1 * c2;
    stack[stackp - 2].data[1] = r1 * c2 + r2 * c1;
    --stackp;
}

void
builtin_div_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
    {
	if (stack[stackp - 1].data[i] == 0)
	{
	    /* fprintf(stderr, "division by zero at pc = %d\n", exprp); */
	    stack[stackp - 2].data[i] = 0.0;
	}
	else
	    stack[stackp - 2].data[i] = stack[stackp - 2].data[i] / stack[stackp - 1].data[i];
    }

    --stackp;
}

void
builtin_div_1 (postfix_arg *arg)
{
    if (stack[stackp - 1].data[0] == 0)
    {
	/* fprintf(stderr, "division by zero at pc = %d\n", exprp); */
	stack[stackp - 2].data[0] = 0.0;
    }
    else
	stack[stackp - 2].data[0] = stack[stackp - 2].data[0] / stack[stackp - 1].data[0];

    --stackp;
}

void
builtin_div_s (postfix_arg *arg)
{
    int i;

    if (stack[stackp - 1].data[0] == 0)
	for (i = 0; i < stack[stackp - 2].length; ++i)
	    stack[stackp - 2].data[i] = 0.0;
    else
	for (i = 0; i < stack[stackp - 2].length; ++i)
	    stack[stackp - 2].data[i] = stack[stackp - 2].data[i] / stack[stackp - 1].data[0];

    --stackp;
}

void
builtin_div_ri (postfix_arg *arg)
{
    float r1 = stack[stackp - 2].data[0],
	r2 = stack[stackp - 1].data[0],
	c1 = stack[stackp - 2].data[1],
	c2 = stack[stackp - 1].data[1];

    if (r2 == 0.0 && c2 == 0.0)
    {
	stack[stackp - 2].data[0] = 0.0;
	stack[stackp - 2].data[1] = 0.0;
    }
    else
    {
	stack[stackp - 2].data[0] = (r1 * r2 + c1 * c2) / (r2 * r2 + c2 * c2);
	stack[stackp - 2].data[1] = (-r1 * c2 + r2 * c1) / (r2 * r2 + c2 * c2);
    }

    --stackp;
}

void
builtin_mod_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
    {
	if (stack[stackp - 1].data[i] == 0)
	{
	    /* fprintf(stderr, "division by zero at pc = %d\n", exprp); */
	    stack[stackp - 2].data[i] = 0.0;
	}
	else
	    stack[stackp - 2].data[i] = fmod(stack[stackp - 2].data[i], stack[stackp - 1].data[i]);
    }

    --stackp;
}

void
builtin_mod_1 (postfix_arg *arg)
{
    if (stack[stackp - 1].data[0] == 0)
    {
	/* fprintf(stderr, "division by zero at pc = %d\n", exprp); */
	stack[stackp - 2].data[0] = 0.0;
    }
    else
	stack[stackp - 2].data[0] = fmod(stack[stackp - 2].data[0], stack[stackp - 1].data[0]);

    --stackp;
}

void
builtin_mod_s (postfix_arg *arg)
{
    int i;

    if (stack[stackp - 1].data[0] == 0)
	for (i = 0; i < stack[stackp - 2].length; ++i)
	    stack[stackp - 2].data[i] = 0.0;
    else
	for (i = 0; i < stack[stackp - 2].length; ++i)
	    stack[stackp - 2].data[i] = fmod(stack[stackp - 2].data[i], stack[stackp - 1].data[0]);

    --stackp;
}

void
builtin_neg (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 1].length; ++i)
	stack[stackp - 1].data[i] = -stack[stackp - 1].data[i];
}

void
builtin_sin (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = sin(stack[stackp - 1].data[0] * M_PI / 180.0);
}

void
builtin_cos (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = cos(stack[stackp - 1].data[0] * M_PI / 180.0);
}

void
builtin_tan (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = tan(stack[stackp - 1].data[0] * M_PI / 180.0);
}

void
builtin_asin (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = asin(stack[stackp - 1].data[0]) * 180.0 / M_PI;
}

void
builtin_acos (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = acos(stack[stackp - 1].data[0]) * 180.0 / M_PI;
}

void
builtin_atan (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = atan(stack[stackp - 1].data[0]) * 180.0 / M_PI;
}

void
builtin_pow_1 (postfix_arg *arg)
{
    stack[stackp - 2].data[0] = pow(stack[stackp - 2].data[0], stack[stackp - 1].data[0]);
    --stackp;
}

void
builtin_pow_s (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	stack[stackp - 2].data[i] = pow(stack[stackp - 2].data[i], stack[stackp - 1].data[0]);
    --stackp;
}

void
builtin_abs_1 (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = fabs(stack[stackp - 1].data[0]);
}

void
builtin_abs_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 1].length; ++i)
	stack[stackp - 1].data[i] = fabs(stack[stackp - 1].data[i]);
}

void
builtin_abs_ri (postfix_arg *arg)
{
    float r = stack[stackp - 1].data[0],
	i = stack[stackp - 1].data[1];

    stack[stackp - 1].data[0] = sqrt(r * r + i * i);
    stack[stackp - 1].number = nil_tag_number;
    stack[stackp - 1].length = 1;
}

void
builtin_floor (postfix_arg *arg)
{
    stack[stackp - 1].data[0] = floor(stack[stackp - 1].data[0]);
}

void
builtin_sign_1 (postfix_arg *arg)
{
    if (stack[stackp - 1].data[0] < 0)
	stack[stackp - 1].data[0] = -1.0;
    else if (stack[stackp - 1].data[0] > 0)
	stack[stackp - 1].data[0] = 1.0;
    else
	stack[stackp - 1].data[0] = 0.0;
}

void
builtin_sign_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 1].length; ++i)
	if (stack[stackp - 1].data[i] < 0)
	    stack[stackp - 1].data[i] = -1.0;
	else if (stack[stackp - 1].data[i] > 0)
	    stack[stackp - 1].data[i] = 1.0;
	else
	    stack[stackp - 1].data[i] = 0.0;
}

void
builtin_min_1 (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] >= stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = stack[stackp - 1].data[0];
    --stackp;
}

void
builtin_min_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	if (stack[stackp - 2].data[i] >= stack[stackp - 1].data[i])
	    stack[stackp - 2].data[i] = stack[stackp - 1].data[i];
    --stackp;
}

void
builtin_max_1 (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] <= stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = stack[stackp - 1].data[0];
    --stackp;
}

void
builtin_max_n (postfix_arg *arg)
{
    int i;

    for (i = 0; i < stack[stackp - 2].length; ++i)
	if (stack[stackp - 2].data[i] <= stack[stackp - 1].data[i])
	    stack[stackp - 2].data[i] = stack[stackp - 1].data[i];
    --stackp;
}

void
builtin_not (postfix_arg *arg)
{
    if (stack[stackp - 1].data[0] != 0.0)
	stack[stackp - 1].data[0] = 0.0;
    else
	stack[stackp - 1].data[0] = 1.0;
}

void
builtin_or (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] || stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_and (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] && stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_equal (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] == stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_less (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] < stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_greater (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] > stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_lessequal (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] <= stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_greaterequal (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] >= stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_notequal (postfix_arg *arg)
{
    if (stack[stackp - 2].data[0] != stack[stackp - 1].data[0])
	stack[stackp - 2].data[0] = 1.0;
    else
	stack[stackp - 2].data[0] = 0.0;
    --stackp;
}

void
builtin_inintv (postfix_arg *arg)
{
    if (stack[stackp - 3].data[0] >= stack[stackp - 2].data[0]
	&& stack[stackp - 3].data[0] <= stack[stackp - 1].data[0])
	stack[stackp - 3].data[0] = 1.0;
    else
	stack[stackp - 3].data[0] = 0.0;
    stackp -= 2;
}

void
builtin_rand (postfix_arg *arg)
{
    stack[stackp - 2].data[0] = (random() / (double)0x7fffffff)
	* (stack[stackp - 1].data[0] - stack[stackp - 2].data[0]) + stack[stackp - 2].data[0];
    --stackp;
}

void mathmap_get_pixel (int x, int y, unsigned char *pixel);

static void
get_pixel (int x, int y, guchar *pixel)
{
    if (previewing)
    {
	x = (x - sel_x1) * preview_width / sel_width;
	y = (y - sel_y1) * preview_height / sel_height;

	if (x < 0 || x > preview_width || y < 0 || y >= preview_height)
	{
	    static unsigned char blackPixel[4] = { 0, 0, 0, 0 };

	    memcpy(pixel, blackPixel, outputBPP);
	}
	else
	    memcpy(pixel, fast_image_source + (x + y * preview_width) * outputBPP, outputBPP);
    }
    else
	mathmap_get_pixel(x, y, pixel);
}

extern int originX,
    originY,
    wholeImageWidth,
    wholeImageHeight;

void
builtin_origVal (postfix_arg *arg)
{
    double x,
	y;
    unsigned char pixel[4];
    int i;

    if (stack[stackp - 1].number == xy_tag_number)
    {
	x = stack[stackp - 1].data[0];
	y = stack[stackp - 1].data[1];
    }
    else
    {
	x = cos(stack[stackp - 1].data[1] * M_PI / 180) * stack[stackp - 1].data[0];
	y = sin(stack[stackp - 1].data[1] * M_PI / 180) * stack[stackp - 1].data[0];
    }

    x += originX + middleX;
    y += originY + middleY;

    if (!oversamplingEnabled)
    {
	x += 0.5;
	y += 0.5;
    }

    get_pixel(floor(x), floor(y), pixel);
    
    for (i = 0; i < 4; ++i)
	stack[stackp - 1].data[i] = (float)pixel[i] / 255.0;
    stack[stackp - 1].length = 4;
    stack[stackp - 1].number = rgba_tag_number;
}

void
builtin_origValIntersample (postfix_arg *arg)
{
    static unsigned char blackPixel[4] = { 0, 0, 0, 0 };

    double x,
	y;
    int x1,
	x2,
	y1,
	y2;
    double x2fact,
	y2fact,
	x1fact,
	y1fact,
	p1fact,
	p2fact,
	p3fact,
	p4fact;
    unsigned char pixel1a[4],
	pixel2a[4],
	pixel3a[4],
	pixel4a[4],
	resultPixel[4];
    unsigned char *pixel1 = pixel1a,
	*pixel2 = pixel2a,
	*pixel3 = pixel3a,
	*pixel4 = pixel4a;
    int i;
    
    if (stack[stackp - 1].number == xy_tag_number)
    {
	x = stack[stackp - 1].data[0] + middleX + originX;
	y = stack[stackp - 1].data[1] + middleY + originY;
    }
    else
    {
	x = cos(stack[stackp - 1].data[1] * M_PI / 180) * stack[stackp - 1].data[0] + middleX + originX;
	y = sin(stack[stackp - 1].data[1] * M_PI / 180) * stack[stackp - 1].data[0] + middleY + originY;
    }

    x1 = floor(x);
    x2 = x1 + 1;
    y1 = floor(y);
    y2 = y1 + 1;
    x2fact = (x - x1);
    y2fact = (y - y1);
    x1fact = 1.0 - x2fact;
    y1fact = 1.0 - y2fact;
    p1fact = x1fact * y1fact;
    p2fact = x1fact * y2fact;
    p3fact = x2fact * y1fact;
    p4fact = x2fact * y2fact;

    if (x1 < 0 || x1 >= wholeImageWidth || y1 < 0 || y1 >= wholeImageHeight)
	pixel1 = blackPixel;
    else
	get_pixel(x1, y1, pixel1);

    if (x1 < 0 || x1 >= wholeImageWidth || y2 < 0 || y2 >= wholeImageHeight)
	pixel2 = blackPixel;
    else
	get_pixel(x1, y2, pixel2);

    if (x2 < 0 || x2 >= wholeImageWidth || y1 < 0 || y1 >= wholeImageHeight)
	pixel3 = blackPixel;
    else
	get_pixel(x2, y1, pixel3);

    if (x2 < 0 || x2 >= wholeImageWidth || y2 < 0 || y2 >= wholeImageHeight)
	pixel4 = blackPixel;
    else
	get_pixel(x2, y2, pixel4);

    for (i = 0; i < outputBPP; ++i)
	resultPixel[i] = pixel1[i] * p1fact
	    + pixel2[i] * p2fact
	    + pixel3[i] * p3fact
	    + pixel4[i] * p4fact;

    for (i = 0; i < 4; ++i)
	stack[stackp - 1].data[i] = (float)resultPixel[i] / 255.0;
    stack[stackp - 1].length = 4;
    stack[stackp - 1].number = rgba_tag_number;
}

void
builtin_gray (postfix_arg *arg)
{
    stack[stackp - 1].data[0] =
	0.299 * stack[stackp - 1].data[0] +
	0.587 * stack[stackp - 1].data[1] +
	0.114 * stack[stackp - 1].data[2];
    stack[stackp - 1].length = 1;
}

void
builtin_curve (postfix_arg *arg)
{
    int index = stack[stackp - 1].data[0] * (user_curve_points - 1);

    if (index < 0)
	index = 0;
    else if (index >= user_curve_points)
	index = user_curve_points - 1;

    stack[stackp - 1].data[0] = user_curve_values[index];
}

void
builtin_gradient (postfix_arg *arg)
{
    int index = stack[stackp - 1].data[0] * (num_gradient_samples - 1);

    if (index < 0)
	index = 0;
    else if (index >= num_gradient_samples)
	index = num_gradient_samples - 1;

    stack[stackp - 1] = gradient_samples[index];
}

builtin_function_t
builtin_with_name (const char *name)
{
    if (strcmp(name, "origVal") == 0)
    {
	if (intersamplingEnabled)
	    return builtin_origValIntersample;
	else
	    return builtin_origVal;
    }

    return 0;
}

void
init_builtins (void)
{
    register_overloaded_builtin("__add", "ri:2=ri:2,ri:2", builtin_add_ri);
    register_overloaded_builtin("__add", "T:1=T:1,T:1", builtin_add_1);
    register_overloaded_builtin("__add", "T:L=T:L,_:1", builtin_add_s);
    register_overloaded_builtin("__add", "T:L=T:L,T:L", builtin_add_n);

    register_overloaded_builtin("__sub", "ri:2=ri:2,ri:2", builtin_sub_ri);
    register_overloaded_builtin("__sub", "T:1=T:1,T:1", builtin_sub_1);
    register_overloaded_builtin("__sub", "T:L=T:L,_:1", builtin_sub_s);
    register_overloaded_builtin("__sub", "T:L=T:L,T:L", builtin_sub_n);

    register_overloaded_builtin("__mul", "ri:2=ri:2,ri:2", builtin_mul_ri);
    register_overloaded_builtin("__mul", "T:1=T:1,T:1", builtin_mul_1);
    register_overloaded_builtin("__mul", "T:L=T:L,_:1", builtin_mul_s);
    register_overloaded_builtin("__mul", "T:L=T:L,T:L", builtin_mul_n);

    register_overloaded_builtin("__div", "ri:2=ri:2,ri:2", builtin_div_ri);
    register_overloaded_builtin("__div", "T:1=T:1,T:1", builtin_div_1);
    register_overloaded_builtin("__div", "T:L=T:L,_:1", builtin_div_s);
    register_overloaded_builtin("__div", "T:L=T:L,T:L", builtin_div_n);

    register_overloaded_builtin("__mod", "T:1=T:1,T:1", builtin_mod_1);
    register_overloaded_builtin("__mod", "T:L=T:L,_:1", builtin_mod_s);
    register_overloaded_builtin("__mod", "T:L=T:L,T:L", builtin_mod_n);

    register_overloaded_builtin("__neg", "T:L=T:L", builtin_neg);
    
    register_overloaded_builtin("__pow", "T:1=T:1,T:1", builtin_pow_1);
    register_overloaded_builtin("__pow", "T:L=T:L,_:1", builtin_pow_s);

    register_overloaded_builtin("__not", "T:1=T:1", builtin_not);
    register_overloaded_builtin("__or", "T:1=T:1,T:1", builtin_or);
    register_overloaded_builtin("__and", "T:1=T:1,T:1", builtin_and);

    register_overloaded_builtin("__equal", "T:1=T:1,T:1", builtin_equal);
    register_overloaded_builtin("__less", "T:1=T:1,T:1", builtin_less);
    register_overloaded_builtin("__greater", "T:1=T:1,T:1", builtin_greater);
    register_overloaded_builtin("__lessequal", "T:1=T:1,T:1", builtin_lessequal);
    register_overloaded_builtin("__greaterequal", "T:1=T:1,T:1", builtin_greaterequal);
    register_overloaded_builtin("__notequal", "T:1=T:1,T:1", builtin_notequal);

    register_overloaded_builtin("sin", "T:1=T:1", builtin_sin);
    register_overloaded_builtin("cos", "T:1=T:1", builtin_cos);
    register_overloaded_builtin("tan", "T:1=T:1", builtin_tan);
    register_overloaded_builtin("asin", "T:1=T:1", builtin_asin);
    register_overloaded_builtin("acos", "T:1=T:1", builtin_acos);
    register_overloaded_builtin("atan", "T:1=T:1", builtin_atan);

    register_overloaded_builtin("abs", "nil:1=ri:2", builtin_abs_ri);
    register_overloaded_builtin("abs", "T:1=T:1", builtin_abs_1);
    register_overloaded_builtin("abs", "T:L=T:L", builtin_abs_n);
    register_overloaded_builtin("floor", "T:1=T:1", builtin_floor);
    register_overloaded_builtin("sign", "T:1=T:1", builtin_sign_1);
    register_overloaded_builtin("sign", "T:L=T:L", builtin_sign_n);
    register_overloaded_builtin("min", "T:1=T:1,T:1", builtin_min_1);
    register_overloaded_builtin("min", "T:L=T:L,T:L", builtin_min_n);
    register_overloaded_builtin("max", "T:1=T:1,T:1", builtin_max_1);
    register_overloaded_builtin("max", "T:L=T:L,T:L", builtin_max_n);

    register_overloaded_builtin("inintv", "T:1=T:1,T:1,T:1", builtin_inintv);

    register_overloaded_builtin("rand", "T:1=T:1,T:1", builtin_rand);

    register_overloaded_builtin("origVal", "rgba:4=xy:2", builtin_origVal);
    register_overloaded_builtin("origVal", "rgba:4=ra:2", builtin_origVal);
    register_overloaded_builtin("origValIntersample", "rgba:4=xy:2", builtin_origValIntersample);
    register_overloaded_builtin("origValIntersample", "rgba:4=ra:2", builtin_origValIntersample);

    register_overloaded_builtin("gray", "nil:1=rgba:4", builtin_gray);

    register_overloaded_builtin("curve", "T:1=T:1", builtin_curve);
    register_overloaded_builtin("gradient", "rgba:4=_:1", builtin_gradient);
}
