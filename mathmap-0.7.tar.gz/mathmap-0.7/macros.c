#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "postfix.h"
#include "internals.h"
#include "tags.h"
#include "exprtree.h"
#include "overload.h"

#include "macros.h"

static var_macro_t *first = 0;

void
register_variable_macro (const char *name,  macro_function_t function, tuple_info_t info)
{
    var_macro_t *macro = (var_macro_t*)malloc(sizeof(var_macro_t));

    strncpy(macro->name, name, MAX_MACRO_LENGTH);
    macro->name[MAX_MACRO_LENGTH] = '\0';
    macro->info = info;
    macro->function = function;

    macro->next = first;
    first = macro;
}

macro_function_t
lookup_variable_macro (const char *name, tuple_info_t *info)
{
    var_macro_t *macro;

    for (macro = first; macro != 0; macro = macro->next)
	if (strcmp(macro->name, name) == 0)
	{
	    *info = macro->info;
	    return macro->function;
	}

    return 0;
}

void
macro_var_x (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("xy", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 0;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_var_y (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("xy", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 1;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_var_r (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("ra", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 0;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_var_a (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("ra", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 1;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_var_big_x (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("XY", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 0;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_var_big_y (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("XY", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 1;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_var_big_w (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("WH", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 0;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_var_big_h (exprtree *args)
{
    tuple_info_t dummy;

    expression[exprp].func = stack_push_internal;
    expression[exprp].arg.internal = lookup_internal("WH", &dummy);
    ++exprp;

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 1;
    ++exprp;

    make_tuple_info(nil_tag_number, 1);
}

void
macro_func_origValXY (exprtree *args)
{
    make_postfix_recursive(args);
    make_postfix_recursive(args->next);

    expression[exprp].func = stack_tuple;
    expression[exprp].arg.integer = 2;
    ++exprp;

    expression[exprp].func = stack_cast;
    expression[exprp].arg.integer = xy_tag_number;
    ++exprp;

    expression[exprp++].func = builtin_with_name("origVal");
}

void
macro_func_origValRA (exprtree *args)
{
    make_postfix_recursive(args);
    make_postfix_recursive(args->next);

    expression[exprp].func = stack_tuple;
    expression[exprp].arg.integer = 2;
    ++exprp;

    expression[exprp].func = stack_cast;
    expression[exprp].arg.integer = ra_tag_number;
    ++exprp;

    expression[exprp++].func = builtin_with_name("origVal");
}

void
macro_func_red (exprtree *arg)
{
    make_postfix_recursive(arg);

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 0;
    ++exprp;
}

void
macro_func_green (exprtree *arg)
{
    make_postfix_recursive(arg);

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 1;
    ++exprp;
}

void
macro_func_blue (exprtree *arg)
{
    make_postfix_recursive(arg);

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 2;
    ++exprp;
}

void
macro_func_alpha (exprtree *arg)
{
    make_postfix_recursive(arg);

    expression[exprp].func = stack_select_i;
    expression[exprp].arg.integer = 3;
    ++exprp;
}

void
macro_func_rgbColor (exprtree *args)
{
    int i;

    for (i = 0; i < 3; args = args->next, ++i)
	make_postfix_recursive(args);

    expression[exprp].func = stack_push;
    expression[exprp].arg.tuple.number = nil_tag_number;
    expression[exprp].arg.tuple.length = 1;
    expression[exprp].arg.tuple.data[0] = 1.0;
    ++exprp;

    expression[exprp].func = stack_tuple;
    expression[exprp].arg.integer = 4;
    ++exprp;

    expression[exprp].func = stack_cast;
    expression[exprp].arg.integer = rgba_tag_number;
    ++exprp;
}

void
macro_func_rgbaColor (exprtree *args)
{
    int i;

    for (i = 0; i < 4; args = args->next, ++i)
	make_postfix_recursive(args);

    expression[exprp].func = stack_tuple;
    expression[exprp].arg.integer = 4;
    ++exprp;

    expression[exprp].func = stack_cast;
    expression[exprp].arg.integer = rgba_tag_number;
    ++exprp;
}

void
macro_func_grayColor (exprtree *arg)
{
    make_postfix_recursive(arg);

    expression[exprp].func = stack_dupn_i;
    expression[exprp].arg.integer = 2;
    ++exprp;

    expression[exprp].func = stack_push;
    expression[exprp].arg.tuple.number = nil_tag_number;
    expression[exprp].arg.tuple.length = 1;
    expression[exprp].arg.tuple.data[0] = 1.0;
    ++exprp;

    expression[exprp].func = stack_tuple;
    expression[exprp].arg.integer = 4;
    ++exprp;

    expression[exprp].func = stack_cast;
    expression[exprp].arg.integer = rgba_tag_number;
    ++exprp;
}

void
macro_func_grayaColor (exprtree *arg)
{
    make_postfix_recursive(arg);

    expression[exprp].func = stack_dupn_i;
    expression[exprp].arg.integer = 2;
    ++exprp;

    make_postfix_recursive(arg->next);

    expression[exprp].func = stack_tuple;
    expression[exprp].arg.integer = 4;
    ++exprp;

    expression[exprp].func = stack_cast;
    expression[exprp].arg.integer = rgba_tag_number;
    ++exprp;
}

void
init_macros (void)
{
    register_variable_macro("x", macro_var_x, make_tuple_info(nil_tag_number, 1));
    register_variable_macro("y", macro_var_y, make_tuple_info(nil_tag_number, 1));
    register_variable_macro("r", macro_var_r, make_tuple_info(nil_tag_number, 1));
    register_variable_macro("a", macro_var_a, make_tuple_info(nil_tag_number, 1));
    register_variable_macro("X", macro_var_big_x, make_tuple_info(nil_tag_number, 1));
    register_variable_macro("Y", macro_var_big_y, make_tuple_info(nil_tag_number, 1));
    register_variable_macro("W", macro_var_big_w, make_tuple_info(nil_tag_number, 1));
    register_variable_macro("H", macro_var_big_h, make_tuple_info(nil_tag_number, 1));

    register_overloaded_macro("origValXY", "rgba:4=T:1,T:1", macro_func_origValXY);
    register_overloaded_macro("origValRA", "rgba:4=T:1,T:1", macro_func_origValRA);

    register_overloaded_macro("red", "nil:1=rgba:4", macro_func_red);
    register_overloaded_macro("green", "nil:1=rgba:4", macro_func_green);
    register_overloaded_macro("blue", "nil:1=rgba:4", macro_func_blue);
    register_overloaded_macro("alpha", "nil:1=rgba:4", macro_func_alpha);

    register_overloaded_macro("red", "nil:1=rgba:4", macro_func_red);
    register_overloaded_macro("green", "nil:1=rgba:4", macro_func_green);
    register_overloaded_macro("blue", "nil:1=rgba:4", macro_func_blue);
    register_overloaded_macro("alpha", "nil:1=rgba:4", macro_func_alpha);

    register_overloaded_macro("rgbColor", "rgba:4=T:1,T:1,T:1", macro_func_rgbColor);
    register_overloaded_macro("rgbaColor", "rgba:4=T:1,T:1,T:1,T:1", macro_func_rgbaColor);
    register_overloaded_macro("grayColor", "rgba:4=T:1", macro_func_grayColor);
    register_overloaded_macro("grayaColor", "rgba:4=T:1,T:1", macro_func_grayaColor);
}
