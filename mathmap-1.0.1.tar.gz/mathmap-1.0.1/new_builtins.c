void
builtin_print (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_0;
for (tmp_0 = 0; tmp_0 < STK[STKP - 1].length; ++tmp_0)
{
{
float tmp_1;
tmp_1 = STK[STKP - 1].data[tmp_0];
PRINT(tmp_1);
}
}
}
NEWLINE();
result[0] = 0;
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_print (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_2;
for (tmp_2 = 0; tmp_2 < arglengths[0]; ++tmp_2)
{
{
compvar_t *tmp_3, *tmp_4 = make_temporary();
tmp_3 = args[0][tmp_2];
emit_assign(make_lhs(tmp_4), make_op_rhs(OP_PRINT, make_compvar_primary(tmp_3)));
}
}
}
{
compvar_t *tmp_5 = make_temporary();
emit_assign(make_lhs(tmp_5), make_op_rhs(OP_NEWLINE));
}
{
int tmp_6;
for (tmp_6 = 0; tmp_6 < 1; ++tmp_6)
{
switch (tmp_6)
{
case 0 :
emit_assign(make_lhs(result[tmp_6]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
}

void
builtin_add_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_7;
float tmp_8;
tmp_7 = STK[STKP - 2].data[0];
tmp_8 = STK[STKP - 1].data[0];
result[0] = tmp_7 + tmp_8;
}
{
float tmp_9;
float tmp_10;
tmp_9 = STK[STKP - 2].data[1];
tmp_10 = STK[STKP - 1].data[1];
result[1] = tmp_9 + tmp_10;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_add_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_11;
for (tmp_11 = 0; tmp_11 < 2; ++tmp_11)
{
{
compvar_t *tmp_12, *tmp_13;
tmp_12 = args[0][tmp_11];
tmp_13 = args[1][tmp_11];
emit_assign(make_lhs(result[tmp_11]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_12), make_compvar_primary(tmp_13)));
}
}
}
}

void
builtin_add_ri_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_14;
float tmp_15;
tmp_14 = STK[STKP - 2].data[0];
tmp_15 = STK[STKP - 1].data[0];
result[0] = tmp_14 + tmp_15;
}
{
float tmp_16;
float tmp_17;
tmp_16 = STK[STKP - 2].data[1];
tmp_17 = 0;
result[1] = tmp_16 + tmp_17;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_add_ri_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_18;
for (tmp_18 = 0; tmp_18 < 2; ++tmp_18)
{
{
compvar_t *tmp_19, *tmp_20;
tmp_19 = args[0][tmp_18];
switch (tmp_18)
{
case 0 :
tmp_20 = args[1][0];
break;
case 1 :
tmp_20 = make_temporary();
emit_assign(make_lhs(tmp_20), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_18]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_19), make_compvar_primary(tmp_20)));
}
}
}
}

void
builtin_add_1_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_21;
float tmp_22;
tmp_21 = STK[STKP - 1].data[0];
tmp_22 = STK[STKP - 2].data[0];
result[0] = tmp_21 + tmp_22;
}
{
float tmp_23;
float tmp_24;
tmp_23 = STK[STKP - 1].data[1];
tmp_24 = 0;
result[1] = tmp_23 + tmp_24;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_add_1_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_25;
for (tmp_25 = 0; tmp_25 < 2; ++tmp_25)
{
{
compvar_t *tmp_26, *tmp_27;
tmp_26 = args[1][tmp_25];
switch (tmp_25)
{
case 0 :
tmp_27 = args[0][0];
break;
case 1 :
tmp_27 = make_temporary();
emit_assign(make_lhs(tmp_27), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_25]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_26), make_compvar_primary(tmp_27)));
}
}
}
}

void
builtin_add_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_28;
float tmp_29;
tmp_28 = STK[STKP - 2].data[0];
tmp_29 = STK[STKP - 1].data[0];
result[0] = tmp_28 + tmp_29;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_add_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_30;
for (tmp_30 = 0; tmp_30 < 1; ++tmp_30)
{
{
compvar_t *tmp_31, *tmp_32;
tmp_31 = args[0][tmp_30];
tmp_32 = args[1][tmp_30];
emit_assign(make_lhs(result[tmp_30]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_31), make_compvar_primary(tmp_32)));
}
}
}
}

void
builtin_add_s (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_33;
for (tmp_33 = 0; tmp_33 < STK[STKP - 2].length; ++tmp_33)
{
{
float tmp_34;
float tmp_35;
tmp_34 = STK[STKP - 2].data[tmp_33];
tmp_35 = STK[STKP - 1].data[0];
result[tmp_33] = tmp_34 + tmp_35;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_add_s (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_36;
for (tmp_36 = 0; tmp_36 < arglengths[0]; ++tmp_36)
{
{
compvar_t *tmp_37, *tmp_38;
tmp_37 = args[0][tmp_36];
tmp_38 = args[1][0];
emit_assign(make_lhs(result[tmp_36]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_37), make_compvar_primary(tmp_38)));
}
}
}
}

void
builtin_add_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_39;
for (tmp_39 = 0; tmp_39 < STK[STKP - 2].length; ++tmp_39)
{
{
float tmp_40;
float tmp_41;
tmp_40 = STK[STKP - 2].data[tmp_39];
tmp_41 = STK[STKP - 1].data[tmp_39];
result[tmp_39] = tmp_40 + tmp_41;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_add_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_42;
for (tmp_42 = 0; tmp_42 < arglengths[0]; ++tmp_42)
{
{
compvar_t *tmp_43, *tmp_44;
tmp_43 = args[0][tmp_42];
tmp_44 = args[1][tmp_42];
emit_assign(make_lhs(result[tmp_42]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_43), make_compvar_primary(tmp_44)));
}
}
}
}

void
builtin_sub_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_45;
float tmp_46;
tmp_45 = STK[STKP - 2].data[0];
tmp_46 = STK[STKP - 1].data[0];
result[0] = tmp_45 - tmp_46;
}
{
float tmp_47;
float tmp_48;
tmp_47 = STK[STKP - 2].data[1];
tmp_48 = STK[STKP - 1].data[1];
result[1] = tmp_47 - tmp_48;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_sub_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_49;
for (tmp_49 = 0; tmp_49 < 2; ++tmp_49)
{
{
compvar_t *tmp_50, *tmp_51;
tmp_50 = args[0][tmp_49];
tmp_51 = args[1][tmp_49];
emit_assign(make_lhs(result[tmp_49]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_50), make_compvar_primary(tmp_51)));
}
}
}
}

void
builtin_sub_ri_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_52;
float tmp_53;
tmp_52 = STK[STKP - 2].data[0];
tmp_53 = STK[STKP - 1].data[0];
result[0] = tmp_52 - tmp_53;
}
{
float tmp_54;
float tmp_55;
tmp_54 = STK[STKP - 2].data[1];
tmp_55 = 0;
result[1] = tmp_54 - tmp_55;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_sub_ri_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_56;
for (tmp_56 = 0; tmp_56 < 2; ++tmp_56)
{
{
compvar_t *tmp_57, *tmp_58;
tmp_57 = args[0][tmp_56];
switch (tmp_56)
{
case 0 :
tmp_58 = args[1][0];
break;
case 1 :
tmp_58 = make_temporary();
emit_assign(make_lhs(tmp_58), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_56]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_57), make_compvar_primary(tmp_58)));
}
}
}
}

void
builtin_sub_1_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_59;
float tmp_60;
tmp_59 = STK[STKP - 2].data[0];
tmp_60 = STK[STKP - 1].data[0];
result[0] = tmp_59 - tmp_60;
}
{
float tmp_61;
float tmp_62;
tmp_61 = 0;
tmp_62 = STK[STKP - 1].data[1];
result[1] = tmp_61 - tmp_62;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_sub_1_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_63;
for (tmp_63 = 0; tmp_63 < 2; ++tmp_63)
{
{
compvar_t *tmp_64, *tmp_65;
switch (tmp_63)
{
case 0 :
tmp_64 = args[0][0];
break;
case 1 :
tmp_64 = make_temporary();
emit_assign(make_lhs(tmp_64), make_int_const_rhs(0));
break;
default :
assert(0);
}
tmp_65 = args[1][tmp_63];
emit_assign(make_lhs(result[tmp_63]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_64), make_compvar_primary(tmp_65)));
}
}
}
}

void
builtin_sub_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_66;
float tmp_67;
tmp_66 = STK[STKP - 2].data[0];
tmp_67 = STK[STKP - 1].data[0];
result[0] = tmp_66 - tmp_67;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_sub_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_68;
for (tmp_68 = 0; tmp_68 < 1; ++tmp_68)
{
{
compvar_t *tmp_69, *tmp_70;
tmp_69 = args[0][tmp_68];
tmp_70 = args[1][tmp_68];
emit_assign(make_lhs(result[tmp_68]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_69), make_compvar_primary(tmp_70)));
}
}
}
}

void
builtin_sub_s (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_71;
for (tmp_71 = 0; tmp_71 < STK[STKP - 2].length; ++tmp_71)
{
{
float tmp_72;
float tmp_73;
tmp_72 = STK[STKP - 2].data[tmp_71];
tmp_73 = STK[STKP - 1].data[0];
result[tmp_71] = tmp_72 - tmp_73;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_sub_s (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_74;
for (tmp_74 = 0; tmp_74 < arglengths[0]; ++tmp_74)
{
{
compvar_t *tmp_75, *tmp_76;
tmp_75 = args[0][tmp_74];
tmp_76 = args[1][0];
emit_assign(make_lhs(result[tmp_74]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_75), make_compvar_primary(tmp_76)));
}
}
}
}

void
builtin_sub_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_77;
for (tmp_77 = 0; tmp_77 < STK[STKP - 2].length; ++tmp_77)
{
{
float tmp_78;
float tmp_79;
tmp_78 = STK[STKP - 2].data[tmp_77];
tmp_79 = STK[STKP - 1].data[tmp_77];
result[tmp_77] = tmp_78 - tmp_79;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_sub_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_80;
for (tmp_80 = 0; tmp_80 < arglengths[0]; ++tmp_80)
{
{
compvar_t *tmp_81, *tmp_82;
tmp_81 = args[0][tmp_80];
tmp_82 = args[1][tmp_80];
emit_assign(make_lhs(result[tmp_80]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_81), make_compvar_primary(tmp_82)));
}
}
}
}

void
builtin_neg (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_83;
for (tmp_83 = 0; tmp_83 < STK[STKP - 1].length; ++tmp_83)
{
{
float tmp_84;
tmp_84 = STK[STKP - 1].data[tmp_83];
result[tmp_83] = -tmp_84;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].length; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = STK[STKP - 1].length;
STKP -= 0;
}

void
gen_neg (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_85;
for (tmp_85 = 0; tmp_85 < arglengths[0]; ++tmp_85)
{
{
compvar_t *tmp_86;
tmp_86 = args[0][tmp_85];
emit_assign(make_lhs(result[tmp_85]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_86)));
}
}
}
}

void
builtin_mul_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_87;
float tmp_88;
{
float tmp_89;
float tmp_90;
tmp_89 = STK[STKP - 2].data[0];
tmp_90 = STK[STKP - 1].data[0];
tmp_87 = tmp_89 * tmp_90;
}
{
float tmp_91;
float tmp_92;
tmp_91 = STK[STKP - 2].data[1];
tmp_92 = STK[STKP - 1].data[1];
tmp_88 = tmp_91 * tmp_92;
}
result[0] = tmp_87 - tmp_88;
}
{
float tmp_93;
float tmp_94;
{
float tmp_95;
float tmp_96;
tmp_95 = STK[STKP - 2].data[0];
tmp_96 = STK[STKP - 1].data[1];
tmp_93 = tmp_95 * tmp_96;
}
{
float tmp_97;
float tmp_98;
tmp_97 = STK[STKP - 1].data[0];
tmp_98 = STK[STKP - 2].data[1];
tmp_94 = tmp_97 * tmp_98;
}
result[1] = tmp_93 + tmp_94;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_mul_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_99;
for (tmp_99 = 0; tmp_99 < 2; ++tmp_99)
{
switch (tmp_99)
{
case 0 :
{
compvar_t *tmp_100, *tmp_101;
tmp_100 = make_temporary();
{
compvar_t *tmp_102, *tmp_103;
tmp_102 = args[0][0];
tmp_103 = args[1][0];
emit_assign(make_lhs(tmp_100), make_op_rhs(OP_MUL, make_compvar_primary(tmp_102), make_compvar_primary(tmp_103)));
}
tmp_101 = make_temporary();
{
compvar_t *tmp_104, *tmp_105;
tmp_104 = args[0][1];
tmp_105 = args[1][1];
emit_assign(make_lhs(tmp_101), make_op_rhs(OP_MUL, make_compvar_primary(tmp_104), make_compvar_primary(tmp_105)));
}
emit_assign(make_lhs(result[tmp_99]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_100), make_compvar_primary(tmp_101)));
}
break;
case 1 :
{
compvar_t *tmp_106, *tmp_107;
tmp_106 = make_temporary();
{
compvar_t *tmp_108, *tmp_109;
tmp_108 = args[0][0];
tmp_109 = args[1][1];
emit_assign(make_lhs(tmp_106), make_op_rhs(OP_MUL, make_compvar_primary(tmp_108), make_compvar_primary(tmp_109)));
}
tmp_107 = make_temporary();
{
compvar_t *tmp_110, *tmp_111;
tmp_110 = args[1][0];
tmp_111 = args[0][1];
emit_assign(make_lhs(tmp_107), make_op_rhs(OP_MUL, make_compvar_primary(tmp_110), make_compvar_primary(tmp_111)));
}
emit_assign(make_lhs(result[tmp_99]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_106), make_compvar_primary(tmp_107)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_1_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_112;
float tmp_113;
tmp_112 = STK[STKP - 2].data[0];
tmp_113 = STK[STKP - 1].data[0];
result[0] = tmp_112 * tmp_113;
}
{
float tmp_114;
float tmp_115;
tmp_114 = STK[STKP - 2].data[0];
tmp_115 = STK[STKP - 1].data[1];
result[1] = tmp_114 * tmp_115;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_mul_1_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_116;
for (tmp_116 = 0; tmp_116 < 2; ++tmp_116)
{
{
compvar_t *tmp_117, *tmp_118;
tmp_117 = args[0][0];
tmp_118 = args[1][tmp_116];
emit_assign(make_lhs(result[tmp_116]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_117), make_compvar_primary(tmp_118)));
}
}
}
}

void
builtin_mul_m2x2 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_119;
float tmp_120;
{
float tmp_121;
float tmp_122;
tmp_121 = STK[STKP - 2].data[0];
tmp_122 = STK[STKP - 1].data[0];
tmp_119 = tmp_121 * tmp_122;
}
{
float tmp_123;
float tmp_124;
tmp_123 = STK[STKP - 2].data[1];
tmp_124 = STK[STKP - 1].data[2];
tmp_120 = tmp_123 * tmp_124;
}
result[0] = tmp_119 + tmp_120;
}
{
float tmp_125;
float tmp_126;
{
float tmp_127;
float tmp_128;
tmp_127 = STK[STKP - 2].data[0];
tmp_128 = STK[STKP - 1].data[1];
tmp_125 = tmp_127 * tmp_128;
}
{
float tmp_129;
float tmp_130;
tmp_129 = STK[STKP - 2].data[1];
tmp_130 = STK[STKP - 1].data[3];
tmp_126 = tmp_129 * tmp_130;
}
result[1] = tmp_125 + tmp_126;
}
{
float tmp_131;
float tmp_132;
{
float tmp_133;
float tmp_134;
tmp_133 = STK[STKP - 2].data[2];
tmp_134 = STK[STKP - 1].data[0];
tmp_131 = tmp_133 * tmp_134;
}
{
float tmp_135;
float tmp_136;
tmp_135 = STK[STKP - 2].data[3];
tmp_136 = STK[STKP - 1].data[2];
tmp_132 = tmp_135 * tmp_136;
}
result[2] = tmp_131 + tmp_132;
}
{
float tmp_137;
float tmp_138;
{
float tmp_139;
float tmp_140;
tmp_139 = STK[STKP - 2].data[2];
tmp_140 = STK[STKP - 1].data[1];
tmp_137 = tmp_139 * tmp_140;
}
{
float tmp_141;
float tmp_142;
tmp_141 = STK[STKP - 2].data[3];
tmp_142 = STK[STKP - 1].data[3];
tmp_138 = tmp_141 * tmp_142;
}
result[3] = tmp_137 + tmp_138;
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 4;
STKP -= 1;
}

void
gen_mul_m2x2 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_143;
for (tmp_143 = 0; tmp_143 < 4; ++tmp_143)
{
switch (tmp_143)
{
case 0 :
{
compvar_t *tmp_144, *tmp_145;
tmp_144 = make_temporary();
{
compvar_t *tmp_146, *tmp_147;
tmp_146 = args[0][0];
tmp_147 = args[1][0];
emit_assign(make_lhs(tmp_144), make_op_rhs(OP_MUL, make_compvar_primary(tmp_146), make_compvar_primary(tmp_147)));
}
tmp_145 = make_temporary();
{
compvar_t *tmp_148, *tmp_149;
tmp_148 = args[0][1];
tmp_149 = args[1][2];
emit_assign(make_lhs(tmp_145), make_op_rhs(OP_MUL, make_compvar_primary(tmp_148), make_compvar_primary(tmp_149)));
}
emit_assign(make_lhs(result[tmp_143]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_144), make_compvar_primary(tmp_145)));
}
break;
case 1 :
{
compvar_t *tmp_150, *tmp_151;
tmp_150 = make_temporary();
{
compvar_t *tmp_152, *tmp_153;
tmp_152 = args[0][0];
tmp_153 = args[1][1];
emit_assign(make_lhs(tmp_150), make_op_rhs(OP_MUL, make_compvar_primary(tmp_152), make_compvar_primary(tmp_153)));
}
tmp_151 = make_temporary();
{
compvar_t *tmp_154, *tmp_155;
tmp_154 = args[0][1];
tmp_155 = args[1][3];
emit_assign(make_lhs(tmp_151), make_op_rhs(OP_MUL, make_compvar_primary(tmp_154), make_compvar_primary(tmp_155)));
}
emit_assign(make_lhs(result[tmp_143]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_150), make_compvar_primary(tmp_151)));
}
break;
case 2 :
{
compvar_t *tmp_156, *tmp_157;
tmp_156 = make_temporary();
{
compvar_t *tmp_158, *tmp_159;
tmp_158 = args[0][2];
tmp_159 = args[1][0];
emit_assign(make_lhs(tmp_156), make_op_rhs(OP_MUL, make_compvar_primary(tmp_158), make_compvar_primary(tmp_159)));
}
tmp_157 = make_temporary();
{
compvar_t *tmp_160, *tmp_161;
tmp_160 = args[0][3];
tmp_161 = args[1][2];
emit_assign(make_lhs(tmp_157), make_op_rhs(OP_MUL, make_compvar_primary(tmp_160), make_compvar_primary(tmp_161)));
}
emit_assign(make_lhs(result[tmp_143]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_156), make_compvar_primary(tmp_157)));
}
break;
case 3 :
{
compvar_t *tmp_162, *tmp_163;
tmp_162 = make_temporary();
{
compvar_t *tmp_164, *tmp_165;
tmp_164 = args[0][2];
tmp_165 = args[1][1];
emit_assign(make_lhs(tmp_162), make_op_rhs(OP_MUL, make_compvar_primary(tmp_164), make_compvar_primary(tmp_165)));
}
tmp_163 = make_temporary();
{
compvar_t *tmp_166, *tmp_167;
tmp_166 = args[0][3];
tmp_167 = args[1][3];
emit_assign(make_lhs(tmp_163), make_op_rhs(OP_MUL, make_compvar_primary(tmp_166), make_compvar_primary(tmp_167)));
}
emit_assign(make_lhs(result[tmp_143]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_162), make_compvar_primary(tmp_163)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_m3x3 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_168;
float tmp_169;
{
float tmp_170;
float tmp_171;
{
float tmp_172;
float tmp_173;
tmp_172 = STK[STKP - 2].data[0];
tmp_173 = STK[STKP - 1].data[0];
tmp_170 = tmp_172 * tmp_173;
}
{
float tmp_174;
float tmp_175;
tmp_174 = STK[STKP - 2].data[1];
tmp_175 = STK[STKP - 1].data[3];
tmp_171 = tmp_174 * tmp_175;
}
tmp_168 = tmp_170 + tmp_171;
}
{
float tmp_176;
float tmp_177;
tmp_176 = STK[STKP - 2].data[2];
tmp_177 = STK[STKP - 1].data[6];
tmp_169 = tmp_176 * tmp_177;
}
result[0] = tmp_168 + tmp_169;
}
{
float tmp_178;
float tmp_179;
{
float tmp_180;
float tmp_181;
{
float tmp_182;
float tmp_183;
tmp_182 = STK[STKP - 2].data[0];
tmp_183 = STK[STKP - 1].data[1];
tmp_180 = tmp_182 * tmp_183;
}
{
float tmp_184;
float tmp_185;
tmp_184 = STK[STKP - 2].data[1];
tmp_185 = STK[STKP - 1].data[4];
tmp_181 = tmp_184 * tmp_185;
}
tmp_178 = tmp_180 + tmp_181;
}
{
float tmp_186;
float tmp_187;
tmp_186 = STK[STKP - 2].data[2];
tmp_187 = STK[STKP - 1].data[7];
tmp_179 = tmp_186 * tmp_187;
}
result[1] = tmp_178 + tmp_179;
}
{
float tmp_188;
float tmp_189;
{
float tmp_190;
float tmp_191;
{
float tmp_192;
float tmp_193;
tmp_192 = STK[STKP - 2].data[0];
tmp_193 = STK[STKP - 1].data[2];
tmp_190 = tmp_192 * tmp_193;
}
{
float tmp_194;
float tmp_195;
tmp_194 = STK[STKP - 2].data[1];
tmp_195 = STK[STKP - 1].data[5];
tmp_191 = tmp_194 * tmp_195;
}
tmp_188 = tmp_190 + tmp_191;
}
{
float tmp_196;
float tmp_197;
tmp_196 = STK[STKP - 2].data[2];
tmp_197 = STK[STKP - 1].data[8];
tmp_189 = tmp_196 * tmp_197;
}
result[2] = tmp_188 + tmp_189;
}
{
float tmp_198;
float tmp_199;
{
float tmp_200;
float tmp_201;
{
float tmp_202;
float tmp_203;
tmp_202 = STK[STKP - 2].data[3];
tmp_203 = STK[STKP - 1].data[0];
tmp_200 = tmp_202 * tmp_203;
}
{
float tmp_204;
float tmp_205;
tmp_204 = STK[STKP - 2].data[4];
tmp_205 = STK[STKP - 1].data[3];
tmp_201 = tmp_204 * tmp_205;
}
tmp_198 = tmp_200 + tmp_201;
}
{
float tmp_206;
float tmp_207;
tmp_206 = STK[STKP - 2].data[5];
tmp_207 = STK[STKP - 1].data[6];
tmp_199 = tmp_206 * tmp_207;
}
result[3] = tmp_198 + tmp_199;
}
{
float tmp_208;
float tmp_209;
{
float tmp_210;
float tmp_211;
{
float tmp_212;
float tmp_213;
tmp_212 = STK[STKP - 2].data[3];
tmp_213 = STK[STKP - 1].data[1];
tmp_210 = tmp_212 * tmp_213;
}
{
float tmp_214;
float tmp_215;
tmp_214 = STK[STKP - 2].data[4];
tmp_215 = STK[STKP - 1].data[4];
tmp_211 = tmp_214 * tmp_215;
}
tmp_208 = tmp_210 + tmp_211;
}
{
float tmp_216;
float tmp_217;
tmp_216 = STK[STKP - 2].data[5];
tmp_217 = STK[STKP - 1].data[7];
tmp_209 = tmp_216 * tmp_217;
}
result[4] = tmp_208 + tmp_209;
}
{
float tmp_218;
float tmp_219;
{
float tmp_220;
float tmp_221;
{
float tmp_222;
float tmp_223;
tmp_222 = STK[STKP - 2].data[3];
tmp_223 = STK[STKP - 1].data[2];
tmp_220 = tmp_222 * tmp_223;
}
{
float tmp_224;
float tmp_225;
tmp_224 = STK[STKP - 2].data[4];
tmp_225 = STK[STKP - 1].data[5];
tmp_221 = tmp_224 * tmp_225;
}
tmp_218 = tmp_220 + tmp_221;
}
{
float tmp_226;
float tmp_227;
tmp_226 = STK[STKP - 2].data[5];
tmp_227 = STK[STKP - 1].data[8];
tmp_219 = tmp_226 * tmp_227;
}
result[5] = tmp_218 + tmp_219;
}
{
float tmp_228;
float tmp_229;
{
float tmp_230;
float tmp_231;
{
float tmp_232;
float tmp_233;
tmp_232 = STK[STKP - 2].data[6];
tmp_233 = STK[STKP - 1].data[0];
tmp_230 = tmp_232 * tmp_233;
}
{
float tmp_234;
float tmp_235;
tmp_234 = STK[STKP - 2].data[7];
tmp_235 = STK[STKP - 1].data[3];
tmp_231 = tmp_234 * tmp_235;
}
tmp_228 = tmp_230 + tmp_231;
}
{
float tmp_236;
float tmp_237;
tmp_236 = STK[STKP - 2].data[8];
tmp_237 = STK[STKP - 1].data[6];
tmp_229 = tmp_236 * tmp_237;
}
result[6] = tmp_228 + tmp_229;
}
{
float tmp_238;
float tmp_239;
{
float tmp_240;
float tmp_241;
{
float tmp_242;
float tmp_243;
tmp_242 = STK[STKP - 2].data[6];
tmp_243 = STK[STKP - 1].data[1];
tmp_240 = tmp_242 * tmp_243;
}
{
float tmp_244;
float tmp_245;
tmp_244 = STK[STKP - 2].data[7];
tmp_245 = STK[STKP - 1].data[4];
tmp_241 = tmp_244 * tmp_245;
}
tmp_238 = tmp_240 + tmp_241;
}
{
float tmp_246;
float tmp_247;
tmp_246 = STK[STKP - 2].data[8];
tmp_247 = STK[STKP - 1].data[7];
tmp_239 = tmp_246 * tmp_247;
}
result[7] = tmp_238 + tmp_239;
}
{
float tmp_248;
float tmp_249;
{
float tmp_250;
float tmp_251;
{
float tmp_252;
float tmp_253;
tmp_252 = STK[STKP - 2].data[6];
tmp_253 = STK[STKP - 1].data[2];
tmp_250 = tmp_252 * tmp_253;
}
{
float tmp_254;
float tmp_255;
tmp_254 = STK[STKP - 2].data[7];
tmp_255 = STK[STKP - 1].data[5];
tmp_251 = tmp_254 * tmp_255;
}
tmp_248 = tmp_250 + tmp_251;
}
{
float tmp_256;
float tmp_257;
tmp_256 = STK[STKP - 2].data[8];
tmp_257 = STK[STKP - 1].data[8];
tmp_249 = tmp_256 * tmp_257;
}
result[8] = tmp_248 + tmp_249;
}
{
int i;
for (i = 0; i < 9; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 9;
STKP -= 1;
}

void
gen_mul_m3x3 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_258;
for (tmp_258 = 0; tmp_258 < 9; ++tmp_258)
{
switch (tmp_258)
{
case 0 :
{
compvar_t *tmp_259, *tmp_260;
tmp_259 = make_temporary();
{
compvar_t *tmp_261, *tmp_262;
tmp_261 = make_temporary();
{
compvar_t *tmp_263, *tmp_264;
tmp_263 = args[0][0];
tmp_264 = args[1][0];
emit_assign(make_lhs(tmp_261), make_op_rhs(OP_MUL, make_compvar_primary(tmp_263), make_compvar_primary(tmp_264)));
}
tmp_262 = make_temporary();
{
compvar_t *tmp_265, *tmp_266;
tmp_265 = args[0][1];
tmp_266 = args[1][3];
emit_assign(make_lhs(tmp_262), make_op_rhs(OP_MUL, make_compvar_primary(tmp_265), make_compvar_primary(tmp_266)));
}
emit_assign(make_lhs(tmp_259), make_op_rhs(OP_ADD, make_compvar_primary(tmp_261), make_compvar_primary(tmp_262)));
}
tmp_260 = make_temporary();
{
compvar_t *tmp_267, *tmp_268;
tmp_267 = args[0][2];
tmp_268 = args[1][6];
emit_assign(make_lhs(tmp_260), make_op_rhs(OP_MUL, make_compvar_primary(tmp_267), make_compvar_primary(tmp_268)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_259), make_compvar_primary(tmp_260)));
}
break;
case 1 :
{
compvar_t *tmp_269, *tmp_270;
tmp_269 = make_temporary();
{
compvar_t *tmp_271, *tmp_272;
tmp_271 = make_temporary();
{
compvar_t *tmp_273, *tmp_274;
tmp_273 = args[0][0];
tmp_274 = args[1][1];
emit_assign(make_lhs(tmp_271), make_op_rhs(OP_MUL, make_compvar_primary(tmp_273), make_compvar_primary(tmp_274)));
}
tmp_272 = make_temporary();
{
compvar_t *tmp_275, *tmp_276;
tmp_275 = args[0][1];
tmp_276 = args[1][4];
emit_assign(make_lhs(tmp_272), make_op_rhs(OP_MUL, make_compvar_primary(tmp_275), make_compvar_primary(tmp_276)));
}
emit_assign(make_lhs(tmp_269), make_op_rhs(OP_ADD, make_compvar_primary(tmp_271), make_compvar_primary(tmp_272)));
}
tmp_270 = make_temporary();
{
compvar_t *tmp_277, *tmp_278;
tmp_277 = args[0][2];
tmp_278 = args[1][7];
emit_assign(make_lhs(tmp_270), make_op_rhs(OP_MUL, make_compvar_primary(tmp_277), make_compvar_primary(tmp_278)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_269), make_compvar_primary(tmp_270)));
}
break;
case 2 :
{
compvar_t *tmp_279, *tmp_280;
tmp_279 = make_temporary();
{
compvar_t *tmp_281, *tmp_282;
tmp_281 = make_temporary();
{
compvar_t *tmp_283, *tmp_284;
tmp_283 = args[0][0];
tmp_284 = args[1][2];
emit_assign(make_lhs(tmp_281), make_op_rhs(OP_MUL, make_compvar_primary(tmp_283), make_compvar_primary(tmp_284)));
}
tmp_282 = make_temporary();
{
compvar_t *tmp_285, *tmp_286;
tmp_285 = args[0][1];
tmp_286 = args[1][5];
emit_assign(make_lhs(tmp_282), make_op_rhs(OP_MUL, make_compvar_primary(tmp_285), make_compvar_primary(tmp_286)));
}
emit_assign(make_lhs(tmp_279), make_op_rhs(OP_ADD, make_compvar_primary(tmp_281), make_compvar_primary(tmp_282)));
}
tmp_280 = make_temporary();
{
compvar_t *tmp_287, *tmp_288;
tmp_287 = args[0][2];
tmp_288 = args[1][8];
emit_assign(make_lhs(tmp_280), make_op_rhs(OP_MUL, make_compvar_primary(tmp_287), make_compvar_primary(tmp_288)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_279), make_compvar_primary(tmp_280)));
}
break;
case 3 :
{
compvar_t *tmp_289, *tmp_290;
tmp_289 = make_temporary();
{
compvar_t *tmp_291, *tmp_292;
tmp_291 = make_temporary();
{
compvar_t *tmp_293, *tmp_294;
tmp_293 = args[0][3];
tmp_294 = args[1][0];
emit_assign(make_lhs(tmp_291), make_op_rhs(OP_MUL, make_compvar_primary(tmp_293), make_compvar_primary(tmp_294)));
}
tmp_292 = make_temporary();
{
compvar_t *tmp_295, *tmp_296;
tmp_295 = args[0][4];
tmp_296 = args[1][3];
emit_assign(make_lhs(tmp_292), make_op_rhs(OP_MUL, make_compvar_primary(tmp_295), make_compvar_primary(tmp_296)));
}
emit_assign(make_lhs(tmp_289), make_op_rhs(OP_ADD, make_compvar_primary(tmp_291), make_compvar_primary(tmp_292)));
}
tmp_290 = make_temporary();
{
compvar_t *tmp_297, *tmp_298;
tmp_297 = args[0][5];
tmp_298 = args[1][6];
emit_assign(make_lhs(tmp_290), make_op_rhs(OP_MUL, make_compvar_primary(tmp_297), make_compvar_primary(tmp_298)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_289), make_compvar_primary(tmp_290)));
}
break;
case 4 :
{
compvar_t *tmp_299, *tmp_300;
tmp_299 = make_temporary();
{
compvar_t *tmp_301, *tmp_302;
tmp_301 = make_temporary();
{
compvar_t *tmp_303, *tmp_304;
tmp_303 = args[0][3];
tmp_304 = args[1][1];
emit_assign(make_lhs(tmp_301), make_op_rhs(OP_MUL, make_compvar_primary(tmp_303), make_compvar_primary(tmp_304)));
}
tmp_302 = make_temporary();
{
compvar_t *tmp_305, *tmp_306;
tmp_305 = args[0][4];
tmp_306 = args[1][4];
emit_assign(make_lhs(tmp_302), make_op_rhs(OP_MUL, make_compvar_primary(tmp_305), make_compvar_primary(tmp_306)));
}
emit_assign(make_lhs(tmp_299), make_op_rhs(OP_ADD, make_compvar_primary(tmp_301), make_compvar_primary(tmp_302)));
}
tmp_300 = make_temporary();
{
compvar_t *tmp_307, *tmp_308;
tmp_307 = args[0][5];
tmp_308 = args[1][7];
emit_assign(make_lhs(tmp_300), make_op_rhs(OP_MUL, make_compvar_primary(tmp_307), make_compvar_primary(tmp_308)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_299), make_compvar_primary(tmp_300)));
}
break;
case 5 :
{
compvar_t *tmp_309, *tmp_310;
tmp_309 = make_temporary();
{
compvar_t *tmp_311, *tmp_312;
tmp_311 = make_temporary();
{
compvar_t *tmp_313, *tmp_314;
tmp_313 = args[0][3];
tmp_314 = args[1][2];
emit_assign(make_lhs(tmp_311), make_op_rhs(OP_MUL, make_compvar_primary(tmp_313), make_compvar_primary(tmp_314)));
}
tmp_312 = make_temporary();
{
compvar_t *tmp_315, *tmp_316;
tmp_315 = args[0][4];
tmp_316 = args[1][5];
emit_assign(make_lhs(tmp_312), make_op_rhs(OP_MUL, make_compvar_primary(tmp_315), make_compvar_primary(tmp_316)));
}
emit_assign(make_lhs(tmp_309), make_op_rhs(OP_ADD, make_compvar_primary(tmp_311), make_compvar_primary(tmp_312)));
}
tmp_310 = make_temporary();
{
compvar_t *tmp_317, *tmp_318;
tmp_317 = args[0][5];
tmp_318 = args[1][8];
emit_assign(make_lhs(tmp_310), make_op_rhs(OP_MUL, make_compvar_primary(tmp_317), make_compvar_primary(tmp_318)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_309), make_compvar_primary(tmp_310)));
}
break;
case 6 :
{
compvar_t *tmp_319, *tmp_320;
tmp_319 = make_temporary();
{
compvar_t *tmp_321, *tmp_322;
tmp_321 = make_temporary();
{
compvar_t *tmp_323, *tmp_324;
tmp_323 = args[0][6];
tmp_324 = args[1][0];
emit_assign(make_lhs(tmp_321), make_op_rhs(OP_MUL, make_compvar_primary(tmp_323), make_compvar_primary(tmp_324)));
}
tmp_322 = make_temporary();
{
compvar_t *tmp_325, *tmp_326;
tmp_325 = args[0][7];
tmp_326 = args[1][3];
emit_assign(make_lhs(tmp_322), make_op_rhs(OP_MUL, make_compvar_primary(tmp_325), make_compvar_primary(tmp_326)));
}
emit_assign(make_lhs(tmp_319), make_op_rhs(OP_ADD, make_compvar_primary(tmp_321), make_compvar_primary(tmp_322)));
}
tmp_320 = make_temporary();
{
compvar_t *tmp_327, *tmp_328;
tmp_327 = args[0][8];
tmp_328 = args[1][6];
emit_assign(make_lhs(tmp_320), make_op_rhs(OP_MUL, make_compvar_primary(tmp_327), make_compvar_primary(tmp_328)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_319), make_compvar_primary(tmp_320)));
}
break;
case 7 :
{
compvar_t *tmp_329, *tmp_330;
tmp_329 = make_temporary();
{
compvar_t *tmp_331, *tmp_332;
tmp_331 = make_temporary();
{
compvar_t *tmp_333, *tmp_334;
tmp_333 = args[0][6];
tmp_334 = args[1][1];
emit_assign(make_lhs(tmp_331), make_op_rhs(OP_MUL, make_compvar_primary(tmp_333), make_compvar_primary(tmp_334)));
}
tmp_332 = make_temporary();
{
compvar_t *tmp_335, *tmp_336;
tmp_335 = args[0][7];
tmp_336 = args[1][4];
emit_assign(make_lhs(tmp_332), make_op_rhs(OP_MUL, make_compvar_primary(tmp_335), make_compvar_primary(tmp_336)));
}
emit_assign(make_lhs(tmp_329), make_op_rhs(OP_ADD, make_compvar_primary(tmp_331), make_compvar_primary(tmp_332)));
}
tmp_330 = make_temporary();
{
compvar_t *tmp_337, *tmp_338;
tmp_337 = args[0][8];
tmp_338 = args[1][7];
emit_assign(make_lhs(tmp_330), make_op_rhs(OP_MUL, make_compvar_primary(tmp_337), make_compvar_primary(tmp_338)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_329), make_compvar_primary(tmp_330)));
}
break;
case 8 :
{
compvar_t *tmp_339, *tmp_340;
tmp_339 = make_temporary();
{
compvar_t *tmp_341, *tmp_342;
tmp_341 = make_temporary();
{
compvar_t *tmp_343, *tmp_344;
tmp_343 = args[0][6];
tmp_344 = args[1][2];
emit_assign(make_lhs(tmp_341), make_op_rhs(OP_MUL, make_compvar_primary(tmp_343), make_compvar_primary(tmp_344)));
}
tmp_342 = make_temporary();
{
compvar_t *tmp_345, *tmp_346;
tmp_345 = args[0][7];
tmp_346 = args[1][5];
emit_assign(make_lhs(tmp_342), make_op_rhs(OP_MUL, make_compvar_primary(tmp_345), make_compvar_primary(tmp_346)));
}
emit_assign(make_lhs(tmp_339), make_op_rhs(OP_ADD, make_compvar_primary(tmp_341), make_compvar_primary(tmp_342)));
}
tmp_340 = make_temporary();
{
compvar_t *tmp_347, *tmp_348;
tmp_347 = args[0][8];
tmp_348 = args[1][8];
emit_assign(make_lhs(tmp_340), make_op_rhs(OP_MUL, make_compvar_primary(tmp_347), make_compvar_primary(tmp_348)));
}
emit_assign(make_lhs(result[tmp_258]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_339), make_compvar_primary(tmp_340)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_v2m2x2 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_349;
float tmp_350;
{
float tmp_351;
float tmp_352;
tmp_351 = STK[STKP - 2].data[0];
tmp_352 = STK[STKP - 1].data[0];
tmp_349 = tmp_351 * tmp_352;
}
{
float tmp_353;
float tmp_354;
tmp_353 = STK[STKP - 2].data[1];
tmp_354 = STK[STKP - 1].data[2];
tmp_350 = tmp_353 * tmp_354;
}
result[0] = tmp_349 + tmp_350;
}
{
float tmp_355;
float tmp_356;
{
float tmp_357;
float tmp_358;
tmp_357 = STK[STKP - 2].data[0];
tmp_358 = STK[STKP - 1].data[1];
tmp_355 = tmp_357 * tmp_358;
}
{
float tmp_359;
float tmp_360;
tmp_359 = STK[STKP - 2].data[1];
tmp_360 = STK[STKP - 1].data[3];
tmp_356 = tmp_359 * tmp_360;
}
result[1] = tmp_355 + tmp_356;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_mul_v2m2x2 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_361;
for (tmp_361 = 0; tmp_361 < 2; ++tmp_361)
{
switch (tmp_361)
{
case 0 :
{
compvar_t *tmp_362, *tmp_363;
tmp_362 = make_temporary();
{
compvar_t *tmp_364, *tmp_365;
tmp_364 = args[0][0];
tmp_365 = args[1][0];
emit_assign(make_lhs(tmp_362), make_op_rhs(OP_MUL, make_compvar_primary(tmp_364), make_compvar_primary(tmp_365)));
}
tmp_363 = make_temporary();
{
compvar_t *tmp_366, *tmp_367;
tmp_366 = args[0][1];
tmp_367 = args[1][2];
emit_assign(make_lhs(tmp_363), make_op_rhs(OP_MUL, make_compvar_primary(tmp_366), make_compvar_primary(tmp_367)));
}
emit_assign(make_lhs(result[tmp_361]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_362), make_compvar_primary(tmp_363)));
}
break;
case 1 :
{
compvar_t *tmp_368, *tmp_369;
tmp_368 = make_temporary();
{
compvar_t *tmp_370, *tmp_371;
tmp_370 = args[0][0];
tmp_371 = args[1][1];
emit_assign(make_lhs(tmp_368), make_op_rhs(OP_MUL, make_compvar_primary(tmp_370), make_compvar_primary(tmp_371)));
}
tmp_369 = make_temporary();
{
compvar_t *tmp_372, *tmp_373;
tmp_372 = args[0][1];
tmp_373 = args[1][3];
emit_assign(make_lhs(tmp_369), make_op_rhs(OP_MUL, make_compvar_primary(tmp_372), make_compvar_primary(tmp_373)));
}
emit_assign(make_lhs(result[tmp_361]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_368), make_compvar_primary(tmp_369)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_v3m3x3 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_374;
float tmp_375;
{
float tmp_376;
float tmp_377;
{
float tmp_378;
float tmp_379;
tmp_378 = STK[STKP - 2].data[0];
tmp_379 = STK[STKP - 1].data[0];
tmp_376 = tmp_378 * tmp_379;
}
{
float tmp_380;
float tmp_381;
tmp_380 = STK[STKP - 2].data[1];
tmp_381 = STK[STKP - 1].data[3];
tmp_377 = tmp_380 * tmp_381;
}
tmp_374 = tmp_376 + tmp_377;
}
{
float tmp_382;
float tmp_383;
tmp_382 = STK[STKP - 2].data[2];
tmp_383 = STK[STKP - 1].data[6];
tmp_375 = tmp_382 * tmp_383;
}
result[0] = tmp_374 + tmp_375;
}
{
float tmp_384;
float tmp_385;
{
float tmp_386;
float tmp_387;
{
float tmp_388;
float tmp_389;
tmp_388 = STK[STKP - 2].data[0];
tmp_389 = STK[STKP - 1].data[1];
tmp_386 = tmp_388 * tmp_389;
}
{
float tmp_390;
float tmp_391;
tmp_390 = STK[STKP - 2].data[1];
tmp_391 = STK[STKP - 1].data[4];
tmp_387 = tmp_390 * tmp_391;
}
tmp_384 = tmp_386 + tmp_387;
}
{
float tmp_392;
float tmp_393;
tmp_392 = STK[STKP - 2].data[2];
tmp_393 = STK[STKP - 1].data[7];
tmp_385 = tmp_392 * tmp_393;
}
result[1] = tmp_384 + tmp_385;
}
{
float tmp_394;
float tmp_395;
{
float tmp_396;
float tmp_397;
{
float tmp_398;
float tmp_399;
tmp_398 = STK[STKP - 2].data[0];
tmp_399 = STK[STKP - 1].data[2];
tmp_396 = tmp_398 * tmp_399;
}
{
float tmp_400;
float tmp_401;
tmp_400 = STK[STKP - 2].data[1];
tmp_401 = STK[STKP - 1].data[5];
tmp_397 = tmp_400 * tmp_401;
}
tmp_394 = tmp_396 + tmp_397;
}
{
float tmp_402;
float tmp_403;
tmp_402 = STK[STKP - 2].data[2];
tmp_403 = STK[STKP - 1].data[8];
tmp_395 = tmp_402 * tmp_403;
}
result[2] = tmp_394 + tmp_395;
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 3;
STKP -= 1;
}

void
gen_mul_v3m3x3 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_404;
for (tmp_404 = 0; tmp_404 < 3; ++tmp_404)
{
switch (tmp_404)
{
case 0 :
{
compvar_t *tmp_405, *tmp_406;
tmp_405 = make_temporary();
{
compvar_t *tmp_407, *tmp_408;
tmp_407 = make_temporary();
{
compvar_t *tmp_409, *tmp_410;
tmp_409 = args[0][0];
tmp_410 = args[1][0];
emit_assign(make_lhs(tmp_407), make_op_rhs(OP_MUL, make_compvar_primary(tmp_409), make_compvar_primary(tmp_410)));
}
tmp_408 = make_temporary();
{
compvar_t *tmp_411, *tmp_412;
tmp_411 = args[0][1];
tmp_412 = args[1][3];
emit_assign(make_lhs(tmp_408), make_op_rhs(OP_MUL, make_compvar_primary(tmp_411), make_compvar_primary(tmp_412)));
}
emit_assign(make_lhs(tmp_405), make_op_rhs(OP_ADD, make_compvar_primary(tmp_407), make_compvar_primary(tmp_408)));
}
tmp_406 = make_temporary();
{
compvar_t *tmp_413, *tmp_414;
tmp_413 = args[0][2];
tmp_414 = args[1][6];
emit_assign(make_lhs(tmp_406), make_op_rhs(OP_MUL, make_compvar_primary(tmp_413), make_compvar_primary(tmp_414)));
}
emit_assign(make_lhs(result[tmp_404]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_405), make_compvar_primary(tmp_406)));
}
break;
case 1 :
{
compvar_t *tmp_415, *tmp_416;
tmp_415 = make_temporary();
{
compvar_t *tmp_417, *tmp_418;
tmp_417 = make_temporary();
{
compvar_t *tmp_419, *tmp_420;
tmp_419 = args[0][0];
tmp_420 = args[1][1];
emit_assign(make_lhs(tmp_417), make_op_rhs(OP_MUL, make_compvar_primary(tmp_419), make_compvar_primary(tmp_420)));
}
tmp_418 = make_temporary();
{
compvar_t *tmp_421, *tmp_422;
tmp_421 = args[0][1];
tmp_422 = args[1][4];
emit_assign(make_lhs(tmp_418), make_op_rhs(OP_MUL, make_compvar_primary(tmp_421), make_compvar_primary(tmp_422)));
}
emit_assign(make_lhs(tmp_415), make_op_rhs(OP_ADD, make_compvar_primary(tmp_417), make_compvar_primary(tmp_418)));
}
tmp_416 = make_temporary();
{
compvar_t *tmp_423, *tmp_424;
tmp_423 = args[0][2];
tmp_424 = args[1][7];
emit_assign(make_lhs(tmp_416), make_op_rhs(OP_MUL, make_compvar_primary(tmp_423), make_compvar_primary(tmp_424)));
}
emit_assign(make_lhs(result[tmp_404]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_415), make_compvar_primary(tmp_416)));
}
break;
case 2 :
{
compvar_t *tmp_425, *tmp_426;
tmp_425 = make_temporary();
{
compvar_t *tmp_427, *tmp_428;
tmp_427 = make_temporary();
{
compvar_t *tmp_429, *tmp_430;
tmp_429 = args[0][0];
tmp_430 = args[1][2];
emit_assign(make_lhs(tmp_427), make_op_rhs(OP_MUL, make_compvar_primary(tmp_429), make_compvar_primary(tmp_430)));
}
tmp_428 = make_temporary();
{
compvar_t *tmp_431, *tmp_432;
tmp_431 = args[0][1];
tmp_432 = args[1][5];
emit_assign(make_lhs(tmp_428), make_op_rhs(OP_MUL, make_compvar_primary(tmp_431), make_compvar_primary(tmp_432)));
}
emit_assign(make_lhs(tmp_425), make_op_rhs(OP_ADD, make_compvar_primary(tmp_427), make_compvar_primary(tmp_428)));
}
tmp_426 = make_temporary();
{
compvar_t *tmp_433, *tmp_434;
tmp_433 = args[0][2];
tmp_434 = args[1][8];
emit_assign(make_lhs(tmp_426), make_op_rhs(OP_MUL, make_compvar_primary(tmp_433), make_compvar_primary(tmp_434)));
}
emit_assign(make_lhs(result[tmp_404]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_425), make_compvar_primary(tmp_426)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_m2x2v2 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_435;
float tmp_436;
{
float tmp_437;
float tmp_438;
tmp_437 = STK[STKP - 2].data[0];
tmp_438 = STK[STKP - 1].data[0];
tmp_435 = tmp_437 * tmp_438;
}
{
float tmp_439;
float tmp_440;
tmp_439 = STK[STKP - 2].data[1];
tmp_440 = STK[STKP - 1].data[1];
tmp_436 = tmp_439 * tmp_440;
}
result[0] = tmp_435 + tmp_436;
}
{
float tmp_441;
float tmp_442;
{
float tmp_443;
float tmp_444;
tmp_443 = STK[STKP - 2].data[2];
tmp_444 = STK[STKP - 1].data[0];
tmp_441 = tmp_443 * tmp_444;
}
{
float tmp_445;
float tmp_446;
tmp_445 = STK[STKP - 2].data[3];
tmp_446 = STK[STKP - 1].data[1];
tmp_442 = tmp_445 * tmp_446;
}
result[1] = tmp_441 + tmp_442;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_mul_m2x2v2 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_447;
for (tmp_447 = 0; tmp_447 < 2; ++tmp_447)
{
switch (tmp_447)
{
case 0 :
{
compvar_t *tmp_448, *tmp_449;
tmp_448 = make_temporary();
{
compvar_t *tmp_450, *tmp_451;
tmp_450 = args[0][0];
tmp_451 = args[1][0];
emit_assign(make_lhs(tmp_448), make_op_rhs(OP_MUL, make_compvar_primary(tmp_450), make_compvar_primary(tmp_451)));
}
tmp_449 = make_temporary();
{
compvar_t *tmp_452, *tmp_453;
tmp_452 = args[0][1];
tmp_453 = args[1][1];
emit_assign(make_lhs(tmp_449), make_op_rhs(OP_MUL, make_compvar_primary(tmp_452), make_compvar_primary(tmp_453)));
}
emit_assign(make_lhs(result[tmp_447]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_448), make_compvar_primary(tmp_449)));
}
break;
case 1 :
{
compvar_t *tmp_454, *tmp_455;
tmp_454 = make_temporary();
{
compvar_t *tmp_456, *tmp_457;
tmp_456 = args[0][2];
tmp_457 = args[1][0];
emit_assign(make_lhs(tmp_454), make_op_rhs(OP_MUL, make_compvar_primary(tmp_456), make_compvar_primary(tmp_457)));
}
tmp_455 = make_temporary();
{
compvar_t *tmp_458, *tmp_459;
tmp_458 = args[0][3];
tmp_459 = args[1][1];
emit_assign(make_lhs(tmp_455), make_op_rhs(OP_MUL, make_compvar_primary(tmp_458), make_compvar_primary(tmp_459)));
}
emit_assign(make_lhs(result[tmp_447]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_454), make_compvar_primary(tmp_455)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_m3x3v3 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_460;
float tmp_461;
{
float tmp_462;
float tmp_463;
{
float tmp_464;
float tmp_465;
tmp_464 = STK[STKP - 2].data[0];
tmp_465 = STK[STKP - 1].data[0];
tmp_462 = tmp_464 * tmp_465;
}
{
float tmp_466;
float tmp_467;
tmp_466 = STK[STKP - 2].data[1];
tmp_467 = STK[STKP - 1].data[1];
tmp_463 = tmp_466 * tmp_467;
}
tmp_460 = tmp_462 + tmp_463;
}
{
float tmp_468;
float tmp_469;
tmp_468 = STK[STKP - 2].data[2];
tmp_469 = STK[STKP - 1].data[2];
tmp_461 = tmp_468 * tmp_469;
}
result[0] = tmp_460 + tmp_461;
}
{
float tmp_470;
float tmp_471;
{
float tmp_472;
float tmp_473;
{
float tmp_474;
float tmp_475;
tmp_474 = STK[STKP - 2].data[3];
tmp_475 = STK[STKP - 1].data[0];
tmp_472 = tmp_474 * tmp_475;
}
{
float tmp_476;
float tmp_477;
tmp_476 = STK[STKP - 2].data[4];
tmp_477 = STK[STKP - 1].data[1];
tmp_473 = tmp_476 * tmp_477;
}
tmp_470 = tmp_472 + tmp_473;
}
{
float tmp_478;
float tmp_479;
tmp_478 = STK[STKP - 2].data[5];
tmp_479 = STK[STKP - 1].data[2];
tmp_471 = tmp_478 * tmp_479;
}
result[1] = tmp_470 + tmp_471;
}
{
float tmp_480;
float tmp_481;
{
float tmp_482;
float tmp_483;
{
float tmp_484;
float tmp_485;
tmp_484 = STK[STKP - 2].data[6];
tmp_485 = STK[STKP - 1].data[0];
tmp_482 = tmp_484 * tmp_485;
}
{
float tmp_486;
float tmp_487;
tmp_486 = STK[STKP - 2].data[7];
tmp_487 = STK[STKP - 1].data[1];
tmp_483 = tmp_486 * tmp_487;
}
tmp_480 = tmp_482 + tmp_483;
}
{
float tmp_488;
float tmp_489;
tmp_488 = STK[STKP - 2].data[8];
tmp_489 = STK[STKP - 1].data[2];
tmp_481 = tmp_488 * tmp_489;
}
result[2] = tmp_480 + tmp_481;
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 3;
STKP -= 1;
}

void
gen_mul_m3x3v3 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_490;
for (tmp_490 = 0; tmp_490 < 3; ++tmp_490)
{
switch (tmp_490)
{
case 0 :
{
compvar_t *tmp_491, *tmp_492;
tmp_491 = make_temporary();
{
compvar_t *tmp_493, *tmp_494;
tmp_493 = make_temporary();
{
compvar_t *tmp_495, *tmp_496;
tmp_495 = args[0][0];
tmp_496 = args[1][0];
emit_assign(make_lhs(tmp_493), make_op_rhs(OP_MUL, make_compvar_primary(tmp_495), make_compvar_primary(tmp_496)));
}
tmp_494 = make_temporary();
{
compvar_t *tmp_497, *tmp_498;
tmp_497 = args[0][1];
tmp_498 = args[1][1];
emit_assign(make_lhs(tmp_494), make_op_rhs(OP_MUL, make_compvar_primary(tmp_497), make_compvar_primary(tmp_498)));
}
emit_assign(make_lhs(tmp_491), make_op_rhs(OP_ADD, make_compvar_primary(tmp_493), make_compvar_primary(tmp_494)));
}
tmp_492 = make_temporary();
{
compvar_t *tmp_499, *tmp_500;
tmp_499 = args[0][2];
tmp_500 = args[1][2];
emit_assign(make_lhs(tmp_492), make_op_rhs(OP_MUL, make_compvar_primary(tmp_499), make_compvar_primary(tmp_500)));
}
emit_assign(make_lhs(result[tmp_490]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_491), make_compvar_primary(tmp_492)));
}
break;
case 1 :
{
compvar_t *tmp_501, *tmp_502;
tmp_501 = make_temporary();
{
compvar_t *tmp_503, *tmp_504;
tmp_503 = make_temporary();
{
compvar_t *tmp_505, *tmp_506;
tmp_505 = args[0][3];
tmp_506 = args[1][0];
emit_assign(make_lhs(tmp_503), make_op_rhs(OP_MUL, make_compvar_primary(tmp_505), make_compvar_primary(tmp_506)));
}
tmp_504 = make_temporary();
{
compvar_t *tmp_507, *tmp_508;
tmp_507 = args[0][4];
tmp_508 = args[1][1];
emit_assign(make_lhs(tmp_504), make_op_rhs(OP_MUL, make_compvar_primary(tmp_507), make_compvar_primary(tmp_508)));
}
emit_assign(make_lhs(tmp_501), make_op_rhs(OP_ADD, make_compvar_primary(tmp_503), make_compvar_primary(tmp_504)));
}
tmp_502 = make_temporary();
{
compvar_t *tmp_509, *tmp_510;
tmp_509 = args[0][5];
tmp_510 = args[1][2];
emit_assign(make_lhs(tmp_502), make_op_rhs(OP_MUL, make_compvar_primary(tmp_509), make_compvar_primary(tmp_510)));
}
emit_assign(make_lhs(result[tmp_490]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_501), make_compvar_primary(tmp_502)));
}
break;
case 2 :
{
compvar_t *tmp_511, *tmp_512;
tmp_511 = make_temporary();
{
compvar_t *tmp_513, *tmp_514;
tmp_513 = make_temporary();
{
compvar_t *tmp_515, *tmp_516;
tmp_515 = args[0][6];
tmp_516 = args[1][0];
emit_assign(make_lhs(tmp_513), make_op_rhs(OP_MUL, make_compvar_primary(tmp_515), make_compvar_primary(tmp_516)));
}
tmp_514 = make_temporary();
{
compvar_t *tmp_517, *tmp_518;
tmp_517 = args[0][7];
tmp_518 = args[1][1];
emit_assign(make_lhs(tmp_514), make_op_rhs(OP_MUL, make_compvar_primary(tmp_517), make_compvar_primary(tmp_518)));
}
emit_assign(make_lhs(tmp_511), make_op_rhs(OP_ADD, make_compvar_primary(tmp_513), make_compvar_primary(tmp_514)));
}
tmp_512 = make_temporary();
{
compvar_t *tmp_519, *tmp_520;
tmp_519 = args[0][8];
tmp_520 = args[1][2];
emit_assign(make_lhs(tmp_512), make_op_rhs(OP_MUL, make_compvar_primary(tmp_519), make_compvar_primary(tmp_520)));
}
emit_assign(make_lhs(result[tmp_490]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_511), make_compvar_primary(tmp_512)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_521;
float tmp_522;
tmp_521 = STK[STKP - 2].data[0];
tmp_522 = STK[STKP - 1].data[0];
result[0] = tmp_521 * tmp_522;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_mul_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_523;
for (tmp_523 = 0; tmp_523 < 1; ++tmp_523)
{
switch (tmp_523)
{
case 0 :
{
compvar_t *tmp_524, *tmp_525;
tmp_524 = args[0][0];
tmp_525 = args[1][0];
emit_assign(make_lhs(result[tmp_523]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_524), make_compvar_primary(tmp_525)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_mul_s (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_526;
for (tmp_526 = 0; tmp_526 < STK[STKP - 2].length; ++tmp_526)
{
{
float tmp_527;
float tmp_528;
tmp_527 = STK[STKP - 2].data[tmp_526];
tmp_528 = STK[STKP - 1].data[0];
result[tmp_526] = tmp_527 * tmp_528;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_mul_s (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_529;
for (tmp_529 = 0; tmp_529 < arglengths[0]; ++tmp_529)
{
{
compvar_t *tmp_530, *tmp_531;
tmp_530 = args[0][tmp_529];
tmp_531 = args[1][0];
emit_assign(make_lhs(result[tmp_529]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_530), make_compvar_primary(tmp_531)));
}
}
}
}

void
builtin_mul_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_532;
for (tmp_532 = 0; tmp_532 < STK[STKP - 2].length; ++tmp_532)
{
{
float tmp_533;
float tmp_534;
tmp_533 = STK[STKP - 2].data[tmp_532];
tmp_534 = STK[STKP - 1].data[tmp_532];
result[tmp_532] = tmp_533 * tmp_534;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_mul_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_535;
for (tmp_535 = 0; tmp_535 < arglengths[0]; ++tmp_535)
{
{
compvar_t *tmp_536, *tmp_537;
tmp_536 = args[0][tmp_535];
tmp_537 = args[1][tmp_535];
emit_assign(make_lhs(result[tmp_535]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_536), make_compvar_primary(tmp_537)));
}
}
}
}

void
builtin_div_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_538;
{
float tmp_539;
float tmp_540;
tmp_539 = STK[STKP - 1].data[0];
tmp_540 = 0;
tmp_538 = (tmp_539 == tmp_540);
}
if (tmp_538)
{
{
float tmp_541;
float tmp_542;
tmp_541 = STK[STKP - 1].data[1];
tmp_542 = 0;
tmp_538 = (tmp_541 == tmp_542);
}
}
if (tmp_538)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_543;

{
float tmp_544 = 0.0, tmp_545;
{
float tmp_546;
float tmp_547;
tmp_546 = STK[STKP - 1].data[0];
tmp_547 = STK[STKP - 1].data[0];
tmp_545 = tmp_546 * tmp_547;
}
tmp_544 += tmp_545;
{
float tmp_548;
float tmp_549;
tmp_548 = STK[STKP - 1].data[1];
tmp_549 = STK[STKP - 1].data[1];
tmp_545 = tmp_548 * tmp_549;
}
tmp_544 += tmp_545;
tmp_543 = tmp_544;
}

{
float tmp_550;
float tmp_551;
{
float tmp_552 = 0.0, tmp_553;
{
float tmp_554;
float tmp_555;
tmp_554 = STK[STKP - 2].data[0];
tmp_555 = STK[STKP - 1].data[0];
tmp_553 = tmp_554 * tmp_555;
}
tmp_552 += tmp_553;
{
float tmp_556;
float tmp_557;
tmp_556 = STK[STKP - 2].data[1];
tmp_557 = STK[STKP - 1].data[1];
tmp_553 = tmp_556 * tmp_557;
}
tmp_552 += tmp_553;
tmp_550 = tmp_552;
}
tmp_551 = tmp_543;
result[0] = tmp_550 / tmp_551;
}
{
float tmp_558;
float tmp_559;
{
float tmp_560;
float tmp_561;
{
float tmp_562;
float tmp_563;
{
float tmp_564;
tmp_564 = STK[STKP - 2].data[0];
tmp_562 = -tmp_564;
}
tmp_563 = STK[STKP - 1].data[1];
tmp_560 = tmp_562 * tmp_563;
}
{
float tmp_565;
float tmp_566;
tmp_565 = STK[STKP - 1].data[0];
tmp_566 = STK[STKP - 2].data[1];
tmp_561 = tmp_565 * tmp_566;
}
tmp_558 = tmp_560 + tmp_561;
}
tmp_559 = tmp_543;
result[1] = tmp_558 / tmp_559;
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_div_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_567;
tmp_567 = make_temporary();
{
compvar_t *tmp_568, *tmp_569;
tmp_568 = args[1][0];
tmp_569 = make_temporary();
emit_assign(make_lhs(tmp_569), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_567), make_op_rhs(OP_EQ, make_compvar_primary(tmp_568), make_compvar_primary(tmp_569)));
}
start_if_cond(make_compvar_rhs(tmp_567));
{
compvar_t *tmp_570, *tmp_571;
tmp_570 = args[1][1];
tmp_571 = make_temporary();
emit_assign(make_lhs(tmp_571), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_567), make_op_rhs(OP_EQ, make_compvar_primary(tmp_570), make_compvar_primary(tmp_571)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_567));
{
int tmp_572;
for (tmp_572 = 0; tmp_572 < 2; ++tmp_572)
{
switch (tmp_572)
{
case 0 :
emit_assign(make_lhs(result[tmp_572]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_572]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_573;

if (2 == 1)
{
tmp_573 = make_temporary();
{
compvar_t *tmp_577, *tmp_578;
tmp_577 = args[1][0];
tmp_578 = args[1][0];
emit_assign(make_lhs(tmp_573), make_op_rhs(OP_MUL, make_compvar_primary(tmp_577), make_compvar_primary(tmp_578)));
}

}
else
{
compvar_t *tmp_574, *tmp_575;
int tmp_576;
tmp_573 = make_temporary();
tmp_574 = make_temporary();
{
compvar_t *tmp_579, *tmp_580;
tmp_579 = args[1][0];
tmp_580 = args[1][0];
emit_assign(make_lhs(tmp_574), make_op_rhs(OP_MUL, make_compvar_primary(tmp_579), make_compvar_primary(tmp_580)));
}
tmp_575 = make_temporary();
{
compvar_t *tmp_581, *tmp_582;
tmp_581 = args[1][1];
tmp_582 = args[1][1];
emit_assign(make_lhs(tmp_575), make_op_rhs(OP_MUL, make_compvar_primary(tmp_581), make_compvar_primary(tmp_582)));
}
emit_assign(make_lhs(tmp_573), make_op_rhs(OP_ADD, make_compvar_primary(tmp_574), make_compvar_primary(tmp_575)));
for (tmp_576 = 2; tmp_576 < 2; ++tmp_576)
{
tmp_574 = make_temporary();
{
compvar_t *tmp_583, *tmp_584;
tmp_583 = args[1][tmp_576];
tmp_584 = args[1][tmp_576];
emit_assign(make_lhs(tmp_574), make_op_rhs(OP_MUL, make_compvar_primary(tmp_583), make_compvar_primary(tmp_584)));
}
emit_assign(make_lhs(tmp_573), make_op_rhs(OP_ADD, make_compvar_primary(tmp_573), make_compvar_primary(tmp_574)));
}
}

{
int tmp_585;
for (tmp_585 = 0; tmp_585 < 2; ++tmp_585)
{
switch (tmp_585)
{
case 0 :
{
compvar_t *tmp_586, *tmp_587;
if (2 == 1)
{
tmp_586 = make_temporary();
{
compvar_t *tmp_591, *tmp_592;
tmp_591 = args[0][0];
tmp_592 = args[1][0];
emit_assign(make_lhs(tmp_586), make_op_rhs(OP_MUL, make_compvar_primary(tmp_591), make_compvar_primary(tmp_592)));
}

}
else
{
compvar_t *tmp_588, *tmp_589;
int tmp_590;
tmp_586 = make_temporary();
tmp_588 = make_temporary();
{
compvar_t *tmp_593, *tmp_594;
tmp_593 = args[0][0];
tmp_594 = args[1][0];
emit_assign(make_lhs(tmp_588), make_op_rhs(OP_MUL, make_compvar_primary(tmp_593), make_compvar_primary(tmp_594)));
}
tmp_589 = make_temporary();
{
compvar_t *tmp_595, *tmp_596;
tmp_595 = args[0][1];
tmp_596 = args[1][1];
emit_assign(make_lhs(tmp_589), make_op_rhs(OP_MUL, make_compvar_primary(tmp_595), make_compvar_primary(tmp_596)));
}
emit_assign(make_lhs(tmp_586), make_op_rhs(OP_ADD, make_compvar_primary(tmp_588), make_compvar_primary(tmp_589)));
for (tmp_590 = 2; tmp_590 < 2; ++tmp_590)
{
tmp_588 = make_temporary();
{
compvar_t *tmp_597, *tmp_598;
tmp_597 = args[0][tmp_590];
tmp_598 = args[1][tmp_590];
emit_assign(make_lhs(tmp_588), make_op_rhs(OP_MUL, make_compvar_primary(tmp_597), make_compvar_primary(tmp_598)));
}
emit_assign(make_lhs(tmp_586), make_op_rhs(OP_ADD, make_compvar_primary(tmp_586), make_compvar_primary(tmp_588)));
}
}
tmp_587 = tmp_573;
emit_assign(make_lhs(result[tmp_585]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_586), make_compvar_primary(tmp_587)));
}
break;
case 1 :
{
compvar_t *tmp_599, *tmp_600;
tmp_599 = make_temporary();
{
compvar_t *tmp_601, *tmp_602;
tmp_601 = make_temporary();
{
compvar_t *tmp_603, *tmp_604;
tmp_603 = make_temporary();
{
compvar_t *tmp_605;
tmp_605 = args[0][0];
emit_assign(make_lhs(tmp_603), make_op_rhs(OP_NEG, make_compvar_primary(tmp_605)));
}
tmp_604 = args[1][1];
emit_assign(make_lhs(tmp_601), make_op_rhs(OP_MUL, make_compvar_primary(tmp_603), make_compvar_primary(tmp_604)));
}
tmp_602 = make_temporary();
{
compvar_t *tmp_606, *tmp_607;
tmp_606 = args[1][0];
tmp_607 = args[0][1];
emit_assign(make_lhs(tmp_602), make_op_rhs(OP_MUL, make_compvar_primary(tmp_606), make_compvar_primary(tmp_607)));
}
emit_assign(make_lhs(tmp_599), make_op_rhs(OP_ADD, make_compvar_primary(tmp_601), make_compvar_primary(tmp_602)));
}
tmp_600 = tmp_573;
emit_assign(make_lhs(result[tmp_585]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_599), make_compvar_primary(tmp_600)));
}
break;
default :
assert(0);
}
}
}
}
end_if_cond();
}
}

void
builtin_div_1_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_608;

{
float tmp_609 = 0.0, tmp_610;
{
float tmp_611;
float tmp_612;
tmp_611 = STK[STKP - 1].data[0];
tmp_612 = STK[STKP - 1].data[0];
tmp_610 = tmp_611 * tmp_612;
}
tmp_609 += tmp_610;
{
float tmp_613;
float tmp_614;
tmp_613 = STK[STKP - 1].data[1];
tmp_614 = STK[STKP - 1].data[1];
tmp_610 = tmp_613 * tmp_614;
}
tmp_609 += tmp_610;
tmp_608 = tmp_609;
}

{
float tmp_615;
{
float tmp_616;
float tmp_617;
tmp_616 = tmp_608;
tmp_617 = 0;
tmp_615 = (tmp_616 == tmp_617);
}
if (tmp_615)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_618;
float tmp_619;
{
float tmp_620;
float tmp_621;
tmp_620 = STK[STKP - 2].data[0];
tmp_621 = STK[STKP - 1].data[0];
tmp_618 = tmp_620 * tmp_621;
}
tmp_619 = tmp_608;
result[0] = tmp_618 / tmp_619;
}
{
float tmp_622;
{
float tmp_623;
float tmp_624;
{
float tmp_625;
float tmp_626;
tmp_625 = STK[STKP - 2].data[0];
tmp_626 = STK[STKP - 1].data[1];
tmp_623 = tmp_625 * tmp_626;
}
tmp_624 = tmp_608;
tmp_622 = tmp_623 / tmp_624;
}
result[1] = -tmp_622;
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_div_1_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_627;

if (2 == 1)
{
tmp_627 = make_temporary();
{
compvar_t *tmp_631, *tmp_632;
tmp_631 = args[1][0];
tmp_632 = args[1][0];
emit_assign(make_lhs(tmp_627), make_op_rhs(OP_MUL, make_compvar_primary(tmp_631), make_compvar_primary(tmp_632)));
}

}
else
{
compvar_t *tmp_628, *tmp_629;
int tmp_630;
tmp_627 = make_temporary();
tmp_628 = make_temporary();
{
compvar_t *tmp_633, *tmp_634;
tmp_633 = args[1][0];
tmp_634 = args[1][0];
emit_assign(make_lhs(tmp_628), make_op_rhs(OP_MUL, make_compvar_primary(tmp_633), make_compvar_primary(tmp_634)));
}
tmp_629 = make_temporary();
{
compvar_t *tmp_635, *tmp_636;
tmp_635 = args[1][1];
tmp_636 = args[1][1];
emit_assign(make_lhs(tmp_629), make_op_rhs(OP_MUL, make_compvar_primary(tmp_635), make_compvar_primary(tmp_636)));
}
emit_assign(make_lhs(tmp_627), make_op_rhs(OP_ADD, make_compvar_primary(tmp_628), make_compvar_primary(tmp_629)));
for (tmp_630 = 2; tmp_630 < 2; ++tmp_630)
{
tmp_628 = make_temporary();
{
compvar_t *tmp_637, *tmp_638;
tmp_637 = args[1][tmp_630];
tmp_638 = args[1][tmp_630];
emit_assign(make_lhs(tmp_628), make_op_rhs(OP_MUL, make_compvar_primary(tmp_637), make_compvar_primary(tmp_638)));
}
emit_assign(make_lhs(tmp_627), make_op_rhs(OP_ADD, make_compvar_primary(tmp_627), make_compvar_primary(tmp_628)));
}
}

{
compvar_t *tmp_639;
tmp_639 = make_temporary();
{
compvar_t *tmp_640, *tmp_641;
tmp_640 = tmp_627;
tmp_641 = make_temporary();
emit_assign(make_lhs(tmp_641), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_639), make_op_rhs(OP_EQ, make_compvar_primary(tmp_640), make_compvar_primary(tmp_641)));
}
start_if_cond(make_compvar_rhs(tmp_639));
{
int tmp_642;
for (tmp_642 = 0; tmp_642 < 2; ++tmp_642)
{
switch (tmp_642)
{
case 0 :
emit_assign(make_lhs(result[tmp_642]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_642]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_643;
for (tmp_643 = 0; tmp_643 < 2; ++tmp_643)
{
switch (tmp_643)
{
case 0 :
{
compvar_t *tmp_644, *tmp_645;
tmp_644 = make_temporary();
{
compvar_t *tmp_646, *tmp_647;
tmp_646 = args[0][0];
tmp_647 = args[1][0];
emit_assign(make_lhs(tmp_644), make_op_rhs(OP_MUL, make_compvar_primary(tmp_646), make_compvar_primary(tmp_647)));
}
tmp_645 = tmp_627;
emit_assign(make_lhs(result[tmp_643]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_644), make_compvar_primary(tmp_645)));
}
break;
case 1 :
{
compvar_t *tmp_648;
tmp_648 = make_temporary();
{
compvar_t *tmp_649, *tmp_650;
tmp_649 = make_temporary();
{
compvar_t *tmp_651, *tmp_652;
tmp_651 = args[0][0];
tmp_652 = args[1][1];
emit_assign(make_lhs(tmp_649), make_op_rhs(OP_MUL, make_compvar_primary(tmp_651), make_compvar_primary(tmp_652)));
}
tmp_650 = tmp_627;
emit_assign(make_lhs(tmp_648), make_op_rhs(OP_DIV, make_compvar_primary(tmp_649), make_compvar_primary(tmp_650)));
}
emit_assign(make_lhs(result[tmp_643]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_648)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
}

void
builtin_div_v2m2x2 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
gsl_matrix * tmp_653;
gsl_vector * tmp_658;

{
float tmp_654;
float tmp_655;
float tmp_656;
float tmp_657;
tmp_654 = STK[STKP - 1].data[0];
tmp_655 = STK[STKP - 1].data[1];
tmp_656 = STK[STKP - 1].data[2];
tmp_657 = STK[STKP - 1].data[3];
tmp_653 = MAKE_M2X2(tmp_654, tmp_655, tmp_656, tmp_657);
}

{
float tmp_659;
float tmp_660;
tmp_659 = STK[STKP - 2].data[0];
tmp_660 = STK[STKP - 2].data[1];
tmp_658 = MAKE_V2(tmp_659, tmp_660);
}

{
gsl_vector * tmp_661;

{
gsl_matrix * tmp_662;
gsl_vector * tmp_663;
tmp_662 = tmp_653;
tmp_663 = tmp_658;
tmp_661 = SOLVE_LINEAR_2(tmp_662, tmp_663);
}

{
float tmp_664;
gsl_vector * tmp_665;
tmp_664 = 0;
tmp_665 = tmp_661;
result[0] = gsl_vector_get(tmp_665, tmp_664);
}
{
float tmp_666;
gsl_vector * tmp_667;
tmp_666 = 1;
tmp_667 = tmp_661;
result[1] = gsl_vector_get(tmp_667, tmp_666);
}
{
float tmp_668;
{
gsl_vector * tmp_669;
tmp_669 = tmp_661;
gsl_vector_free(tmp_669);
}
}
{
float tmp_670;
{
gsl_vector * tmp_671;
tmp_671 = tmp_658;
gsl_vector_free(tmp_671);
}
}
{
float tmp_672;
{
gsl_matrix * tmp_673;
tmp_673 = tmp_653;
gsl_matrix_free(tmp_673);
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_div_v2m2x2 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_674;
compvar_t *tmp_679;

tmp_674 = make_temporary();
{
compvar_t *tmp_675, *tmp_676, *tmp_677, *tmp_678;
tmp_675 = args[1][0];
tmp_676 = args[1][1];
tmp_677 = args[1][2];
tmp_678 = args[1][3];
emit_assign(make_lhs(tmp_674), make_op_rhs(OP_MAKE_M2X2, make_compvar_primary(tmp_675), make_compvar_primary(tmp_676), make_compvar_primary(tmp_677), make_compvar_primary(tmp_678)));
}

tmp_679 = make_temporary();
{
compvar_t *tmp_680, *tmp_681;
tmp_680 = args[0][0];
tmp_681 = args[0][1];
emit_assign(make_lhs(tmp_679), make_op_rhs(OP_MAKE_V2, make_compvar_primary(tmp_680), make_compvar_primary(tmp_681)));
}

{
compvar_t *tmp_682;

tmp_682 = make_temporary();
{
compvar_t *tmp_683, *tmp_684;
tmp_683 = tmp_674;
tmp_684 = tmp_679;
emit_assign(make_lhs(tmp_682), make_op_rhs(OP_SOLVE_LINEAR_2, make_compvar_primary(tmp_683), make_compvar_primary(tmp_684)));
}

{
int tmp_685;
for (tmp_685 = 0; tmp_685 < 2; ++tmp_685)
{
switch (tmp_685)
{
case 0 :
{
compvar_t *tmp_686, *tmp_687;
tmp_686 = make_temporary();
emit_assign(make_lhs(tmp_686), make_int_const_rhs(0));
tmp_687 = tmp_682;
emit_assign(make_lhs(result[tmp_685]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_686), make_compvar_primary(tmp_687)));
}
break;
case 1 :
{
compvar_t *tmp_688, *tmp_689;
tmp_688 = make_temporary();
emit_assign(make_lhs(tmp_688), make_int_const_rhs(1));
tmp_689 = tmp_682;
emit_assign(make_lhs(result[tmp_685]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_688), make_compvar_primary(tmp_689)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_690;
tmp_690 = make_temporary();
{
compvar_t *tmp_691;
tmp_691 = tmp_682;
emit_assign(make_lhs(tmp_690), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_691)));
}
}
{
compvar_t *tmp_692;
tmp_692 = make_temporary();
{
compvar_t *tmp_693;
tmp_693 = tmp_679;
emit_assign(make_lhs(tmp_692), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_693)));
}
}
{
compvar_t *tmp_694;
tmp_694 = make_temporary();
{
compvar_t *tmp_695;
tmp_695 = tmp_674;
emit_assign(make_lhs(tmp_694), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_695)));
}
}
}
}
}

void
builtin_div_v3m3x3 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
gsl_matrix * tmp_696;
gsl_vector * tmp_706;

{
float tmp_697;
float tmp_698;
float tmp_699;
float tmp_700;
float tmp_701;
float tmp_702;
float tmp_703;
float tmp_704;
float tmp_705;
tmp_697 = STK[STKP - 1].data[0];
tmp_698 = STK[STKP - 1].data[1];
tmp_699 = STK[STKP - 1].data[2];
tmp_700 = STK[STKP - 1].data[3];
tmp_701 = STK[STKP - 1].data[4];
tmp_702 = STK[STKP - 1].data[5];
tmp_703 = STK[STKP - 1].data[6];
tmp_704 = STK[STKP - 1].data[7];
tmp_705 = STK[STKP - 1].data[8];
tmp_696 = MAKE_M3X3(tmp_697, tmp_698, tmp_699, tmp_700, tmp_701, tmp_702, tmp_703, tmp_704, tmp_705);
}

{
float tmp_707;
float tmp_708;
float tmp_709;
tmp_707 = STK[STKP - 2].data[0];
tmp_708 = STK[STKP - 2].data[1];
tmp_709 = STK[STKP - 2].data[2];
tmp_706 = MAKE_V3(tmp_707, tmp_708, tmp_709);
}

{
gsl_vector * tmp_710;

{
gsl_matrix * tmp_711;
gsl_vector * tmp_712;
tmp_711 = tmp_696;
tmp_712 = tmp_706;
tmp_710 = SOLVE_LINEAR_3(tmp_711, tmp_712);
}

{
float tmp_713;
gsl_vector * tmp_714;
tmp_713 = 0;
tmp_714 = tmp_710;
result[0] = gsl_vector_get(tmp_714, tmp_713);
}
{
float tmp_715;
gsl_vector * tmp_716;
tmp_715 = 1;
tmp_716 = tmp_710;
result[1] = gsl_vector_get(tmp_716, tmp_715);
}
{
float tmp_717;
gsl_vector * tmp_718;
tmp_717 = 2;
tmp_718 = tmp_710;
result[2] = gsl_vector_get(tmp_718, tmp_717);
}
{
float tmp_719;
{
gsl_vector * tmp_720;
tmp_720 = tmp_710;
gsl_vector_free(tmp_720);
}
}
{
float tmp_721;
{
gsl_vector * tmp_722;
tmp_722 = tmp_706;
gsl_vector_free(tmp_722);
}
}
{
float tmp_723;
{
gsl_matrix * tmp_724;
tmp_724 = tmp_696;
gsl_matrix_free(tmp_724);
}
}
}
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 3;
STKP -= 1;
}

void
gen_div_v3m3x3 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_725;
compvar_t *tmp_735;

tmp_725 = make_temporary();
{
compvar_t *tmp_726, *tmp_727, *tmp_728, *tmp_729, *tmp_730, *tmp_731, *tmp_732, *tmp_733, *tmp_734;
tmp_726 = args[1][0];
tmp_727 = args[1][1];
tmp_728 = args[1][2];
tmp_729 = args[1][3];
tmp_730 = args[1][4];
tmp_731 = args[1][5];
tmp_732 = args[1][6];
tmp_733 = args[1][7];
tmp_734 = args[1][8];
emit_assign(make_lhs(tmp_725), make_op_rhs(OP_MAKE_M3X3, make_compvar_primary(tmp_726), make_compvar_primary(tmp_727), make_compvar_primary(tmp_728), make_compvar_primary(tmp_729), make_compvar_primary(tmp_730), make_compvar_primary(tmp_731), make_compvar_primary(tmp_732), make_compvar_primary(tmp_733), make_compvar_primary(tmp_734)));
}

tmp_735 = make_temporary();
{
compvar_t *tmp_736, *tmp_737, *tmp_738;
tmp_736 = args[0][0];
tmp_737 = args[0][1];
tmp_738 = args[0][2];
emit_assign(make_lhs(tmp_735), make_op_rhs(OP_MAKE_V3, make_compvar_primary(tmp_736), make_compvar_primary(tmp_737), make_compvar_primary(tmp_738)));
}

{
compvar_t *tmp_739;

tmp_739 = make_temporary();
{
compvar_t *tmp_740, *tmp_741;
tmp_740 = tmp_725;
tmp_741 = tmp_735;
emit_assign(make_lhs(tmp_739), make_op_rhs(OP_SOLVE_LINEAR_3, make_compvar_primary(tmp_740), make_compvar_primary(tmp_741)));
}

{
int tmp_742;
for (tmp_742 = 0; tmp_742 < 3; ++tmp_742)
{
switch (tmp_742)
{
case 0 :
{
compvar_t *tmp_743, *tmp_744;
tmp_743 = make_temporary();
emit_assign(make_lhs(tmp_743), make_int_const_rhs(0));
tmp_744 = tmp_739;
emit_assign(make_lhs(result[tmp_742]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_743), make_compvar_primary(tmp_744)));
}
break;
case 1 :
{
compvar_t *tmp_745, *tmp_746;
tmp_745 = make_temporary();
emit_assign(make_lhs(tmp_745), make_int_const_rhs(1));
tmp_746 = tmp_739;
emit_assign(make_lhs(result[tmp_742]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_745), make_compvar_primary(tmp_746)));
}
break;
case 2 :
{
compvar_t *tmp_747, *tmp_748;
tmp_747 = make_temporary();
emit_assign(make_lhs(tmp_747), make_int_const_rhs(2));
tmp_748 = tmp_739;
emit_assign(make_lhs(result[tmp_742]), make_op_rhs(OP_VECTOR_NTH, make_compvar_primary(tmp_747), make_compvar_primary(tmp_748)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_749;
tmp_749 = make_temporary();
{
compvar_t *tmp_750;
tmp_750 = tmp_739;
emit_assign(make_lhs(tmp_749), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_750)));
}
}
{
compvar_t *tmp_751;
tmp_751 = make_temporary();
{
compvar_t *tmp_752;
tmp_752 = tmp_735;
emit_assign(make_lhs(tmp_751), make_op_rhs(OP_FREE_VECTOR, make_compvar_primary(tmp_752)));
}
}
{
compvar_t *tmp_753;
tmp_753 = make_temporary();
{
compvar_t *tmp_754;
tmp_754 = tmp_725;
emit_assign(make_lhs(tmp_753), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_754)));
}
}
}
}
}

void
builtin_div_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_755;
{
float tmp_756;
float tmp_757;
tmp_756 = STK[STKP - 1].data[0];
tmp_757 = 0;
tmp_755 = (tmp_756 == tmp_757);
}
if (tmp_755)
{
result[0] = 0;
}
else
{
{
float tmp_758;
float tmp_759;
tmp_758 = STK[STKP - 2].data[0];
tmp_759 = STK[STKP - 1].data[0];
result[0] = tmp_758 / tmp_759;
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_div_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_760;
tmp_760 = make_temporary();
{
compvar_t *tmp_761, *tmp_762;
tmp_761 = args[1][0];
tmp_762 = make_temporary();
emit_assign(make_lhs(tmp_762), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_760), make_op_rhs(OP_EQ, make_compvar_primary(tmp_761), make_compvar_primary(tmp_762)));
}
start_if_cond(make_compvar_rhs(tmp_760));
{
int tmp_763;
for (tmp_763 = 0; tmp_763 < 1; ++tmp_763)
{
switch (tmp_763)
{
case 0 :
emit_assign(make_lhs(result[tmp_763]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_764;
for (tmp_764 = 0; tmp_764 < 1; ++tmp_764)
{
{
compvar_t *tmp_765, *tmp_766;
tmp_765 = args[0][tmp_764];
tmp_766 = args[1][tmp_764];
emit_assign(make_lhs(result[tmp_764]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_765), make_compvar_primary(tmp_766)));
}
}
}
end_if_cond();
}
}

void
builtin_div_s (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_767;
{
float tmp_768;
float tmp_769;
tmp_768 = STK[STKP - 1].data[0];
tmp_769 = 0;
tmp_767 = (tmp_768 == tmp_769);
}
if (tmp_767)
{
{
int tmp_770;
for (tmp_770 = 0; tmp_770 < STK[STKP - 2].length; ++tmp_770)
{
result[tmp_770] = 0;
}
}
}
else
{
{
int tmp_771;
for (tmp_771 = 0; tmp_771 < STK[STKP - 2].length; ++tmp_771)
{
{
float tmp_772;
float tmp_773;
tmp_772 = STK[STKP - 2].data[tmp_771];
tmp_773 = STK[STKP - 1].data[0];
result[tmp_771] = tmp_772 / tmp_773;
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_div_s (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_774;
tmp_774 = make_temporary();
{
compvar_t *tmp_775, *tmp_776;
tmp_775 = args[1][0];
tmp_776 = make_temporary();
emit_assign(make_lhs(tmp_776), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_774), make_op_rhs(OP_EQ, make_compvar_primary(tmp_775), make_compvar_primary(tmp_776)));
}
start_if_cond(make_compvar_rhs(tmp_774));
{
int tmp_777;
for (tmp_777 = 0; tmp_777 < arglengths[0]; ++tmp_777)
{
emit_assign(make_lhs(result[tmp_777]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_778;
for (tmp_778 = 0; tmp_778 < arglengths[0]; ++tmp_778)
{
{
compvar_t *tmp_779, *tmp_780;
tmp_779 = args[0][tmp_778];
tmp_780 = args[1][0];
emit_assign(make_lhs(result[tmp_778]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_779), make_compvar_primary(tmp_780)));
}
}
}
end_if_cond();
}
}

void
builtin_div_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_781;
for (tmp_781 = 0; tmp_781 < STK[STKP - 1].length; ++tmp_781)
{
{
float tmp_782;
{
float tmp_783;
float tmp_784;
tmp_783 = STK[STKP - 1].data[tmp_781];
tmp_784 = 0;
tmp_782 = (tmp_783 == tmp_784);
}
if (tmp_782)
{
result[tmp_781] = 0;
}
else
{
{
float tmp_785;
float tmp_786;
tmp_785 = STK[STKP - 2].data[tmp_781];
tmp_786 = STK[STKP - 1].data[tmp_781];
result[tmp_781] = tmp_785 / tmp_786;
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_div_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_787;
for (tmp_787 = 0; tmp_787 < arglengths[1]; ++tmp_787)
{
{
compvar_t *tmp_788;
tmp_788 = make_temporary();
{
compvar_t *tmp_789, *tmp_790;
tmp_789 = args[1][tmp_787];
tmp_790 = make_temporary();
emit_assign(make_lhs(tmp_790), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_788), make_op_rhs(OP_EQ, make_compvar_primary(tmp_789), make_compvar_primary(tmp_790)));
}
start_if_cond(make_compvar_rhs(tmp_788));
emit_assign(make_lhs(result[tmp_787]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_791, *tmp_792;
tmp_791 = args[0][tmp_787];
tmp_792 = args[1][tmp_787];
emit_assign(make_lhs(result[tmp_787]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_791), make_compvar_primary(tmp_792)));
}
end_if_cond();
}
}
}
}

void
builtin_mod_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_793;
{
float tmp_794;
float tmp_795;
tmp_794 = STK[STKP - 1].data[0];
tmp_795 = 0;
tmp_793 = (tmp_794 == tmp_795);
}
if (tmp_793)
{
result[0] = 0;
}
else
{
{
float tmp_796;
float tmp_797;
tmp_796 = STK[STKP - 2].data[0];
tmp_797 = STK[STKP - 1].data[0];
result[0] = fmod(tmp_796, tmp_797);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_mod_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_798;
tmp_798 = make_temporary();
{
compvar_t *tmp_799, *tmp_800;
tmp_799 = args[1][0];
tmp_800 = make_temporary();
emit_assign(make_lhs(tmp_800), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_798), make_op_rhs(OP_EQ, make_compvar_primary(tmp_799), make_compvar_primary(tmp_800)));
}
start_if_cond(make_compvar_rhs(tmp_798));
{
int tmp_801;
for (tmp_801 = 0; tmp_801 < 1; ++tmp_801)
{
switch (tmp_801)
{
case 0 :
emit_assign(make_lhs(result[tmp_801]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_802;
for (tmp_802 = 0; tmp_802 < 1; ++tmp_802)
{
{
compvar_t *tmp_803, *tmp_804;
tmp_803 = args[0][tmp_802];
tmp_804 = args[1][tmp_802];
emit_assign(make_lhs(result[tmp_802]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_803), make_compvar_primary(tmp_804)));
}
}
}
end_if_cond();
}
}

void
builtin_mod_s (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_805;
{
float tmp_806;
float tmp_807;
tmp_806 = STK[STKP - 1].data[0];
tmp_807 = 0;
tmp_805 = (tmp_806 == tmp_807);
}
if (tmp_805)
{
{
int tmp_808;
for (tmp_808 = 0; tmp_808 < STK[STKP - 2].length; ++tmp_808)
{
result[tmp_808] = 0;
}
}
}
else
{
{
int tmp_809;
for (tmp_809 = 0; tmp_809 < STK[STKP - 2].length; ++tmp_809)
{
{
float tmp_810;
float tmp_811;
tmp_810 = STK[STKP - 2].data[tmp_809];
tmp_811 = STK[STKP - 1].data[0];
result[tmp_809] = fmod(tmp_810, tmp_811);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_mod_s (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_812;
tmp_812 = make_temporary();
{
compvar_t *tmp_813, *tmp_814;
tmp_813 = args[1][0];
tmp_814 = make_temporary();
emit_assign(make_lhs(tmp_814), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_812), make_op_rhs(OP_EQ, make_compvar_primary(tmp_813), make_compvar_primary(tmp_814)));
}
start_if_cond(make_compvar_rhs(tmp_812));
{
int tmp_815;
for (tmp_815 = 0; tmp_815 < arglengths[0]; ++tmp_815)
{
emit_assign(make_lhs(result[tmp_815]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_816;
for (tmp_816 = 0; tmp_816 < arglengths[0]; ++tmp_816)
{
{
compvar_t *tmp_817, *tmp_818;
tmp_817 = args[0][tmp_816];
tmp_818 = args[1][0];
emit_assign(make_lhs(result[tmp_816]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_817), make_compvar_primary(tmp_818)));
}
}
}
end_if_cond();
}
}

void
builtin_mod_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_819;
for (tmp_819 = 0; tmp_819 < STK[STKP - 1].length; ++tmp_819)
{
{
float tmp_820;
{
float tmp_821;
float tmp_822;
tmp_821 = STK[STKP - 1].data[tmp_819];
tmp_822 = 0;
tmp_820 = (tmp_821 == tmp_822);
}
if (tmp_820)
{
result[tmp_819] = 0;
}
else
{
{
float tmp_823;
float tmp_824;
tmp_823 = STK[STKP - 2].data[tmp_819];
tmp_824 = STK[STKP - 1].data[tmp_819];
result[tmp_819] = fmod(tmp_823, tmp_824);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_mod_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_825;
for (tmp_825 = 0; tmp_825 < arglengths[1]; ++tmp_825)
{
{
compvar_t *tmp_826;
tmp_826 = make_temporary();
{
compvar_t *tmp_827, *tmp_828;
tmp_827 = args[1][tmp_825];
tmp_828 = make_temporary();
emit_assign(make_lhs(tmp_828), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_826), make_op_rhs(OP_EQ, make_compvar_primary(tmp_827), make_compvar_primary(tmp_828)));
}
start_if_cond(make_compvar_rhs(tmp_826));
emit_assign(make_lhs(result[tmp_825]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_829, *tmp_830;
tmp_829 = args[0][tmp_825];
tmp_830 = args[1][tmp_825];
emit_assign(make_lhs(result[tmp_825]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_829), make_compvar_primary(tmp_830)));
}
end_if_cond();
}
}
}
}

void
builtin_pmod (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_831;

{
float tmp_832;
float tmp_833;
tmp_832 = STK[STKP - 2].data[0];
tmp_833 = STK[STKP - 1].data[0];
tmp_831 = fmod(tmp_832, tmp_833);
}

{
float tmp_834;
{
float tmp_835;
float tmp_836;
tmp_835 = STK[STKP - 2].data[0];
tmp_836 = 0;
tmp_834 = (tmp_835 < tmp_836);
}
if (tmp_834)
{
{
float tmp_837;
float tmp_838;
tmp_837 = tmp_831;
tmp_838 = STK[STKP - 1].data[0];
result[0] = tmp_837 + tmp_838;
}
}
else
{
result[0] = tmp_831;
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_pmod (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_839;

tmp_839 = make_temporary();
{
compvar_t *tmp_840, *tmp_841;
tmp_840 = args[0][0];
tmp_841 = args[1][0];
emit_assign(make_lhs(tmp_839), make_op_rhs(OP_MOD, make_compvar_primary(tmp_840), make_compvar_primary(tmp_841)));
}

{
compvar_t *tmp_842;
tmp_842 = make_temporary();
{
compvar_t *tmp_843, *tmp_844;
tmp_843 = args[0][0];
tmp_844 = make_temporary();
emit_assign(make_lhs(tmp_844), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_842), make_op_rhs(OP_LESS, make_compvar_primary(tmp_843), make_compvar_primary(tmp_844)));
}
start_if_cond(make_compvar_rhs(tmp_842));
{
int tmp_845;
for (tmp_845 = 0; tmp_845 < 1; ++tmp_845)
{
switch (tmp_845)
{
case 0 :
{
compvar_t *tmp_846, *tmp_847;
tmp_846 = tmp_839;
tmp_847 = args[1][0];
emit_assign(make_lhs(result[tmp_845]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_846), make_compvar_primary(tmp_847)));
}
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_848;
for (tmp_848 = 0; tmp_848 < 1; ++tmp_848)
{
switch (tmp_848)
{
case 0 :
emit_assign(make_lhs(result[tmp_848]), make_compvar_rhs(tmp_839));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
}

void
builtin_sqrt_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_849;

{
complex float tmp_850;
{
float tmp_851;
float tmp_852;
tmp_851 = STK[STKP - 1].data[0];
tmp_852 = STK[STKP - 1].data[1];
tmp_850 = (tmp_851 + tmp_852 * I);
}
tmp_849 = csqrtf(tmp_850);
}

{
complex float tmp_853;
tmp_853 = tmp_849;
result[0] = crealf(tmp_853);
}
{
complex float tmp_854;
tmp_854 = tmp_849;
result[1] = cimagf(tmp_854);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_sqrt_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_855;

tmp_855 = make_temporary();
{
compvar_t *tmp_856;
tmp_856 = make_temporary();
{
compvar_t *tmp_857, *tmp_858;
tmp_857 = args[0][0];
tmp_858 = args[0][1];
emit_assign(make_lhs(tmp_856), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_857), make_compvar_primary(tmp_858)));
}
emit_assign(make_lhs(tmp_855), make_op_rhs(OP_C_SQRT, make_compvar_primary(tmp_856)));
}

{
int tmp_859;
for (tmp_859 = 0; tmp_859 < 2; ++tmp_859)
{
switch (tmp_859)
{
case 0 :
{
compvar_t *tmp_860;
tmp_860 = tmp_855;
emit_assign(make_lhs(result[tmp_859]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_860)));
}
break;
case 1 :
{
compvar_t *tmp_861;
tmp_861 = tmp_855;
emit_assign(make_lhs(result[tmp_859]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_861)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_sqrt_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_862;
tmp_862 = STK[STKP - 1].data[0];
result[0] = sqrt(tmp_862);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_sqrt_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_863;
for (tmp_863 = 0; tmp_863 < 1; ++tmp_863)
{
switch (tmp_863)
{
case 0 :
{
compvar_t *tmp_864;
tmp_864 = args[0][0];
emit_assign(make_lhs(result[tmp_863]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_864)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_sum (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_867;
float tmp_865 = 0.0, tmp_866;
for (tmp_867 = 0; tmp_867 < STK[STKP - 1].length; ++tmp_867)
{
tmp_866 = STK[STKP - 1].data[tmp_867];

tmp_865 += tmp_866;
}
result[0] = tmp_865;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_sum (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_868;
for (tmp_868 = 0; tmp_868 < 1; ++tmp_868)
{
switch (tmp_868)
{
case 0 :
if (arglengths[0] == 1)
{
emit_assign(make_lhs(result[tmp_868]), make_compvar_rhs(args[0][0]));

}
else
{
compvar_t *tmp_869, *tmp_870;
int tmp_871;
tmp_869 = args[0][0];
tmp_870 = args[0][1];
emit_assign(make_lhs(result[tmp_868]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_869), make_compvar_primary(tmp_870)));
for (tmp_871 = 2; tmp_871 < arglengths[0]; ++tmp_871)
{
tmp_869 = args[0][tmp_871];
emit_assign(make_lhs(result[tmp_868]), make_op_rhs(OP_ADD, make_compvar_primary(result[tmp_868]), make_compvar_primary(tmp_869)));
}
}
break;
default :
assert(0);
}
}
}
}

void
builtin_dotp (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_874;
float tmp_872 = 0.0, tmp_873;
for (tmp_874 = 0; tmp_874 < STK[STKP - 2].length; ++tmp_874)
{
{
float tmp_875;
float tmp_876;
tmp_875 = STK[STKP - 2].data[tmp_874];
tmp_876 = STK[STKP - 1].data[tmp_874];
tmp_873 = tmp_875 * tmp_876;
}

tmp_872 += tmp_873;
}
result[0] = tmp_872;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_dotp (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_877;
for (tmp_877 = 0; tmp_877 < 1; ++tmp_877)
{
switch (tmp_877)
{
case 0 :
if (arglengths[0] == 1)
{
{
compvar_t *tmp_881, *tmp_882;
tmp_881 = args[0][0];
tmp_882 = args[1][0];
emit_assign(make_lhs(result[tmp_877]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_881), make_compvar_primary(tmp_882)));
}

}
else
{
compvar_t *tmp_878, *tmp_879;
int tmp_880;
tmp_878 = make_temporary();
{
compvar_t *tmp_883, *tmp_884;
tmp_883 = args[0][0];
tmp_884 = args[1][0];
emit_assign(make_lhs(tmp_878), make_op_rhs(OP_MUL, make_compvar_primary(tmp_883), make_compvar_primary(tmp_884)));
}
tmp_879 = make_temporary();
{
compvar_t *tmp_885, *tmp_886;
tmp_885 = args[0][1];
tmp_886 = args[1][1];
emit_assign(make_lhs(tmp_879), make_op_rhs(OP_MUL, make_compvar_primary(tmp_885), make_compvar_primary(tmp_886)));
}
emit_assign(make_lhs(result[tmp_877]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_878), make_compvar_primary(tmp_879)));
for (tmp_880 = 2; tmp_880 < arglengths[0]; ++tmp_880)
{
tmp_878 = make_temporary();
{
compvar_t *tmp_887, *tmp_888;
tmp_887 = args[0][tmp_880];
tmp_888 = args[1][tmp_880];
emit_assign(make_lhs(tmp_878), make_op_rhs(OP_MUL, make_compvar_primary(tmp_887), make_compvar_primary(tmp_888)));
}
emit_assign(make_lhs(result[tmp_877]), make_op_rhs(OP_ADD, make_compvar_primary(result[tmp_877]), make_compvar_primary(tmp_878)));
}
}
break;
default :
assert(0);
}
}
}
}

void
builtin_crossp (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_889;
float tmp_890;
{
float tmp_891;
float tmp_892;
tmp_891 = STK[STKP - 2].data[1];
tmp_892 = STK[STKP - 1].data[2];
tmp_889 = tmp_891 * tmp_892;
}
{
float tmp_893;
float tmp_894;
tmp_893 = STK[STKP - 2].data[2];
tmp_894 = STK[STKP - 1].data[1];
tmp_890 = tmp_893 * tmp_894;
}
result[0] = tmp_889 - tmp_890;
}
{
float tmp_895;
float tmp_896;
{
float tmp_897;
float tmp_898;
tmp_897 = STK[STKP - 2].data[2];
tmp_898 = STK[STKP - 1].data[0];
tmp_895 = tmp_897 * tmp_898;
}
{
float tmp_899;
float tmp_900;
tmp_899 = STK[STKP - 2].data[0];
tmp_900 = STK[STKP - 1].data[2];
tmp_896 = tmp_899 * tmp_900;
}
result[1] = tmp_895 - tmp_896;
}
{
float tmp_901;
float tmp_902;
{
float tmp_903;
float tmp_904;
tmp_903 = STK[STKP - 2].data[0];
tmp_904 = STK[STKP - 1].data[1];
tmp_901 = tmp_903 * tmp_904;
}
{
float tmp_905;
float tmp_906;
tmp_905 = STK[STKP - 2].data[1];
tmp_906 = STK[STKP - 1].data[0];
tmp_902 = tmp_905 * tmp_906;
}
result[2] = tmp_901 - tmp_902;
}
{
int i;
for (i = 0; i < 3; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 3;
STKP -= 1;
}

void
gen_crossp (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_907;
for (tmp_907 = 0; tmp_907 < 3; ++tmp_907)
{
switch (tmp_907)
{
case 0 :
{
compvar_t *tmp_908, *tmp_909;
tmp_908 = make_temporary();
{
compvar_t *tmp_910, *tmp_911;
tmp_910 = args[0][1];
tmp_911 = args[1][2];
emit_assign(make_lhs(tmp_908), make_op_rhs(OP_MUL, make_compvar_primary(tmp_910), make_compvar_primary(tmp_911)));
}
tmp_909 = make_temporary();
{
compvar_t *tmp_912, *tmp_913;
tmp_912 = args[0][2];
tmp_913 = args[1][1];
emit_assign(make_lhs(tmp_909), make_op_rhs(OP_MUL, make_compvar_primary(tmp_912), make_compvar_primary(tmp_913)));
}
emit_assign(make_lhs(result[tmp_907]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_908), make_compvar_primary(tmp_909)));
}
break;
case 1 :
{
compvar_t *tmp_914, *tmp_915;
tmp_914 = make_temporary();
{
compvar_t *tmp_916, *tmp_917;
tmp_916 = args[0][2];
tmp_917 = args[1][0];
emit_assign(make_lhs(tmp_914), make_op_rhs(OP_MUL, make_compvar_primary(tmp_916), make_compvar_primary(tmp_917)));
}
tmp_915 = make_temporary();
{
compvar_t *tmp_918, *tmp_919;
tmp_918 = args[0][0];
tmp_919 = args[1][2];
emit_assign(make_lhs(tmp_915), make_op_rhs(OP_MUL, make_compvar_primary(tmp_918), make_compvar_primary(tmp_919)));
}
emit_assign(make_lhs(result[tmp_907]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_914), make_compvar_primary(tmp_915)));
}
break;
case 2 :
{
compvar_t *tmp_920, *tmp_921;
tmp_920 = make_temporary();
{
compvar_t *tmp_922, *tmp_923;
tmp_922 = args[0][0];
tmp_923 = args[1][1];
emit_assign(make_lhs(tmp_920), make_op_rhs(OP_MUL, make_compvar_primary(tmp_922), make_compvar_primary(tmp_923)));
}
tmp_921 = make_temporary();
{
compvar_t *tmp_924, *tmp_925;
tmp_924 = args[0][1];
tmp_925 = args[1][0];
emit_assign(make_lhs(tmp_921), make_op_rhs(OP_MUL, make_compvar_primary(tmp_924), make_compvar_primary(tmp_925)));
}
emit_assign(make_lhs(result[tmp_907]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_920), make_compvar_primary(tmp_921)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_det_m2x2 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_926;
float tmp_927;
{
float tmp_928;
float tmp_929;
tmp_928 = STK[STKP - 1].data[0];
tmp_929 = STK[STKP - 1].data[3];
tmp_926 = tmp_928 * tmp_929;
}
{
float tmp_930;
float tmp_931;
tmp_930 = STK[STKP - 1].data[1];
tmp_931 = STK[STKP - 1].data[2];
tmp_927 = tmp_930 * tmp_931;
}
result[0] = tmp_926 - tmp_927;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_det_m2x2 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_932;
for (tmp_932 = 0; tmp_932 < 1; ++tmp_932)
{
switch (tmp_932)
{
case 0 :
{
compvar_t *tmp_933, *tmp_934;
tmp_933 = make_temporary();
{
compvar_t *tmp_935, *tmp_936;
tmp_935 = args[0][0];
tmp_936 = args[0][3];
emit_assign(make_lhs(tmp_933), make_op_rhs(OP_MUL, make_compvar_primary(tmp_935), make_compvar_primary(tmp_936)));
}
tmp_934 = make_temporary();
{
compvar_t *tmp_937, *tmp_938;
tmp_937 = args[0][1];
tmp_938 = args[0][2];
emit_assign(make_lhs(tmp_934), make_op_rhs(OP_MUL, make_compvar_primary(tmp_937), make_compvar_primary(tmp_938)));
}
emit_assign(make_lhs(result[tmp_932]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_933), make_compvar_primary(tmp_934)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_det_m3x3 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_939;
float tmp_940;
{
float tmp_941;
float tmp_942;
{
float tmp_943;
float tmp_944;
{
float tmp_945;
float tmp_946;
{
float tmp_947;
float tmp_948;
tmp_947 = STK[STKP - 1].data[0];
tmp_948 = STK[STKP - 1].data[4];
tmp_945 = tmp_947 * tmp_948;
}
tmp_946 = STK[STKP - 1].data[8];
tmp_943 = tmp_945 * tmp_946;
}
{
float tmp_949;
float tmp_950;
{
float tmp_951;
float tmp_952;
tmp_951 = STK[STKP - 1].data[1];
tmp_952 = STK[STKP - 1].data[5];
tmp_949 = tmp_951 * tmp_952;
}
tmp_950 = STK[STKP - 1].data[6];
tmp_944 = tmp_949 * tmp_950;
}
tmp_941 = tmp_943 + tmp_944;
}
{
float tmp_953;
float tmp_954;
{
float tmp_955;
float tmp_956;
tmp_955 = STK[STKP - 1].data[2];
tmp_956 = STK[STKP - 1].data[3];
tmp_953 = tmp_955 * tmp_956;
}
tmp_954 = STK[STKP - 1].data[7];
tmp_942 = tmp_953 * tmp_954;
}
tmp_939 = tmp_941 + tmp_942;
}
{
float tmp_957;
float tmp_958;
{
float tmp_959;
float tmp_960;
{
float tmp_961;
float tmp_962;
{
float tmp_963;
float tmp_964;
tmp_963 = STK[STKP - 1].data[2];
tmp_964 = STK[STKP - 1].data[4];
tmp_961 = tmp_963 * tmp_964;
}
tmp_962 = STK[STKP - 1].data[6];
tmp_959 = tmp_961 * tmp_962;
}
{
float tmp_965;
float tmp_966;
{
float tmp_967;
float tmp_968;
tmp_967 = STK[STKP - 1].data[0];
tmp_968 = STK[STKP - 1].data[5];
tmp_965 = tmp_967 * tmp_968;
}
tmp_966 = STK[STKP - 1].data[7];
tmp_960 = tmp_965 * tmp_966;
}
tmp_957 = tmp_959 + tmp_960;
}
{
float tmp_969;
float tmp_970;
{
float tmp_971;
float tmp_972;
tmp_971 = STK[STKP - 1].data[1];
tmp_972 = STK[STKP - 1].data[3];
tmp_969 = tmp_971 * tmp_972;
}
tmp_970 = STK[STKP - 1].data[8];
tmp_958 = tmp_969 * tmp_970;
}
tmp_940 = tmp_957 + tmp_958;
}
result[0] = tmp_939 - tmp_940;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_det_m3x3 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_973;
for (tmp_973 = 0; tmp_973 < 1; ++tmp_973)
{
switch (tmp_973)
{
case 0 :
{
compvar_t *tmp_974, *tmp_975;
tmp_974 = make_temporary();
{
compvar_t *tmp_976, *tmp_977;
tmp_976 = make_temporary();
{
compvar_t *tmp_978, *tmp_979;
tmp_978 = make_temporary();
{
compvar_t *tmp_980, *tmp_981;
tmp_980 = make_temporary();
{
compvar_t *tmp_982, *tmp_983;
tmp_982 = args[0][0];
tmp_983 = args[0][4];
emit_assign(make_lhs(tmp_980), make_op_rhs(OP_MUL, make_compvar_primary(tmp_982), make_compvar_primary(tmp_983)));
}
tmp_981 = args[0][8];
emit_assign(make_lhs(tmp_978), make_op_rhs(OP_MUL, make_compvar_primary(tmp_980), make_compvar_primary(tmp_981)));
}
tmp_979 = make_temporary();
{
compvar_t *tmp_984, *tmp_985;
tmp_984 = make_temporary();
{
compvar_t *tmp_986, *tmp_987;
tmp_986 = args[0][1];
tmp_987 = args[0][5];
emit_assign(make_lhs(tmp_984), make_op_rhs(OP_MUL, make_compvar_primary(tmp_986), make_compvar_primary(tmp_987)));
}
tmp_985 = args[0][6];
emit_assign(make_lhs(tmp_979), make_op_rhs(OP_MUL, make_compvar_primary(tmp_984), make_compvar_primary(tmp_985)));
}
emit_assign(make_lhs(tmp_976), make_op_rhs(OP_ADD, make_compvar_primary(tmp_978), make_compvar_primary(tmp_979)));
}
tmp_977 = make_temporary();
{
compvar_t *tmp_988, *tmp_989;
tmp_988 = make_temporary();
{
compvar_t *tmp_990, *tmp_991;
tmp_990 = args[0][2];
tmp_991 = args[0][3];
emit_assign(make_lhs(tmp_988), make_op_rhs(OP_MUL, make_compvar_primary(tmp_990), make_compvar_primary(tmp_991)));
}
tmp_989 = args[0][7];
emit_assign(make_lhs(tmp_977), make_op_rhs(OP_MUL, make_compvar_primary(tmp_988), make_compvar_primary(tmp_989)));
}
emit_assign(make_lhs(tmp_974), make_op_rhs(OP_ADD, make_compvar_primary(tmp_976), make_compvar_primary(tmp_977)));
}
tmp_975 = make_temporary();
{
compvar_t *tmp_992, *tmp_993;
tmp_992 = make_temporary();
{
compvar_t *tmp_994, *tmp_995;
tmp_994 = make_temporary();
{
compvar_t *tmp_996, *tmp_997;
tmp_996 = make_temporary();
{
compvar_t *tmp_998, *tmp_999;
tmp_998 = args[0][2];
tmp_999 = args[0][4];
emit_assign(make_lhs(tmp_996), make_op_rhs(OP_MUL, make_compvar_primary(tmp_998), make_compvar_primary(tmp_999)));
}
tmp_997 = args[0][6];
emit_assign(make_lhs(tmp_994), make_op_rhs(OP_MUL, make_compvar_primary(tmp_996), make_compvar_primary(tmp_997)));
}
tmp_995 = make_temporary();
{
compvar_t *tmp_1000, *tmp_1001;
tmp_1000 = make_temporary();
{
compvar_t *tmp_1002, *tmp_1003;
tmp_1002 = args[0][0];
tmp_1003 = args[0][5];
emit_assign(make_lhs(tmp_1000), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1002), make_compvar_primary(tmp_1003)));
}
tmp_1001 = args[0][7];
emit_assign(make_lhs(tmp_995), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1000), make_compvar_primary(tmp_1001)));
}
emit_assign(make_lhs(tmp_992), make_op_rhs(OP_ADD, make_compvar_primary(tmp_994), make_compvar_primary(tmp_995)));
}
tmp_993 = make_temporary();
{
compvar_t *tmp_1004, *tmp_1005;
tmp_1004 = make_temporary();
{
compvar_t *tmp_1006, *tmp_1007;
tmp_1006 = args[0][1];
tmp_1007 = args[0][3];
emit_assign(make_lhs(tmp_1004), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1006), make_compvar_primary(tmp_1007)));
}
tmp_1005 = args[0][8];
emit_assign(make_lhs(tmp_993), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1004), make_compvar_primary(tmp_1005)));
}
emit_assign(make_lhs(tmp_975), make_op_rhs(OP_ADD, make_compvar_primary(tmp_992), make_compvar_primary(tmp_993)));
}
emit_assign(make_lhs(result[tmp_973]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_974), make_compvar_primary(tmp_975)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_normalize (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1008;

{
int tmp_1011;
float tmp_1009 = 0.0, tmp_1010;
for (tmp_1011 = 0; tmp_1011 < STK[STKP - 1].length; ++tmp_1011)
{
{
float tmp_1012;
float tmp_1013;
tmp_1012 = STK[STKP - 1].data[tmp_1011];
tmp_1013 = STK[STKP - 1].data[tmp_1011];
tmp_1010 = tmp_1012 * tmp_1013;
}

tmp_1009 += tmp_1010;
}
tmp_1008 = tmp_1009;
}

{
float tmp_1014;
{
float tmp_1015;
float tmp_1016;
tmp_1015 = tmp_1008;
tmp_1016 = 0;
tmp_1014 = (tmp_1015 == tmp_1016);
}
if (tmp_1014)
{
{
int tmp_1017;
for (tmp_1017 = 0; tmp_1017 < STK[STKP - 1].length; ++tmp_1017)
{
result[tmp_1017] = 0;
}
}
}
else
{
{
int tmp_1018;
for (tmp_1018 = 0; tmp_1018 < STK[STKP - 1].length; ++tmp_1018)
{
{
float tmp_1019;
float tmp_1020;
tmp_1019 = STK[STKP - 1].data[tmp_1018];
{
float tmp_1021;
tmp_1021 = tmp_1008;
tmp_1020 = sqrt(tmp_1021);
}
result[tmp_1018] = tmp_1019 / tmp_1020;
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].length; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = STK[STKP - 1].length;
STKP -= 0;
}

void
gen_normalize (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1022;

if (arglengths[0] == 1)
{
tmp_1022 = make_temporary();
{
compvar_t *tmp_1026, *tmp_1027;
tmp_1026 = args[0][0];
tmp_1027 = args[0][0];
emit_assign(make_lhs(tmp_1022), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1026), make_compvar_primary(tmp_1027)));
}

}
else
{
compvar_t *tmp_1023, *tmp_1024;
int tmp_1025;
tmp_1022 = make_temporary();
tmp_1023 = make_temporary();
{
compvar_t *tmp_1028, *tmp_1029;
tmp_1028 = args[0][0];
tmp_1029 = args[0][0];
emit_assign(make_lhs(tmp_1023), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1028), make_compvar_primary(tmp_1029)));
}
tmp_1024 = make_temporary();
{
compvar_t *tmp_1030, *tmp_1031;
tmp_1030 = args[0][1];
tmp_1031 = args[0][1];
emit_assign(make_lhs(tmp_1024), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1030), make_compvar_primary(tmp_1031)));
}
emit_assign(make_lhs(tmp_1022), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1023), make_compvar_primary(tmp_1024)));
for (tmp_1025 = 2; tmp_1025 < arglengths[0]; ++tmp_1025)
{
tmp_1023 = make_temporary();
{
compvar_t *tmp_1032, *tmp_1033;
tmp_1032 = args[0][tmp_1025];
tmp_1033 = args[0][tmp_1025];
emit_assign(make_lhs(tmp_1023), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1032), make_compvar_primary(tmp_1033)));
}
emit_assign(make_lhs(tmp_1022), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1022), make_compvar_primary(tmp_1023)));
}
}

{
compvar_t *tmp_1034;
tmp_1034 = make_temporary();
{
compvar_t *tmp_1035, *tmp_1036;
tmp_1035 = tmp_1022;
tmp_1036 = make_temporary();
emit_assign(make_lhs(tmp_1036), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1034), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1035), make_compvar_primary(tmp_1036)));
}
start_if_cond(make_compvar_rhs(tmp_1034));
{
int tmp_1037;
for (tmp_1037 = 0; tmp_1037 < arglengths[0]; ++tmp_1037)
{
emit_assign(make_lhs(result[tmp_1037]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_1038;
for (tmp_1038 = 0; tmp_1038 < arglengths[0]; ++tmp_1038)
{
{
compvar_t *tmp_1039, *tmp_1040;
tmp_1039 = args[0][tmp_1038];
tmp_1040 = make_temporary();
{
compvar_t *tmp_1041;
tmp_1041 = tmp_1022;
emit_assign(make_lhs(tmp_1040), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_1041)));
}
emit_assign(make_lhs(result[tmp_1038]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1039), make_compvar_primary(tmp_1040)));
}
}
}
end_if_cond();
}
}
}

void
builtin_abs_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1042;
float tmp_1043;
tmp_1042 = STK[STKP - 1].data[0];
tmp_1043 = STK[STKP - 1].data[1];
result[0] = hypot(tmp_1042, tmp_1043);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_abs_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1044;
for (tmp_1044 = 0; tmp_1044 < 1; ++tmp_1044)
{
switch (tmp_1044)
{
case 0 :
{
compvar_t *tmp_1045, *tmp_1046;
tmp_1045 = args[0][0];
tmp_1046 = args[0][1];
emit_assign(make_lhs(result[tmp_1044]), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_1045), make_compvar_primary(tmp_1046)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_abs_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1047;
tmp_1047 = STK[STKP - 1].data[0];
result[0] = fabs(tmp_1047);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_abs_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1048;
for (tmp_1048 = 0; tmp_1048 < 1; ++tmp_1048)
{
{
compvar_t *tmp_1049;
tmp_1049 = args[0][tmp_1048];
emit_assign(make_lhs(result[tmp_1048]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_1049)));
}
}
}
}

void
builtin_abs_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1050;
for (tmp_1050 = 0; tmp_1050 < STK[STKP - 1].length; ++tmp_1050)
{
{
float tmp_1051;
tmp_1051 = STK[STKP - 1].data[tmp_1050];
result[tmp_1050] = fabs(tmp_1051);
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].length; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = STK[STKP - 1].length;
STKP -= 0;
}

void
gen_abs_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1052;
for (tmp_1052 = 0; tmp_1052 < arglengths[0]; ++tmp_1052)
{
{
compvar_t *tmp_1053;
tmp_1053 = args[0][tmp_1052];
emit_assign(make_lhs(result[tmp_1052]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_1053)));
}
}
}
}

void
builtin_deg2rad (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1054;
float tmp_1055;
tmp_1054 = STK[STKP - 1].data[0];
tmp_1055 = 0.017453292;
result[0] = tmp_1054 * tmp_1055;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_deg2rad (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1056;
for (tmp_1056 = 0; tmp_1056 < 1; ++tmp_1056)
{
switch (tmp_1056)
{
case 0 :
{
compvar_t *tmp_1057, *tmp_1058;
tmp_1057 = args[0][0];
tmp_1058 = make_temporary();
emit_assign(make_lhs(tmp_1058), make_float_const_rhs(0.017453292));
emit_assign(make_lhs(result[tmp_1056]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1057), make_compvar_primary(tmp_1058)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_rad2deg (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1059;
float tmp_1060;
tmp_1059 = STK[STKP - 1].data[0];
tmp_1060 = 57.29578;
result[0] = tmp_1059 * tmp_1060;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_rad2deg (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1061;
for (tmp_1061 = 0; tmp_1061 < 1; ++tmp_1061)
{
switch (tmp_1061)
{
case 0 :
{
compvar_t *tmp_1062, *tmp_1063;
tmp_1062 = args[0][0];
tmp_1063 = make_temporary();
emit_assign(make_lhs(tmp_1063), make_float_const_rhs(57.29578));
emit_assign(make_lhs(result[tmp_1061]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1062), make_compvar_primary(tmp_1063)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_sin_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1064;

{
complex float tmp_1065;
{
float tmp_1066;
float tmp_1067;
tmp_1066 = STK[STKP - 1].data[0];
tmp_1067 = STK[STKP - 1].data[1];
tmp_1065 = (tmp_1066 + tmp_1067 * I);
}
tmp_1064 = csinf(tmp_1065);
}

{
complex float tmp_1068;
tmp_1068 = tmp_1064;
result[0] = crealf(tmp_1068);
}
{
complex float tmp_1069;
tmp_1069 = tmp_1064;
result[1] = cimagf(tmp_1069);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_sin_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1070;

tmp_1070 = make_temporary();
{
compvar_t *tmp_1071;
tmp_1071 = make_temporary();
{
compvar_t *tmp_1072, *tmp_1073;
tmp_1072 = args[0][0];
tmp_1073 = args[0][1];
emit_assign(make_lhs(tmp_1071), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1072), make_compvar_primary(tmp_1073)));
}
emit_assign(make_lhs(tmp_1070), make_op_rhs(OP_C_SIN, make_compvar_primary(tmp_1071)));
}

{
int tmp_1074;
for (tmp_1074 = 0; tmp_1074 < 2; ++tmp_1074)
{
switch (tmp_1074)
{
case 0 :
{
compvar_t *tmp_1075;
tmp_1075 = tmp_1070;
emit_assign(make_lhs(result[tmp_1074]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1075)));
}
break;
case 1 :
{
compvar_t *tmp_1076;
tmp_1076 = tmp_1070;
emit_assign(make_lhs(result[tmp_1074]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1076)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_sin (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1077;
tmp_1077 = STK[STKP - 1].data[0];
result[0] = sin(tmp_1077);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_sin (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1078;
for (tmp_1078 = 0; tmp_1078 < 1; ++tmp_1078)
{
switch (tmp_1078)
{
case 0 :
{
compvar_t *tmp_1079;
tmp_1079 = args[0][0];
emit_assign(make_lhs(result[tmp_1078]), make_op_rhs(OP_SIN, make_compvar_primary(tmp_1079)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_cos_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1080;

{
complex float tmp_1081;
{
float tmp_1082;
float tmp_1083;
tmp_1082 = STK[STKP - 1].data[0];
tmp_1083 = STK[STKP - 1].data[1];
tmp_1081 = (tmp_1082 + tmp_1083 * I);
}
tmp_1080 = ccosf(tmp_1081);
}

{
complex float tmp_1084;
tmp_1084 = tmp_1080;
result[0] = crealf(tmp_1084);
}
{
complex float tmp_1085;
tmp_1085 = tmp_1080;
result[1] = cimagf(tmp_1085);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_cos_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1086;

tmp_1086 = make_temporary();
{
compvar_t *tmp_1087;
tmp_1087 = make_temporary();
{
compvar_t *tmp_1088, *tmp_1089;
tmp_1088 = args[0][0];
tmp_1089 = args[0][1];
emit_assign(make_lhs(tmp_1087), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1088), make_compvar_primary(tmp_1089)));
}
emit_assign(make_lhs(tmp_1086), make_op_rhs(OP_C_COS, make_compvar_primary(tmp_1087)));
}

{
int tmp_1090;
for (tmp_1090 = 0; tmp_1090 < 2; ++tmp_1090)
{
switch (tmp_1090)
{
case 0 :
{
compvar_t *tmp_1091;
tmp_1091 = tmp_1086;
emit_assign(make_lhs(result[tmp_1090]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1091)));
}
break;
case 1 :
{
compvar_t *tmp_1092;
tmp_1092 = tmp_1086;
emit_assign(make_lhs(result[tmp_1090]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1092)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_cos (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1093;
tmp_1093 = STK[STKP - 1].data[0];
result[0] = cos(tmp_1093);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_cos (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1094;
for (tmp_1094 = 0; tmp_1094 < 1; ++tmp_1094)
{
switch (tmp_1094)
{
case 0 :
{
compvar_t *tmp_1095;
tmp_1095 = args[0][0];
emit_assign(make_lhs(result[tmp_1094]), make_op_rhs(OP_COS, make_compvar_primary(tmp_1095)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_tan_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1096;

{
complex float tmp_1097;
{
float tmp_1098;
float tmp_1099;
tmp_1098 = STK[STKP - 1].data[0];
tmp_1099 = STK[STKP - 1].data[1];
tmp_1097 = (tmp_1098 + tmp_1099 * I);
}
tmp_1096 = ctanf(tmp_1097);
}

{
complex float tmp_1100;
tmp_1100 = tmp_1096;
result[0] = crealf(tmp_1100);
}
{
complex float tmp_1101;
tmp_1101 = tmp_1096;
result[1] = cimagf(tmp_1101);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_tan_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1102;

tmp_1102 = make_temporary();
{
compvar_t *tmp_1103;
tmp_1103 = make_temporary();
{
compvar_t *tmp_1104, *tmp_1105;
tmp_1104 = args[0][0];
tmp_1105 = args[0][1];
emit_assign(make_lhs(tmp_1103), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1104), make_compvar_primary(tmp_1105)));
}
emit_assign(make_lhs(tmp_1102), make_op_rhs(OP_C_TAN, make_compvar_primary(tmp_1103)));
}

{
int tmp_1106;
for (tmp_1106 = 0; tmp_1106 < 2; ++tmp_1106)
{
switch (tmp_1106)
{
case 0 :
{
compvar_t *tmp_1107;
tmp_1107 = tmp_1102;
emit_assign(make_lhs(result[tmp_1106]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1107)));
}
break;
case 1 :
{
compvar_t *tmp_1108;
tmp_1108 = tmp_1102;
emit_assign(make_lhs(result[tmp_1106]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1108)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_tan (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1109;
tmp_1109 = STK[STKP - 1].data[0];
result[0] = tan(tmp_1109);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_tan (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1110;
for (tmp_1110 = 0; tmp_1110 < 1; ++tmp_1110)
{
switch (tmp_1110)
{
case 0 :
{
compvar_t *tmp_1111;
tmp_1111 = args[0][0];
emit_assign(make_lhs(result[tmp_1110]), make_op_rhs(OP_TAN, make_compvar_primary(tmp_1111)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_asin_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1112;

{
complex float tmp_1113;
{
float tmp_1114;
float tmp_1115;
tmp_1114 = STK[STKP - 1].data[0];
tmp_1115 = STK[STKP - 1].data[1];
tmp_1113 = (tmp_1114 + tmp_1115 * I);
}
tmp_1112 = casinf(tmp_1113);
}

{
complex float tmp_1116;
tmp_1116 = tmp_1112;
result[0] = crealf(tmp_1116);
}
{
complex float tmp_1117;
tmp_1117 = tmp_1112;
result[1] = cimagf(tmp_1117);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_asin_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1118;

tmp_1118 = make_temporary();
{
compvar_t *tmp_1119;
tmp_1119 = make_temporary();
{
compvar_t *tmp_1120, *tmp_1121;
tmp_1120 = args[0][0];
tmp_1121 = args[0][1];
emit_assign(make_lhs(tmp_1119), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1120), make_compvar_primary(tmp_1121)));
}
emit_assign(make_lhs(tmp_1118), make_op_rhs(OP_C_ASIN, make_compvar_primary(tmp_1119)));
}

{
int tmp_1122;
for (tmp_1122 = 0; tmp_1122 < 2; ++tmp_1122)
{
switch (tmp_1122)
{
case 0 :
{
compvar_t *tmp_1123;
tmp_1123 = tmp_1118;
emit_assign(make_lhs(result[tmp_1122]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1123)));
}
break;
case 1 :
{
compvar_t *tmp_1124;
tmp_1124 = tmp_1118;
emit_assign(make_lhs(result[tmp_1122]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1124)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_asin (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1125;
{
float tmp_1126;
float tmp_1127;
tmp_1126 = STK[STKP - 1].data[0];
tmp_1127 = -1;
tmp_1125 = (tmp_1126 < tmp_1127);
}
if (!tmp_1125)
{
{
float tmp_1128;
float tmp_1129;
tmp_1128 = 1;
tmp_1129 = STK[STKP - 1].data[0];
tmp_1125 = (tmp_1128 < tmp_1129);
}
}
if (tmp_1125)
{
result[0] = 0;
}
else
{
{
float tmp_1130;
tmp_1130 = STK[STKP - 1].data[0];
result[0] = asin(tmp_1130);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_asin (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1131;
tmp_1131 = make_temporary();
{
compvar_t *tmp_1132, *tmp_1133;
tmp_1132 = args[0][0];
tmp_1133 = make_temporary();
emit_assign(make_lhs(tmp_1133), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_1131), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1132), make_compvar_primary(tmp_1133)));
}
start_if_cond(make_compvar_rhs(tmp_1131));
switch_if_branch();
{
compvar_t *tmp_1134, *tmp_1135;
tmp_1134 = make_temporary();
emit_assign(make_lhs(tmp_1134), make_int_const_rhs(1));
tmp_1135 = args[0][0];
emit_assign(make_lhs(tmp_1131), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1134), make_compvar_primary(tmp_1135)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1131));
{
int tmp_1136;
for (tmp_1136 = 0; tmp_1136 < 1; ++tmp_1136)
{
switch (tmp_1136)
{
case 0 :
emit_assign(make_lhs(result[tmp_1136]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1137;
for (tmp_1137 = 0; tmp_1137 < 1; ++tmp_1137)
{
switch (tmp_1137)
{
case 0 :
{
compvar_t *tmp_1138;
tmp_1138 = args[0][0];
emit_assign(make_lhs(result[tmp_1137]), make_op_rhs(OP_ASIN, make_compvar_primary(tmp_1138)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_acos_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1139;

{
complex float tmp_1140;
{
float tmp_1141;
float tmp_1142;
tmp_1141 = STK[STKP - 1].data[0];
tmp_1142 = STK[STKP - 1].data[1];
tmp_1140 = (tmp_1141 + tmp_1142 * I);
}
tmp_1139 = cacosf(tmp_1140);
}

{
complex float tmp_1143;
tmp_1143 = tmp_1139;
result[0] = crealf(tmp_1143);
}
{
complex float tmp_1144;
tmp_1144 = tmp_1139;
result[1] = cimagf(tmp_1144);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_acos_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1145;

tmp_1145 = make_temporary();
{
compvar_t *tmp_1146;
tmp_1146 = make_temporary();
{
compvar_t *tmp_1147, *tmp_1148;
tmp_1147 = args[0][0];
tmp_1148 = args[0][1];
emit_assign(make_lhs(tmp_1146), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1147), make_compvar_primary(tmp_1148)));
}
emit_assign(make_lhs(tmp_1145), make_op_rhs(OP_C_ACOS, make_compvar_primary(tmp_1146)));
}

{
int tmp_1149;
for (tmp_1149 = 0; tmp_1149 < 2; ++tmp_1149)
{
switch (tmp_1149)
{
case 0 :
{
compvar_t *tmp_1150;
tmp_1150 = tmp_1145;
emit_assign(make_lhs(result[tmp_1149]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1150)));
}
break;
case 1 :
{
compvar_t *tmp_1151;
tmp_1151 = tmp_1145;
emit_assign(make_lhs(result[tmp_1149]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1151)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_acos (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1152;
{
float tmp_1153;
float tmp_1154;
tmp_1153 = STK[STKP - 1].data[0];
tmp_1154 = -1;
tmp_1152 = (tmp_1153 < tmp_1154);
}
if (!tmp_1152)
{
{
float tmp_1155;
float tmp_1156;
tmp_1155 = 1;
tmp_1156 = STK[STKP - 1].data[0];
tmp_1152 = (tmp_1155 < tmp_1156);
}
}
if (tmp_1152)
{
result[0] = 0;
}
else
{
{
float tmp_1157;
tmp_1157 = STK[STKP - 1].data[0];
result[0] = acos(tmp_1157);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_acos (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1158;
tmp_1158 = make_temporary();
{
compvar_t *tmp_1159, *tmp_1160;
tmp_1159 = args[0][0];
tmp_1160 = make_temporary();
emit_assign(make_lhs(tmp_1160), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_1158), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1159), make_compvar_primary(tmp_1160)));
}
start_if_cond(make_compvar_rhs(tmp_1158));
switch_if_branch();
{
compvar_t *tmp_1161, *tmp_1162;
tmp_1161 = make_temporary();
emit_assign(make_lhs(tmp_1161), make_int_const_rhs(1));
tmp_1162 = args[0][0];
emit_assign(make_lhs(tmp_1158), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1161), make_compvar_primary(tmp_1162)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1158));
{
int tmp_1163;
for (tmp_1163 = 0; tmp_1163 < 1; ++tmp_1163)
{
switch (tmp_1163)
{
case 0 :
emit_assign(make_lhs(result[tmp_1163]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1164;
for (tmp_1164 = 0; tmp_1164 < 1; ++tmp_1164)
{
switch (tmp_1164)
{
case 0 :
{
compvar_t *tmp_1165;
tmp_1165 = args[0][0];
emit_assign(make_lhs(result[tmp_1164]), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_1165)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_atan_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1166;

{
complex float tmp_1167;
{
float tmp_1168;
float tmp_1169;
tmp_1168 = STK[STKP - 1].data[0];
tmp_1169 = STK[STKP - 1].data[1];
tmp_1167 = (tmp_1168 + tmp_1169 * I);
}
tmp_1166 = catanf(tmp_1167);
}

{
complex float tmp_1170;
tmp_1170 = tmp_1166;
result[0] = crealf(tmp_1170);
}
{
complex float tmp_1171;
tmp_1171 = tmp_1166;
result[1] = cimagf(tmp_1171);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_atan_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1172;

tmp_1172 = make_temporary();
{
compvar_t *tmp_1173;
tmp_1173 = make_temporary();
{
compvar_t *tmp_1174, *tmp_1175;
tmp_1174 = args[0][0];
tmp_1175 = args[0][1];
emit_assign(make_lhs(tmp_1173), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1174), make_compvar_primary(tmp_1175)));
}
emit_assign(make_lhs(tmp_1172), make_op_rhs(OP_C_ATAN, make_compvar_primary(tmp_1173)));
}

{
int tmp_1176;
for (tmp_1176 = 0; tmp_1176 < 2; ++tmp_1176)
{
switch (tmp_1176)
{
case 0 :
{
compvar_t *tmp_1177;
tmp_1177 = tmp_1172;
emit_assign(make_lhs(result[tmp_1176]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1177)));
}
break;
case 1 :
{
compvar_t *tmp_1178;
tmp_1178 = tmp_1172;
emit_assign(make_lhs(result[tmp_1176]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1178)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_atan (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1179;
tmp_1179 = STK[STKP - 1].data[0];
result[0] = atan(tmp_1179);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_atan (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1180;
for (tmp_1180 = 0; tmp_1180 < 1; ++tmp_1180)
{
switch (tmp_1180)
{
case 0 :
{
compvar_t *tmp_1181;
tmp_1181 = args[0][0];
emit_assign(make_lhs(result[tmp_1180]), make_op_rhs(OP_ATAN, make_compvar_primary(tmp_1181)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_atan2 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1182;
float tmp_1183;
tmp_1182 = STK[STKP - 2].data[0];
tmp_1183 = STK[STKP - 1].data[0];
result[0] = atan2(tmp_1182, tmp_1183);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_atan2 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1184;
for (tmp_1184 = 0; tmp_1184 < 1; ++tmp_1184)
{
switch (tmp_1184)
{
case 0 :
{
compvar_t *tmp_1185, *tmp_1186;
tmp_1185 = args[0][0];
tmp_1186 = args[1][0];
emit_assign(make_lhs(result[tmp_1184]), make_op_rhs(OP_ATAN2, make_compvar_primary(tmp_1185), make_compvar_primary(tmp_1186)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_pow_ri_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1187;

{
complex float tmp_1188;
complex float tmp_1189;
{
float tmp_1190;
float tmp_1191;
tmp_1190 = STK[STKP - 2].data[0];
tmp_1191 = STK[STKP - 2].data[1];
tmp_1188 = (tmp_1190 + tmp_1191 * I);
}
{
float tmp_1192;
float tmp_1193;
tmp_1192 = STK[STKP - 1].data[0];
tmp_1193 = 0.0;
tmp_1189 = (tmp_1192 + tmp_1193 * I);
}
tmp_1187 = cpowf(tmp_1188, tmp_1189);
}

{
complex float tmp_1194;
tmp_1194 = tmp_1187;
result[0] = crealf(tmp_1194);
}
{
complex float tmp_1195;
tmp_1195 = tmp_1187;
result[1] = cimagf(tmp_1195);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_pow_ri_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1196;

tmp_1196 = make_temporary();
{
compvar_t *tmp_1197, *tmp_1198;
tmp_1197 = make_temporary();
{
compvar_t *tmp_1199, *tmp_1200;
tmp_1199 = args[0][0];
tmp_1200 = args[0][1];
emit_assign(make_lhs(tmp_1197), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1199), make_compvar_primary(tmp_1200)));
}
tmp_1198 = make_temporary();
{
compvar_t *tmp_1201, *tmp_1202;
tmp_1201 = args[1][0];
tmp_1202 = make_temporary();
emit_assign(make_lhs(tmp_1202), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_1198), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1201), make_compvar_primary(tmp_1202)));
}
emit_assign(make_lhs(tmp_1196), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_1197), make_compvar_primary(tmp_1198)));
}

{
int tmp_1203;
for (tmp_1203 = 0; tmp_1203 < 2; ++tmp_1203)
{
switch (tmp_1203)
{
case 0 :
{
compvar_t *tmp_1204;
tmp_1204 = tmp_1196;
emit_assign(make_lhs(result[tmp_1203]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1204)));
}
break;
case 1 :
{
compvar_t *tmp_1205;
tmp_1205 = tmp_1196;
emit_assign(make_lhs(result[tmp_1203]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1205)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_pow_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1206;

{
complex float tmp_1207;
complex float tmp_1208;
{
float tmp_1209;
float tmp_1210;
tmp_1209 = STK[STKP - 2].data[0];
tmp_1210 = STK[STKP - 2].data[1];
tmp_1207 = (tmp_1209 + tmp_1210 * I);
}
{
float tmp_1211;
float tmp_1212;
tmp_1211 = STK[STKP - 1].data[0];
tmp_1212 = STK[STKP - 1].data[1];
tmp_1208 = (tmp_1211 + tmp_1212 * I);
}
tmp_1206 = cpowf(tmp_1207, tmp_1208);
}

{
complex float tmp_1213;
tmp_1213 = tmp_1206;
result[0] = crealf(tmp_1213);
}
{
complex float tmp_1214;
tmp_1214 = tmp_1206;
result[1] = cimagf(tmp_1214);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_pow_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1215;

tmp_1215 = make_temporary();
{
compvar_t *tmp_1216, *tmp_1217;
tmp_1216 = make_temporary();
{
compvar_t *tmp_1218, *tmp_1219;
tmp_1218 = args[0][0];
tmp_1219 = args[0][1];
emit_assign(make_lhs(tmp_1216), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1218), make_compvar_primary(tmp_1219)));
}
tmp_1217 = make_temporary();
{
compvar_t *tmp_1220, *tmp_1221;
tmp_1220 = args[1][0];
tmp_1221 = args[1][1];
emit_assign(make_lhs(tmp_1217), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1220), make_compvar_primary(tmp_1221)));
}
emit_assign(make_lhs(tmp_1215), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_1216), make_compvar_primary(tmp_1217)));
}

{
int tmp_1222;
for (tmp_1222 = 0; tmp_1222 < 2; ++tmp_1222)
{
switch (tmp_1222)
{
case 0 :
{
compvar_t *tmp_1223;
tmp_1223 = tmp_1215;
emit_assign(make_lhs(result[tmp_1222]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1223)));
}
break;
case 1 :
{
compvar_t *tmp_1224;
tmp_1224 = tmp_1215;
emit_assign(make_lhs(result[tmp_1222]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1224)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_pow_1_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1225;

{
complex float tmp_1226;
complex float tmp_1227;
{
float tmp_1228;
float tmp_1229;
tmp_1228 = STK[STKP - 2].data[0];
tmp_1229 = 0.0;
tmp_1226 = (tmp_1228 + tmp_1229 * I);
}
{
float tmp_1230;
float tmp_1231;
tmp_1230 = STK[STKP - 1].data[0];
tmp_1231 = STK[STKP - 1].data[1];
tmp_1227 = (tmp_1230 + tmp_1231 * I);
}
tmp_1225 = cpowf(tmp_1226, tmp_1227);
}

{
complex float tmp_1232;
tmp_1232 = tmp_1225;
result[0] = crealf(tmp_1232);
}
{
complex float tmp_1233;
tmp_1233 = tmp_1225;
result[1] = cimagf(tmp_1233);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 2;
STKP -= 1;
}

void
gen_pow_1_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1234;

tmp_1234 = make_temporary();
{
compvar_t *tmp_1235, *tmp_1236;
tmp_1235 = make_temporary();
{
compvar_t *tmp_1237, *tmp_1238;
tmp_1237 = args[0][0];
tmp_1238 = make_temporary();
emit_assign(make_lhs(tmp_1238), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_1235), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1237), make_compvar_primary(tmp_1238)));
}
tmp_1236 = make_temporary();
{
compvar_t *tmp_1239, *tmp_1240;
tmp_1239 = args[1][0];
tmp_1240 = args[1][1];
emit_assign(make_lhs(tmp_1236), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1239), make_compvar_primary(tmp_1240)));
}
emit_assign(make_lhs(tmp_1234), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_1235), make_compvar_primary(tmp_1236)));
}

{
int tmp_1241;
for (tmp_1241 = 0; tmp_1241 < 2; ++tmp_1241)
{
switch (tmp_1241)
{
case 0 :
{
compvar_t *tmp_1242;
tmp_1242 = tmp_1234;
emit_assign(make_lhs(result[tmp_1241]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1242)));
}
break;
case 1 :
{
compvar_t *tmp_1243;
tmp_1243 = tmp_1234;
emit_assign(make_lhs(result[tmp_1241]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1243)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_pow_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1244;
{
float tmp_1245;
float tmp_1246;
tmp_1245 = STK[STKP - 1].data[0];
tmp_1246 = 0;
tmp_1244 = (tmp_1245 <= tmp_1246);
}
if (tmp_1244)
{
{
float tmp_1247;
float tmp_1248;
tmp_1247 = STK[STKP - 2].data[0];
tmp_1248 = 0;
tmp_1244 = (tmp_1247 == tmp_1248);
}
}
if (tmp_1244)
{
result[0] = 0;
}
else
{
{
float tmp_1249;
float tmp_1250;
tmp_1249 = STK[STKP - 2].data[0];
tmp_1250 = STK[STKP - 1].data[0];
result[0] = pow(tmp_1249, tmp_1250);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_pow_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1251;
tmp_1251 = make_temporary();
{
compvar_t *tmp_1252, *tmp_1253;
tmp_1252 = args[1][0];
tmp_1253 = make_temporary();
emit_assign(make_lhs(tmp_1253), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1251), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1252), make_compvar_primary(tmp_1253)));
}
start_if_cond(make_compvar_rhs(tmp_1251));
{
compvar_t *tmp_1254, *tmp_1255;
tmp_1254 = args[0][0];
tmp_1255 = make_temporary();
emit_assign(make_lhs(tmp_1255), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1251), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1254), make_compvar_primary(tmp_1255)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1251));
{
int tmp_1256;
for (tmp_1256 = 0; tmp_1256 < 1; ++tmp_1256)
{
switch (tmp_1256)
{
case 0 :
emit_assign(make_lhs(result[tmp_1256]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1257;
for (tmp_1257 = 0; tmp_1257 < 1; ++tmp_1257)
{
switch (tmp_1257)
{
case 0 :
{
compvar_t *tmp_1258, *tmp_1259;
tmp_1258 = args[0][0];
tmp_1259 = args[1][0];
emit_assign(make_lhs(result[tmp_1257]), make_op_rhs(OP_POW, make_compvar_primary(tmp_1258), make_compvar_primary(tmp_1259)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_pow_s (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1260;
for (tmp_1260 = 0; tmp_1260 < STK[STKP - 2].length; ++tmp_1260)
{
{
float tmp_1261;
{
float tmp_1262;
float tmp_1263;
tmp_1262 = STK[STKP - 1].data[0];
tmp_1263 = 0;
tmp_1261 = (tmp_1262 <= tmp_1263);
}
if (tmp_1261)
{
{
float tmp_1264;
float tmp_1265;
tmp_1264 = STK[STKP - 2].data[tmp_1260];
tmp_1265 = 0;
tmp_1261 = (tmp_1264 == tmp_1265);
}
}
if (tmp_1261)
{
result[tmp_1260] = 0;
}
else
{
{
float tmp_1266;
float tmp_1267;
tmp_1266 = STK[STKP - 2].data[tmp_1260];
tmp_1267 = STK[STKP - 1].data[0];
result[tmp_1260] = pow(tmp_1266, tmp_1267);
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_pow_s (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1268;
for (tmp_1268 = 0; tmp_1268 < arglengths[0]; ++tmp_1268)
{
{
compvar_t *tmp_1269;
tmp_1269 = make_temporary();
{
compvar_t *tmp_1270, *tmp_1271;
tmp_1270 = args[1][0];
tmp_1271 = make_temporary();
emit_assign(make_lhs(tmp_1271), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1269), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1270), make_compvar_primary(tmp_1271)));
}
start_if_cond(make_compvar_rhs(tmp_1269));
{
compvar_t *tmp_1272, *tmp_1273;
tmp_1272 = args[0][tmp_1268];
tmp_1273 = make_temporary();
emit_assign(make_lhs(tmp_1273), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1269), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1272), make_compvar_primary(tmp_1273)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1269));
emit_assign(make_lhs(result[tmp_1268]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1274, *tmp_1275;
tmp_1274 = args[0][tmp_1268];
tmp_1275 = args[1][0];
emit_assign(make_lhs(result[tmp_1268]), make_op_rhs(OP_POW, make_compvar_primary(tmp_1274), make_compvar_primary(tmp_1275)));
}
end_if_cond();
}
}
}
}

void
builtin_exp_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1276;

{
complex float tmp_1277;
{
float tmp_1278;
float tmp_1279;
tmp_1278 = STK[STKP - 1].data[0];
tmp_1279 = STK[STKP - 1].data[1];
tmp_1277 = (tmp_1278 + tmp_1279 * I);
}
tmp_1276 = cexpf(tmp_1277);
}

{
complex float tmp_1280;
tmp_1280 = tmp_1276;
result[0] = crealf(tmp_1280);
}
{
complex float tmp_1281;
tmp_1281 = tmp_1276;
result[1] = cimagf(tmp_1281);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_exp_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1282;

tmp_1282 = make_temporary();
{
compvar_t *tmp_1283;
tmp_1283 = make_temporary();
{
compvar_t *tmp_1284, *tmp_1285;
tmp_1284 = args[0][0];
tmp_1285 = args[0][1];
emit_assign(make_lhs(tmp_1283), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1284), make_compvar_primary(tmp_1285)));
}
emit_assign(make_lhs(tmp_1282), make_op_rhs(OP_C_EXP, make_compvar_primary(tmp_1283)));
}

{
int tmp_1286;
for (tmp_1286 = 0; tmp_1286 < 2; ++tmp_1286)
{
switch (tmp_1286)
{
case 0 :
{
compvar_t *tmp_1287;
tmp_1287 = tmp_1282;
emit_assign(make_lhs(result[tmp_1286]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1287)));
}
break;
case 1 :
{
compvar_t *tmp_1288;
tmp_1288 = tmp_1282;
emit_assign(make_lhs(result[tmp_1286]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1288)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_exp_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1289;
tmp_1289 = STK[STKP - 1].data[0];
result[0] = exp(tmp_1289);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_exp_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1290;
for (tmp_1290 = 0; tmp_1290 < 1; ++tmp_1290)
{
switch (tmp_1290)
{
case 0 :
{
compvar_t *tmp_1291;
tmp_1291 = args[0][0];
emit_assign(make_lhs(result[tmp_1290]), make_op_rhs(OP_EXP, make_compvar_primary(tmp_1291)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_log_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1292;

{
complex float tmp_1293;
{
float tmp_1294;
float tmp_1295;
tmp_1294 = STK[STKP - 1].data[0];
tmp_1295 = STK[STKP - 1].data[1];
tmp_1293 = (tmp_1294 + tmp_1295 * I);
}
tmp_1292 = clogf(tmp_1293);
}

{
complex float tmp_1296;
tmp_1296 = tmp_1292;
result[0] = crealf(tmp_1296);
}
{
complex float tmp_1297;
tmp_1297 = tmp_1292;
result[1] = cimagf(tmp_1297);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_log_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1298;

tmp_1298 = make_temporary();
{
compvar_t *tmp_1299;
tmp_1299 = make_temporary();
{
compvar_t *tmp_1300, *tmp_1301;
tmp_1300 = args[0][0];
tmp_1301 = args[0][1];
emit_assign(make_lhs(tmp_1299), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1300), make_compvar_primary(tmp_1301)));
}
emit_assign(make_lhs(tmp_1298), make_op_rhs(OP_C_LOG, make_compvar_primary(tmp_1299)));
}

{
int tmp_1302;
for (tmp_1302 = 0; tmp_1302 < 2; ++tmp_1302)
{
switch (tmp_1302)
{
case 0 :
{
compvar_t *tmp_1303;
tmp_1303 = tmp_1298;
emit_assign(make_lhs(result[tmp_1302]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1303)));
}
break;
case 1 :
{
compvar_t *tmp_1304;
tmp_1304 = tmp_1298;
emit_assign(make_lhs(result[tmp_1302]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1304)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_log_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1305;
{
float tmp_1306;
float tmp_1307;
tmp_1306 = STK[STKP - 1].data[0];
tmp_1307 = 0;
tmp_1305 = (tmp_1306 <= tmp_1307);
}
if (tmp_1305)
{
result[0] = 0;
}
else
{
{
float tmp_1308;
tmp_1308 = STK[STKP - 1].data[0];
result[0] = log(tmp_1308);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_log_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1309;
tmp_1309 = make_temporary();
{
compvar_t *tmp_1310, *tmp_1311;
tmp_1310 = args[0][0];
tmp_1311 = make_temporary();
emit_assign(make_lhs(tmp_1311), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1309), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1310), make_compvar_primary(tmp_1311)));
}
start_if_cond(make_compvar_rhs(tmp_1309));
{
int tmp_1312;
for (tmp_1312 = 0; tmp_1312 < 1; ++tmp_1312)
{
switch (tmp_1312)
{
case 0 :
emit_assign(make_lhs(result[tmp_1312]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1313;
for (tmp_1313 = 0; tmp_1313 < 1; ++tmp_1313)
{
switch (tmp_1313)
{
case 0 :
{
compvar_t *tmp_1314;
tmp_1314 = args[0][0];
emit_assign(make_lhs(result[tmp_1313]), make_op_rhs(OP_LOG, make_compvar_primary(tmp_1314)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_arg_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1315;
{
float tmp_1316;
float tmp_1317;
tmp_1316 = STK[STKP - 1].data[0];
tmp_1317 = STK[STKP - 1].data[1];
tmp_1315 = (tmp_1316 + tmp_1317 * I);
}
result[0] = cargf(tmp_1315);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_arg_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1318;
for (tmp_1318 = 0; tmp_1318 < 1; ++tmp_1318)
{
switch (tmp_1318)
{
case 0 :
{
compvar_t *tmp_1319;
tmp_1319 = make_temporary();
{
compvar_t *tmp_1320, *tmp_1321;
tmp_1320 = args[0][0];
tmp_1321 = args[0][1];
emit_assign(make_lhs(tmp_1319), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1320), make_compvar_primary(tmp_1321)));
}
emit_assign(make_lhs(result[tmp_1318]), make_op_rhs(OP_C_ARG, make_compvar_primary(tmp_1319)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_conj_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
result[0] = STK[STKP - 1].data[0];
{
float tmp_1322;
tmp_1322 = STK[STKP - 1].data[1];
result[1] = -tmp_1322;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_conj_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1323;
for (tmp_1323 = 0; tmp_1323 < 2; ++tmp_1323)
{
switch (tmp_1323)
{
case 0 :
emit_assign(make_lhs(result[tmp_1323]), make_compvar_rhs(args[0][0]));
break;
case 1 :
{
compvar_t *tmp_1324;
tmp_1324 = args[0][1];
emit_assign(make_lhs(result[tmp_1323]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_1324)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_sinh_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1325;

{
complex float tmp_1326;
{
float tmp_1327;
float tmp_1328;
tmp_1327 = STK[STKP - 1].data[0];
tmp_1328 = STK[STKP - 1].data[1];
tmp_1326 = (tmp_1327 + tmp_1328 * I);
}
tmp_1325 = csinhf(tmp_1326);
}

{
complex float tmp_1329;
tmp_1329 = tmp_1325;
result[0] = crealf(tmp_1329);
}
{
complex float tmp_1330;
tmp_1330 = tmp_1325;
result[1] = cimagf(tmp_1330);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_sinh_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1331;

tmp_1331 = make_temporary();
{
compvar_t *tmp_1332;
tmp_1332 = make_temporary();
{
compvar_t *tmp_1333, *tmp_1334;
tmp_1333 = args[0][0];
tmp_1334 = args[0][1];
emit_assign(make_lhs(tmp_1332), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1333), make_compvar_primary(tmp_1334)));
}
emit_assign(make_lhs(tmp_1331), make_op_rhs(OP_C_SINH, make_compvar_primary(tmp_1332)));
}

{
int tmp_1335;
for (tmp_1335 = 0; tmp_1335 < 2; ++tmp_1335)
{
switch (tmp_1335)
{
case 0 :
{
compvar_t *tmp_1336;
tmp_1336 = tmp_1331;
emit_assign(make_lhs(result[tmp_1335]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1336)));
}
break;
case 1 :
{
compvar_t *tmp_1337;
tmp_1337 = tmp_1331;
emit_assign(make_lhs(result[tmp_1335]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1337)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_sinh_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1338;
tmp_1338 = STK[STKP - 1].data[0];
result[0] = sinh(tmp_1338);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_sinh_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1339;
for (tmp_1339 = 0; tmp_1339 < 1; ++tmp_1339)
{
switch (tmp_1339)
{
case 0 :
{
compvar_t *tmp_1340;
tmp_1340 = args[0][0];
emit_assign(make_lhs(result[tmp_1339]), make_op_rhs(OP_SINH, make_compvar_primary(tmp_1340)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_cosh_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1341;

{
complex float tmp_1342;
{
float tmp_1343;
float tmp_1344;
tmp_1343 = STK[STKP - 1].data[0];
tmp_1344 = STK[STKP - 1].data[1];
tmp_1342 = (tmp_1343 + tmp_1344 * I);
}
tmp_1341 = ccoshf(tmp_1342);
}

{
complex float tmp_1345;
tmp_1345 = tmp_1341;
result[0] = crealf(tmp_1345);
}
{
complex float tmp_1346;
tmp_1346 = tmp_1341;
result[1] = cimagf(tmp_1346);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_cosh_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1347;

tmp_1347 = make_temporary();
{
compvar_t *tmp_1348;
tmp_1348 = make_temporary();
{
compvar_t *tmp_1349, *tmp_1350;
tmp_1349 = args[0][0];
tmp_1350 = args[0][1];
emit_assign(make_lhs(tmp_1348), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1349), make_compvar_primary(tmp_1350)));
}
emit_assign(make_lhs(tmp_1347), make_op_rhs(OP_C_COSH, make_compvar_primary(tmp_1348)));
}

{
int tmp_1351;
for (tmp_1351 = 0; tmp_1351 < 2; ++tmp_1351)
{
switch (tmp_1351)
{
case 0 :
{
compvar_t *tmp_1352;
tmp_1352 = tmp_1347;
emit_assign(make_lhs(result[tmp_1351]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1352)));
}
break;
case 1 :
{
compvar_t *tmp_1353;
tmp_1353 = tmp_1347;
emit_assign(make_lhs(result[tmp_1351]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1353)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_cosh_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1354;
tmp_1354 = STK[STKP - 1].data[0];
result[0] = cosh(tmp_1354);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_cosh_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1355;
for (tmp_1355 = 0; tmp_1355 < 1; ++tmp_1355)
{
switch (tmp_1355)
{
case 0 :
{
compvar_t *tmp_1356;
tmp_1356 = args[0][0];
emit_assign(make_lhs(result[tmp_1355]), make_op_rhs(OP_COSH, make_compvar_primary(tmp_1356)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_tanh_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1357;

{
complex float tmp_1358;
{
float tmp_1359;
float tmp_1360;
tmp_1359 = STK[STKP - 1].data[0];
tmp_1360 = STK[STKP - 1].data[1];
tmp_1358 = (tmp_1359 + tmp_1360 * I);
}
tmp_1357 = ctanhf(tmp_1358);
}

{
complex float tmp_1361;
tmp_1361 = tmp_1357;
result[0] = crealf(tmp_1361);
}
{
complex float tmp_1362;
tmp_1362 = tmp_1357;
result[1] = cimagf(tmp_1362);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_tanh_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1363;

tmp_1363 = make_temporary();
{
compvar_t *tmp_1364;
tmp_1364 = make_temporary();
{
compvar_t *tmp_1365, *tmp_1366;
tmp_1365 = args[0][0];
tmp_1366 = args[0][1];
emit_assign(make_lhs(tmp_1364), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1365), make_compvar_primary(tmp_1366)));
}
emit_assign(make_lhs(tmp_1363), make_op_rhs(OP_C_TANH, make_compvar_primary(tmp_1364)));
}

{
int tmp_1367;
for (tmp_1367 = 0; tmp_1367 < 2; ++tmp_1367)
{
switch (tmp_1367)
{
case 0 :
{
compvar_t *tmp_1368;
tmp_1368 = tmp_1363;
emit_assign(make_lhs(result[tmp_1367]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1368)));
}
break;
case 1 :
{
compvar_t *tmp_1369;
tmp_1369 = tmp_1363;
emit_assign(make_lhs(result[tmp_1367]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1369)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_tanh_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1370;
tmp_1370 = STK[STKP - 1].data[0];
result[0] = tanh(tmp_1370);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_tanh_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1371;
for (tmp_1371 = 0; tmp_1371 < 1; ++tmp_1371)
{
switch (tmp_1371)
{
case 0 :
{
compvar_t *tmp_1372;
tmp_1372 = args[0][0];
emit_assign(make_lhs(result[tmp_1371]), make_op_rhs(OP_TANH, make_compvar_primary(tmp_1372)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_asinh_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1373;

{
complex float tmp_1374;
{
float tmp_1375;
float tmp_1376;
tmp_1375 = STK[STKP - 1].data[0];
tmp_1376 = STK[STKP - 1].data[1];
tmp_1374 = (tmp_1375 + tmp_1376 * I);
}
tmp_1373 = casinhf(tmp_1374);
}

{
complex float tmp_1377;
tmp_1377 = tmp_1373;
result[0] = crealf(tmp_1377);
}
{
complex float tmp_1378;
tmp_1378 = tmp_1373;
result[1] = cimagf(tmp_1378);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_asinh_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1379;

tmp_1379 = make_temporary();
{
compvar_t *tmp_1380;
tmp_1380 = make_temporary();
{
compvar_t *tmp_1381, *tmp_1382;
tmp_1381 = args[0][0];
tmp_1382 = args[0][1];
emit_assign(make_lhs(tmp_1380), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1381), make_compvar_primary(tmp_1382)));
}
emit_assign(make_lhs(tmp_1379), make_op_rhs(OP_C_ASINH, make_compvar_primary(tmp_1380)));
}

{
int tmp_1383;
for (tmp_1383 = 0; tmp_1383 < 2; ++tmp_1383)
{
switch (tmp_1383)
{
case 0 :
{
compvar_t *tmp_1384;
tmp_1384 = tmp_1379;
emit_assign(make_lhs(result[tmp_1383]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1384)));
}
break;
case 1 :
{
compvar_t *tmp_1385;
tmp_1385 = tmp_1379;
emit_assign(make_lhs(result[tmp_1383]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1385)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_asinh_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1386;
tmp_1386 = STK[STKP - 1].data[0];
result[0] = asinh(tmp_1386);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_asinh_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1387;
for (tmp_1387 = 0; tmp_1387 < 1; ++tmp_1387)
{
switch (tmp_1387)
{
case 0 :
{
compvar_t *tmp_1388;
tmp_1388 = args[0][0];
emit_assign(make_lhs(result[tmp_1387]), make_op_rhs(OP_ASINH, make_compvar_primary(tmp_1388)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_acosh_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1389;

{
complex float tmp_1390;
{
float tmp_1391;
float tmp_1392;
tmp_1391 = STK[STKP - 1].data[0];
tmp_1392 = STK[STKP - 1].data[1];
tmp_1390 = (tmp_1391 + tmp_1392 * I);
}
tmp_1389 = cacoshf(tmp_1390);
}

{
complex float tmp_1393;
tmp_1393 = tmp_1389;
result[0] = crealf(tmp_1393);
}
{
complex float tmp_1394;
tmp_1394 = tmp_1389;
result[1] = cimagf(tmp_1394);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_acosh_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1395;

tmp_1395 = make_temporary();
{
compvar_t *tmp_1396;
tmp_1396 = make_temporary();
{
compvar_t *tmp_1397, *tmp_1398;
tmp_1397 = args[0][0];
tmp_1398 = args[0][1];
emit_assign(make_lhs(tmp_1396), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1397), make_compvar_primary(tmp_1398)));
}
emit_assign(make_lhs(tmp_1395), make_op_rhs(OP_C_ACOSH, make_compvar_primary(tmp_1396)));
}

{
int tmp_1399;
for (tmp_1399 = 0; tmp_1399 < 2; ++tmp_1399)
{
switch (tmp_1399)
{
case 0 :
{
compvar_t *tmp_1400;
tmp_1400 = tmp_1395;
emit_assign(make_lhs(result[tmp_1399]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1400)));
}
break;
case 1 :
{
compvar_t *tmp_1401;
tmp_1401 = tmp_1395;
emit_assign(make_lhs(result[tmp_1399]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1401)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_acosh_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1402;
tmp_1402 = STK[STKP - 1].data[0];
result[0] = acosh(tmp_1402);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_acosh_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1403;
for (tmp_1403 = 0; tmp_1403 < 1; ++tmp_1403)
{
switch (tmp_1403)
{
case 0 :
{
compvar_t *tmp_1404;
tmp_1404 = args[0][0];
emit_assign(make_lhs(result[tmp_1403]), make_op_rhs(OP_ACOSH, make_compvar_primary(tmp_1404)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_atanh_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1405;

{
complex float tmp_1406;
{
float tmp_1407;
float tmp_1408;
tmp_1407 = STK[STKP - 1].data[0];
tmp_1408 = STK[STKP - 1].data[1];
tmp_1406 = (tmp_1407 + tmp_1408 * I);
}
tmp_1405 = catanhf(tmp_1406);
}

{
complex float tmp_1409;
tmp_1409 = tmp_1405;
result[0] = crealf(tmp_1409);
}
{
complex float tmp_1410;
tmp_1410 = tmp_1405;
result[1] = cimagf(tmp_1410);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_atanh_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1411;

tmp_1411 = make_temporary();
{
compvar_t *tmp_1412;
tmp_1412 = make_temporary();
{
compvar_t *tmp_1413, *tmp_1414;
tmp_1413 = args[0][0];
tmp_1414 = args[0][1];
emit_assign(make_lhs(tmp_1412), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1413), make_compvar_primary(tmp_1414)));
}
emit_assign(make_lhs(tmp_1411), make_op_rhs(OP_C_ATANH, make_compvar_primary(tmp_1412)));
}

{
int tmp_1415;
for (tmp_1415 = 0; tmp_1415 < 2; ++tmp_1415)
{
switch (tmp_1415)
{
case 0 :
{
compvar_t *tmp_1416;
tmp_1416 = tmp_1411;
emit_assign(make_lhs(result[tmp_1415]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1416)));
}
break;
case 1 :
{
compvar_t *tmp_1417;
tmp_1417 = tmp_1411;
emit_assign(make_lhs(result[tmp_1415]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1417)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_atanh_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1418;
tmp_1418 = STK[STKP - 1].data[0];
result[0] = atanh(tmp_1418);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_atanh_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1419;
for (tmp_1419 = 0; tmp_1419 < 1; ++tmp_1419)
{
switch (tmp_1419)
{
case 0 :
{
compvar_t *tmp_1420;
tmp_1420 = args[0][0];
emit_assign(make_lhs(result[tmp_1419]), make_op_rhs(OP_ATANH, make_compvar_primary(tmp_1420)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_gamma_ri (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
complex float tmp_1421;

{
complex float tmp_1422;
{
float tmp_1423;
float tmp_1424;
tmp_1423 = STK[STKP - 1].data[0];
tmp_1424 = STK[STKP - 1].data[1];
tmp_1422 = (tmp_1423 + tmp_1424 * I);
}
tmp_1421 = cgamma(tmp_1422);
}

{
complex float tmp_1425;
tmp_1425 = tmp_1421;
result[0] = crealf(tmp_1425);
}
{
complex float tmp_1426;
tmp_1426 = tmp_1421;
result[1] = cimagf(tmp_1426);
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_gamma_ri (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1427;

tmp_1427 = make_temporary();
{
compvar_t *tmp_1428;
tmp_1428 = make_temporary();
{
compvar_t *tmp_1429, *tmp_1430;
tmp_1429 = args[0][0];
tmp_1430 = args[0][1];
emit_assign(make_lhs(tmp_1428), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_1429), make_compvar_primary(tmp_1430)));
}
emit_assign(make_lhs(tmp_1427), make_op_rhs(OP_C_GAMMA, make_compvar_primary(tmp_1428)));
}

{
int tmp_1431;
for (tmp_1431 = 0; tmp_1431 < 2; ++tmp_1431)
{
switch (tmp_1431)
{
case 0 :
{
compvar_t *tmp_1432;
tmp_1432 = tmp_1427;
emit_assign(make_lhs(result[tmp_1431]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_1432)));
}
break;
case 1 :
{
compvar_t *tmp_1433;
tmp_1433 = tmp_1427;
emit_assign(make_lhs(result[tmp_1431]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_1433)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_gamma_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1434;
{
float tmp_1435;
float tmp_1436;
tmp_1435 = STK[STKP - 1].data[0];
tmp_1436 = 0;
tmp_1434 = (tmp_1435 < tmp_1436);
}
if (tmp_1434)
{
result[0] = 0;
}
else
{
{
float tmp_1437;
tmp_1437 = STK[STKP - 1].data[0];
result[0] = GAMMA(tmp_1437);
}
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_gamma_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1438;
tmp_1438 = make_temporary();
{
compvar_t *tmp_1439, *tmp_1440;
tmp_1439 = args[0][0];
tmp_1440 = make_temporary();
emit_assign(make_lhs(tmp_1440), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1438), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1439), make_compvar_primary(tmp_1440)));
}
start_if_cond(make_compvar_rhs(tmp_1438));
{
int tmp_1441;
for (tmp_1441 = 0; tmp_1441 < 1; ++tmp_1441)
{
switch (tmp_1441)
{
case 0 :
emit_assign(make_lhs(result[tmp_1441]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1442;
for (tmp_1442 = 0; tmp_1442 < 1; ++tmp_1442)
{
switch (tmp_1442)
{
case 0 :
{
compvar_t *tmp_1443;
tmp_1443 = args[0][0];
emit_assign(make_lhs(result[tmp_1442]), make_op_rhs(OP_GAMMA, make_compvar_primary(tmp_1443)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_floor (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1444;
tmp_1444 = STK[STKP - 1].data[0];
result[0] = floor(tmp_1444);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_floor (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1445;
for (tmp_1445 = 0; tmp_1445 < 1; ++tmp_1445)
{
switch (tmp_1445)
{
case 0 :
{
compvar_t *tmp_1446;
tmp_1446 = args[0][0];
emit_assign(make_lhs(result[tmp_1445]), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1446)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_sign_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1447;
for (tmp_1447 = 0; tmp_1447 < STK[STKP - 1].length; ++tmp_1447)
{
{
float tmp_1448;
{
float tmp_1449;
float tmp_1450;
tmp_1449 = STK[STKP - 1].data[tmp_1447];
tmp_1450 = 0;
tmp_1448 = (tmp_1449 < tmp_1450);
}
if (tmp_1448)
{
result[tmp_1447] = -1;
}
else
{
{
float tmp_1451;
{
float tmp_1452;
float tmp_1453;
tmp_1452 = 0;
tmp_1453 = STK[STKP - 1].data[tmp_1447];
tmp_1451 = (tmp_1452 < tmp_1453);
}
if (tmp_1451)
{
result[tmp_1447] = 1;
}
else
{
result[tmp_1447] = 0;
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 1].length; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = STK[STKP - 1].length;
STKP -= 0;
}

void
gen_sign_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1454;
for (tmp_1454 = 0; tmp_1454 < arglengths[0]; ++tmp_1454)
{
{
compvar_t *tmp_1455;
tmp_1455 = make_temporary();
{
compvar_t *tmp_1456, *tmp_1457;
tmp_1456 = args[0][tmp_1454];
tmp_1457 = make_temporary();
emit_assign(make_lhs(tmp_1457), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1455), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1456), make_compvar_primary(tmp_1457)));
}
start_if_cond(make_compvar_rhs(tmp_1455));
emit_assign(make_lhs(result[tmp_1454]), make_int_const_rhs(-1));
switch_if_branch();
{
compvar_t *tmp_1458;
tmp_1458 = make_temporary();
{
compvar_t *tmp_1459, *tmp_1460;
tmp_1459 = make_temporary();
emit_assign(make_lhs(tmp_1459), make_int_const_rhs(0));
tmp_1460 = args[0][tmp_1454];
emit_assign(make_lhs(tmp_1458), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1459), make_compvar_primary(tmp_1460)));
}
start_if_cond(make_compvar_rhs(tmp_1458));
emit_assign(make_lhs(result[tmp_1454]), make_int_const_rhs(1));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1454]), make_int_const_rhs(0));
end_if_cond();
}
end_if_cond();
}
}
}
}

void
builtin_min_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1461;
for (tmp_1461 = 0; tmp_1461 < STK[STKP - 2].length; ++tmp_1461)
{
{
float tmp_1462;
{
float tmp_1463;
float tmp_1464;
tmp_1463 = STK[STKP - 2].data[tmp_1461];
tmp_1464 = STK[STKP - 1].data[tmp_1461];
tmp_1462 = (tmp_1463 < tmp_1464);
}
if (tmp_1462)
{
result[tmp_1461] = STK[STKP - 2].data[tmp_1461];
}
else
{
result[tmp_1461] = STK[STKP - 1].data[tmp_1461];
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_min_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1465;
for (tmp_1465 = 0; tmp_1465 < arglengths[0]; ++tmp_1465)
{
{
compvar_t *tmp_1466;
tmp_1466 = make_temporary();
{
compvar_t *tmp_1467, *tmp_1468;
tmp_1467 = args[0][tmp_1465];
tmp_1468 = args[1][tmp_1465];
emit_assign(make_lhs(tmp_1466), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1467), make_compvar_primary(tmp_1468)));
}
start_if_cond(make_compvar_rhs(tmp_1466));
emit_assign(make_lhs(result[tmp_1465]), make_compvar_rhs(args[0][tmp_1465]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1465]), make_compvar_rhs(args[1][tmp_1465]));
end_if_cond();
}
}
}
}

void
builtin_max_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1469;
for (tmp_1469 = 0; tmp_1469 < STK[STKP - 2].length; ++tmp_1469)
{
{
float tmp_1470;
{
float tmp_1471;
float tmp_1472;
tmp_1471 = STK[STKP - 2].data[tmp_1469];
tmp_1472 = STK[STKP - 1].data[tmp_1469];
tmp_1470 = (tmp_1471 < tmp_1472);
}
if (tmp_1470)
{
result[tmp_1469] = STK[STKP - 1].data[tmp_1469];
}
else
{
result[tmp_1469] = STK[STKP - 2].data[tmp_1469];
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = STK[STKP - 2].length;
STKP -= 1;
}

void
gen_max_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1473;
for (tmp_1473 = 0; tmp_1473 < arglengths[0]; ++tmp_1473)
{
{
compvar_t *tmp_1474;
tmp_1474 = make_temporary();
{
compvar_t *tmp_1475, *tmp_1476;
tmp_1475 = args[0][tmp_1473];
tmp_1476 = args[1][tmp_1473];
emit_assign(make_lhs(tmp_1474), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1475), make_compvar_primary(tmp_1476)));
}
start_if_cond(make_compvar_rhs(tmp_1474));
emit_assign(make_lhs(result[tmp_1473]), make_compvar_rhs(args[1][tmp_1473]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1473]), make_compvar_rhs(args[0][tmp_1473]));
end_if_cond();
}
}
}
}

void
builtin_clamp (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1477;
for (tmp_1477 = 0; tmp_1477 < STK[STKP - 3].length; ++tmp_1477)
{
{
float tmp_1478;
{
float tmp_1479;
float tmp_1480;
tmp_1479 = STK[STKP - 3].data[tmp_1477];
tmp_1480 = STK[STKP - 2].data[tmp_1477];
tmp_1478 = (tmp_1479 < tmp_1480);
}
if (tmp_1478)
{
result[tmp_1477] = STK[STKP - 2].data[tmp_1477];
}
else
{
{
float tmp_1481;
{
float tmp_1482;
float tmp_1483;
tmp_1482 = STK[STKP - 1].data[tmp_1477];
tmp_1483 = STK[STKP - 3].data[tmp_1477];
tmp_1481 = (tmp_1482 < tmp_1483);
}
if (tmp_1481)
{
result[tmp_1477] = STK[STKP - 1].data[tmp_1477];
}
else
{
result[tmp_1477] = STK[STKP - 3].data[tmp_1477];
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 3].length; ++i)
STK[STKP - 3].data[i] = result[i];
}
STK[STKP - 3].length = STK[STKP - 3].length;
STKP -= 2;
}

void
gen_clamp (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1484;
for (tmp_1484 = 0; tmp_1484 < arglengths[0]; ++tmp_1484)
{
{
compvar_t *tmp_1485;
tmp_1485 = make_temporary();
{
compvar_t *tmp_1486, *tmp_1487;
tmp_1486 = args[0][tmp_1484];
tmp_1487 = args[1][tmp_1484];
emit_assign(make_lhs(tmp_1485), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1486), make_compvar_primary(tmp_1487)));
}
start_if_cond(make_compvar_rhs(tmp_1485));
emit_assign(make_lhs(result[tmp_1484]), make_compvar_rhs(args[1][tmp_1484]));
switch_if_branch();
{
compvar_t *tmp_1488;
tmp_1488 = make_temporary();
{
compvar_t *tmp_1489, *tmp_1490;
tmp_1489 = args[2][tmp_1484];
tmp_1490 = args[0][tmp_1484];
emit_assign(make_lhs(tmp_1488), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1489), make_compvar_primary(tmp_1490)));
}
start_if_cond(make_compvar_rhs(tmp_1488));
emit_assign(make_lhs(result[tmp_1484]), make_compvar_rhs(args[2][tmp_1484]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_1484]), make_compvar_rhs(args[0][tmp_1484]));
end_if_cond();
}
end_if_cond();
}
}
}
}

void
builtin_lerp_1 (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1491;

{
float tmp_1492;
float tmp_1493;
tmp_1492 = 1;
tmp_1493 = STK[STKP - 3].data[0];
tmp_1491 = tmp_1492 - tmp_1493;
}

{
int tmp_1494;
for (tmp_1494 = 0; tmp_1494 < STK[STKP - 2].length; ++tmp_1494)
{
{
float tmp_1495;
float tmp_1496;
{
float tmp_1497;
float tmp_1498;
tmp_1497 = tmp_1491;
tmp_1498 = STK[STKP - 2].data[tmp_1494];
tmp_1495 = tmp_1497 * tmp_1498;
}
{
float tmp_1499;
float tmp_1500;
tmp_1499 = STK[STKP - 3].data[0];
tmp_1500 = STK[STKP - 1].data[tmp_1494];
tmp_1496 = tmp_1499 * tmp_1500;
}
result[tmp_1494] = tmp_1495 + tmp_1496;
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 2].length; ++i)
STK[STKP - 3].data[i] = result[i];
}
STK[STKP - 3].length = STK[STKP - 2].length;
STKP -= 2;
}

void
gen_lerp_1 (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1501;

tmp_1501 = make_temporary();
{
compvar_t *tmp_1502, *tmp_1503;
tmp_1502 = make_temporary();
emit_assign(make_lhs(tmp_1502), make_int_const_rhs(1));
tmp_1503 = args[0][0];
emit_assign(make_lhs(tmp_1501), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1502), make_compvar_primary(tmp_1503)));
}

{
int tmp_1504;
for (tmp_1504 = 0; tmp_1504 < arglengths[1]; ++tmp_1504)
{
{
compvar_t *tmp_1505, *tmp_1506;
tmp_1505 = make_temporary();
{
compvar_t *tmp_1507, *tmp_1508;
tmp_1507 = tmp_1501;
tmp_1508 = args[1][tmp_1504];
emit_assign(make_lhs(tmp_1505), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1507), make_compvar_primary(tmp_1508)));
}
tmp_1506 = make_temporary();
{
compvar_t *tmp_1509, *tmp_1510;
tmp_1509 = args[0][0];
tmp_1510 = args[2][tmp_1504];
emit_assign(make_lhs(tmp_1506), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1509), make_compvar_primary(tmp_1510)));
}
emit_assign(make_lhs(result[tmp_1504]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1505), make_compvar_primary(tmp_1506)));
}
}
}
}
}

void
builtin_lerp_n (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1511;
for (tmp_1511 = 0; tmp_1511 < STK[STKP - 2].length; ++tmp_1511)
{
{
float tmp_1512;
float tmp_1513;
{
float tmp_1514;
float tmp_1515;
{
float tmp_1516;
float tmp_1517;
tmp_1516 = 1;
tmp_1517 = STK[STKP - 3].data[tmp_1511];
tmp_1514 = tmp_1516 - tmp_1517;
}
tmp_1515 = STK[STKP - 2].data[tmp_1511];
tmp_1512 = tmp_1514 * tmp_1515;
}
{
float tmp_1518;
float tmp_1519;
tmp_1518 = STK[STKP - 3].data[tmp_1511];
tmp_1519 = STK[STKP - 1].data[tmp_1511];
tmp_1513 = tmp_1518 * tmp_1519;
}
result[tmp_1511] = tmp_1512 + tmp_1513;
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 3].length; ++i)
STK[STKP - 3].data[i] = result[i];
}
STK[STKP - 3].length = STK[STKP - 3].length;
STKP -= 2;
}

void
gen_lerp_n (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1520;
for (tmp_1520 = 0; tmp_1520 < arglengths[1]; ++tmp_1520)
{
{
compvar_t *tmp_1521, *tmp_1522;
tmp_1521 = make_temporary();
{
compvar_t *tmp_1523, *tmp_1524;
tmp_1523 = make_temporary();
{
compvar_t *tmp_1525, *tmp_1526;
tmp_1525 = make_temporary();
emit_assign(make_lhs(tmp_1525), make_int_const_rhs(1));
tmp_1526 = args[0][tmp_1520];
emit_assign(make_lhs(tmp_1523), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1525), make_compvar_primary(tmp_1526)));
}
tmp_1524 = args[1][tmp_1520];
emit_assign(make_lhs(tmp_1521), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1523), make_compvar_primary(tmp_1524)));
}
tmp_1522 = make_temporary();
{
compvar_t *tmp_1527, *tmp_1528;
tmp_1527 = args[0][tmp_1520];
tmp_1528 = args[2][tmp_1520];
emit_assign(make_lhs(tmp_1522), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1527), make_compvar_primary(tmp_1528)));
}
emit_assign(make_lhs(result[tmp_1520]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1521), make_compvar_primary(tmp_1522)));
}
}
}
}

void
builtin_scale (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
int tmp_1529;
for (tmp_1529 = 0; tmp_1529 < STK[STKP - 5].length; ++tmp_1529)
{
{
float tmp_1530;

{
float tmp_1531;
float tmp_1532;
tmp_1531 = STK[STKP - 3].data[tmp_1529];
tmp_1532 = STK[STKP - 4].data[tmp_1529];
tmp_1530 = tmp_1531 - tmp_1532;
}

{
float tmp_1533;
{
float tmp_1534;
float tmp_1535;
tmp_1534 = tmp_1530;
tmp_1535 = 0;
tmp_1533 = (tmp_1534 == tmp_1535);
}
if (tmp_1533)
{
result[tmp_1529] = 0;
}
else
{
{
float tmp_1536;
float tmp_1537;
{
float tmp_1538;
float tmp_1539;
{
float tmp_1540;
float tmp_1541;
{
float tmp_1542;
float tmp_1543;
tmp_1542 = STK[STKP - 5].data[tmp_1529];
tmp_1543 = STK[STKP - 4].data[tmp_1529];
tmp_1540 = tmp_1542 - tmp_1543;
}
tmp_1541 = tmp_1530;
tmp_1538 = tmp_1540 / tmp_1541;
}
{
float tmp_1544;
float tmp_1545;
tmp_1544 = STK[STKP - 1].data[tmp_1529];
tmp_1545 = STK[STKP - 2].data[tmp_1529];
tmp_1539 = tmp_1544 - tmp_1545;
}
tmp_1536 = tmp_1538 * tmp_1539;
}
tmp_1537 = STK[STKP - 2].data[tmp_1529];
result[tmp_1529] = tmp_1536 + tmp_1537;
}
}
}
}
}
}
{
int i;
for (i = 0; i < STK[STKP - 5].length; ++i)
STK[STKP - 5].data[i] = result[i];
}
STK[STKP - 5].length = STK[STKP - 5].length;
STKP -= 4;
}

void
gen_scale (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1546;
for (tmp_1546 = 0; tmp_1546 < arglengths[0]; ++tmp_1546)
{
{
compvar_t *tmp_1547;

tmp_1547 = make_temporary();
{
compvar_t *tmp_1548, *tmp_1549;
tmp_1548 = args[2][tmp_1546];
tmp_1549 = args[1][tmp_1546];
emit_assign(make_lhs(tmp_1547), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1548), make_compvar_primary(tmp_1549)));
}

{
compvar_t *tmp_1550;
tmp_1550 = make_temporary();
{
compvar_t *tmp_1551, *tmp_1552;
tmp_1551 = tmp_1547;
tmp_1552 = make_temporary();
emit_assign(make_lhs(tmp_1552), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1550), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1551), make_compvar_primary(tmp_1552)));
}
start_if_cond(make_compvar_rhs(tmp_1550));
emit_assign(make_lhs(result[tmp_1546]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1553, *tmp_1554;
tmp_1553 = make_temporary();
{
compvar_t *tmp_1555, *tmp_1556;
tmp_1555 = make_temporary();
{
compvar_t *tmp_1557, *tmp_1558;
tmp_1557 = make_temporary();
{
compvar_t *tmp_1559, *tmp_1560;
tmp_1559 = args[0][tmp_1546];
tmp_1560 = args[1][tmp_1546];
emit_assign(make_lhs(tmp_1557), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1559), make_compvar_primary(tmp_1560)));
}
tmp_1558 = tmp_1547;
emit_assign(make_lhs(tmp_1555), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1557), make_compvar_primary(tmp_1558)));
}
tmp_1556 = make_temporary();
{
compvar_t *tmp_1561, *tmp_1562;
tmp_1561 = args[4][tmp_1546];
tmp_1562 = args[3][tmp_1546];
emit_assign(make_lhs(tmp_1556), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1561), make_compvar_primary(tmp_1562)));
}
emit_assign(make_lhs(tmp_1553), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1555), make_compvar_primary(tmp_1556)));
}
tmp_1554 = args[3][tmp_1546];
emit_assign(make_lhs(result[tmp_1546]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1553), make_compvar_primary(tmp_1554)));
}
end_if_cond();
}
}
}
}
}

void
builtin_not (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1563;
{
float tmp_1564;
float tmp_1565;
tmp_1564 = STK[STKP - 1].data[0];
tmp_1565 = 0;
tmp_1563 = (tmp_1564 == tmp_1565);
}
if (tmp_1563)
{
result[0] = 1;
}
else
{
result[0] = 0;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_not (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1566;
tmp_1566 = make_temporary();
{
compvar_t *tmp_1567, *tmp_1568;
tmp_1567 = args[0][0];
tmp_1568 = make_temporary();
emit_assign(make_lhs(tmp_1568), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1566), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1567), make_compvar_primary(tmp_1568)));
}
start_if_cond(make_compvar_rhs(tmp_1566));
{
int tmp_1569;
for (tmp_1569 = 0; tmp_1569 < 1; ++tmp_1569)
{
switch (tmp_1569)
{
case 0 :
emit_assign(make_lhs(result[tmp_1569]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1570;
for (tmp_1570 = 0; tmp_1570 < 1; ++tmp_1570)
{
switch (tmp_1570)
{
case 0 :
emit_assign(make_lhs(result[tmp_1570]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_or (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1571;
{
float tmp_1572;
float tmp_1573;
tmp_1572 = STK[STKP - 2].data[0];
tmp_1573 = 0;
tmp_1571 = (tmp_1572 == tmp_1573);
}
if (tmp_1571)
{
{
float tmp_1574;
float tmp_1575;
tmp_1574 = STK[STKP - 1].data[0];
tmp_1575 = 0;
tmp_1571 = (tmp_1574 == tmp_1575);
}
}
if (tmp_1571)
{
result[0] = 0;
}
else
{
result[0] = 1;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_or (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1576;
tmp_1576 = make_temporary();
{
compvar_t *tmp_1577, *tmp_1578;
tmp_1577 = args[0][0];
tmp_1578 = make_temporary();
emit_assign(make_lhs(tmp_1578), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1576), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1577), make_compvar_primary(tmp_1578)));
}
start_if_cond(make_compvar_rhs(tmp_1576));
{
compvar_t *tmp_1579, *tmp_1580;
tmp_1579 = args[1][0];
tmp_1580 = make_temporary();
emit_assign(make_lhs(tmp_1580), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1576), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1579), make_compvar_primary(tmp_1580)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1576));
{
int tmp_1581;
for (tmp_1581 = 0; tmp_1581 < 1; ++tmp_1581)
{
switch (tmp_1581)
{
case 0 :
emit_assign(make_lhs(result[tmp_1581]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1582;
for (tmp_1582 = 0; tmp_1582 < 1; ++tmp_1582)
{
switch (tmp_1582)
{
case 0 :
emit_assign(make_lhs(result[tmp_1582]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_and (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1583;
{
float tmp_1584;
float tmp_1585;
tmp_1584 = STK[STKP - 2].data[0];
tmp_1585 = 0;
tmp_1583 = (tmp_1584 == tmp_1585);
}
if (!tmp_1583)
{
{
float tmp_1586;
float tmp_1587;
tmp_1586 = STK[STKP - 1].data[0];
tmp_1587 = 0;
tmp_1583 = (tmp_1586 == tmp_1587);
}
}
if (tmp_1583)
{
result[0] = 0;
}
else
{
result[0] = 1;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_and (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1588;
tmp_1588 = make_temporary();
{
compvar_t *tmp_1589, *tmp_1590;
tmp_1589 = args[0][0];
tmp_1590 = make_temporary();
emit_assign(make_lhs(tmp_1590), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1588), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1589), make_compvar_primary(tmp_1590)));
}
start_if_cond(make_compvar_rhs(tmp_1588));
switch_if_branch();
{
compvar_t *tmp_1591, *tmp_1592;
tmp_1591 = args[1][0];
tmp_1592 = make_temporary();
emit_assign(make_lhs(tmp_1592), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1588), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1591), make_compvar_primary(tmp_1592)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1588));
{
int tmp_1593;
for (tmp_1593 = 0; tmp_1593 < 1; ++tmp_1593)
{
switch (tmp_1593)
{
case 0 :
emit_assign(make_lhs(result[tmp_1593]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1594;
for (tmp_1594 = 0; tmp_1594 < 1; ++tmp_1594)
{
switch (tmp_1594)
{
case 0 :
emit_assign(make_lhs(result[tmp_1594]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_xor (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1595;
{
float tmp_1596;
float tmp_1597;
tmp_1596 = STK[STKP - 2].data[0];
tmp_1597 = 0;
tmp_1595 = (tmp_1596 == tmp_1597);
}
tmp_1595 = !tmp_1595;
if (tmp_1595)
{
{
float tmp_1598;
float tmp_1599;
tmp_1598 = STK[STKP - 1].data[0];
tmp_1599 = 0;
tmp_1595 = (tmp_1598 == tmp_1599);
}
}
if (!tmp_1595)
{
{
float tmp_1600;
float tmp_1601;
tmp_1600 = STK[STKP - 1].data[0];
tmp_1601 = 0;
tmp_1595 = (tmp_1600 == tmp_1601);
}
tmp_1595 = !tmp_1595;
if (tmp_1595)
{
{
float tmp_1602;
float tmp_1603;
tmp_1602 = STK[STKP - 2].data[0];
tmp_1603 = 0;
tmp_1595 = (tmp_1602 == tmp_1603);
}
}
}
if (tmp_1595)
{
result[0] = 1;
}
else
{
result[0] = 0;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_xor (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1604;
tmp_1604 = make_temporary();
{
compvar_t *tmp_1605, *tmp_1606;
tmp_1605 = args[0][0];
tmp_1606 = make_temporary();
emit_assign(make_lhs(tmp_1606), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1604), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1605), make_compvar_primary(tmp_1606)));
}
emit_assign(make_lhs(tmp_1604), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1604)));
start_if_cond(make_compvar_rhs(tmp_1604));
{
compvar_t *tmp_1607, *tmp_1608;
tmp_1607 = args[1][0];
tmp_1608 = make_temporary();
emit_assign(make_lhs(tmp_1608), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1604), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1607), make_compvar_primary(tmp_1608)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1604));
switch_if_branch();
{
compvar_t *tmp_1609, *tmp_1610;
tmp_1609 = args[1][0];
tmp_1610 = make_temporary();
emit_assign(make_lhs(tmp_1610), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1604), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1609), make_compvar_primary(tmp_1610)));
}
emit_assign(make_lhs(tmp_1604), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1604)));
start_if_cond(make_compvar_rhs(tmp_1604));
{
compvar_t *tmp_1611, *tmp_1612;
tmp_1611 = args[0][0];
tmp_1612 = make_temporary();
emit_assign(make_lhs(tmp_1612), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1604), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1611), make_compvar_primary(tmp_1612)));
}
switch_if_branch();
end_if_cond();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1604));
{
int tmp_1613;
for (tmp_1613 = 0; tmp_1613 < 1; ++tmp_1613)
{
switch (tmp_1613)
{
case 0 :
emit_assign(make_lhs(result[tmp_1613]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1614;
for (tmp_1614 = 0; tmp_1614 < 1; ++tmp_1614)
{
switch (tmp_1614)
{
case 0 :
emit_assign(make_lhs(result[tmp_1614]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_equal (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1615;
float tmp_1616;
tmp_1615 = STK[STKP - 2].data[0];
tmp_1616 = STK[STKP - 1].data[0];
result[0] = (tmp_1615 == tmp_1616);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_equal (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1617;
for (tmp_1617 = 0; tmp_1617 < 1; ++tmp_1617)
{
switch (tmp_1617)
{
case 0 :
{
compvar_t *tmp_1618, *tmp_1619;
tmp_1618 = args[0][0];
tmp_1619 = args[1][0];
emit_assign(make_lhs(result[tmp_1617]), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1618), make_compvar_primary(tmp_1619)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_less (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1620;
float tmp_1621;
tmp_1620 = STK[STKP - 2].data[0];
tmp_1621 = STK[STKP - 1].data[0];
result[0] = (tmp_1620 < tmp_1621);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_less (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1622;
for (tmp_1622 = 0; tmp_1622 < 1; ++tmp_1622)
{
switch (tmp_1622)
{
case 0 :
{
compvar_t *tmp_1623, *tmp_1624;
tmp_1623 = args[0][0];
tmp_1624 = args[1][0];
emit_assign(make_lhs(result[tmp_1622]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1623), make_compvar_primary(tmp_1624)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_greater (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1625;
float tmp_1626;
tmp_1625 = STK[STKP - 1].data[0];
tmp_1626 = STK[STKP - 2].data[0];
result[0] = (tmp_1625 < tmp_1626);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_greater (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1627;
for (tmp_1627 = 0; tmp_1627 < 1; ++tmp_1627)
{
switch (tmp_1627)
{
case 0 :
{
compvar_t *tmp_1628, *tmp_1629;
tmp_1628 = args[1][0];
tmp_1629 = args[0][0];
emit_assign(make_lhs(result[tmp_1627]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1628), make_compvar_primary(tmp_1629)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_lessequal (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1630;
float tmp_1631;
tmp_1630 = STK[STKP - 2].data[0];
tmp_1631 = STK[STKP - 1].data[0];
result[0] = (tmp_1630 <= tmp_1631);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_lessequal (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1632;
for (tmp_1632 = 0; tmp_1632 < 1; ++tmp_1632)
{
switch (tmp_1632)
{
case 0 :
{
compvar_t *tmp_1633, *tmp_1634;
tmp_1633 = args[0][0];
tmp_1634 = args[1][0];
emit_assign(make_lhs(result[tmp_1632]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1633), make_compvar_primary(tmp_1634)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_greaterequal (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1635;
float tmp_1636;
tmp_1635 = STK[STKP - 1].data[0];
tmp_1636 = STK[STKP - 2].data[0];
result[0] = (tmp_1635 <= tmp_1636);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_greaterequal (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1637;
for (tmp_1637 = 0; tmp_1637 < 1; ++tmp_1637)
{
switch (tmp_1637)
{
case 0 :
{
compvar_t *tmp_1638, *tmp_1639;
tmp_1638 = args[1][0];
tmp_1639 = args[0][0];
emit_assign(make_lhs(result[tmp_1637]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1638), make_compvar_primary(tmp_1639)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_notequal (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1640;
{
float tmp_1641;
float tmp_1642;
tmp_1641 = STK[STKP - 2].data[0];
tmp_1642 = STK[STKP - 1].data[0];
tmp_1640 = (tmp_1641 == tmp_1642);
}
result[0] = !tmp_1640;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_notequal (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1643;
for (tmp_1643 = 0; tmp_1643 < 1; ++tmp_1643)
{
switch (tmp_1643)
{
case 0 :
{
compvar_t *tmp_1644;
tmp_1644 = make_temporary();
{
compvar_t *tmp_1645, *tmp_1646;
tmp_1645 = args[0][0];
tmp_1646 = args[1][0];
emit_assign(make_lhs(tmp_1644), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1645), make_compvar_primary(tmp_1646)));
}
emit_assign(make_lhs(result[tmp_1643]), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1644)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_inintv (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1647;
{
float tmp_1648;
float tmp_1649;
tmp_1648 = STK[STKP - 2].data[0];
tmp_1649 = STK[STKP - 3].data[0];
tmp_1647 = (tmp_1648 <= tmp_1649);
}
if (tmp_1647)
{
{
float tmp_1650;
float tmp_1651;
tmp_1650 = STK[STKP - 3].data[0];
tmp_1651 = STK[STKP - 1].data[0];
tmp_1647 = (tmp_1650 <= tmp_1651);
}
}
if (tmp_1647)
{
result[0] = 1;
}
else
{
result[0] = 0;
}
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 3].data[i] = result[i];
}
STK[STKP - 3].length = 1;
STKP -= 2;
}

void
gen_inintv (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1652;
tmp_1652 = make_temporary();
{
compvar_t *tmp_1653, *tmp_1654;
tmp_1653 = args[1][0];
tmp_1654 = args[0][0];
emit_assign(make_lhs(tmp_1652), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1653), make_compvar_primary(tmp_1654)));
}
start_if_cond(make_compvar_rhs(tmp_1652));
{
compvar_t *tmp_1655, *tmp_1656;
tmp_1655 = args[0][0];
tmp_1656 = args[2][0];
emit_assign(make_lhs(tmp_1652), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1655), make_compvar_primary(tmp_1656)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1652));
{
int tmp_1657;
for (tmp_1657 = 0; tmp_1657 < 1; ++tmp_1657)
{
switch (tmp_1657)
{
case 0 :
emit_assign(make_lhs(result[tmp_1657]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1658;
for (tmp_1658 = 0; tmp_1658 < 1; ++tmp_1658)
{
switch (tmp_1658)
{
case 0 :
emit_assign(make_lhs(result[tmp_1658]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

void
builtin_origvalxy (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
color_t tmp_1659;

{
float tmp_1660;
float tmp_1661;
float tmp_1662;
float tmp_1663;
tmp_1660 = STK[STKP - 3].data[0];
tmp_1661 = STK[STKP - 3].data[1];
tmp_1662 = STK[STKP - 2].data[0];
tmp_1663 = STK[STKP - 1].data[0];
({ if (invocation->antialiasing)
tmp_1659 = get_orig_val_intersample_pixel(invocation, tmp_1660, tmp_1661, tmp_1662, tmp_1663);
else
tmp_1659 = get_orig_val_pixel(invocation, tmp_1660, tmp_1661, tmp_1662, tmp_1663); });
}

{
color_t tmp_1664;
tmp_1664 = tmp_1659;
result[0] = RED_FLOAT(tmp_1664);
}
{
color_t tmp_1665;
tmp_1665 = tmp_1659;
result[1] = GREEN_FLOAT(tmp_1665);
}
{
color_t tmp_1666;
tmp_1666 = tmp_1659;
result[2] = BLUE_FLOAT(tmp_1666);
}
{
color_t tmp_1667;
tmp_1667 = tmp_1659;
result[3] = ALPHA_FLOAT(tmp_1667);
}
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 3].data[i] = result[i];
}
STK[STKP - 3].length = 4;
STKP -= 2;
}

void
gen_origvalxy (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1668;

tmp_1668 = make_temporary();
{
compvar_t *tmp_1669, *tmp_1670, *tmp_1671, *tmp_1672;
tmp_1669 = args[0][0];
tmp_1670 = args[0][1];
tmp_1671 = args[1][0];
tmp_1672 = args[2][0];
emit_assign(make_lhs(tmp_1668), make_op_rhs(OP_ORIG_VAL, make_compvar_primary(tmp_1669), make_compvar_primary(tmp_1670), make_compvar_primary(tmp_1671), make_compvar_primary(tmp_1672)));
}

{
int tmp_1673;
for (tmp_1673 = 0; tmp_1673 < 4; ++tmp_1673)
{
switch (tmp_1673)
{
case 0 :
{
compvar_t *tmp_1674;
tmp_1674 = tmp_1668;
emit_assign(make_lhs(result[tmp_1673]), make_op_rhs(OP_RED, make_compvar_primary(tmp_1674)));
}
break;
case 1 :
{
compvar_t *tmp_1675;
tmp_1675 = tmp_1668;
emit_assign(make_lhs(result[tmp_1673]), make_op_rhs(OP_GREEN, make_compvar_primary(tmp_1675)));
}
break;
case 2 :
{
compvar_t *tmp_1676;
tmp_1676 = tmp_1668;
emit_assign(make_lhs(result[tmp_1673]), make_op_rhs(OP_BLUE, make_compvar_primary(tmp_1676)));
}
break;
case 3 :
{
compvar_t *tmp_1677;
tmp_1677 = tmp_1668;
emit_assign(make_lhs(result[tmp_1673]), make_op_rhs(OP_ALPHA, make_compvar_primary(tmp_1677)));
}
break;
default :
assert(0);
}
}
}
}
}

void
builtin_gray (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1678;
float tmp_1679;
{
float tmp_1680;
float tmp_1681;
{
float tmp_1682;
float tmp_1683;
tmp_1682 = 0.299;
tmp_1683 = STK[STKP - 1].data[0];
tmp_1680 = tmp_1682 * tmp_1683;
}
{
float tmp_1684;
float tmp_1685;
tmp_1684 = 0.587;
tmp_1685 = STK[STKP - 1].data[1];
tmp_1681 = tmp_1684 * tmp_1685;
}
tmp_1678 = tmp_1680 + tmp_1681;
}
{
float tmp_1686;
float tmp_1687;
tmp_1686 = 0.114;
tmp_1687 = STK[STKP - 1].data[2];
tmp_1679 = tmp_1686 * tmp_1687;
}
result[0] = tmp_1678 + tmp_1679;
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_gray (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1688;
for (tmp_1688 = 0; tmp_1688 < 1; ++tmp_1688)
{
switch (tmp_1688)
{
case 0 :
{
compvar_t *tmp_1689, *tmp_1690;
tmp_1689 = make_temporary();
{
compvar_t *tmp_1691, *tmp_1692;
tmp_1691 = make_temporary();
{
compvar_t *tmp_1693, *tmp_1694;
tmp_1693 = make_temporary();
emit_assign(make_lhs(tmp_1693), make_float_const_rhs(0.299));
tmp_1694 = args[0][0];
emit_assign(make_lhs(tmp_1691), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1693), make_compvar_primary(tmp_1694)));
}
tmp_1692 = make_temporary();
{
compvar_t *tmp_1695, *tmp_1696;
tmp_1695 = make_temporary();
emit_assign(make_lhs(tmp_1695), make_float_const_rhs(0.587));
tmp_1696 = args[0][1];
emit_assign(make_lhs(tmp_1692), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1695), make_compvar_primary(tmp_1696)));
}
emit_assign(make_lhs(tmp_1689), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1691), make_compvar_primary(tmp_1692)));
}
tmp_1690 = make_temporary();
{
compvar_t *tmp_1697, *tmp_1698;
tmp_1697 = make_temporary();
emit_assign(make_lhs(tmp_1697), make_float_const_rhs(0.114));
tmp_1698 = args[0][2];
emit_assign(make_lhs(tmp_1690), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1697), make_compvar_primary(tmp_1698)));
}
emit_assign(make_lhs(result[tmp_1688]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1689), make_compvar_primary(tmp_1690)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_tohsva (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1699;
float tmp_1704;
float tmp_1709;

{
float tmp_1700;
float tmp_1701;
tmp_1700 = 0;
{
float tmp_1702;
float tmp_1703;
tmp_1702 = 1;
tmp_1703 = STK[STKP - 1].data[0];
tmp_1701 = ((tmp_1702 < tmp_1703) ? tmp_1702 : tmp_1703);
}
tmp_1699 = ((tmp_1700 > tmp_1701) ? tmp_1700 : tmp_1701);
}

{
float tmp_1705;
float tmp_1706;
tmp_1705 = 0;
{
float tmp_1707;
float tmp_1708;
tmp_1707 = 1;
tmp_1708 = STK[STKP - 1].data[1];
tmp_1706 = ((tmp_1707 < tmp_1708) ? tmp_1707 : tmp_1708);
}
tmp_1704 = ((tmp_1705 > tmp_1706) ? tmp_1705 : tmp_1706);
}

{
float tmp_1710;
float tmp_1711;
tmp_1710 = 0;
{
float tmp_1712;
float tmp_1713;
tmp_1712 = 1;
tmp_1713 = STK[STKP - 1].data[2];
tmp_1711 = ((tmp_1712 < tmp_1713) ? tmp_1712 : tmp_1713);
}
tmp_1709 = ((tmp_1710 > tmp_1711) ? tmp_1710 : tmp_1711);
}

{
float tmp_1714;
float tmp_1715;
tmp_1714 = 0;
{
float tmp_1716;
float tmp_1717;
tmp_1716 = 1;
tmp_1717 = STK[STKP - 1].data[3];
tmp_1715 = ((tmp_1716 < tmp_1717) ? tmp_1716 : tmp_1717);
}
result[3] = ((tmp_1714 > tmp_1715) ? tmp_1714 : tmp_1715);
}
{
float tmp_1718;
float tmp_1723;

{
float tmp_1719;
float tmp_1720;
tmp_1719 = tmp_1699;
{
float tmp_1721;
float tmp_1722;
tmp_1721 = tmp_1704;
tmp_1722 = tmp_1709;
tmp_1720 = ((tmp_1721 > tmp_1722) ? tmp_1721 : tmp_1722);
}
tmp_1718 = ((tmp_1719 > tmp_1720) ? tmp_1719 : tmp_1720);
}

{
float tmp_1724;
float tmp_1725;
tmp_1724 = tmp_1699;
{
float tmp_1726;
float tmp_1727;
tmp_1726 = tmp_1704;
tmp_1727 = tmp_1709;
tmp_1725 = ((tmp_1726 < tmp_1727) ? tmp_1726 : tmp_1727);
}
tmp_1723 = ((tmp_1724 < tmp_1725) ? tmp_1724 : tmp_1725);
}

result[2] = tmp_1718;
{
float tmp_1728;
{
float tmp_1729;
float tmp_1730;
tmp_1729 = tmp_1718;
tmp_1730 = 0;
tmp_1728 = (tmp_1729 == tmp_1730);
}
if (tmp_1728)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_1731;
float tmp_1734;

{
float tmp_1732;
float tmp_1733;
tmp_1732 = tmp_1718;
tmp_1733 = tmp_1723;
tmp_1731 = tmp_1732 - tmp_1733;
}

tmp_1734 = 0;

{
float tmp_1735;
float tmp_1736;
tmp_1735 = tmp_1731;
tmp_1736 = tmp_1718;
result[1] = tmp_1735 / tmp_1736;
}
{
float tmp_1737;
{
float tmp_1738;
float tmp_1739;
tmp_1738 = tmp_1699;
tmp_1739 = tmp_1718;
tmp_1737 = (tmp_1738 == tmp_1739);
}
if (tmp_1737)
{
{
float tmp_1740;
float tmp_1741;
{
float tmp_1742;
float tmp_1743;
tmp_1742 = tmp_1704;
tmp_1743 = tmp_1709;
tmp_1740 = tmp_1742 - tmp_1743;
}
tmp_1741 = tmp_1731;
tmp_1734 = tmp_1740 / tmp_1741;
}
}
else
{
{
float tmp_1744;
{
float tmp_1745;
float tmp_1746;
tmp_1745 = tmp_1704;
tmp_1746 = tmp_1718;
tmp_1744 = (tmp_1745 == tmp_1746);
}
if (tmp_1744)
{
{
float tmp_1747;
float tmp_1748;
tmp_1747 = 2;
{
float tmp_1749;
float tmp_1750;
{
float tmp_1751;
float tmp_1752;
tmp_1751 = tmp_1709;
tmp_1752 = tmp_1699;
tmp_1749 = tmp_1751 - tmp_1752;
}
tmp_1750 = tmp_1731;
tmp_1748 = tmp_1749 / tmp_1750;
}
tmp_1734 = tmp_1747 + tmp_1748;
}
}
else
{
{
float tmp_1753;
float tmp_1754;
tmp_1753 = 4;
{
float tmp_1755;
float tmp_1756;
{
float tmp_1757;
float tmp_1758;
tmp_1757 = tmp_1699;
tmp_1758 = tmp_1704;
tmp_1755 = tmp_1757 - tmp_1758;
}
tmp_1756 = tmp_1731;
tmp_1754 = tmp_1755 / tmp_1756;
}
tmp_1734 = tmp_1753 + tmp_1754;
}
}
}
}
}
{
float tmp_1759;
float tmp_1760;
tmp_1759 = tmp_1734;
tmp_1760 = 6.0;
tmp_1734 = tmp_1759 / tmp_1760;
}
{
float tmp_1761;
{
float tmp_1762;
float tmp_1763;
tmp_1762 = tmp_1734;
tmp_1763 = 0;
tmp_1761 = (tmp_1762 < tmp_1763);
}
if (tmp_1761)
{
{
float tmp_1764;
float tmp_1765;
tmp_1764 = tmp_1734;
tmp_1765 = 1;
result[0] = tmp_1764 + tmp_1765;
}
}
else
{
result[0] = tmp_1734;
}
}
}
}
}
}
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 4;
STKP -= 0;
}

void
gen_tohsva (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1766;
compvar_t *tmp_1771;
compvar_t *tmp_1776;

tmp_1766 = make_temporary();
{
compvar_t *tmp_1767, *tmp_1768;
tmp_1767 = make_temporary();
emit_assign(make_lhs(tmp_1767), make_int_const_rhs(0));
tmp_1768 = make_temporary();
{
compvar_t *tmp_1769, *tmp_1770;
tmp_1769 = make_temporary();
emit_assign(make_lhs(tmp_1769), make_int_const_rhs(1));
tmp_1770 = args[0][0];
emit_assign(make_lhs(tmp_1768), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1769), make_compvar_primary(tmp_1770)));
}
emit_assign(make_lhs(tmp_1766), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1767), make_compvar_primary(tmp_1768)));
}

tmp_1771 = make_temporary();
{
compvar_t *tmp_1772, *tmp_1773;
tmp_1772 = make_temporary();
emit_assign(make_lhs(tmp_1772), make_int_const_rhs(0));
tmp_1773 = make_temporary();
{
compvar_t *tmp_1774, *tmp_1775;
tmp_1774 = make_temporary();
emit_assign(make_lhs(tmp_1774), make_int_const_rhs(1));
tmp_1775 = args[0][1];
emit_assign(make_lhs(tmp_1773), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1774), make_compvar_primary(tmp_1775)));
}
emit_assign(make_lhs(tmp_1771), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1772), make_compvar_primary(tmp_1773)));
}

tmp_1776 = make_temporary();
{
compvar_t *tmp_1777, *tmp_1778;
tmp_1777 = make_temporary();
emit_assign(make_lhs(tmp_1777), make_int_const_rhs(0));
tmp_1778 = make_temporary();
{
compvar_t *tmp_1779, *tmp_1780;
tmp_1779 = make_temporary();
emit_assign(make_lhs(tmp_1779), make_int_const_rhs(1));
tmp_1780 = args[0][2];
emit_assign(make_lhs(tmp_1778), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1779), make_compvar_primary(tmp_1780)));
}
emit_assign(make_lhs(tmp_1776), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1777), make_compvar_primary(tmp_1778)));
}

{
compvar_t *tmp_1781, *tmp_1782;
tmp_1781 = make_temporary();
emit_assign(make_lhs(tmp_1781), make_int_const_rhs(0));
tmp_1782 = make_temporary();
{
compvar_t *tmp_1783, *tmp_1784;
tmp_1783 = make_temporary();
emit_assign(make_lhs(tmp_1783), make_int_const_rhs(1));
tmp_1784 = args[0][3];
emit_assign(make_lhs(tmp_1782), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1783), make_compvar_primary(tmp_1784)));
}
emit_assign(make_lhs(result[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1781), make_compvar_primary(tmp_1782)));
}
{
compvar_t *tmp_1785;
compvar_t *tmp_1790;

tmp_1785 = make_temporary();
{
compvar_t *tmp_1786, *tmp_1787;
tmp_1786 = tmp_1766;
tmp_1787 = make_temporary();
{
compvar_t *tmp_1788, *tmp_1789;
tmp_1788 = tmp_1771;
tmp_1789 = tmp_1776;
emit_assign(make_lhs(tmp_1787), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1788), make_compvar_primary(tmp_1789)));
}
emit_assign(make_lhs(tmp_1785), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1786), make_compvar_primary(tmp_1787)));
}

tmp_1790 = make_temporary();
{
compvar_t *tmp_1791, *tmp_1792;
tmp_1791 = tmp_1766;
tmp_1792 = make_temporary();
{
compvar_t *tmp_1793, *tmp_1794;
tmp_1793 = tmp_1771;
tmp_1794 = tmp_1776;
emit_assign(make_lhs(tmp_1792), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1793), make_compvar_primary(tmp_1794)));
}
emit_assign(make_lhs(tmp_1790), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1791), make_compvar_primary(tmp_1792)));
}

emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1785));
{
compvar_t *tmp_1795;
tmp_1795 = make_temporary();
{
compvar_t *tmp_1796, *tmp_1797;
tmp_1796 = tmp_1785;
tmp_1797 = make_temporary();
emit_assign(make_lhs(tmp_1797), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1795), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1796), make_compvar_primary(tmp_1797)));
}
start_if_cond(make_compvar_rhs(tmp_1795));
emit_assign(make_lhs(result[0]), make_int_const_rhs(0));
emit_assign(make_lhs(result[1]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1798;
compvar_t *tmp_1801;

tmp_1798 = make_temporary();
{
compvar_t *tmp_1799, *tmp_1800;
tmp_1799 = tmp_1785;
tmp_1800 = tmp_1790;
emit_assign(make_lhs(tmp_1798), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1799), make_compvar_primary(tmp_1800)));
}

tmp_1801 = make_temporary();
emit_assign(make_lhs(tmp_1801), make_int_const_rhs(0));

{
compvar_t *tmp_1802, *tmp_1803;
tmp_1802 = tmp_1798;
tmp_1803 = tmp_1785;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1802), make_compvar_primary(tmp_1803)));
}
{
compvar_t *tmp_1804;
tmp_1804 = make_temporary();
{
compvar_t *tmp_1805, *tmp_1806;
tmp_1805 = tmp_1766;
tmp_1806 = tmp_1785;
emit_assign(make_lhs(tmp_1804), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1805), make_compvar_primary(tmp_1806)));
}
start_if_cond(make_compvar_rhs(tmp_1804));
{
compvar_t *tmp_1807, *tmp_1808;
tmp_1807 = make_temporary();
{
compvar_t *tmp_1809, *tmp_1810;
tmp_1809 = tmp_1771;
tmp_1810 = tmp_1776;
emit_assign(make_lhs(tmp_1807), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1809), make_compvar_primary(tmp_1810)));
}
tmp_1808 = tmp_1798;
emit_assign(make_lhs(tmp_1801), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1807), make_compvar_primary(tmp_1808)));
}
switch_if_branch();
{
compvar_t *tmp_1811;
tmp_1811 = make_temporary();
{
compvar_t *tmp_1812, *tmp_1813;
tmp_1812 = tmp_1771;
tmp_1813 = tmp_1785;
emit_assign(make_lhs(tmp_1811), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1812), make_compvar_primary(tmp_1813)));
}
start_if_cond(make_compvar_rhs(tmp_1811));
{
compvar_t *tmp_1814, *tmp_1815;
tmp_1814 = make_temporary();
emit_assign(make_lhs(tmp_1814), make_int_const_rhs(2));
tmp_1815 = make_temporary();
{
compvar_t *tmp_1816, *tmp_1817;
tmp_1816 = make_temporary();
{
compvar_t *tmp_1818, *tmp_1819;
tmp_1818 = tmp_1776;
tmp_1819 = tmp_1766;
emit_assign(make_lhs(tmp_1816), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1818), make_compvar_primary(tmp_1819)));
}
tmp_1817 = tmp_1798;
emit_assign(make_lhs(tmp_1815), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1816), make_compvar_primary(tmp_1817)));
}
emit_assign(make_lhs(tmp_1801), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1814), make_compvar_primary(tmp_1815)));
}
switch_if_branch();
{
compvar_t *tmp_1820, *tmp_1821;
tmp_1820 = make_temporary();
emit_assign(make_lhs(tmp_1820), make_int_const_rhs(4));
tmp_1821 = make_temporary();
{
compvar_t *tmp_1822, *tmp_1823;
tmp_1822 = make_temporary();
{
compvar_t *tmp_1824, *tmp_1825;
tmp_1824 = tmp_1766;
tmp_1825 = tmp_1771;
emit_assign(make_lhs(tmp_1822), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1824), make_compvar_primary(tmp_1825)));
}
tmp_1823 = tmp_1798;
emit_assign(make_lhs(tmp_1821), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1822), make_compvar_primary(tmp_1823)));
}
emit_assign(make_lhs(tmp_1801), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1820), make_compvar_primary(tmp_1821)));
}
end_if_cond();
}
end_if_cond();
}
{
compvar_t *tmp_1826, *tmp_1827;
tmp_1826 = tmp_1801;
tmp_1827 = make_temporary();
emit_assign(make_lhs(tmp_1827), make_float_const_rhs(6.0));
emit_assign(make_lhs(tmp_1801), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1826), make_compvar_primary(tmp_1827)));
}
{
compvar_t *tmp_1828;
tmp_1828 = make_temporary();
{
compvar_t *tmp_1829, *tmp_1830;
tmp_1829 = tmp_1801;
tmp_1830 = make_temporary();
emit_assign(make_lhs(tmp_1830), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1828), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1829), make_compvar_primary(tmp_1830)));
}
start_if_cond(make_compvar_rhs(tmp_1828));
{
compvar_t *tmp_1831, *tmp_1832;
tmp_1831 = tmp_1801;
tmp_1832 = make_temporary();
emit_assign(make_lhs(tmp_1832), make_int_const_rhs(1));
emit_assign(make_lhs(result[0]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1831), make_compvar_primary(tmp_1832)));
}
switch_if_branch();
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1801));
end_if_cond();
}
}
end_if_cond();
}
}
}
}

void
builtin_torgba (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1833;
float tmp_1838;

{
float tmp_1834;
float tmp_1835;
tmp_1834 = 0;
{
float tmp_1836;
float tmp_1837;
tmp_1836 = 1;
tmp_1837 = STK[STKP - 1].data[1];
tmp_1835 = ((tmp_1836 < tmp_1837) ? tmp_1836 : tmp_1837);
}
tmp_1833 = ((tmp_1834 > tmp_1835) ? tmp_1834 : tmp_1835);
}

{
float tmp_1839;
float tmp_1840;
tmp_1839 = 0;
{
float tmp_1841;
float tmp_1842;
tmp_1841 = 1;
tmp_1842 = STK[STKP - 1].data[2];
tmp_1840 = ((tmp_1841 < tmp_1842) ? tmp_1841 : tmp_1842);
}
tmp_1838 = ((tmp_1839 > tmp_1840) ? tmp_1839 : tmp_1840);
}

{
float tmp_1843;
float tmp_1844;
tmp_1843 = 0;
{
float tmp_1845;
float tmp_1846;
tmp_1845 = 1;
tmp_1846 = STK[STKP - 1].data[3];
tmp_1844 = ((tmp_1845 < tmp_1846) ? tmp_1845 : tmp_1846);
}
result[3] = ((tmp_1843 > tmp_1844) ? tmp_1843 : tmp_1844);
}
{
float tmp_1847;
{
float tmp_1848;
float tmp_1849;
tmp_1848 = tmp_1833;
tmp_1849 = 0;
tmp_1847 = (tmp_1848 == tmp_1849);
}
if (tmp_1847)
{
result[0] = tmp_1838;
result[1] = tmp_1838;
result[2] = tmp_1838;
}
else
{
{
float tmp_1850;

{
float tmp_1851;
float tmp_1852;
tmp_1851 = 0;
tmp_1852 = STK[STKP - 1].data[0];
tmp_1850 = ((tmp_1851 > tmp_1852) ? tmp_1851 : tmp_1852);
}

{
float tmp_1853;
{
float tmp_1854;
float tmp_1855;
tmp_1854 = 1;
tmp_1855 = tmp_1850;
tmp_1853 = (tmp_1854 <= tmp_1855);
}
if (tmp_1853)
{
tmp_1850 = 0;
}
else
{
{
float tmp_1856;
float tmp_1857;
tmp_1856 = tmp_1850;
tmp_1857 = 6;
tmp_1850 = tmp_1856 * tmp_1857;
}
}
}
{
float tmp_1858;

{
float tmp_1859;
tmp_1859 = tmp_1850;
tmp_1858 = floor(tmp_1859);
}

{
float tmp_1860;

{
float tmp_1861;
float tmp_1862;
tmp_1861 = tmp_1850;
tmp_1862 = tmp_1858;
tmp_1860 = tmp_1861 - tmp_1862;
}

{
float tmp_1863;
float tmp_1868;
float tmp_1875;

{
float tmp_1864;
float tmp_1865;
tmp_1864 = tmp_1838;
{
float tmp_1866;
float tmp_1867;
tmp_1866 = 1;
tmp_1867 = tmp_1833;
tmp_1865 = tmp_1866 - tmp_1867;
}
tmp_1863 = tmp_1864 * tmp_1865;
}

{
float tmp_1869;
float tmp_1870;
tmp_1869 = tmp_1838;
{
float tmp_1871;
float tmp_1872;
tmp_1871 = 1;
{
float tmp_1873;
float tmp_1874;
tmp_1873 = tmp_1833;
tmp_1874 = tmp_1860;
tmp_1872 = tmp_1873 * tmp_1874;
}
tmp_1870 = tmp_1871 - tmp_1872;
}
tmp_1868 = tmp_1869 * tmp_1870;
}

{
float tmp_1876;
float tmp_1877;
tmp_1876 = tmp_1838;
{
float tmp_1878;
float tmp_1879;
tmp_1878 = 1;
{
float tmp_1880;
float tmp_1881;
tmp_1880 = tmp_1833;
{
float tmp_1882;
float tmp_1883;
tmp_1882 = 1;
tmp_1883 = tmp_1860;
tmp_1881 = tmp_1882 - tmp_1883;
}
tmp_1879 = tmp_1880 * tmp_1881;
}
tmp_1877 = tmp_1878 - tmp_1879;
}
tmp_1875 = tmp_1876 * tmp_1877;
}

{
float tmp_1884;
{
float tmp_1885;
float tmp_1886;
tmp_1885 = tmp_1858;
tmp_1886 = 0;
tmp_1884 = (tmp_1885 == tmp_1886);
}
if (tmp_1884)
{
result[0] = tmp_1838;
result[1] = tmp_1875;
result[2] = tmp_1863;
}
else
{
{
float tmp_1887;
{
float tmp_1888;
float tmp_1889;
tmp_1888 = tmp_1858;
tmp_1889 = 1;
tmp_1887 = (tmp_1888 == tmp_1889);
}
if (tmp_1887)
{
result[0] = tmp_1868;
result[1] = tmp_1838;
result[2] = tmp_1863;
}
else
{
{
float tmp_1890;
{
float tmp_1891;
float tmp_1892;
tmp_1891 = tmp_1858;
tmp_1892 = 2;
tmp_1890 = (tmp_1891 == tmp_1892);
}
if (tmp_1890)
{
result[0] = tmp_1863;
result[1] = tmp_1838;
result[2] = tmp_1875;
}
else
{
{
float tmp_1893;
{
float tmp_1894;
float tmp_1895;
tmp_1894 = tmp_1858;
tmp_1895 = 3;
tmp_1893 = (tmp_1894 == tmp_1895);
}
if (tmp_1893)
{
result[0] = tmp_1863;
result[1] = tmp_1868;
result[2] = tmp_1838;
}
else
{
{
float tmp_1896;
{
float tmp_1897;
float tmp_1898;
tmp_1897 = tmp_1858;
tmp_1898 = 4;
tmp_1896 = (tmp_1897 == tmp_1898);
}
if (tmp_1896)
{
result[0] = tmp_1875;
result[1] = tmp_1863;
result[2] = tmp_1838;
}
else
{
result[0] = tmp_1838;
result[1] = tmp_1863;
result[2] = tmp_1868;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
{
int i;
for (i = 0; i < 4; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 4;
STKP -= 0;
}

void
gen_torgba (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1899;
compvar_t *tmp_1904;

tmp_1899 = make_temporary();
{
compvar_t *tmp_1900, *tmp_1901;
tmp_1900 = make_temporary();
emit_assign(make_lhs(tmp_1900), make_int_const_rhs(0));
tmp_1901 = make_temporary();
{
compvar_t *tmp_1902, *tmp_1903;
tmp_1902 = make_temporary();
emit_assign(make_lhs(tmp_1902), make_int_const_rhs(1));
tmp_1903 = args[0][1];
emit_assign(make_lhs(tmp_1901), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1902), make_compvar_primary(tmp_1903)));
}
emit_assign(make_lhs(tmp_1899), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1900), make_compvar_primary(tmp_1901)));
}

tmp_1904 = make_temporary();
{
compvar_t *tmp_1905, *tmp_1906;
tmp_1905 = make_temporary();
emit_assign(make_lhs(tmp_1905), make_int_const_rhs(0));
tmp_1906 = make_temporary();
{
compvar_t *tmp_1907, *tmp_1908;
tmp_1907 = make_temporary();
emit_assign(make_lhs(tmp_1907), make_int_const_rhs(1));
tmp_1908 = args[0][2];
emit_assign(make_lhs(tmp_1906), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1907), make_compvar_primary(tmp_1908)));
}
emit_assign(make_lhs(tmp_1904), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1905), make_compvar_primary(tmp_1906)));
}

{
compvar_t *tmp_1909, *tmp_1910;
tmp_1909 = make_temporary();
emit_assign(make_lhs(tmp_1909), make_int_const_rhs(0));
tmp_1910 = make_temporary();
{
compvar_t *tmp_1911, *tmp_1912;
tmp_1911 = make_temporary();
emit_assign(make_lhs(tmp_1911), make_int_const_rhs(1));
tmp_1912 = args[0][3];
emit_assign(make_lhs(tmp_1910), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1911), make_compvar_primary(tmp_1912)));
}
emit_assign(make_lhs(result[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1909), make_compvar_primary(tmp_1910)));
}
{
compvar_t *tmp_1913;
tmp_1913 = make_temporary();
{
compvar_t *tmp_1914, *tmp_1915;
tmp_1914 = tmp_1899;
tmp_1915 = make_temporary();
emit_assign(make_lhs(tmp_1915), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1913), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1914), make_compvar_primary(tmp_1915)));
}
start_if_cond(make_compvar_rhs(tmp_1913));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1904));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1904));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1904));
switch_if_branch();
{
compvar_t *tmp_1916;

tmp_1916 = make_temporary();
{
compvar_t *tmp_1917, *tmp_1918;
tmp_1917 = make_temporary();
emit_assign(make_lhs(tmp_1917), make_int_const_rhs(0));
tmp_1918 = args[0][0];
emit_assign(make_lhs(tmp_1916), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1917), make_compvar_primary(tmp_1918)));
}

{
compvar_t *tmp_1919;
tmp_1919 = make_temporary();
{
compvar_t *tmp_1920, *tmp_1921;
tmp_1920 = make_temporary();
emit_assign(make_lhs(tmp_1920), make_int_const_rhs(1));
tmp_1921 = tmp_1916;
emit_assign(make_lhs(tmp_1919), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1920), make_compvar_primary(tmp_1921)));
}
start_if_cond(make_compvar_rhs(tmp_1919));
emit_assign(make_lhs(tmp_1916), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1922, *tmp_1923;
tmp_1922 = tmp_1916;
tmp_1923 = make_temporary();
emit_assign(make_lhs(tmp_1923), make_int_const_rhs(6));
emit_assign(make_lhs(tmp_1916), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1922), make_compvar_primary(tmp_1923)));
}
end_if_cond();
}
{
compvar_t *tmp_1924;

tmp_1924 = make_temporary();
{
compvar_t *tmp_1925;
tmp_1925 = tmp_1916;
emit_assign(make_lhs(tmp_1924), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1925)));
}

{
compvar_t *tmp_1926;

tmp_1926 = make_temporary();
{
compvar_t *tmp_1927, *tmp_1928;
tmp_1927 = tmp_1916;
tmp_1928 = tmp_1924;
emit_assign(make_lhs(tmp_1926), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1927), make_compvar_primary(tmp_1928)));
}

{
compvar_t *tmp_1929;
compvar_t *tmp_1934;
compvar_t *tmp_1941;

tmp_1929 = make_temporary();
{
compvar_t *tmp_1930, *tmp_1931;
tmp_1930 = tmp_1904;
tmp_1931 = make_temporary();
{
compvar_t *tmp_1932, *tmp_1933;
tmp_1932 = make_temporary();
emit_assign(make_lhs(tmp_1932), make_int_const_rhs(1));
tmp_1933 = tmp_1899;
emit_assign(make_lhs(tmp_1931), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1932), make_compvar_primary(tmp_1933)));
}
emit_assign(make_lhs(tmp_1929), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1930), make_compvar_primary(tmp_1931)));
}

tmp_1934 = make_temporary();
{
compvar_t *tmp_1935, *tmp_1936;
tmp_1935 = tmp_1904;
tmp_1936 = make_temporary();
{
compvar_t *tmp_1937, *tmp_1938;
tmp_1937 = make_temporary();
emit_assign(make_lhs(tmp_1937), make_int_const_rhs(1));
tmp_1938 = make_temporary();
{
compvar_t *tmp_1939, *tmp_1940;
tmp_1939 = tmp_1899;
tmp_1940 = tmp_1926;
emit_assign(make_lhs(tmp_1938), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1939), make_compvar_primary(tmp_1940)));
}
emit_assign(make_lhs(tmp_1936), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1937), make_compvar_primary(tmp_1938)));
}
emit_assign(make_lhs(tmp_1934), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1935), make_compvar_primary(tmp_1936)));
}

tmp_1941 = make_temporary();
{
compvar_t *tmp_1942, *tmp_1943;
tmp_1942 = tmp_1904;
tmp_1943 = make_temporary();
{
compvar_t *tmp_1944, *tmp_1945;
tmp_1944 = make_temporary();
emit_assign(make_lhs(tmp_1944), make_int_const_rhs(1));
tmp_1945 = make_temporary();
{
compvar_t *tmp_1946, *tmp_1947;
tmp_1946 = tmp_1899;
tmp_1947 = make_temporary();
{
compvar_t *tmp_1948, *tmp_1949;
tmp_1948 = make_temporary();
emit_assign(make_lhs(tmp_1948), make_int_const_rhs(1));
tmp_1949 = tmp_1926;
emit_assign(make_lhs(tmp_1947), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1948), make_compvar_primary(tmp_1949)));
}
emit_assign(make_lhs(tmp_1945), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1946), make_compvar_primary(tmp_1947)));
}
emit_assign(make_lhs(tmp_1943), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1944), make_compvar_primary(tmp_1945)));
}
emit_assign(make_lhs(tmp_1941), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1942), make_compvar_primary(tmp_1943)));
}

{
compvar_t *tmp_1950;
tmp_1950 = make_temporary();
{
compvar_t *tmp_1951, *tmp_1952;
tmp_1951 = tmp_1924;
tmp_1952 = make_temporary();
emit_assign(make_lhs(tmp_1952), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1950), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1951), make_compvar_primary(tmp_1952)));
}
start_if_cond(make_compvar_rhs(tmp_1950));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1904));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1941));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1929));
switch_if_branch();
{
compvar_t *tmp_1953;
tmp_1953 = make_temporary();
{
compvar_t *tmp_1954, *tmp_1955;
tmp_1954 = tmp_1924;
tmp_1955 = make_temporary();
emit_assign(make_lhs(tmp_1955), make_int_const_rhs(1));
emit_assign(make_lhs(tmp_1953), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1954), make_compvar_primary(tmp_1955)));
}
start_if_cond(make_compvar_rhs(tmp_1953));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1934));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1904));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1929));
switch_if_branch();
{
compvar_t *tmp_1956;
tmp_1956 = make_temporary();
{
compvar_t *tmp_1957, *tmp_1958;
tmp_1957 = tmp_1924;
tmp_1958 = make_temporary();
emit_assign(make_lhs(tmp_1958), make_int_const_rhs(2));
emit_assign(make_lhs(tmp_1956), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1957), make_compvar_primary(tmp_1958)));
}
start_if_cond(make_compvar_rhs(tmp_1956));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1929));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1904));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1941));
switch_if_branch();
{
compvar_t *tmp_1959;
tmp_1959 = make_temporary();
{
compvar_t *tmp_1960, *tmp_1961;
tmp_1960 = tmp_1924;
tmp_1961 = make_temporary();
emit_assign(make_lhs(tmp_1961), make_int_const_rhs(3));
emit_assign(make_lhs(tmp_1959), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1960), make_compvar_primary(tmp_1961)));
}
start_if_cond(make_compvar_rhs(tmp_1959));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1929));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1934));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1904));
switch_if_branch();
{
compvar_t *tmp_1962;
tmp_1962 = make_temporary();
{
compvar_t *tmp_1963, *tmp_1964;
tmp_1963 = tmp_1924;
tmp_1964 = make_temporary();
emit_assign(make_lhs(tmp_1964), make_int_const_rhs(4));
emit_assign(make_lhs(tmp_1962), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1963), make_compvar_primary(tmp_1964)));
}
start_if_cond(make_compvar_rhs(tmp_1962));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1941));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1929));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1904));
switch_if_branch();
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1904));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1929));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1934));
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
}
}
}
}
end_if_cond();
}
}
}

void
builtin_toxy (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1965;
float tmp_1966;
{
float tmp_1967;
tmp_1967 = STK[STKP - 1].data[1];
tmp_1965 = cos(tmp_1967);
}
tmp_1966 = STK[STKP - 1].data[0];
result[0] = tmp_1965 * tmp_1966;
}
{
float tmp_1968;
float tmp_1969;
{
float tmp_1970;
tmp_1970 = STK[STKP - 1].data[1];
tmp_1968 = sin(tmp_1970);
}
tmp_1969 = STK[STKP - 1].data[0];
result[1] = tmp_1968 * tmp_1969;
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_toxy (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_1971;
for (tmp_1971 = 0; tmp_1971 < 2; ++tmp_1971)
{
switch (tmp_1971)
{
case 0 :
{
compvar_t *tmp_1972, *tmp_1973;
tmp_1972 = make_temporary();
{
compvar_t *tmp_1974;
tmp_1974 = args[0][1];
emit_assign(make_lhs(tmp_1972), make_op_rhs(OP_COS, make_compvar_primary(tmp_1974)));
}
tmp_1973 = args[0][0];
emit_assign(make_lhs(result[tmp_1971]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1972), make_compvar_primary(tmp_1973)));
}
break;
case 1 :
{
compvar_t *tmp_1975, *tmp_1976;
tmp_1975 = make_temporary();
{
compvar_t *tmp_1977;
tmp_1977 = args[0][1];
emit_assign(make_lhs(tmp_1975), make_op_rhs(OP_SIN, make_compvar_primary(tmp_1977)));
}
tmp_1976 = args[0][0];
emit_assign(make_lhs(result[tmp_1971]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1975), make_compvar_primary(tmp_1976)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_tora (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_1978;

{
float tmp_1979;
float tmp_1980;
tmp_1979 = STK[STKP - 1].data[0];
tmp_1980 = STK[STKP - 1].data[1];
tmp_1978 = hypot(tmp_1979, tmp_1980);
}

{
float tmp_1981;
{
float tmp_1982;
float tmp_1983;
tmp_1982 = tmp_1978;
tmp_1983 = 0;
tmp_1981 = (tmp_1982 == tmp_1983);
}
if (tmp_1981)
{
result[0] = 0;
result[1] = 0;
}
else
{
{
float tmp_1984;

{
float tmp_1985;
{
float tmp_1986;
float tmp_1987;
tmp_1986 = STK[STKP - 1].data[0];
tmp_1987 = tmp_1978;
tmp_1985 = tmp_1986 / tmp_1987;
}
tmp_1984 = acos(tmp_1985);
}

result[0] = tmp_1978;
{
float tmp_1988;
{
float tmp_1989;
float tmp_1990;
tmp_1989 = STK[STKP - 1].data[1];
tmp_1990 = 0;
tmp_1988 = (tmp_1989 < tmp_1990);
}
if (tmp_1988)
{
{
float tmp_1991;
float tmp_1992;
{
float tmp_1993;
float tmp_1994;
tmp_1993 = 2;
tmp_1994 = M_PI;
tmp_1991 = tmp_1993 * tmp_1994;
}
tmp_1992 = tmp_1984;
result[1] = tmp_1991 - tmp_1992;
}
}
else
{
result[1] = tmp_1984;
}
}
}
}
}
}
{
int i;
for (i = 0; i < 2; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 2;
STKP -= 0;
}

void
gen_tora (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
compvar_t *tmp_1995;

tmp_1995 = make_temporary();
{
compvar_t *tmp_1996, *tmp_1997;
tmp_1996 = args[0][0];
tmp_1997 = args[0][1];
emit_assign(make_lhs(tmp_1995), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_1996), make_compvar_primary(tmp_1997)));
}

{
compvar_t *tmp_1998;
tmp_1998 = make_temporary();
{
compvar_t *tmp_1999, *tmp_2000;
tmp_1999 = tmp_1995;
tmp_2000 = make_temporary();
emit_assign(make_lhs(tmp_2000), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1998), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1999), make_compvar_primary(tmp_2000)));
}
start_if_cond(make_compvar_rhs(tmp_1998));
{
int tmp_2001;
for (tmp_2001 = 0; tmp_2001 < 2; ++tmp_2001)
{
switch (tmp_2001)
{
case 0 :
emit_assign(make_lhs(result[tmp_2001]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_2001]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_2002;

tmp_2002 = make_temporary();
{
compvar_t *tmp_2003;
tmp_2003 = make_temporary();
{
compvar_t *tmp_2004, *tmp_2005;
tmp_2004 = args[0][0];
tmp_2005 = tmp_1995;
emit_assign(make_lhs(tmp_2003), make_op_rhs(OP_DIV, make_compvar_primary(tmp_2004), make_compvar_primary(tmp_2005)));
}
emit_assign(make_lhs(tmp_2002), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_2003)));
}

emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1995));
{
compvar_t *tmp_2006;
tmp_2006 = make_temporary();
{
compvar_t *tmp_2007, *tmp_2008;
tmp_2007 = args[0][1];
tmp_2008 = make_temporary();
emit_assign(make_lhs(tmp_2008), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_2006), make_op_rhs(OP_LESS, make_compvar_primary(tmp_2007), make_compvar_primary(tmp_2008)));
}
start_if_cond(make_compvar_rhs(tmp_2006));
{
compvar_t *tmp_2009, *tmp_2010;
tmp_2009 = make_temporary();
{
compvar_t *tmp_2011, *tmp_2012;
tmp_2011 = make_temporary();
emit_assign(make_lhs(tmp_2011), make_int_const_rhs(2));
tmp_2012 = make_temporary();
emit_assign(make_lhs(tmp_2012), make_float_const_rhs(M_PI));
emit_assign(make_lhs(tmp_2009), make_op_rhs(OP_MUL, make_compvar_primary(tmp_2011), make_compvar_primary(tmp_2012)));
}
tmp_2010 = tmp_2002;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_2009), make_compvar_primary(tmp_2010)));
}
switch_if_branch();
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_2002));
end_if_cond();
}
}
end_if_cond();
}
}
}

void
builtin_rand (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_2013;
float tmp_2014;
tmp_2013 = STK[STKP - 2].data[0];
tmp_2014 = STK[STKP - 1].data[0];
result[0] = RAND(tmp_2013, tmp_2014);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 2].data[i] = result[i];
}
STK[STKP - 2].length = 1;
STKP -= 1;
}

void
gen_rand (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_2015;
for (tmp_2015 = 0; tmp_2015 < 1; ++tmp_2015)
{
switch (tmp_2015)
{
case 0 :
{
compvar_t *tmp_2016, *tmp_2017;
tmp_2016 = args[0][0];
tmp_2017 = args[1][0];
emit_assign(make_lhs(result[tmp_2015]), make_op_rhs(OP_RAND, make_compvar_primary(tmp_2016), make_compvar_primary(tmp_2017)));
}
break;
default :
assert(0);
}
}
}
}

void
builtin_noise (mathmap_invocation_t *invocation, postfix_arg *arg)
{
float result[MAX_TUPLE_LENGTH];
{
float tmp_2018;
float tmp_2019;
float tmp_2020;
tmp_2018 = STK[STKP - 1].data[0];
tmp_2019 = STK[STKP - 1].data[1];
tmp_2020 = STK[STKP - 1].data[2];
result[0] = noise(tmp_2018, tmp_2019, tmp_2020);
}
{
int i;
for (i = 0; i < 1; ++i)
STK[STKP - 1].data[i] = result[i];
}
STK[STKP - 1].length = 1;
STKP -= 0;
}

void
gen_noise (compvar_t ***args, int *arglengths, compvar_t **result)
{
{
int tmp_2021;
for (tmp_2021 = 0; tmp_2021 < 1; ++tmp_2021)
{
switch (tmp_2021)
{
case 0 :
{
compvar_t *tmp_2022, *tmp_2023, *tmp_2024;
tmp_2022 = args[0][0];
tmp_2023 = args[0][1];
tmp_2024 = args[0][2];
emit_assign(make_lhs(result[tmp_2021]), make_op_rhs(OP_NOISE, make_compvar_primary(tmp_2022), make_compvar_primary(tmp_2023), make_compvar_primary(tmp_2024)));
}
break;
default :
assert(0);
}
}
}
}


void
init_builtins (void)
{
register_overloaded_builtin("print", "((nil 1) (_ _))", builtin_print, gen_print);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (ri 2))", builtin_add_ri, gen_add_ri);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (_ 1))", builtin_add_ri_1, gen_add_ri_1);
register_overloaded_builtin("__add", "((ri 2) (_ 1) (ri 2))", builtin_add_1_ri, gen_add_1_ri);
register_overloaded_builtin("__add", "((T 1) (T 1) (T 1))", builtin_add_1, gen_add_1);
register_overloaded_builtin("__add", "((T L) (T L) (_ 1))", builtin_add_s, gen_add_s);
register_overloaded_builtin("__add", "((T L) (T L) (T L))", builtin_add_n, gen_add_n);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (ri 2))", builtin_sub_ri, gen_sub_ri);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (_ 1))", builtin_sub_ri_1, gen_sub_ri_1);
register_overloaded_builtin("__sub", "((ri 2) (_ 1) (ri 2))", builtin_sub_1_ri, gen_sub_1_ri);
register_overloaded_builtin("__sub", "((T 1) (T 1) (T 1))", builtin_sub_1, gen_sub_1);
register_overloaded_builtin("__sub", "((T L) (T L) (_ 1))", builtin_sub_s, gen_sub_s);
register_overloaded_builtin("__sub", "((T L) (T L) (T L))", builtin_sub_n, gen_sub_n);
register_overloaded_builtin("__neg", "((T L) (T L))", builtin_neg, gen_neg);
register_overloaded_builtin("__mul", "((ri 2) (ri 2) (ri 2))", builtin_mul_ri, gen_mul_ri);
register_overloaded_builtin("__mul", "((ri 2) (_ 1) (ri 2))", builtin_mul_1_ri, gen_mul_1_ri);
register_overloaded_builtin("__mul", "((m2x2 4) (m2x2 4) (m2x2 4))", builtin_mul_m2x2, gen_mul_m2x2);
register_overloaded_builtin("__mul", "((m3x3 9) (m3x3 9) (m3x3 9))", builtin_mul_m3x3, gen_mul_m3x3);
register_overloaded_builtin("__mul", "((v2 2) (v2 2) (m2x2 4))", builtin_mul_v2m2x2, gen_mul_v2m2x2);
register_overloaded_builtin("__mul", "((v3 3) (v3 3) (m3x3 9))", builtin_mul_v3m3x3, gen_mul_v3m3x3);
register_overloaded_builtin("__mul", "((v2 2) (m2x2 4) (v2 2))", builtin_mul_m2x2v2, gen_mul_m2x2v2);
register_overloaded_builtin("__mul", "((v3 3) (m3x3 9) (v3 3))", builtin_mul_m3x3v3, gen_mul_m3x3v3);
register_overloaded_builtin("__mul", "((T 1) (T 1) (T 1))", builtin_mul_1, gen_mul_1);
register_overloaded_builtin("__mul", "((T L) (T L) (_ 1))", builtin_mul_s, gen_mul_s);
register_overloaded_builtin("__mul", "((T L) (T L) (T L))", builtin_mul_n, gen_mul_n);
register_overloaded_builtin("__div", "((ri 2) (ri 2) (ri 2))", builtin_div_ri, gen_div_ri);
register_overloaded_builtin("__div", "((ri 2) (T 1) (ri 2))", builtin_div_1_ri, gen_div_1_ri);
register_overloaded_builtin("__div", "((v2 2) (_ 2) (m2x2 4))", builtin_div_v2m2x2, gen_div_v2m2x2);
register_overloaded_builtin("__div", "((v3 3) (_ 3) (m3x3 9))", builtin_div_v3m3x3, gen_div_v3m3x3);
register_overloaded_builtin("__div", "((T 1) (T 1) (T 1))", builtin_div_1, gen_div_1);
register_overloaded_builtin("__div", "((T L) (T L) (_ 1))", builtin_div_s, gen_div_s);
register_overloaded_builtin("__div", "((T L) (T L) (T L))", builtin_div_n, gen_div_n);
register_overloaded_builtin("__mod", "((T 1) (T 1) (T 1))", builtin_mod_1, gen_mod_1);
register_overloaded_builtin("__mod", "((T L) (T L) (_ 1))", builtin_mod_s, gen_mod_s);
register_overloaded_builtin("__mod", "((T L) (T L) (T L))", builtin_mod_n, gen_mod_n);
register_overloaded_builtin("pmod", "((T 1) (T 1) (T 1))", builtin_pmod, gen_pmod);
register_overloaded_builtin("sqrt", "((ri 2) (ri 2))", builtin_sqrt_ri, gen_sqrt_ri);
register_overloaded_builtin("sqrt", "((T 1) (T 1))", builtin_sqrt_1, gen_sqrt_1);
register_overloaded_builtin("sum", "((T 1) (T L))", builtin_sum, gen_sum);
register_overloaded_builtin("dotp", "((nil 1) (T L) (T L))", builtin_dotp, gen_dotp);
register_overloaded_builtin("crossp", "((T 3) (T 3) (T 3))", builtin_crossp, gen_crossp);
register_overloaded_builtin("det", "((nil 1) (m2x2 4))", builtin_det_m2x2, gen_det_m2x2);
register_overloaded_builtin("det", "((nil 1) (m3x3 9))", builtin_det_m3x3, gen_det_m3x3);
register_overloaded_builtin("normalize", "((T L) (T L))", builtin_normalize, gen_normalize);
register_overloaded_builtin("abs", "((nil 1) (ri 2))", builtin_abs_ri, gen_abs_ri);
register_overloaded_builtin("abs", "((T 1) (T 1))", builtin_abs_1, gen_abs_1);
register_overloaded_builtin("abs", "((T L) (T L))", builtin_abs_n, gen_abs_n);
register_overloaded_builtin("deg2rad", "((nil 1) (_ 1))", builtin_deg2rad, gen_deg2rad);
register_overloaded_builtin("rad2deg", "((deg 1) (_ 1))", builtin_rad2deg, gen_rad2deg);
register_overloaded_builtin("sin", "((ri 2) (ri 2))", builtin_sin_ri, gen_sin_ri);
register_overloaded_builtin("sin", "((T 1) (T 1))", builtin_sin, gen_sin);
register_overloaded_builtin("cos", "((ri 2) (ri 2))", builtin_cos_ri, gen_cos_ri);
register_overloaded_builtin("cos", "((T 1) (T 1))", builtin_cos, gen_cos);
register_overloaded_builtin("tan", "((ri 2) (ri 2))", builtin_tan_ri, gen_tan_ri);
register_overloaded_builtin("tan", "((T 1) (T 1))", builtin_tan, gen_tan);
register_overloaded_builtin("asin", "((ri 2) (ri 2))", builtin_asin_ri, gen_asin_ri);
register_overloaded_builtin("asin", "((T 1) (T 1))", builtin_asin, gen_asin);
register_overloaded_builtin("acos", "((ri 2) (ri 2))", builtin_acos_ri, gen_acos_ri);
register_overloaded_builtin("acos", "((T 1) (T 1))", builtin_acos, gen_acos);
register_overloaded_builtin("atan", "((ri 2) (ri 2))", builtin_atan_ri, gen_atan_ri);
register_overloaded_builtin("atan", "((T 1) (T 1))", builtin_atan, gen_atan);
register_overloaded_builtin("atan", "((T 1) (T 1) (T 1))", builtin_atan2, gen_atan2);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (T 1))", builtin_pow_ri_1, gen_pow_ri_1);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (ri 2))", builtin_pow_ri, gen_pow_ri);
register_overloaded_builtin("__pow", "((ri 2) (T 1) (ri 2))", builtin_pow_1_ri, gen_pow_1_ri);
register_overloaded_builtin("__pow", "((T 1) (T 1) (T 1))", builtin_pow_1, gen_pow_1);
register_overloaded_builtin("__pow", "((T L) (T L) (_ 1))", builtin_pow_s, gen_pow_s);
register_overloaded_builtin("exp", "((ri 2) (ri 2))", builtin_exp_ri, gen_exp_ri);
register_overloaded_builtin("exp", "((T 1) (T 1))", builtin_exp_1, gen_exp_1);
register_overloaded_builtin("log", "((ri 2) (ri 2))", builtin_log_ri, gen_log_ri);
register_overloaded_builtin("log", "((T 1) (T 1))", builtin_log_1, gen_log_1);
register_overloaded_builtin("arg", "((nil 1) (ri 2))", builtin_arg_ri, gen_arg_ri);
register_overloaded_builtin("conj", "((ri 2) (ri 2))", builtin_conj_ri, gen_conj_ri);
register_overloaded_builtin("sinh", "((ri 2) (ri 2))", builtin_sinh_ri, gen_sinh_ri);
register_overloaded_builtin("sinh", "((T 1) (T 1))", builtin_sinh_1, gen_sinh_1);
register_overloaded_builtin("cosh", "((ri 2) (ri 2))", builtin_cosh_ri, gen_cosh_ri);
register_overloaded_builtin("cosh", "((T 1) (T 1))", builtin_cosh_1, gen_cosh_1);
register_overloaded_builtin("tanh", "((ri 2) (ri 2))", builtin_tanh_ri, gen_tanh_ri);
register_overloaded_builtin("tanh", "((T 1) (T 1))", builtin_tanh_1, gen_tanh_1);
register_overloaded_builtin("asinh", "((ri 2) (ri 2))", builtin_asinh_ri, gen_asinh_ri);
register_overloaded_builtin("asinh", "((T 1) (T 1))", builtin_asinh_1, gen_asinh_1);
register_overloaded_builtin("acosh", "((ri 2) (ri 2))", builtin_acosh_ri, gen_acosh_ri);
register_overloaded_builtin("acosh", "((T 1) (T 1))", builtin_acosh_1, gen_acosh_1);
register_overloaded_builtin("atanh", "((ri 2) (ri 2))", builtin_atanh_ri, gen_atanh_ri);
register_overloaded_builtin("atanh", "((T 1) (T 1))", builtin_atanh_1, gen_atanh_1);
register_overloaded_builtin("gamma", "((ri 2) (ri 2))", builtin_gamma_ri, gen_gamma_ri);
register_overloaded_builtin("gamma", "((T 1) (T 1))", builtin_gamma_1, gen_gamma_1);
register_overloaded_builtin("floor", "((T 1) (T 1))", builtin_floor, gen_floor);
register_overloaded_builtin("sign", "((T L) (T L))", builtin_sign_n, gen_sign_n);
register_overloaded_builtin("min", "((T L) (T L) (T L))", builtin_min_n, gen_min_n);
register_overloaded_builtin("max", "((T L) (T L) (T L))", builtin_max_n, gen_max_n);
register_overloaded_builtin("clamp", "((T L) (T L) (T L) (T L))", builtin_clamp, gen_clamp);
register_overloaded_builtin("lerp", "((T L) (_ 1) (T L) (T L))", builtin_lerp_1, gen_lerp_1);
register_overloaded_builtin("lerp", "((T L) (T L) (T L) (T L))", builtin_lerp_n, gen_lerp_n);
register_overloaded_builtin("scale", "((T L) (T L) (T L) (T L) (T L) (T L))", builtin_scale, gen_scale);
register_overloaded_builtin("__not", "((T 1) (T 1))", builtin_not, gen_not);
register_overloaded_builtin("__or", "((T 1) (T 1) (T 1))", builtin_or, gen_or);
register_overloaded_builtin("__and", "((T 1) (T 1) (T 1))", builtin_and, gen_and);
register_overloaded_builtin("__xor", "((T 1) (T 1) (T 1))", builtin_xor, gen_xor);
register_overloaded_builtin("__equal", "((T 1) (T 1) (T 1))", builtin_equal, gen_equal);
register_overloaded_builtin("__less", "((T 1) (T 1) (T 1))", builtin_less, gen_less);
register_overloaded_builtin("__greater", "((T 1) (T 1) (T 1))", builtin_greater, gen_greater);
register_overloaded_builtin("__lessequal", "((T 1) (T 1) (T 1))", builtin_lessequal, gen_lessequal);
register_overloaded_builtin("__greaterequal", "((T 1) (T 1) (T 1))", builtin_greaterequal, gen_greaterequal);
register_overloaded_builtin("__notequal", "((T 1) (T 1) (T 1))", builtin_notequal, gen_notequal);
register_overloaded_builtin("inintv", "((T 1) (T 1) (T 1) (T 1))", builtin_inintv, gen_inintv);
register_overloaded_builtin("origVal", "((rgba 4) (xy 2) (image 1) (nil 1))", builtin_origvalxy, gen_origvalxy);
register_overloaded_builtin("gray", "((nil 1) (rgba 4))", builtin_gray, gen_gray);
register_overloaded_builtin("toHSVA", "((hsva 4) (rgba 4))", builtin_tohsva, gen_tohsva);
register_overloaded_builtin("toRGBA", "((rgba 4) (hsva 4))", builtin_torgba, gen_torgba);
register_overloaded_builtin("toXY", "((xy 2) (ra 2))", builtin_toxy, gen_toxy);
register_overloaded_builtin("toRA", "((ra 2) (xy 2))", builtin_tora, gen_tora);
register_overloaded_builtin("rand", "((T 1) (T 1) (T 1))", builtin_rand, gen_rand);
register_overloaded_builtin("noise", "((nil 1) (_ 3))", builtin_noise, gen_noise);
}
