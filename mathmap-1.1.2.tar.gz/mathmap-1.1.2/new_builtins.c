static void
gen_merd (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_0;

tmp_0 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1;
tmp_1 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1), make_int_const_rhs(argnumbers[0]));
emit_assign(make_lhs(tmp_0), make_op_rhs(OP_START_DEBUG_TUPLE, make_compvar_primary(tmp_1)));
}

{
int tmp_2;
for (tmp_2 = 0; tmp_2 < arglengths[0]; ++tmp_2)
{
{
compvar_t *tmp_3;

tmp_3 = make_temporary(TYPE_INT);
{
compvar_t *tmp_4, *tmp_5;
tmp_4 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_4), make_int_const_rhs(tmp_2));
tmp_5 = args[0][tmp_2];
emit_assign(make_lhs(tmp_3), make_op_rhs(OP_SET_DEBUG_TUPLE_DATA, make_compvar_primary(tmp_4), make_compvar_primary(tmp_5)));
}

emit_assign(make_lhs(result[tmp_2]), make_compvar_rhs(args[0][tmp_2]));
}
}
}
}
}

static void
gen_print (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_6;
for (tmp_6 = 0; tmp_6 < arglengths[0]; ++tmp_6)
{
{
compvar_t *tmp_7;
tmp_7 = make_temporary(TYPE_INT);
{
compvar_t *tmp_8;
tmp_8 = args[0][tmp_6];
emit_assign(make_lhs(tmp_7), make_op_rhs(OP_PRINT, make_compvar_primary(tmp_8)));
}
}
}
}
{
compvar_t *tmp_9;
tmp_9 = make_temporary(TYPE_INT);
{
emit_assign(make_lhs(tmp_9), make_op_rhs(OP_NEWLINE));
}
}
{
int tmp_10;
for (tmp_10 = 0; tmp_10 < 1; ++tmp_10)
{
switch (tmp_10)
{
case 0 :
emit_assign(make_lhs(result[tmp_10]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
}

static void
gen_add_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_11;
for (tmp_11 = 0; tmp_11 < 2; ++tmp_11)
{
{
compvar_t *tmp_12, *tmp_13;
tmp_12 = args[0][tmp_11];
tmp_13 = args[1][tmp_11];
emit_assign(make_lhs(result[tmp_11]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_12), make_compvar_primary(tmp_13)));
}
}
}
}

static void
gen_add_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_14;
for (tmp_14 = 0; tmp_14 < 2; ++tmp_14)
{
{
compvar_t *tmp_15, *tmp_16;
tmp_15 = args[0][tmp_14];
switch (tmp_14)
{
case 0 :
tmp_16 = args[1][0];
break;
case 1 :
tmp_16 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_16), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_14]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_15), make_compvar_primary(tmp_16)));
}
}
}
}

static void
gen_add_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_17;
for (tmp_17 = 0; tmp_17 < 2; ++tmp_17)
{
{
compvar_t *tmp_18, *tmp_19;
tmp_18 = args[1][tmp_17];
switch (tmp_17)
{
case 0 :
tmp_19 = args[0][0];
break;
case 1 :
tmp_19 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_19), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_17]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_18), make_compvar_primary(tmp_19)));
}
}
}
}

static void
gen_add_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_20;
for (tmp_20 = 0; tmp_20 < 1; ++tmp_20)
{
{
compvar_t *tmp_21, *tmp_22;
tmp_21 = args[0][tmp_20];
tmp_22 = args[1][tmp_20];
emit_assign(make_lhs(result[tmp_20]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_21), make_compvar_primary(tmp_22)));
}
}
}
}

static void
gen_add_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_23;
for (tmp_23 = 0; tmp_23 < arglengths[0]; ++tmp_23)
{
{
compvar_t *tmp_24, *tmp_25;
tmp_24 = args[0][tmp_23];
tmp_25 = args[1][0];
emit_assign(make_lhs(result[tmp_23]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_24), make_compvar_primary(tmp_25)));
}
}
}
}

static void
gen_add_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_26;
for (tmp_26 = 0; tmp_26 < arglengths[0]; ++tmp_26)
{
{
compvar_t *tmp_27, *tmp_28;
tmp_27 = args[0][tmp_26];
tmp_28 = args[1][tmp_26];
emit_assign(make_lhs(result[tmp_26]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_27), make_compvar_primary(tmp_28)));
}
}
}
}

static void
gen_sub_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_29;
for (tmp_29 = 0; tmp_29 < 2; ++tmp_29)
{
{
compvar_t *tmp_30, *tmp_31;
tmp_30 = args[0][tmp_29];
tmp_31 = args[1][tmp_29];
emit_assign(make_lhs(result[tmp_29]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_30), make_compvar_primary(tmp_31)));
}
}
}
}

static void
gen_sub_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_32;
for (tmp_32 = 0; tmp_32 < 2; ++tmp_32)
{
{
compvar_t *tmp_33, *tmp_34;
tmp_33 = args[0][tmp_32];
switch (tmp_32)
{
case 0 :
tmp_34 = args[1][0];
break;
case 1 :
tmp_34 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_34), make_int_const_rhs(0));
break;
default :
assert(0);
}
emit_assign(make_lhs(result[tmp_32]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_33), make_compvar_primary(tmp_34)));
}
}
}
}

static void
gen_sub_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_35;
for (tmp_35 = 0; tmp_35 < 2; ++tmp_35)
{
{
compvar_t *tmp_36, *tmp_37;
switch (tmp_35)
{
case 0 :
tmp_36 = args[0][0];
break;
case 1 :
tmp_36 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_36), make_int_const_rhs(0));
break;
default :
assert(0);
}
tmp_37 = args[1][tmp_35];
emit_assign(make_lhs(result[tmp_35]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_36), make_compvar_primary(tmp_37)));
}
}
}
}

static void
gen_sub_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_38;
for (tmp_38 = 0; tmp_38 < 1; ++tmp_38)
{
{
compvar_t *tmp_39, *tmp_40;
tmp_39 = args[0][tmp_38];
tmp_40 = args[1][tmp_38];
emit_assign(make_lhs(result[tmp_38]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_39), make_compvar_primary(tmp_40)));
}
}
}
}

static void
gen_sub_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_41;
for (tmp_41 = 0; tmp_41 < arglengths[0]; ++tmp_41)
{
{
compvar_t *tmp_42, *tmp_43;
tmp_42 = args[0][tmp_41];
tmp_43 = args[1][0];
emit_assign(make_lhs(result[tmp_41]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_42), make_compvar_primary(tmp_43)));
}
}
}
}

static void
gen_sub_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_44;
for (tmp_44 = 0; tmp_44 < arglengths[0]; ++tmp_44)
{
{
compvar_t *tmp_45, *tmp_46;
tmp_45 = args[0][tmp_44];
tmp_46 = args[1][tmp_44];
emit_assign(make_lhs(result[tmp_44]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_45), make_compvar_primary(tmp_46)));
}
}
}
}

static void
gen_neg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_47;
for (tmp_47 = 0; tmp_47 < arglengths[0]; ++tmp_47)
{
{
compvar_t *tmp_48;
tmp_48 = args[0][tmp_47];
emit_assign(make_lhs(result[tmp_47]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_48)));
}
}
}
}

static void
gen_mul_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_49;
for (tmp_49 = 0; tmp_49 < 2; ++tmp_49)
{
switch (tmp_49)
{
case 0 :
{
compvar_t *tmp_50, *tmp_51;
tmp_50 = make_temporary(TYPE_INT);
{
compvar_t *tmp_52, *tmp_53;
tmp_52 = args[0][0];
tmp_53 = args[1][0];
emit_assign(make_lhs(tmp_50), make_op_rhs(OP_MUL, make_compvar_primary(tmp_52), make_compvar_primary(tmp_53)));
}
tmp_51 = make_temporary(TYPE_INT);
{
compvar_t *tmp_54, *tmp_55;
tmp_54 = args[0][1];
tmp_55 = args[1][1];
emit_assign(make_lhs(tmp_51), make_op_rhs(OP_MUL, make_compvar_primary(tmp_54), make_compvar_primary(tmp_55)));
}
emit_assign(make_lhs(result[tmp_49]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_50), make_compvar_primary(tmp_51)));
}
break;
case 1 :
{
compvar_t *tmp_56, *tmp_57;
tmp_56 = make_temporary(TYPE_INT);
{
compvar_t *tmp_58, *tmp_59;
tmp_58 = args[0][0];
tmp_59 = args[1][1];
emit_assign(make_lhs(tmp_56), make_op_rhs(OP_MUL, make_compvar_primary(tmp_58), make_compvar_primary(tmp_59)));
}
tmp_57 = make_temporary(TYPE_INT);
{
compvar_t *tmp_60, *tmp_61;
tmp_60 = args[1][0];
tmp_61 = args[0][1];
emit_assign(make_lhs(tmp_57), make_op_rhs(OP_MUL, make_compvar_primary(tmp_60), make_compvar_primary(tmp_61)));
}
emit_assign(make_lhs(result[tmp_49]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_56), make_compvar_primary(tmp_57)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_62;
for (tmp_62 = 0; tmp_62 < 2; ++tmp_62)
{
{
compvar_t *tmp_63, *tmp_64;
tmp_63 = args[0][0];
tmp_64 = args[1][tmp_62];
emit_assign(make_lhs(result[tmp_62]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_63), make_compvar_primary(tmp_64)));
}
}
}
}

static void
gen_mul_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_65;
for (tmp_65 = 0; tmp_65 < 4; ++tmp_65)
{
switch (tmp_65)
{
case 0 :
{
compvar_t *tmp_66, *tmp_67;
tmp_66 = make_temporary(TYPE_INT);
{
compvar_t *tmp_68, *tmp_69;
tmp_68 = args[0][0];
tmp_69 = args[1][0];
emit_assign(make_lhs(tmp_66), make_op_rhs(OP_MUL, make_compvar_primary(tmp_68), make_compvar_primary(tmp_69)));
}
tmp_67 = make_temporary(TYPE_INT);
{
compvar_t *tmp_70, *tmp_71;
tmp_70 = args[0][1];
tmp_71 = args[1][2];
emit_assign(make_lhs(tmp_67), make_op_rhs(OP_MUL, make_compvar_primary(tmp_70), make_compvar_primary(tmp_71)));
}
emit_assign(make_lhs(result[tmp_65]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_66), make_compvar_primary(tmp_67)));
}
break;
case 1 :
{
compvar_t *tmp_72, *tmp_73;
tmp_72 = make_temporary(TYPE_INT);
{
compvar_t *tmp_74, *tmp_75;
tmp_74 = args[0][0];
tmp_75 = args[1][1];
emit_assign(make_lhs(tmp_72), make_op_rhs(OP_MUL, make_compvar_primary(tmp_74), make_compvar_primary(tmp_75)));
}
tmp_73 = make_temporary(TYPE_INT);
{
compvar_t *tmp_76, *tmp_77;
tmp_76 = args[0][1];
tmp_77 = args[1][3];
emit_assign(make_lhs(tmp_73), make_op_rhs(OP_MUL, make_compvar_primary(tmp_76), make_compvar_primary(tmp_77)));
}
emit_assign(make_lhs(result[tmp_65]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_72), make_compvar_primary(tmp_73)));
}
break;
case 2 :
{
compvar_t *tmp_78, *tmp_79;
tmp_78 = make_temporary(TYPE_INT);
{
compvar_t *tmp_80, *tmp_81;
tmp_80 = args[0][2];
tmp_81 = args[1][0];
emit_assign(make_lhs(tmp_78), make_op_rhs(OP_MUL, make_compvar_primary(tmp_80), make_compvar_primary(tmp_81)));
}
tmp_79 = make_temporary(TYPE_INT);
{
compvar_t *tmp_82, *tmp_83;
tmp_82 = args[0][3];
tmp_83 = args[1][2];
emit_assign(make_lhs(tmp_79), make_op_rhs(OP_MUL, make_compvar_primary(tmp_82), make_compvar_primary(tmp_83)));
}
emit_assign(make_lhs(result[tmp_65]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_78), make_compvar_primary(tmp_79)));
}
break;
case 3 :
{
compvar_t *tmp_84, *tmp_85;
tmp_84 = make_temporary(TYPE_INT);
{
compvar_t *tmp_86, *tmp_87;
tmp_86 = args[0][2];
tmp_87 = args[1][1];
emit_assign(make_lhs(tmp_84), make_op_rhs(OP_MUL, make_compvar_primary(tmp_86), make_compvar_primary(tmp_87)));
}
tmp_85 = make_temporary(TYPE_INT);
{
compvar_t *tmp_88, *tmp_89;
tmp_88 = args[0][3];
tmp_89 = args[1][3];
emit_assign(make_lhs(tmp_85), make_op_rhs(OP_MUL, make_compvar_primary(tmp_88), make_compvar_primary(tmp_89)));
}
emit_assign(make_lhs(result[tmp_65]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_84), make_compvar_primary(tmp_85)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_90;
for (tmp_90 = 0; tmp_90 < 9; ++tmp_90)
{
switch (tmp_90)
{
case 0 :
{
compvar_t *tmp_91, *tmp_92;
tmp_91 = make_temporary(TYPE_INT);
{
compvar_t *tmp_93, *tmp_94;
tmp_93 = make_temporary(TYPE_INT);
{
compvar_t *tmp_95, *tmp_96;
tmp_95 = args[0][0];
tmp_96 = args[1][0];
emit_assign(make_lhs(tmp_93), make_op_rhs(OP_MUL, make_compvar_primary(tmp_95), make_compvar_primary(tmp_96)));
}
tmp_94 = make_temporary(TYPE_INT);
{
compvar_t *tmp_97, *tmp_98;
tmp_97 = args[0][1];
tmp_98 = args[1][3];
emit_assign(make_lhs(tmp_94), make_op_rhs(OP_MUL, make_compvar_primary(tmp_97), make_compvar_primary(tmp_98)));
}
emit_assign(make_lhs(tmp_91), make_op_rhs(OP_ADD, make_compvar_primary(tmp_93), make_compvar_primary(tmp_94)));
}
tmp_92 = make_temporary(TYPE_INT);
{
compvar_t *tmp_99, *tmp_100;
tmp_99 = args[0][2];
tmp_100 = args[1][6];
emit_assign(make_lhs(tmp_92), make_op_rhs(OP_MUL, make_compvar_primary(tmp_99), make_compvar_primary(tmp_100)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_91), make_compvar_primary(tmp_92)));
}
break;
case 1 :
{
compvar_t *tmp_101, *tmp_102;
tmp_101 = make_temporary(TYPE_INT);
{
compvar_t *tmp_103, *tmp_104;
tmp_103 = make_temporary(TYPE_INT);
{
compvar_t *tmp_105, *tmp_106;
tmp_105 = args[0][0];
tmp_106 = args[1][1];
emit_assign(make_lhs(tmp_103), make_op_rhs(OP_MUL, make_compvar_primary(tmp_105), make_compvar_primary(tmp_106)));
}
tmp_104 = make_temporary(TYPE_INT);
{
compvar_t *tmp_107, *tmp_108;
tmp_107 = args[0][1];
tmp_108 = args[1][4];
emit_assign(make_lhs(tmp_104), make_op_rhs(OP_MUL, make_compvar_primary(tmp_107), make_compvar_primary(tmp_108)));
}
emit_assign(make_lhs(tmp_101), make_op_rhs(OP_ADD, make_compvar_primary(tmp_103), make_compvar_primary(tmp_104)));
}
tmp_102 = make_temporary(TYPE_INT);
{
compvar_t *tmp_109, *tmp_110;
tmp_109 = args[0][2];
tmp_110 = args[1][7];
emit_assign(make_lhs(tmp_102), make_op_rhs(OP_MUL, make_compvar_primary(tmp_109), make_compvar_primary(tmp_110)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_101), make_compvar_primary(tmp_102)));
}
break;
case 2 :
{
compvar_t *tmp_111, *tmp_112;
tmp_111 = make_temporary(TYPE_INT);
{
compvar_t *tmp_113, *tmp_114;
tmp_113 = make_temporary(TYPE_INT);
{
compvar_t *tmp_115, *tmp_116;
tmp_115 = args[0][0];
tmp_116 = args[1][2];
emit_assign(make_lhs(tmp_113), make_op_rhs(OP_MUL, make_compvar_primary(tmp_115), make_compvar_primary(tmp_116)));
}
tmp_114 = make_temporary(TYPE_INT);
{
compvar_t *tmp_117, *tmp_118;
tmp_117 = args[0][1];
tmp_118 = args[1][5];
emit_assign(make_lhs(tmp_114), make_op_rhs(OP_MUL, make_compvar_primary(tmp_117), make_compvar_primary(tmp_118)));
}
emit_assign(make_lhs(tmp_111), make_op_rhs(OP_ADD, make_compvar_primary(tmp_113), make_compvar_primary(tmp_114)));
}
tmp_112 = make_temporary(TYPE_INT);
{
compvar_t *tmp_119, *tmp_120;
tmp_119 = args[0][2];
tmp_120 = args[1][8];
emit_assign(make_lhs(tmp_112), make_op_rhs(OP_MUL, make_compvar_primary(tmp_119), make_compvar_primary(tmp_120)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_111), make_compvar_primary(tmp_112)));
}
break;
case 3 :
{
compvar_t *tmp_121, *tmp_122;
tmp_121 = make_temporary(TYPE_INT);
{
compvar_t *tmp_123, *tmp_124;
tmp_123 = make_temporary(TYPE_INT);
{
compvar_t *tmp_125, *tmp_126;
tmp_125 = args[0][3];
tmp_126 = args[1][0];
emit_assign(make_lhs(tmp_123), make_op_rhs(OP_MUL, make_compvar_primary(tmp_125), make_compvar_primary(tmp_126)));
}
tmp_124 = make_temporary(TYPE_INT);
{
compvar_t *tmp_127, *tmp_128;
tmp_127 = args[0][4];
tmp_128 = args[1][3];
emit_assign(make_lhs(tmp_124), make_op_rhs(OP_MUL, make_compvar_primary(tmp_127), make_compvar_primary(tmp_128)));
}
emit_assign(make_lhs(tmp_121), make_op_rhs(OP_ADD, make_compvar_primary(tmp_123), make_compvar_primary(tmp_124)));
}
tmp_122 = make_temporary(TYPE_INT);
{
compvar_t *tmp_129, *tmp_130;
tmp_129 = args[0][5];
tmp_130 = args[1][6];
emit_assign(make_lhs(tmp_122), make_op_rhs(OP_MUL, make_compvar_primary(tmp_129), make_compvar_primary(tmp_130)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_121), make_compvar_primary(tmp_122)));
}
break;
case 4 :
{
compvar_t *tmp_131, *tmp_132;
tmp_131 = make_temporary(TYPE_INT);
{
compvar_t *tmp_133, *tmp_134;
tmp_133 = make_temporary(TYPE_INT);
{
compvar_t *tmp_135, *tmp_136;
tmp_135 = args[0][3];
tmp_136 = args[1][1];
emit_assign(make_lhs(tmp_133), make_op_rhs(OP_MUL, make_compvar_primary(tmp_135), make_compvar_primary(tmp_136)));
}
tmp_134 = make_temporary(TYPE_INT);
{
compvar_t *tmp_137, *tmp_138;
tmp_137 = args[0][4];
tmp_138 = args[1][4];
emit_assign(make_lhs(tmp_134), make_op_rhs(OP_MUL, make_compvar_primary(tmp_137), make_compvar_primary(tmp_138)));
}
emit_assign(make_lhs(tmp_131), make_op_rhs(OP_ADD, make_compvar_primary(tmp_133), make_compvar_primary(tmp_134)));
}
tmp_132 = make_temporary(TYPE_INT);
{
compvar_t *tmp_139, *tmp_140;
tmp_139 = args[0][5];
tmp_140 = args[1][7];
emit_assign(make_lhs(tmp_132), make_op_rhs(OP_MUL, make_compvar_primary(tmp_139), make_compvar_primary(tmp_140)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_131), make_compvar_primary(tmp_132)));
}
break;
case 5 :
{
compvar_t *tmp_141, *tmp_142;
tmp_141 = make_temporary(TYPE_INT);
{
compvar_t *tmp_143, *tmp_144;
tmp_143 = make_temporary(TYPE_INT);
{
compvar_t *tmp_145, *tmp_146;
tmp_145 = args[0][3];
tmp_146 = args[1][2];
emit_assign(make_lhs(tmp_143), make_op_rhs(OP_MUL, make_compvar_primary(tmp_145), make_compvar_primary(tmp_146)));
}
tmp_144 = make_temporary(TYPE_INT);
{
compvar_t *tmp_147, *tmp_148;
tmp_147 = args[0][4];
tmp_148 = args[1][5];
emit_assign(make_lhs(tmp_144), make_op_rhs(OP_MUL, make_compvar_primary(tmp_147), make_compvar_primary(tmp_148)));
}
emit_assign(make_lhs(tmp_141), make_op_rhs(OP_ADD, make_compvar_primary(tmp_143), make_compvar_primary(tmp_144)));
}
tmp_142 = make_temporary(TYPE_INT);
{
compvar_t *tmp_149, *tmp_150;
tmp_149 = args[0][5];
tmp_150 = args[1][8];
emit_assign(make_lhs(tmp_142), make_op_rhs(OP_MUL, make_compvar_primary(tmp_149), make_compvar_primary(tmp_150)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_141), make_compvar_primary(tmp_142)));
}
break;
case 6 :
{
compvar_t *tmp_151, *tmp_152;
tmp_151 = make_temporary(TYPE_INT);
{
compvar_t *tmp_153, *tmp_154;
tmp_153 = make_temporary(TYPE_INT);
{
compvar_t *tmp_155, *tmp_156;
tmp_155 = args[0][6];
tmp_156 = args[1][0];
emit_assign(make_lhs(tmp_153), make_op_rhs(OP_MUL, make_compvar_primary(tmp_155), make_compvar_primary(tmp_156)));
}
tmp_154 = make_temporary(TYPE_INT);
{
compvar_t *tmp_157, *tmp_158;
tmp_157 = args[0][7];
tmp_158 = args[1][3];
emit_assign(make_lhs(tmp_154), make_op_rhs(OP_MUL, make_compvar_primary(tmp_157), make_compvar_primary(tmp_158)));
}
emit_assign(make_lhs(tmp_151), make_op_rhs(OP_ADD, make_compvar_primary(tmp_153), make_compvar_primary(tmp_154)));
}
tmp_152 = make_temporary(TYPE_INT);
{
compvar_t *tmp_159, *tmp_160;
tmp_159 = args[0][8];
tmp_160 = args[1][6];
emit_assign(make_lhs(tmp_152), make_op_rhs(OP_MUL, make_compvar_primary(tmp_159), make_compvar_primary(tmp_160)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_151), make_compvar_primary(tmp_152)));
}
break;
case 7 :
{
compvar_t *tmp_161, *tmp_162;
tmp_161 = make_temporary(TYPE_INT);
{
compvar_t *tmp_163, *tmp_164;
tmp_163 = make_temporary(TYPE_INT);
{
compvar_t *tmp_165, *tmp_166;
tmp_165 = args[0][6];
tmp_166 = args[1][1];
emit_assign(make_lhs(tmp_163), make_op_rhs(OP_MUL, make_compvar_primary(tmp_165), make_compvar_primary(tmp_166)));
}
tmp_164 = make_temporary(TYPE_INT);
{
compvar_t *tmp_167, *tmp_168;
tmp_167 = args[0][7];
tmp_168 = args[1][4];
emit_assign(make_lhs(tmp_164), make_op_rhs(OP_MUL, make_compvar_primary(tmp_167), make_compvar_primary(tmp_168)));
}
emit_assign(make_lhs(tmp_161), make_op_rhs(OP_ADD, make_compvar_primary(tmp_163), make_compvar_primary(tmp_164)));
}
tmp_162 = make_temporary(TYPE_INT);
{
compvar_t *tmp_169, *tmp_170;
tmp_169 = args[0][8];
tmp_170 = args[1][7];
emit_assign(make_lhs(tmp_162), make_op_rhs(OP_MUL, make_compvar_primary(tmp_169), make_compvar_primary(tmp_170)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_161), make_compvar_primary(tmp_162)));
}
break;
case 8 :
{
compvar_t *tmp_171, *tmp_172;
tmp_171 = make_temporary(TYPE_INT);
{
compvar_t *tmp_173, *tmp_174;
tmp_173 = make_temporary(TYPE_INT);
{
compvar_t *tmp_175, *tmp_176;
tmp_175 = args[0][6];
tmp_176 = args[1][2];
emit_assign(make_lhs(tmp_173), make_op_rhs(OP_MUL, make_compvar_primary(tmp_175), make_compvar_primary(tmp_176)));
}
tmp_174 = make_temporary(TYPE_INT);
{
compvar_t *tmp_177, *tmp_178;
tmp_177 = args[0][7];
tmp_178 = args[1][5];
emit_assign(make_lhs(tmp_174), make_op_rhs(OP_MUL, make_compvar_primary(tmp_177), make_compvar_primary(tmp_178)));
}
emit_assign(make_lhs(tmp_171), make_op_rhs(OP_ADD, make_compvar_primary(tmp_173), make_compvar_primary(tmp_174)));
}
tmp_172 = make_temporary(TYPE_INT);
{
compvar_t *tmp_179, *tmp_180;
tmp_179 = args[0][8];
tmp_180 = args[1][8];
emit_assign(make_lhs(tmp_172), make_op_rhs(OP_MUL, make_compvar_primary(tmp_179), make_compvar_primary(tmp_180)));
}
emit_assign(make_lhs(result[tmp_90]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_171), make_compvar_primary(tmp_172)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_181;
for (tmp_181 = 0; tmp_181 < 2; ++tmp_181)
{
switch (tmp_181)
{
case 0 :
{
compvar_t *tmp_182, *tmp_183;
tmp_182 = make_temporary(TYPE_INT);
{
compvar_t *tmp_184, *tmp_185;
tmp_184 = args[0][0];
tmp_185 = args[1][0];
emit_assign(make_lhs(tmp_182), make_op_rhs(OP_MUL, make_compvar_primary(tmp_184), make_compvar_primary(tmp_185)));
}
tmp_183 = make_temporary(TYPE_INT);
{
compvar_t *tmp_186, *tmp_187;
tmp_186 = args[0][1];
tmp_187 = args[1][2];
emit_assign(make_lhs(tmp_183), make_op_rhs(OP_MUL, make_compvar_primary(tmp_186), make_compvar_primary(tmp_187)));
}
emit_assign(make_lhs(result[tmp_181]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_182), make_compvar_primary(tmp_183)));
}
break;
case 1 :
{
compvar_t *tmp_188, *tmp_189;
tmp_188 = make_temporary(TYPE_INT);
{
compvar_t *tmp_190, *tmp_191;
tmp_190 = args[0][0];
tmp_191 = args[1][1];
emit_assign(make_lhs(tmp_188), make_op_rhs(OP_MUL, make_compvar_primary(tmp_190), make_compvar_primary(tmp_191)));
}
tmp_189 = make_temporary(TYPE_INT);
{
compvar_t *tmp_192, *tmp_193;
tmp_192 = args[0][1];
tmp_193 = args[1][3];
emit_assign(make_lhs(tmp_189), make_op_rhs(OP_MUL, make_compvar_primary(tmp_192), make_compvar_primary(tmp_193)));
}
emit_assign(make_lhs(result[tmp_181]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_188), make_compvar_primary(tmp_189)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_194;
for (tmp_194 = 0; tmp_194 < 3; ++tmp_194)
{
switch (tmp_194)
{
case 0 :
{
compvar_t *tmp_195, *tmp_196;
tmp_195 = make_temporary(TYPE_INT);
{
compvar_t *tmp_197, *tmp_198;
tmp_197 = make_temporary(TYPE_INT);
{
compvar_t *tmp_199, *tmp_200;
tmp_199 = args[0][0];
tmp_200 = args[1][0];
emit_assign(make_lhs(tmp_197), make_op_rhs(OP_MUL, make_compvar_primary(tmp_199), make_compvar_primary(tmp_200)));
}
tmp_198 = make_temporary(TYPE_INT);
{
compvar_t *tmp_201, *tmp_202;
tmp_201 = args[0][1];
tmp_202 = args[1][3];
emit_assign(make_lhs(tmp_198), make_op_rhs(OP_MUL, make_compvar_primary(tmp_201), make_compvar_primary(tmp_202)));
}
emit_assign(make_lhs(tmp_195), make_op_rhs(OP_ADD, make_compvar_primary(tmp_197), make_compvar_primary(tmp_198)));
}
tmp_196 = make_temporary(TYPE_INT);
{
compvar_t *tmp_203, *tmp_204;
tmp_203 = args[0][2];
tmp_204 = args[1][6];
emit_assign(make_lhs(tmp_196), make_op_rhs(OP_MUL, make_compvar_primary(tmp_203), make_compvar_primary(tmp_204)));
}
emit_assign(make_lhs(result[tmp_194]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_195), make_compvar_primary(tmp_196)));
}
break;
case 1 :
{
compvar_t *tmp_205, *tmp_206;
tmp_205 = make_temporary(TYPE_INT);
{
compvar_t *tmp_207, *tmp_208;
tmp_207 = make_temporary(TYPE_INT);
{
compvar_t *tmp_209, *tmp_210;
tmp_209 = args[0][0];
tmp_210 = args[1][1];
emit_assign(make_lhs(tmp_207), make_op_rhs(OP_MUL, make_compvar_primary(tmp_209), make_compvar_primary(tmp_210)));
}
tmp_208 = make_temporary(TYPE_INT);
{
compvar_t *tmp_211, *tmp_212;
tmp_211 = args[0][1];
tmp_212 = args[1][4];
emit_assign(make_lhs(tmp_208), make_op_rhs(OP_MUL, make_compvar_primary(tmp_211), make_compvar_primary(tmp_212)));
}
emit_assign(make_lhs(tmp_205), make_op_rhs(OP_ADD, make_compvar_primary(tmp_207), make_compvar_primary(tmp_208)));
}
tmp_206 = make_temporary(TYPE_INT);
{
compvar_t *tmp_213, *tmp_214;
tmp_213 = args[0][2];
tmp_214 = args[1][7];
emit_assign(make_lhs(tmp_206), make_op_rhs(OP_MUL, make_compvar_primary(tmp_213), make_compvar_primary(tmp_214)));
}
emit_assign(make_lhs(result[tmp_194]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_205), make_compvar_primary(tmp_206)));
}
break;
case 2 :
{
compvar_t *tmp_215, *tmp_216;
tmp_215 = make_temporary(TYPE_INT);
{
compvar_t *tmp_217, *tmp_218;
tmp_217 = make_temporary(TYPE_INT);
{
compvar_t *tmp_219, *tmp_220;
tmp_219 = args[0][0];
tmp_220 = args[1][2];
emit_assign(make_lhs(tmp_217), make_op_rhs(OP_MUL, make_compvar_primary(tmp_219), make_compvar_primary(tmp_220)));
}
tmp_218 = make_temporary(TYPE_INT);
{
compvar_t *tmp_221, *tmp_222;
tmp_221 = args[0][1];
tmp_222 = args[1][5];
emit_assign(make_lhs(tmp_218), make_op_rhs(OP_MUL, make_compvar_primary(tmp_221), make_compvar_primary(tmp_222)));
}
emit_assign(make_lhs(tmp_215), make_op_rhs(OP_ADD, make_compvar_primary(tmp_217), make_compvar_primary(tmp_218)));
}
tmp_216 = make_temporary(TYPE_INT);
{
compvar_t *tmp_223, *tmp_224;
tmp_223 = args[0][2];
tmp_224 = args[1][8];
emit_assign(make_lhs(tmp_216), make_op_rhs(OP_MUL, make_compvar_primary(tmp_223), make_compvar_primary(tmp_224)));
}
emit_assign(make_lhs(result[tmp_194]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_215), make_compvar_primary(tmp_216)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_m2x2v2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_225;
for (tmp_225 = 0; tmp_225 < 2; ++tmp_225)
{
switch (tmp_225)
{
case 0 :
{
compvar_t *tmp_226, *tmp_227;
tmp_226 = make_temporary(TYPE_INT);
{
compvar_t *tmp_228, *tmp_229;
tmp_228 = args[0][0];
tmp_229 = args[1][0];
emit_assign(make_lhs(tmp_226), make_op_rhs(OP_MUL, make_compvar_primary(tmp_228), make_compvar_primary(tmp_229)));
}
tmp_227 = make_temporary(TYPE_INT);
{
compvar_t *tmp_230, *tmp_231;
tmp_230 = args[0][1];
tmp_231 = args[1][1];
emit_assign(make_lhs(tmp_227), make_op_rhs(OP_MUL, make_compvar_primary(tmp_230), make_compvar_primary(tmp_231)));
}
emit_assign(make_lhs(result[tmp_225]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_226), make_compvar_primary(tmp_227)));
}
break;
case 1 :
{
compvar_t *tmp_232, *tmp_233;
tmp_232 = make_temporary(TYPE_INT);
{
compvar_t *tmp_234, *tmp_235;
tmp_234 = args[0][2];
tmp_235 = args[1][0];
emit_assign(make_lhs(tmp_232), make_op_rhs(OP_MUL, make_compvar_primary(tmp_234), make_compvar_primary(tmp_235)));
}
tmp_233 = make_temporary(TYPE_INT);
{
compvar_t *tmp_236, *tmp_237;
tmp_236 = args[0][3];
tmp_237 = args[1][1];
emit_assign(make_lhs(tmp_233), make_op_rhs(OP_MUL, make_compvar_primary(tmp_236), make_compvar_primary(tmp_237)));
}
emit_assign(make_lhs(result[tmp_225]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_232), make_compvar_primary(tmp_233)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_m3x3v3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_238;
for (tmp_238 = 0; tmp_238 < 3; ++tmp_238)
{
switch (tmp_238)
{
case 0 :
{
compvar_t *tmp_239, *tmp_240;
tmp_239 = make_temporary(TYPE_INT);
{
compvar_t *tmp_241, *tmp_242;
tmp_241 = make_temporary(TYPE_INT);
{
compvar_t *tmp_243, *tmp_244;
tmp_243 = args[0][0];
tmp_244 = args[1][0];
emit_assign(make_lhs(tmp_241), make_op_rhs(OP_MUL, make_compvar_primary(tmp_243), make_compvar_primary(tmp_244)));
}
tmp_242 = make_temporary(TYPE_INT);
{
compvar_t *tmp_245, *tmp_246;
tmp_245 = args[0][1];
tmp_246 = args[1][1];
emit_assign(make_lhs(tmp_242), make_op_rhs(OP_MUL, make_compvar_primary(tmp_245), make_compvar_primary(tmp_246)));
}
emit_assign(make_lhs(tmp_239), make_op_rhs(OP_ADD, make_compvar_primary(tmp_241), make_compvar_primary(tmp_242)));
}
tmp_240 = make_temporary(TYPE_INT);
{
compvar_t *tmp_247, *tmp_248;
tmp_247 = args[0][2];
tmp_248 = args[1][2];
emit_assign(make_lhs(tmp_240), make_op_rhs(OP_MUL, make_compvar_primary(tmp_247), make_compvar_primary(tmp_248)));
}
emit_assign(make_lhs(result[tmp_238]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_239), make_compvar_primary(tmp_240)));
}
break;
case 1 :
{
compvar_t *tmp_249, *tmp_250;
tmp_249 = make_temporary(TYPE_INT);
{
compvar_t *tmp_251, *tmp_252;
tmp_251 = make_temporary(TYPE_INT);
{
compvar_t *tmp_253, *tmp_254;
tmp_253 = args[0][3];
tmp_254 = args[1][0];
emit_assign(make_lhs(tmp_251), make_op_rhs(OP_MUL, make_compvar_primary(tmp_253), make_compvar_primary(tmp_254)));
}
tmp_252 = make_temporary(TYPE_INT);
{
compvar_t *tmp_255, *tmp_256;
tmp_255 = args[0][4];
tmp_256 = args[1][1];
emit_assign(make_lhs(tmp_252), make_op_rhs(OP_MUL, make_compvar_primary(tmp_255), make_compvar_primary(tmp_256)));
}
emit_assign(make_lhs(tmp_249), make_op_rhs(OP_ADD, make_compvar_primary(tmp_251), make_compvar_primary(tmp_252)));
}
tmp_250 = make_temporary(TYPE_INT);
{
compvar_t *tmp_257, *tmp_258;
tmp_257 = args[0][5];
tmp_258 = args[1][2];
emit_assign(make_lhs(tmp_250), make_op_rhs(OP_MUL, make_compvar_primary(tmp_257), make_compvar_primary(tmp_258)));
}
emit_assign(make_lhs(result[tmp_238]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_249), make_compvar_primary(tmp_250)));
}
break;
case 2 :
{
compvar_t *tmp_259, *tmp_260;
tmp_259 = make_temporary(TYPE_INT);
{
compvar_t *tmp_261, *tmp_262;
tmp_261 = make_temporary(TYPE_INT);
{
compvar_t *tmp_263, *tmp_264;
tmp_263 = args[0][6];
tmp_264 = args[1][0];
emit_assign(make_lhs(tmp_261), make_op_rhs(OP_MUL, make_compvar_primary(tmp_263), make_compvar_primary(tmp_264)));
}
tmp_262 = make_temporary(TYPE_INT);
{
compvar_t *tmp_265, *tmp_266;
tmp_265 = args[0][7];
tmp_266 = args[1][1];
emit_assign(make_lhs(tmp_262), make_op_rhs(OP_MUL, make_compvar_primary(tmp_265), make_compvar_primary(tmp_266)));
}
emit_assign(make_lhs(tmp_259), make_op_rhs(OP_ADD, make_compvar_primary(tmp_261), make_compvar_primary(tmp_262)));
}
tmp_260 = make_temporary(TYPE_INT);
{
compvar_t *tmp_267, *tmp_268;
tmp_267 = args[0][8];
tmp_268 = args[1][2];
emit_assign(make_lhs(tmp_260), make_op_rhs(OP_MUL, make_compvar_primary(tmp_267), make_compvar_primary(tmp_268)));
}
emit_assign(make_lhs(result[tmp_238]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_259), make_compvar_primary(tmp_260)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_269;
for (tmp_269 = 0; tmp_269 < 1; ++tmp_269)
{
switch (tmp_269)
{
case 0 :
{
compvar_t *tmp_270, *tmp_271;
tmp_270 = args[0][0];
tmp_271 = args[1][0];
emit_assign(make_lhs(result[tmp_269]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_270), make_compvar_primary(tmp_271)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_mul_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_272;
for (tmp_272 = 0; tmp_272 < arglengths[0]; ++tmp_272)
{
{
compvar_t *tmp_273, *tmp_274;
tmp_273 = args[0][tmp_272];
tmp_274 = args[1][0];
emit_assign(make_lhs(result[tmp_272]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_273), make_compvar_primary(tmp_274)));
}
}
}
}

static void
gen_mul_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_275;
for (tmp_275 = 0; tmp_275 < arglengths[0]; ++tmp_275)
{
{
compvar_t *tmp_276, *tmp_277;
tmp_276 = args[0][tmp_275];
tmp_277 = args[1][tmp_275];
emit_assign(make_lhs(result[tmp_275]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_276), make_compvar_primary(tmp_277)));
}
}
}
}

static void
gen_div_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_278;
tmp_278 = make_temporary(TYPE_INT);
{
compvar_t *tmp_279, *tmp_280;
tmp_279 = args[1][0];
tmp_280 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_280), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_278), make_op_rhs(OP_EQ, make_compvar_primary(tmp_279), make_compvar_primary(tmp_280)));
}
start_if_cond(make_compvar_rhs(tmp_278));
{
compvar_t *tmp_281, *tmp_282;
tmp_281 = args[1][1];
tmp_282 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_282), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_278), make_op_rhs(OP_EQ, make_compvar_primary(tmp_281), make_compvar_primary(tmp_282)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_278));
{
int tmp_283;
for (tmp_283 = 0; tmp_283 < 2; ++tmp_283)
{
switch (tmp_283)
{
case 0 :
emit_assign(make_lhs(result[tmp_283]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_283]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_284;

if (2 == 1)
{
tmp_284 = make_temporary(TYPE_INT);
{
compvar_t *tmp_288, *tmp_289;
tmp_288 = args[1][0];
tmp_289 = args[1][0];
emit_assign(make_lhs(tmp_284), make_op_rhs(OP_MUL, make_compvar_primary(tmp_288), make_compvar_primary(tmp_289)));
}

}
else
{
compvar_t *tmp_285, *tmp_286;
int tmp_287;
tmp_284 = make_temporary(TYPE_INT);
tmp_285 = make_temporary(TYPE_INT);
{
compvar_t *tmp_290, *tmp_291;
tmp_290 = args[1][0];
tmp_291 = args[1][0];
emit_assign(make_lhs(tmp_285), make_op_rhs(OP_MUL, make_compvar_primary(tmp_290), make_compvar_primary(tmp_291)));
}
tmp_286 = make_temporary(TYPE_INT);
{
compvar_t *tmp_292, *tmp_293;
tmp_292 = args[1][1];
tmp_293 = args[1][1];
emit_assign(make_lhs(tmp_286), make_op_rhs(OP_MUL, make_compvar_primary(tmp_292), make_compvar_primary(tmp_293)));
}
emit_assign(make_lhs(tmp_284), make_op_rhs(OP_ADD, make_compvar_primary(tmp_285), make_compvar_primary(tmp_286)));
for (tmp_287 = 2; tmp_287 < 2; ++tmp_287)
{
tmp_285 = make_temporary(TYPE_INT);
{
compvar_t *tmp_294, *tmp_295;
tmp_294 = args[1][tmp_287];
tmp_295 = args[1][tmp_287];
emit_assign(make_lhs(tmp_285), make_op_rhs(OP_MUL, make_compvar_primary(tmp_294), make_compvar_primary(tmp_295)));
}
emit_assign(make_lhs(tmp_284), make_op_rhs(OP_ADD, make_compvar_primary(tmp_284), make_compvar_primary(tmp_285)));
}
}

{
int tmp_296;
for (tmp_296 = 0; tmp_296 < 2; ++tmp_296)
{
switch (tmp_296)
{
case 0 :
{
compvar_t *tmp_297, *tmp_298;
if (2 == 1)
{
tmp_297 = make_temporary(TYPE_INT);
{
compvar_t *tmp_302, *tmp_303;
tmp_302 = args[0][0];
tmp_303 = args[1][0];
emit_assign(make_lhs(tmp_297), make_op_rhs(OP_MUL, make_compvar_primary(tmp_302), make_compvar_primary(tmp_303)));
}

}
else
{
compvar_t *tmp_299, *tmp_300;
int tmp_301;
tmp_297 = make_temporary(TYPE_INT);
tmp_299 = make_temporary(TYPE_INT);
{
compvar_t *tmp_304, *tmp_305;
tmp_304 = args[0][0];
tmp_305 = args[1][0];
emit_assign(make_lhs(tmp_299), make_op_rhs(OP_MUL, make_compvar_primary(tmp_304), make_compvar_primary(tmp_305)));
}
tmp_300 = make_temporary(TYPE_INT);
{
compvar_t *tmp_306, *tmp_307;
tmp_306 = args[0][1];
tmp_307 = args[1][1];
emit_assign(make_lhs(tmp_300), make_op_rhs(OP_MUL, make_compvar_primary(tmp_306), make_compvar_primary(tmp_307)));
}
emit_assign(make_lhs(tmp_297), make_op_rhs(OP_ADD, make_compvar_primary(tmp_299), make_compvar_primary(tmp_300)));
for (tmp_301 = 2; tmp_301 < 2; ++tmp_301)
{
tmp_299 = make_temporary(TYPE_INT);
{
compvar_t *tmp_308, *tmp_309;
tmp_308 = args[0][tmp_301];
tmp_309 = args[1][tmp_301];
emit_assign(make_lhs(tmp_299), make_op_rhs(OP_MUL, make_compvar_primary(tmp_308), make_compvar_primary(tmp_309)));
}
emit_assign(make_lhs(tmp_297), make_op_rhs(OP_ADD, make_compvar_primary(tmp_297), make_compvar_primary(tmp_299)));
}
}
tmp_298 = tmp_284;
emit_assign(make_lhs(result[tmp_296]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_297), make_compvar_primary(tmp_298)));
}
break;
case 1 :
{
compvar_t *tmp_310, *tmp_311;
tmp_310 = make_temporary(TYPE_INT);
{
compvar_t *tmp_312, *tmp_313;
tmp_312 = make_temporary(TYPE_INT);
{
compvar_t *tmp_314, *tmp_315;
tmp_314 = make_temporary(TYPE_INT);
{
compvar_t *tmp_316;
tmp_316 = args[0][0];
emit_assign(make_lhs(tmp_314), make_op_rhs(OP_NEG, make_compvar_primary(tmp_316)));
}
tmp_315 = args[1][1];
emit_assign(make_lhs(tmp_312), make_op_rhs(OP_MUL, make_compvar_primary(tmp_314), make_compvar_primary(tmp_315)));
}
tmp_313 = make_temporary(TYPE_INT);
{
compvar_t *tmp_317, *tmp_318;
tmp_317 = args[1][0];
tmp_318 = args[0][1];
emit_assign(make_lhs(tmp_313), make_op_rhs(OP_MUL, make_compvar_primary(tmp_317), make_compvar_primary(tmp_318)));
}
emit_assign(make_lhs(tmp_310), make_op_rhs(OP_ADD, make_compvar_primary(tmp_312), make_compvar_primary(tmp_313)));
}
tmp_311 = tmp_284;
emit_assign(make_lhs(result[tmp_296]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_310), make_compvar_primary(tmp_311)));
}
break;
default :
assert(0);
}
}
}
}
end_if_cond();
}
}

static void
gen_div_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_319;

if (2 == 1)
{
tmp_319 = make_temporary(TYPE_INT);
{
compvar_t *tmp_323, *tmp_324;
tmp_323 = args[1][0];
tmp_324 = args[1][0];
emit_assign(make_lhs(tmp_319), make_op_rhs(OP_MUL, make_compvar_primary(tmp_323), make_compvar_primary(tmp_324)));
}

}
else
{
compvar_t *tmp_320, *tmp_321;
int tmp_322;
tmp_319 = make_temporary(TYPE_INT);
tmp_320 = make_temporary(TYPE_INT);
{
compvar_t *tmp_325, *tmp_326;
tmp_325 = args[1][0];
tmp_326 = args[1][0];
emit_assign(make_lhs(tmp_320), make_op_rhs(OP_MUL, make_compvar_primary(tmp_325), make_compvar_primary(tmp_326)));
}
tmp_321 = make_temporary(TYPE_INT);
{
compvar_t *tmp_327, *tmp_328;
tmp_327 = args[1][1];
tmp_328 = args[1][1];
emit_assign(make_lhs(tmp_321), make_op_rhs(OP_MUL, make_compvar_primary(tmp_327), make_compvar_primary(tmp_328)));
}
emit_assign(make_lhs(tmp_319), make_op_rhs(OP_ADD, make_compvar_primary(tmp_320), make_compvar_primary(tmp_321)));
for (tmp_322 = 2; tmp_322 < 2; ++tmp_322)
{
tmp_320 = make_temporary(TYPE_INT);
{
compvar_t *tmp_329, *tmp_330;
tmp_329 = args[1][tmp_322];
tmp_330 = args[1][tmp_322];
emit_assign(make_lhs(tmp_320), make_op_rhs(OP_MUL, make_compvar_primary(tmp_329), make_compvar_primary(tmp_330)));
}
emit_assign(make_lhs(tmp_319), make_op_rhs(OP_ADD, make_compvar_primary(tmp_319), make_compvar_primary(tmp_320)));
}
}

{
compvar_t *tmp_331;
tmp_331 = make_temporary(TYPE_INT);
{
compvar_t *tmp_332, *tmp_333;
tmp_332 = tmp_319;
tmp_333 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_333), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_331), make_op_rhs(OP_EQ, make_compvar_primary(tmp_332), make_compvar_primary(tmp_333)));
}
start_if_cond(make_compvar_rhs(tmp_331));
{
int tmp_334;
for (tmp_334 = 0; tmp_334 < 2; ++tmp_334)
{
switch (tmp_334)
{
case 0 :
emit_assign(make_lhs(result[tmp_334]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_334]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_335;
for (tmp_335 = 0; tmp_335 < 2; ++tmp_335)
{
switch (tmp_335)
{
case 0 :
{
compvar_t *tmp_336, *tmp_337;
tmp_336 = make_temporary(TYPE_INT);
{
compvar_t *tmp_338, *tmp_339;
tmp_338 = args[0][0];
tmp_339 = args[1][0];
emit_assign(make_lhs(tmp_336), make_op_rhs(OP_MUL, make_compvar_primary(tmp_338), make_compvar_primary(tmp_339)));
}
tmp_337 = tmp_319;
emit_assign(make_lhs(result[tmp_335]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_336), make_compvar_primary(tmp_337)));
}
break;
case 1 :
{
compvar_t *tmp_340;
tmp_340 = make_temporary(TYPE_INT);
{
compvar_t *tmp_341, *tmp_342;
tmp_341 = make_temporary(TYPE_INT);
{
compvar_t *tmp_343, *tmp_344;
tmp_343 = args[0][0];
tmp_344 = args[1][1];
emit_assign(make_lhs(tmp_341), make_op_rhs(OP_MUL, make_compvar_primary(tmp_343), make_compvar_primary(tmp_344)));
}
tmp_342 = tmp_319;
emit_assign(make_lhs(tmp_340), make_op_rhs(OP_DIV, make_compvar_primary(tmp_341), make_compvar_primary(tmp_342)));
}
emit_assign(make_lhs(result[tmp_335]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_340)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
}

static void
gen_div_v2m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_345;
compvar_t *tmp_350;

tmp_345 = make_temporary(TYPE_INT);
{
compvar_t *tmp_346, *tmp_347, *tmp_348, *tmp_349;
tmp_346 = args[1][0];
tmp_347 = args[1][1];
tmp_348 = args[1][2];
tmp_349 = args[1][3];
emit_assign(make_lhs(tmp_345), make_op_rhs(OP_MAKE_M2X2, make_compvar_primary(tmp_346), make_compvar_primary(tmp_347), make_compvar_primary(tmp_348), make_compvar_primary(tmp_349)));
}

tmp_350 = make_temporary(TYPE_INT);
{
compvar_t *tmp_351, *tmp_352;
tmp_351 = args[0][0];
tmp_352 = args[0][1];
emit_assign(make_lhs(tmp_350), make_op_rhs(OP_MAKE_V2, make_compvar_primary(tmp_351), make_compvar_primary(tmp_352)));
}

{
compvar_t *tmp_353;

tmp_353 = make_temporary(TYPE_INT);
{
compvar_t *tmp_354, *tmp_355;
tmp_354 = tmp_345;
tmp_355 = tmp_350;
emit_assign(make_lhs(tmp_353), make_op_rhs(OP_SOLVE_LINEAR_2, make_compvar_primary(tmp_354), make_compvar_primary(tmp_355)));
}

{
int tmp_356;
for (tmp_356 = 0; tmp_356 < 2; ++tmp_356)
{
switch (tmp_356)
{
case 0 :
{
compvar_t *tmp_357, *tmp_358;
tmp_357 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_357), make_int_const_rhs(0));
tmp_358 = tmp_353;
emit_assign(make_lhs(result[tmp_356]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_357), make_compvar_primary(tmp_358)));
}
break;
case 1 :
{
compvar_t *tmp_359, *tmp_360;
tmp_359 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_359), make_int_const_rhs(1));
tmp_360 = tmp_353;
emit_assign(make_lhs(result[tmp_356]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_359), make_compvar_primary(tmp_360)));
}
break;
default :
assert(0);
}
}
}
}
}
}

static void
gen_div_v3m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_361;
compvar_t *tmp_371;

tmp_361 = make_temporary(TYPE_INT);
{
compvar_t *tmp_362, *tmp_363, *tmp_364, *tmp_365, *tmp_366, *tmp_367, *tmp_368, *tmp_369, *tmp_370;
tmp_362 = args[1][0];
tmp_363 = args[1][1];
tmp_364 = args[1][2];
tmp_365 = args[1][3];
tmp_366 = args[1][4];
tmp_367 = args[1][5];
tmp_368 = args[1][6];
tmp_369 = args[1][7];
tmp_370 = args[1][8];
emit_assign(make_lhs(tmp_361), make_op_rhs(OP_MAKE_M3X3, make_compvar_primary(tmp_362), make_compvar_primary(tmp_363), make_compvar_primary(tmp_364), make_compvar_primary(tmp_365), make_compvar_primary(tmp_366), make_compvar_primary(tmp_367), make_compvar_primary(tmp_368), make_compvar_primary(tmp_369), make_compvar_primary(tmp_370)));
}

tmp_371 = make_temporary(TYPE_INT);
{
compvar_t *tmp_372, *tmp_373, *tmp_374;
tmp_372 = args[0][0];
tmp_373 = args[0][1];
tmp_374 = args[0][2];
emit_assign(make_lhs(tmp_371), make_op_rhs(OP_MAKE_V3, make_compvar_primary(tmp_372), make_compvar_primary(tmp_373), make_compvar_primary(tmp_374)));
}

{
compvar_t *tmp_375;

tmp_375 = make_temporary(TYPE_INT);
{
compvar_t *tmp_376, *tmp_377;
tmp_376 = tmp_361;
tmp_377 = tmp_371;
emit_assign(make_lhs(tmp_375), make_op_rhs(OP_SOLVE_LINEAR_3, make_compvar_primary(tmp_376), make_compvar_primary(tmp_377)));
}

{
int tmp_378;
for (tmp_378 = 0; tmp_378 < 3; ++tmp_378)
{
switch (tmp_378)
{
case 0 :
{
compvar_t *tmp_379, *tmp_380;
tmp_379 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_379), make_int_const_rhs(0));
tmp_380 = tmp_375;
emit_assign(make_lhs(result[tmp_378]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_379), make_compvar_primary(tmp_380)));
}
break;
case 1 :
{
compvar_t *tmp_381, *tmp_382;
tmp_381 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_381), make_int_const_rhs(1));
tmp_382 = tmp_375;
emit_assign(make_lhs(result[tmp_378]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_381), make_compvar_primary(tmp_382)));
}
break;
case 2 :
{
compvar_t *tmp_383, *tmp_384;
tmp_383 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_383), make_int_const_rhs(2));
tmp_384 = tmp_375;
emit_assign(make_lhs(result[tmp_378]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_383), make_compvar_primary(tmp_384)));
}
break;
default :
assert(0);
}
}
}
{
compvar_t *tmp_385;
tmp_385 = make_temporary(TYPE_INT);
{
compvar_t *tmp_386;
tmp_386 = tmp_361;
emit_assign(make_lhs(tmp_385), make_op_rhs(OP_FREE_MATRIX, make_compvar_primary(tmp_386)));
}
}
}
}
}

static void
gen_div_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_387;
tmp_387 = make_temporary(TYPE_INT);
{
compvar_t *tmp_388, *tmp_389;
tmp_388 = args[1][0];
tmp_389 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_389), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_387), make_op_rhs(OP_EQ, make_compvar_primary(tmp_388), make_compvar_primary(tmp_389)));
}
start_if_cond(make_compvar_rhs(tmp_387));
{
int tmp_390;
for (tmp_390 = 0; tmp_390 < 1; ++tmp_390)
{
switch (tmp_390)
{
case 0 :
emit_assign(make_lhs(result[tmp_390]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_391;
for (tmp_391 = 0; tmp_391 < 1; ++tmp_391)
{
{
compvar_t *tmp_392, *tmp_393;
tmp_392 = args[0][tmp_391];
tmp_393 = args[1][tmp_391];
emit_assign(make_lhs(result[tmp_391]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_392), make_compvar_primary(tmp_393)));
}
}
}
end_if_cond();
}
}

static void
gen_div_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_394;
tmp_394 = make_temporary(TYPE_INT);
{
compvar_t *tmp_395, *tmp_396;
tmp_395 = args[1][0];
tmp_396 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_396), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_394), make_op_rhs(OP_EQ, make_compvar_primary(tmp_395), make_compvar_primary(tmp_396)));
}
start_if_cond(make_compvar_rhs(tmp_394));
{
int tmp_397;
for (tmp_397 = 0; tmp_397 < arglengths[0]; ++tmp_397)
{
emit_assign(make_lhs(result[tmp_397]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_398;
for (tmp_398 = 0; tmp_398 < arglengths[0]; ++tmp_398)
{
{
compvar_t *tmp_399, *tmp_400;
tmp_399 = args[0][tmp_398];
tmp_400 = args[1][0];
emit_assign(make_lhs(result[tmp_398]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_399), make_compvar_primary(tmp_400)));
}
}
}
end_if_cond();
}
}

static void
gen_div_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_401;
for (tmp_401 = 0; tmp_401 < arglengths[1]; ++tmp_401)
{
{
compvar_t *tmp_402;
tmp_402 = make_temporary(TYPE_INT);
{
compvar_t *tmp_403, *tmp_404;
tmp_403 = args[1][tmp_401];
tmp_404 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_404), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_402), make_op_rhs(OP_EQ, make_compvar_primary(tmp_403), make_compvar_primary(tmp_404)));
}
start_if_cond(make_compvar_rhs(tmp_402));
emit_assign(make_lhs(result[tmp_401]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_405, *tmp_406;
tmp_405 = args[0][tmp_401];
tmp_406 = args[1][tmp_401];
emit_assign(make_lhs(result[tmp_401]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_405), make_compvar_primary(tmp_406)));
}
end_if_cond();
}
}
}
}

static void
gen_mod_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_407;
tmp_407 = make_temporary(TYPE_INT);
{
compvar_t *tmp_408, *tmp_409;
tmp_408 = args[1][0];
tmp_409 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_409), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_407), make_op_rhs(OP_EQ, make_compvar_primary(tmp_408), make_compvar_primary(tmp_409)));
}
start_if_cond(make_compvar_rhs(tmp_407));
{
int tmp_410;
for (tmp_410 = 0; tmp_410 < 1; ++tmp_410)
{
switch (tmp_410)
{
case 0 :
emit_assign(make_lhs(result[tmp_410]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_411;
for (tmp_411 = 0; tmp_411 < 1; ++tmp_411)
{
{
compvar_t *tmp_412, *tmp_413;
tmp_412 = args[0][tmp_411];
tmp_413 = args[1][tmp_411];
emit_assign(make_lhs(result[tmp_411]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_412), make_compvar_primary(tmp_413)));
}
}
}
end_if_cond();
}
}

static void
gen_mod_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_414;
tmp_414 = make_temporary(TYPE_INT);
{
compvar_t *tmp_415, *tmp_416;
tmp_415 = args[1][0];
tmp_416 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_416), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_414), make_op_rhs(OP_EQ, make_compvar_primary(tmp_415), make_compvar_primary(tmp_416)));
}
start_if_cond(make_compvar_rhs(tmp_414));
{
int tmp_417;
for (tmp_417 = 0; tmp_417 < arglengths[0]; ++tmp_417)
{
emit_assign(make_lhs(result[tmp_417]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_418;
for (tmp_418 = 0; tmp_418 < arglengths[0]; ++tmp_418)
{
{
compvar_t *tmp_419, *tmp_420;
tmp_419 = args[0][tmp_418];
tmp_420 = args[1][0];
emit_assign(make_lhs(result[tmp_418]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_419), make_compvar_primary(tmp_420)));
}
}
}
end_if_cond();
}
}

static void
gen_mod_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_421;
for (tmp_421 = 0; tmp_421 < arglengths[1]; ++tmp_421)
{
{
compvar_t *tmp_422;
tmp_422 = make_temporary(TYPE_INT);
{
compvar_t *tmp_423, *tmp_424;
tmp_423 = args[1][tmp_421];
tmp_424 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_424), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_422), make_op_rhs(OP_EQ, make_compvar_primary(tmp_423), make_compvar_primary(tmp_424)));
}
start_if_cond(make_compvar_rhs(tmp_422));
emit_assign(make_lhs(result[tmp_421]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_425, *tmp_426;
tmp_425 = args[0][tmp_421];
tmp_426 = args[1][tmp_421];
emit_assign(make_lhs(result[tmp_421]), make_op_rhs(OP_MOD, make_compvar_primary(tmp_425), make_compvar_primary(tmp_426)));
}
end_if_cond();
}
}
}
}

static void
gen_pmod (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_427;

tmp_427 = make_temporary(TYPE_INT);
{
compvar_t *tmp_428, *tmp_429;
tmp_428 = args[0][0];
tmp_429 = args[1][0];
emit_assign(make_lhs(tmp_427), make_op_rhs(OP_MOD, make_compvar_primary(tmp_428), make_compvar_primary(tmp_429)));
}

{
compvar_t *tmp_430;
tmp_430 = make_temporary(TYPE_INT);
{
compvar_t *tmp_431, *tmp_432;
tmp_431 = args[0][0];
tmp_432 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_432), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_430), make_op_rhs(OP_LESS, make_compvar_primary(tmp_431), make_compvar_primary(tmp_432)));
}
start_if_cond(make_compvar_rhs(tmp_430));
{
int tmp_433;
for (tmp_433 = 0; tmp_433 < 1; ++tmp_433)
{
switch (tmp_433)
{
case 0 :
{
compvar_t *tmp_434, *tmp_435;
tmp_434 = tmp_427;
tmp_435 = args[1][0];
emit_assign(make_lhs(result[tmp_433]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_434), make_compvar_primary(tmp_435)));
}
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_436;
for (tmp_436 = 0; tmp_436 < 1; ++tmp_436)
{
switch (tmp_436)
{
case 0 :
emit_assign(make_lhs(result[tmp_436]), make_compvar_rhs(tmp_427));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}
}

static void
gen_sqrt_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_437;

tmp_437 = make_temporary(TYPE_INT);
{
compvar_t *tmp_438;
tmp_438 = make_temporary(TYPE_INT);
{
compvar_t *tmp_439, *tmp_440;
tmp_439 = args[0][0];
tmp_440 = args[0][1];
emit_assign(make_lhs(tmp_438), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_439), make_compvar_primary(tmp_440)));
}
emit_assign(make_lhs(tmp_437), make_op_rhs(OP_C_SQRT, make_compvar_primary(tmp_438)));
}

{
int tmp_441;
for (tmp_441 = 0; tmp_441 < 2; ++tmp_441)
{
switch (tmp_441)
{
case 0 :
{
compvar_t *tmp_442;
tmp_442 = tmp_437;
emit_assign(make_lhs(result[tmp_441]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_442)));
}
break;
case 1 :
{
compvar_t *tmp_443;
tmp_443 = tmp_437;
emit_assign(make_lhs(result[tmp_441]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_443)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_sqrt_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_444;
for (tmp_444 = 0; tmp_444 < 1; ++tmp_444)
{
switch (tmp_444)
{
case 0 :
{
compvar_t *tmp_445;
tmp_445 = args[0][0];
emit_assign(make_lhs(result[tmp_444]), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_445)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_sum (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_446;
for (tmp_446 = 0; tmp_446 < 1; ++tmp_446)
{
switch (tmp_446)
{
case 0 :
if (arglengths[0] == 1)
{
emit_assign(make_lhs(result[tmp_446]), make_compvar_rhs(args[0][0]));

}
else
{
compvar_t *tmp_447, *tmp_448;
int tmp_449;
tmp_447 = args[0][0];
tmp_448 = args[0][1];
emit_assign(make_lhs(result[tmp_446]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_447), make_compvar_primary(tmp_448)));
for (tmp_449 = 2; tmp_449 < arglengths[0]; ++tmp_449)
{
tmp_447 = args[0][tmp_449];
emit_assign(make_lhs(result[tmp_446]), make_op_rhs(OP_ADD, make_compvar_primary(result[tmp_446]), make_compvar_primary(tmp_447)));
}
}
break;
default :
assert(0);
}
}
}
}

static void
gen_dotp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_450;
for (tmp_450 = 0; tmp_450 < 1; ++tmp_450)
{
switch (tmp_450)
{
case 0 :
if (arglengths[0] == 1)
{
{
compvar_t *tmp_454, *tmp_455;
tmp_454 = args[0][0];
tmp_455 = args[1][0];
emit_assign(make_lhs(result[tmp_450]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_454), make_compvar_primary(tmp_455)));
}

}
else
{
compvar_t *tmp_451, *tmp_452;
int tmp_453;
tmp_451 = make_temporary(TYPE_INT);
{
compvar_t *tmp_456, *tmp_457;
tmp_456 = args[0][0];
tmp_457 = args[1][0];
emit_assign(make_lhs(tmp_451), make_op_rhs(OP_MUL, make_compvar_primary(tmp_456), make_compvar_primary(tmp_457)));
}
tmp_452 = make_temporary(TYPE_INT);
{
compvar_t *tmp_458, *tmp_459;
tmp_458 = args[0][1];
tmp_459 = args[1][1];
emit_assign(make_lhs(tmp_452), make_op_rhs(OP_MUL, make_compvar_primary(tmp_458), make_compvar_primary(tmp_459)));
}
emit_assign(make_lhs(result[tmp_450]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_451), make_compvar_primary(tmp_452)));
for (tmp_453 = 2; tmp_453 < arglengths[0]; ++tmp_453)
{
tmp_451 = make_temporary(TYPE_INT);
{
compvar_t *tmp_460, *tmp_461;
tmp_460 = args[0][tmp_453];
tmp_461 = args[1][tmp_453];
emit_assign(make_lhs(tmp_451), make_op_rhs(OP_MUL, make_compvar_primary(tmp_460), make_compvar_primary(tmp_461)));
}
emit_assign(make_lhs(result[tmp_450]), make_op_rhs(OP_ADD, make_compvar_primary(result[tmp_450]), make_compvar_primary(tmp_451)));
}
}
break;
default :
assert(0);
}
}
}
}

static void
gen_crossp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_462;
for (tmp_462 = 0; tmp_462 < 3; ++tmp_462)
{
switch (tmp_462)
{
case 0 :
{
compvar_t *tmp_463, *tmp_464;
tmp_463 = make_temporary(TYPE_INT);
{
compvar_t *tmp_465, *tmp_466;
tmp_465 = args[0][1];
tmp_466 = args[1][2];
emit_assign(make_lhs(tmp_463), make_op_rhs(OP_MUL, make_compvar_primary(tmp_465), make_compvar_primary(tmp_466)));
}
tmp_464 = make_temporary(TYPE_INT);
{
compvar_t *tmp_467, *tmp_468;
tmp_467 = args[0][2];
tmp_468 = args[1][1];
emit_assign(make_lhs(tmp_464), make_op_rhs(OP_MUL, make_compvar_primary(tmp_467), make_compvar_primary(tmp_468)));
}
emit_assign(make_lhs(result[tmp_462]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_463), make_compvar_primary(tmp_464)));
}
break;
case 1 :
{
compvar_t *tmp_469, *tmp_470;
tmp_469 = make_temporary(TYPE_INT);
{
compvar_t *tmp_471, *tmp_472;
tmp_471 = args[0][2];
tmp_472 = args[1][0];
emit_assign(make_lhs(tmp_469), make_op_rhs(OP_MUL, make_compvar_primary(tmp_471), make_compvar_primary(tmp_472)));
}
tmp_470 = make_temporary(TYPE_INT);
{
compvar_t *tmp_473, *tmp_474;
tmp_473 = args[0][0];
tmp_474 = args[1][2];
emit_assign(make_lhs(tmp_470), make_op_rhs(OP_MUL, make_compvar_primary(tmp_473), make_compvar_primary(tmp_474)));
}
emit_assign(make_lhs(result[tmp_462]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_469), make_compvar_primary(tmp_470)));
}
break;
case 2 :
{
compvar_t *tmp_475, *tmp_476;
tmp_475 = make_temporary(TYPE_INT);
{
compvar_t *tmp_477, *tmp_478;
tmp_477 = args[0][0];
tmp_478 = args[1][1];
emit_assign(make_lhs(tmp_475), make_op_rhs(OP_MUL, make_compvar_primary(tmp_477), make_compvar_primary(tmp_478)));
}
tmp_476 = make_temporary(TYPE_INT);
{
compvar_t *tmp_479, *tmp_480;
tmp_479 = args[0][1];
tmp_480 = args[1][0];
emit_assign(make_lhs(tmp_476), make_op_rhs(OP_MUL, make_compvar_primary(tmp_479), make_compvar_primary(tmp_480)));
}
emit_assign(make_lhs(result[tmp_462]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_475), make_compvar_primary(tmp_476)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_det_m2x2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_481;
for (tmp_481 = 0; tmp_481 < 1; ++tmp_481)
{
switch (tmp_481)
{
case 0 :
{
compvar_t *tmp_482, *tmp_483;
tmp_482 = make_temporary(TYPE_INT);
{
compvar_t *tmp_484, *tmp_485;
tmp_484 = args[0][0];
tmp_485 = args[0][3];
emit_assign(make_lhs(tmp_482), make_op_rhs(OP_MUL, make_compvar_primary(tmp_484), make_compvar_primary(tmp_485)));
}
tmp_483 = make_temporary(TYPE_INT);
{
compvar_t *tmp_486, *tmp_487;
tmp_486 = args[0][1];
tmp_487 = args[0][2];
emit_assign(make_lhs(tmp_483), make_op_rhs(OP_MUL, make_compvar_primary(tmp_486), make_compvar_primary(tmp_487)));
}
emit_assign(make_lhs(result[tmp_481]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_482), make_compvar_primary(tmp_483)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_det_m3x3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_488;
for (tmp_488 = 0; tmp_488 < 1; ++tmp_488)
{
switch (tmp_488)
{
case 0 :
{
compvar_t *tmp_489, *tmp_490;
tmp_489 = make_temporary(TYPE_INT);
{
compvar_t *tmp_491, *tmp_492;
tmp_491 = make_temporary(TYPE_INT);
{
compvar_t *tmp_493, *tmp_494;
tmp_493 = make_temporary(TYPE_INT);
{
compvar_t *tmp_495, *tmp_496;
tmp_495 = make_temporary(TYPE_INT);
{
compvar_t *tmp_497, *tmp_498;
tmp_497 = args[0][0];
tmp_498 = args[0][4];
emit_assign(make_lhs(tmp_495), make_op_rhs(OP_MUL, make_compvar_primary(tmp_497), make_compvar_primary(tmp_498)));
}
tmp_496 = args[0][8];
emit_assign(make_lhs(tmp_493), make_op_rhs(OP_MUL, make_compvar_primary(tmp_495), make_compvar_primary(tmp_496)));
}
tmp_494 = make_temporary(TYPE_INT);
{
compvar_t *tmp_499, *tmp_500;
tmp_499 = make_temporary(TYPE_INT);
{
compvar_t *tmp_501, *tmp_502;
tmp_501 = args[0][1];
tmp_502 = args[0][5];
emit_assign(make_lhs(tmp_499), make_op_rhs(OP_MUL, make_compvar_primary(tmp_501), make_compvar_primary(tmp_502)));
}
tmp_500 = args[0][6];
emit_assign(make_lhs(tmp_494), make_op_rhs(OP_MUL, make_compvar_primary(tmp_499), make_compvar_primary(tmp_500)));
}
emit_assign(make_lhs(tmp_491), make_op_rhs(OP_ADD, make_compvar_primary(tmp_493), make_compvar_primary(tmp_494)));
}
tmp_492 = make_temporary(TYPE_INT);
{
compvar_t *tmp_503, *tmp_504;
tmp_503 = make_temporary(TYPE_INT);
{
compvar_t *tmp_505, *tmp_506;
tmp_505 = args[0][2];
tmp_506 = args[0][3];
emit_assign(make_lhs(tmp_503), make_op_rhs(OP_MUL, make_compvar_primary(tmp_505), make_compvar_primary(tmp_506)));
}
tmp_504 = args[0][7];
emit_assign(make_lhs(tmp_492), make_op_rhs(OP_MUL, make_compvar_primary(tmp_503), make_compvar_primary(tmp_504)));
}
emit_assign(make_lhs(tmp_489), make_op_rhs(OP_ADD, make_compvar_primary(tmp_491), make_compvar_primary(tmp_492)));
}
tmp_490 = make_temporary(TYPE_INT);
{
compvar_t *tmp_507, *tmp_508;
tmp_507 = make_temporary(TYPE_INT);
{
compvar_t *tmp_509, *tmp_510;
tmp_509 = make_temporary(TYPE_INT);
{
compvar_t *tmp_511, *tmp_512;
tmp_511 = make_temporary(TYPE_INT);
{
compvar_t *tmp_513, *tmp_514;
tmp_513 = args[0][2];
tmp_514 = args[0][4];
emit_assign(make_lhs(tmp_511), make_op_rhs(OP_MUL, make_compvar_primary(tmp_513), make_compvar_primary(tmp_514)));
}
tmp_512 = args[0][6];
emit_assign(make_lhs(tmp_509), make_op_rhs(OP_MUL, make_compvar_primary(tmp_511), make_compvar_primary(tmp_512)));
}
tmp_510 = make_temporary(TYPE_INT);
{
compvar_t *tmp_515, *tmp_516;
tmp_515 = make_temporary(TYPE_INT);
{
compvar_t *tmp_517, *tmp_518;
tmp_517 = args[0][0];
tmp_518 = args[0][5];
emit_assign(make_lhs(tmp_515), make_op_rhs(OP_MUL, make_compvar_primary(tmp_517), make_compvar_primary(tmp_518)));
}
tmp_516 = args[0][7];
emit_assign(make_lhs(tmp_510), make_op_rhs(OP_MUL, make_compvar_primary(tmp_515), make_compvar_primary(tmp_516)));
}
emit_assign(make_lhs(tmp_507), make_op_rhs(OP_ADD, make_compvar_primary(tmp_509), make_compvar_primary(tmp_510)));
}
tmp_508 = make_temporary(TYPE_INT);
{
compvar_t *tmp_519, *tmp_520;
tmp_519 = make_temporary(TYPE_INT);
{
compvar_t *tmp_521, *tmp_522;
tmp_521 = args[0][1];
tmp_522 = args[0][3];
emit_assign(make_lhs(tmp_519), make_op_rhs(OP_MUL, make_compvar_primary(tmp_521), make_compvar_primary(tmp_522)));
}
tmp_520 = args[0][8];
emit_assign(make_lhs(tmp_508), make_op_rhs(OP_MUL, make_compvar_primary(tmp_519), make_compvar_primary(tmp_520)));
}
emit_assign(make_lhs(tmp_490), make_op_rhs(OP_ADD, make_compvar_primary(tmp_507), make_compvar_primary(tmp_508)));
}
emit_assign(make_lhs(result[tmp_488]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_489), make_compvar_primary(tmp_490)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_normalize (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_523;

if (arglengths[0] == 1)
{
tmp_523 = make_temporary(TYPE_INT);
{
compvar_t *tmp_527, *tmp_528;
tmp_527 = args[0][0];
tmp_528 = args[0][0];
emit_assign(make_lhs(tmp_523), make_op_rhs(OP_MUL, make_compvar_primary(tmp_527), make_compvar_primary(tmp_528)));
}

}
else
{
compvar_t *tmp_524, *tmp_525;
int tmp_526;
tmp_523 = make_temporary(TYPE_INT);
tmp_524 = make_temporary(TYPE_INT);
{
compvar_t *tmp_529, *tmp_530;
tmp_529 = args[0][0];
tmp_530 = args[0][0];
emit_assign(make_lhs(tmp_524), make_op_rhs(OP_MUL, make_compvar_primary(tmp_529), make_compvar_primary(tmp_530)));
}
tmp_525 = make_temporary(TYPE_INT);
{
compvar_t *tmp_531, *tmp_532;
tmp_531 = args[0][1];
tmp_532 = args[0][1];
emit_assign(make_lhs(tmp_525), make_op_rhs(OP_MUL, make_compvar_primary(tmp_531), make_compvar_primary(tmp_532)));
}
emit_assign(make_lhs(tmp_523), make_op_rhs(OP_ADD, make_compvar_primary(tmp_524), make_compvar_primary(tmp_525)));
for (tmp_526 = 2; tmp_526 < arglengths[0]; ++tmp_526)
{
tmp_524 = make_temporary(TYPE_INT);
{
compvar_t *tmp_533, *tmp_534;
tmp_533 = args[0][tmp_526];
tmp_534 = args[0][tmp_526];
emit_assign(make_lhs(tmp_524), make_op_rhs(OP_MUL, make_compvar_primary(tmp_533), make_compvar_primary(tmp_534)));
}
emit_assign(make_lhs(tmp_523), make_op_rhs(OP_ADD, make_compvar_primary(tmp_523), make_compvar_primary(tmp_524)));
}
}

{
compvar_t *tmp_535;
tmp_535 = make_temporary(TYPE_INT);
{
compvar_t *tmp_536, *tmp_537;
tmp_536 = tmp_523;
tmp_537 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_537), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_535), make_op_rhs(OP_EQ, make_compvar_primary(tmp_536), make_compvar_primary(tmp_537)));
}
start_if_cond(make_compvar_rhs(tmp_535));
{
int tmp_538;
for (tmp_538 = 0; tmp_538 < arglengths[0]; ++tmp_538)
{
emit_assign(make_lhs(result[tmp_538]), make_int_const_rhs(0));
}
}
switch_if_branch();
{
int tmp_539;
for (tmp_539 = 0; tmp_539 < arglengths[0]; ++tmp_539)
{
{
compvar_t *tmp_540, *tmp_541;
tmp_540 = args[0][tmp_539];
tmp_541 = make_temporary(TYPE_INT);
{
compvar_t *tmp_542;
tmp_542 = tmp_523;
emit_assign(make_lhs(tmp_541), make_op_rhs(OP_SQRT, make_compvar_primary(tmp_542)));
}
emit_assign(make_lhs(result[tmp_539]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_540), make_compvar_primary(tmp_541)));
}
}
}
end_if_cond();
}
}
}

static void
gen_abs_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_543;
for (tmp_543 = 0; tmp_543 < 1; ++tmp_543)
{
switch (tmp_543)
{
case 0 :
{
compvar_t *tmp_544, *tmp_545;
tmp_544 = args[0][0];
tmp_545 = args[0][1];
emit_assign(make_lhs(result[tmp_543]), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_544), make_compvar_primary(tmp_545)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_abs_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_546;
for (tmp_546 = 0; tmp_546 < 1; ++tmp_546)
{
{
compvar_t *tmp_547;
tmp_547 = args[0][tmp_546];
emit_assign(make_lhs(result[tmp_546]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_547)));
}
}
}
}

static void
gen_abs_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_548;
for (tmp_548 = 0; tmp_548 < arglengths[0]; ++tmp_548)
{
{
compvar_t *tmp_549;
tmp_549 = args[0][tmp_548];
emit_assign(make_lhs(result[tmp_548]), make_op_rhs(OP_ABS, make_compvar_primary(tmp_549)));
}
}
}
}

static void
gen_deg2rad (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_550;
for (tmp_550 = 0; tmp_550 < 1; ++tmp_550)
{
switch (tmp_550)
{
case 0 :
{
compvar_t *tmp_551, *tmp_552;
tmp_551 = args[0][0];
tmp_552 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_552), make_float_const_rhs(0.017453292));
emit_assign(make_lhs(result[tmp_550]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_551), make_compvar_primary(tmp_552)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_rad2deg (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_553;
for (tmp_553 = 0; tmp_553 < 1; ++tmp_553)
{
switch (tmp_553)
{
case 0 :
{
compvar_t *tmp_554, *tmp_555;
tmp_554 = args[0][0];
tmp_555 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_555), make_float_const_rhs(57.29578));
emit_assign(make_lhs(result[tmp_553]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_554), make_compvar_primary(tmp_555)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_sin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_556;

tmp_556 = make_temporary(TYPE_INT);
{
compvar_t *tmp_557;
tmp_557 = make_temporary(TYPE_INT);
{
compvar_t *tmp_558, *tmp_559;
tmp_558 = args[0][0];
tmp_559 = args[0][1];
emit_assign(make_lhs(tmp_557), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_558), make_compvar_primary(tmp_559)));
}
emit_assign(make_lhs(tmp_556), make_op_rhs(OP_C_SIN, make_compvar_primary(tmp_557)));
}

{
int tmp_560;
for (tmp_560 = 0; tmp_560 < 2; ++tmp_560)
{
switch (tmp_560)
{
case 0 :
{
compvar_t *tmp_561;
tmp_561 = tmp_556;
emit_assign(make_lhs(result[tmp_560]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_561)));
}
break;
case 1 :
{
compvar_t *tmp_562;
tmp_562 = tmp_556;
emit_assign(make_lhs(result[tmp_560]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_562)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_sin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_563;
for (tmp_563 = 0; tmp_563 < 1; ++tmp_563)
{
switch (tmp_563)
{
case 0 :
{
compvar_t *tmp_564;
tmp_564 = args[0][0];
emit_assign(make_lhs(result[tmp_563]), make_op_rhs(OP_SIN, make_compvar_primary(tmp_564)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_cos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_565;

tmp_565 = make_temporary(TYPE_INT);
{
compvar_t *tmp_566;
tmp_566 = make_temporary(TYPE_INT);
{
compvar_t *tmp_567, *tmp_568;
tmp_567 = args[0][0];
tmp_568 = args[0][1];
emit_assign(make_lhs(tmp_566), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_567), make_compvar_primary(tmp_568)));
}
emit_assign(make_lhs(tmp_565), make_op_rhs(OP_C_COS, make_compvar_primary(tmp_566)));
}

{
int tmp_569;
for (tmp_569 = 0; tmp_569 < 2; ++tmp_569)
{
switch (tmp_569)
{
case 0 :
{
compvar_t *tmp_570;
tmp_570 = tmp_565;
emit_assign(make_lhs(result[tmp_569]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_570)));
}
break;
case 1 :
{
compvar_t *tmp_571;
tmp_571 = tmp_565;
emit_assign(make_lhs(result[tmp_569]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_571)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_cos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_572;
for (tmp_572 = 0; tmp_572 < 1; ++tmp_572)
{
switch (tmp_572)
{
case 0 :
{
compvar_t *tmp_573;
tmp_573 = args[0][0];
emit_assign(make_lhs(result[tmp_572]), make_op_rhs(OP_COS, make_compvar_primary(tmp_573)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_tan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_574;

tmp_574 = make_temporary(TYPE_INT);
{
compvar_t *tmp_575;
tmp_575 = make_temporary(TYPE_INT);
{
compvar_t *tmp_576, *tmp_577;
tmp_576 = args[0][0];
tmp_577 = args[0][1];
emit_assign(make_lhs(tmp_575), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_576), make_compvar_primary(tmp_577)));
}
emit_assign(make_lhs(tmp_574), make_op_rhs(OP_C_TAN, make_compvar_primary(tmp_575)));
}

{
int tmp_578;
for (tmp_578 = 0; tmp_578 < 2; ++tmp_578)
{
switch (tmp_578)
{
case 0 :
{
compvar_t *tmp_579;
tmp_579 = tmp_574;
emit_assign(make_lhs(result[tmp_578]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_579)));
}
break;
case 1 :
{
compvar_t *tmp_580;
tmp_580 = tmp_574;
emit_assign(make_lhs(result[tmp_578]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_580)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_tan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_581;
for (tmp_581 = 0; tmp_581 < 1; ++tmp_581)
{
switch (tmp_581)
{
case 0 :
{
compvar_t *tmp_582;
tmp_582 = args[0][0];
emit_assign(make_lhs(result[tmp_581]), make_op_rhs(OP_TAN, make_compvar_primary(tmp_582)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_asin_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_583;

tmp_583 = make_temporary(TYPE_INT);
{
compvar_t *tmp_584;
tmp_584 = make_temporary(TYPE_INT);
{
compvar_t *tmp_585, *tmp_586;
tmp_585 = args[0][0];
tmp_586 = args[0][1];
emit_assign(make_lhs(tmp_584), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_585), make_compvar_primary(tmp_586)));
}
emit_assign(make_lhs(tmp_583), make_op_rhs(OP_C_ASIN, make_compvar_primary(tmp_584)));
}

{
int tmp_587;
for (tmp_587 = 0; tmp_587 < 2; ++tmp_587)
{
switch (tmp_587)
{
case 0 :
{
compvar_t *tmp_588;
tmp_588 = tmp_583;
emit_assign(make_lhs(result[tmp_587]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_588)));
}
break;
case 1 :
{
compvar_t *tmp_589;
tmp_589 = tmp_583;
emit_assign(make_lhs(result[tmp_587]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_589)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_asin (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_590;
tmp_590 = make_temporary(TYPE_INT);
{
compvar_t *tmp_591, *tmp_592;
tmp_591 = args[0][0];
tmp_592 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_592), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_590), make_op_rhs(OP_LESS, make_compvar_primary(tmp_591), make_compvar_primary(tmp_592)));
}
start_if_cond(make_compvar_rhs(tmp_590));
switch_if_branch();
{
compvar_t *tmp_593, *tmp_594;
tmp_593 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_593), make_int_const_rhs(1));
tmp_594 = args[0][0];
emit_assign(make_lhs(tmp_590), make_op_rhs(OP_LESS, make_compvar_primary(tmp_593), make_compvar_primary(tmp_594)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_590));
{
int tmp_595;
for (tmp_595 = 0; tmp_595 < 1; ++tmp_595)
{
switch (tmp_595)
{
case 0 :
emit_assign(make_lhs(result[tmp_595]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_596;
for (tmp_596 = 0; tmp_596 < 1; ++tmp_596)
{
switch (tmp_596)
{
case 0 :
{
compvar_t *tmp_597;
tmp_597 = args[0][0];
emit_assign(make_lhs(result[tmp_596]), make_op_rhs(OP_ASIN, make_compvar_primary(tmp_597)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_acos_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_598;

tmp_598 = make_temporary(TYPE_INT);
{
compvar_t *tmp_599;
tmp_599 = make_temporary(TYPE_INT);
{
compvar_t *tmp_600, *tmp_601;
tmp_600 = args[0][0];
tmp_601 = args[0][1];
emit_assign(make_lhs(tmp_599), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_600), make_compvar_primary(tmp_601)));
}
emit_assign(make_lhs(tmp_598), make_op_rhs(OP_C_ACOS, make_compvar_primary(tmp_599)));
}

{
int tmp_602;
for (tmp_602 = 0; tmp_602 < 2; ++tmp_602)
{
switch (tmp_602)
{
case 0 :
{
compvar_t *tmp_603;
tmp_603 = tmp_598;
emit_assign(make_lhs(result[tmp_602]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_603)));
}
break;
case 1 :
{
compvar_t *tmp_604;
tmp_604 = tmp_598;
emit_assign(make_lhs(result[tmp_602]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_604)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_acos (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_605;
tmp_605 = make_temporary(TYPE_INT);
{
compvar_t *tmp_606, *tmp_607;
tmp_606 = args[0][0];
tmp_607 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_607), make_int_const_rhs(-1));
emit_assign(make_lhs(tmp_605), make_op_rhs(OP_LESS, make_compvar_primary(tmp_606), make_compvar_primary(tmp_607)));
}
start_if_cond(make_compvar_rhs(tmp_605));
switch_if_branch();
{
compvar_t *tmp_608, *tmp_609;
tmp_608 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_608), make_int_const_rhs(1));
tmp_609 = args[0][0];
emit_assign(make_lhs(tmp_605), make_op_rhs(OP_LESS, make_compvar_primary(tmp_608), make_compvar_primary(tmp_609)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_605));
{
int tmp_610;
for (tmp_610 = 0; tmp_610 < 1; ++tmp_610)
{
switch (tmp_610)
{
case 0 :
emit_assign(make_lhs(result[tmp_610]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_611;
for (tmp_611 = 0; tmp_611 < 1; ++tmp_611)
{
switch (tmp_611)
{
case 0 :
{
compvar_t *tmp_612;
tmp_612 = args[0][0];
emit_assign(make_lhs(result[tmp_611]), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_612)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_atan_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_613;

tmp_613 = make_temporary(TYPE_INT);
{
compvar_t *tmp_614;
tmp_614 = make_temporary(TYPE_INT);
{
compvar_t *tmp_615, *tmp_616;
tmp_615 = args[0][0];
tmp_616 = args[0][1];
emit_assign(make_lhs(tmp_614), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_615), make_compvar_primary(tmp_616)));
}
emit_assign(make_lhs(tmp_613), make_op_rhs(OP_C_ATAN, make_compvar_primary(tmp_614)));
}

{
int tmp_617;
for (tmp_617 = 0; tmp_617 < 2; ++tmp_617)
{
switch (tmp_617)
{
case 0 :
{
compvar_t *tmp_618;
tmp_618 = tmp_613;
emit_assign(make_lhs(result[tmp_617]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_618)));
}
break;
case 1 :
{
compvar_t *tmp_619;
tmp_619 = tmp_613;
emit_assign(make_lhs(result[tmp_617]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_619)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_atan (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_620;
for (tmp_620 = 0; tmp_620 < 1; ++tmp_620)
{
switch (tmp_620)
{
case 0 :
{
compvar_t *tmp_621;
tmp_621 = args[0][0];
emit_assign(make_lhs(result[tmp_620]), make_op_rhs(OP_ATAN, make_compvar_primary(tmp_621)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_atan2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_622;
for (tmp_622 = 0; tmp_622 < 1; ++tmp_622)
{
switch (tmp_622)
{
case 0 :
{
compvar_t *tmp_623, *tmp_624;
tmp_623 = args[0][0];
tmp_624 = args[1][0];
emit_assign(make_lhs(result[tmp_622]), make_op_rhs(OP_ATAN2, make_compvar_primary(tmp_623), make_compvar_primary(tmp_624)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_pow_ri_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_625;

tmp_625 = make_temporary(TYPE_INT);
{
compvar_t *tmp_626, *tmp_627;
tmp_626 = make_temporary(TYPE_INT);
{
compvar_t *tmp_628, *tmp_629;
tmp_628 = args[0][0];
tmp_629 = args[0][1];
emit_assign(make_lhs(tmp_626), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_628), make_compvar_primary(tmp_629)));
}
tmp_627 = make_temporary(TYPE_INT);
{
compvar_t *tmp_630, *tmp_631;
tmp_630 = args[1][0];
tmp_631 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_631), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_627), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_630), make_compvar_primary(tmp_631)));
}
emit_assign(make_lhs(tmp_625), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_626), make_compvar_primary(tmp_627)));
}

{
int tmp_632;
for (tmp_632 = 0; tmp_632 < 2; ++tmp_632)
{
switch (tmp_632)
{
case 0 :
{
compvar_t *tmp_633;
tmp_633 = tmp_625;
emit_assign(make_lhs(result[tmp_632]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_633)));
}
break;
case 1 :
{
compvar_t *tmp_634;
tmp_634 = tmp_625;
emit_assign(make_lhs(result[tmp_632]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_634)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_pow_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_635;

tmp_635 = make_temporary(TYPE_INT);
{
compvar_t *tmp_636, *tmp_637;
tmp_636 = make_temporary(TYPE_INT);
{
compvar_t *tmp_638, *tmp_639;
tmp_638 = args[0][0];
tmp_639 = args[0][1];
emit_assign(make_lhs(tmp_636), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_638), make_compvar_primary(tmp_639)));
}
tmp_637 = make_temporary(TYPE_INT);
{
compvar_t *tmp_640, *tmp_641;
tmp_640 = args[1][0];
tmp_641 = args[1][1];
emit_assign(make_lhs(tmp_637), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_640), make_compvar_primary(tmp_641)));
}
emit_assign(make_lhs(tmp_635), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_636), make_compvar_primary(tmp_637)));
}

{
int tmp_642;
for (tmp_642 = 0; tmp_642 < 2; ++tmp_642)
{
switch (tmp_642)
{
case 0 :
{
compvar_t *tmp_643;
tmp_643 = tmp_635;
emit_assign(make_lhs(result[tmp_642]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_643)));
}
break;
case 1 :
{
compvar_t *tmp_644;
tmp_644 = tmp_635;
emit_assign(make_lhs(result[tmp_642]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_644)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_pow_1_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_645;

tmp_645 = make_temporary(TYPE_INT);
{
compvar_t *tmp_646, *tmp_647;
tmp_646 = make_temporary(TYPE_INT);
{
compvar_t *tmp_648, *tmp_649;
tmp_648 = args[0][0];
tmp_649 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_649), make_float_const_rhs(0.0));
emit_assign(make_lhs(tmp_646), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_648), make_compvar_primary(tmp_649)));
}
tmp_647 = make_temporary(TYPE_INT);
{
compvar_t *tmp_650, *tmp_651;
tmp_650 = args[1][0];
tmp_651 = args[1][1];
emit_assign(make_lhs(tmp_647), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_650), make_compvar_primary(tmp_651)));
}
emit_assign(make_lhs(tmp_645), make_op_rhs(OP_C_POW, make_compvar_primary(tmp_646), make_compvar_primary(tmp_647)));
}

{
int tmp_652;
for (tmp_652 = 0; tmp_652 < 2; ++tmp_652)
{
switch (tmp_652)
{
case 0 :
{
compvar_t *tmp_653;
tmp_653 = tmp_645;
emit_assign(make_lhs(result[tmp_652]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_653)));
}
break;
case 1 :
{
compvar_t *tmp_654;
tmp_654 = tmp_645;
emit_assign(make_lhs(result[tmp_652]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_654)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_pow_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_655;
tmp_655 = make_temporary(TYPE_INT);
{
compvar_t *tmp_656, *tmp_657;
tmp_656 = args[1][0];
tmp_657 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_657), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_655), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_656), make_compvar_primary(tmp_657)));
}
start_if_cond(make_compvar_rhs(tmp_655));
{
compvar_t *tmp_658, *tmp_659;
tmp_658 = args[0][0];
tmp_659 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_659), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_655), make_op_rhs(OP_EQ, make_compvar_primary(tmp_658), make_compvar_primary(tmp_659)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_655));
{
int tmp_660;
for (tmp_660 = 0; tmp_660 < 1; ++tmp_660)
{
switch (tmp_660)
{
case 0 :
emit_assign(make_lhs(result[tmp_660]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_661;
for (tmp_661 = 0; tmp_661 < 1; ++tmp_661)
{
switch (tmp_661)
{
case 0 :
{
compvar_t *tmp_662, *tmp_663;
tmp_662 = args[0][0];
tmp_663 = args[1][0];
emit_assign(make_lhs(result[tmp_661]), make_op_rhs(OP_POW, make_compvar_primary(tmp_662), make_compvar_primary(tmp_663)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_pow_s (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_664;
for (tmp_664 = 0; tmp_664 < arglengths[0]; ++tmp_664)
{
{
compvar_t *tmp_665;
tmp_665 = make_temporary(TYPE_INT);
{
compvar_t *tmp_666, *tmp_667;
tmp_666 = args[1][0];
tmp_667 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_667), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_665), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_666), make_compvar_primary(tmp_667)));
}
start_if_cond(make_compvar_rhs(tmp_665));
{
compvar_t *tmp_668, *tmp_669;
tmp_668 = args[0][tmp_664];
tmp_669 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_669), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_665), make_op_rhs(OP_EQ, make_compvar_primary(tmp_668), make_compvar_primary(tmp_669)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_665));
emit_assign(make_lhs(result[tmp_664]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_670, *tmp_671;
tmp_670 = args[0][tmp_664];
tmp_671 = args[1][0];
emit_assign(make_lhs(result[tmp_664]), make_op_rhs(OP_POW, make_compvar_primary(tmp_670), make_compvar_primary(tmp_671)));
}
end_if_cond();
}
}
}
}

static void
gen_exp_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_672;

tmp_672 = make_temporary(TYPE_INT);
{
compvar_t *tmp_673;
tmp_673 = make_temporary(TYPE_INT);
{
compvar_t *tmp_674, *tmp_675;
tmp_674 = args[0][0];
tmp_675 = args[0][1];
emit_assign(make_lhs(tmp_673), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_674), make_compvar_primary(tmp_675)));
}
emit_assign(make_lhs(tmp_672), make_op_rhs(OP_C_EXP, make_compvar_primary(tmp_673)));
}

{
int tmp_676;
for (tmp_676 = 0; tmp_676 < 2; ++tmp_676)
{
switch (tmp_676)
{
case 0 :
{
compvar_t *tmp_677;
tmp_677 = tmp_672;
emit_assign(make_lhs(result[tmp_676]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_677)));
}
break;
case 1 :
{
compvar_t *tmp_678;
tmp_678 = tmp_672;
emit_assign(make_lhs(result[tmp_676]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_678)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_exp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_679;
for (tmp_679 = 0; tmp_679 < 1; ++tmp_679)
{
switch (tmp_679)
{
case 0 :
{
compvar_t *tmp_680;
tmp_680 = args[0][0];
emit_assign(make_lhs(result[tmp_679]), make_op_rhs(OP_EXP, make_compvar_primary(tmp_680)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_log_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_681;

tmp_681 = make_temporary(TYPE_INT);
{
compvar_t *tmp_682;
tmp_682 = make_temporary(TYPE_INT);
{
compvar_t *tmp_683, *tmp_684;
tmp_683 = args[0][0];
tmp_684 = args[0][1];
emit_assign(make_lhs(tmp_682), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_683), make_compvar_primary(tmp_684)));
}
emit_assign(make_lhs(tmp_681), make_op_rhs(OP_C_LOG, make_compvar_primary(tmp_682)));
}

{
int tmp_685;
for (tmp_685 = 0; tmp_685 < 2; ++tmp_685)
{
switch (tmp_685)
{
case 0 :
{
compvar_t *tmp_686;
tmp_686 = tmp_681;
emit_assign(make_lhs(result[tmp_685]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_686)));
}
break;
case 1 :
{
compvar_t *tmp_687;
tmp_687 = tmp_681;
emit_assign(make_lhs(result[tmp_685]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_687)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_log_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_688;
tmp_688 = make_temporary(TYPE_INT);
{
compvar_t *tmp_689, *tmp_690;
tmp_689 = args[0][0];
tmp_690 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_690), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_688), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_689), make_compvar_primary(tmp_690)));
}
start_if_cond(make_compvar_rhs(tmp_688));
{
int tmp_691;
for (tmp_691 = 0; tmp_691 < 1; ++tmp_691)
{
switch (tmp_691)
{
case 0 :
emit_assign(make_lhs(result[tmp_691]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_692;
for (tmp_692 = 0; tmp_692 < 1; ++tmp_692)
{
switch (tmp_692)
{
case 0 :
{
compvar_t *tmp_693;
tmp_693 = args[0][0];
emit_assign(make_lhs(result[tmp_692]), make_op_rhs(OP_LOG, make_compvar_primary(tmp_693)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_arg_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_694;
for (tmp_694 = 0; tmp_694 < 1; ++tmp_694)
{
switch (tmp_694)
{
case 0 :
{
compvar_t *tmp_695;
tmp_695 = make_temporary(TYPE_INT);
{
compvar_t *tmp_696, *tmp_697;
tmp_696 = args[0][0];
tmp_697 = args[0][1];
emit_assign(make_lhs(tmp_695), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_696), make_compvar_primary(tmp_697)));
}
emit_assign(make_lhs(result[tmp_694]), make_op_rhs(OP_C_ARG, make_compvar_primary(tmp_695)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_conj_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_698;
for (tmp_698 = 0; tmp_698 < 2; ++tmp_698)
{
switch (tmp_698)
{
case 0 :
emit_assign(make_lhs(result[tmp_698]), make_compvar_rhs(args[0][0]));
break;
case 1 :
{
compvar_t *tmp_699;
tmp_699 = args[0][1];
emit_assign(make_lhs(result[tmp_698]), make_op_rhs(OP_NEG, make_compvar_primary(tmp_699)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_sinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_700;

tmp_700 = make_temporary(TYPE_INT);
{
compvar_t *tmp_701;
tmp_701 = make_temporary(TYPE_INT);
{
compvar_t *tmp_702, *tmp_703;
tmp_702 = args[0][0];
tmp_703 = args[0][1];
emit_assign(make_lhs(tmp_701), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_702), make_compvar_primary(tmp_703)));
}
emit_assign(make_lhs(tmp_700), make_op_rhs(OP_C_SINH, make_compvar_primary(tmp_701)));
}

{
int tmp_704;
for (tmp_704 = 0; tmp_704 < 2; ++tmp_704)
{
switch (tmp_704)
{
case 0 :
{
compvar_t *tmp_705;
tmp_705 = tmp_700;
emit_assign(make_lhs(result[tmp_704]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_705)));
}
break;
case 1 :
{
compvar_t *tmp_706;
tmp_706 = tmp_700;
emit_assign(make_lhs(result[tmp_704]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_706)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_sinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_707;
for (tmp_707 = 0; tmp_707 < 1; ++tmp_707)
{
switch (tmp_707)
{
case 0 :
{
compvar_t *tmp_708;
tmp_708 = args[0][0];
emit_assign(make_lhs(result[tmp_707]), make_op_rhs(OP_SINH, make_compvar_primary(tmp_708)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_cosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_709;

tmp_709 = make_temporary(TYPE_INT);
{
compvar_t *tmp_710;
tmp_710 = make_temporary(TYPE_INT);
{
compvar_t *tmp_711, *tmp_712;
tmp_711 = args[0][0];
tmp_712 = args[0][1];
emit_assign(make_lhs(tmp_710), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_711), make_compvar_primary(tmp_712)));
}
emit_assign(make_lhs(tmp_709), make_op_rhs(OP_C_COSH, make_compvar_primary(tmp_710)));
}

{
int tmp_713;
for (tmp_713 = 0; tmp_713 < 2; ++tmp_713)
{
switch (tmp_713)
{
case 0 :
{
compvar_t *tmp_714;
tmp_714 = tmp_709;
emit_assign(make_lhs(result[tmp_713]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_714)));
}
break;
case 1 :
{
compvar_t *tmp_715;
tmp_715 = tmp_709;
emit_assign(make_lhs(result[tmp_713]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_715)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_cosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_716;
for (tmp_716 = 0; tmp_716 < 1; ++tmp_716)
{
switch (tmp_716)
{
case 0 :
{
compvar_t *tmp_717;
tmp_717 = args[0][0];
emit_assign(make_lhs(result[tmp_716]), make_op_rhs(OP_COSH, make_compvar_primary(tmp_717)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_tanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_718;

tmp_718 = make_temporary(TYPE_INT);
{
compvar_t *tmp_719;
tmp_719 = make_temporary(TYPE_INT);
{
compvar_t *tmp_720, *tmp_721;
tmp_720 = args[0][0];
tmp_721 = args[0][1];
emit_assign(make_lhs(tmp_719), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_720), make_compvar_primary(tmp_721)));
}
emit_assign(make_lhs(tmp_718), make_op_rhs(OP_C_TANH, make_compvar_primary(tmp_719)));
}

{
int tmp_722;
for (tmp_722 = 0; tmp_722 < 2; ++tmp_722)
{
switch (tmp_722)
{
case 0 :
{
compvar_t *tmp_723;
tmp_723 = tmp_718;
emit_assign(make_lhs(result[tmp_722]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_723)));
}
break;
case 1 :
{
compvar_t *tmp_724;
tmp_724 = tmp_718;
emit_assign(make_lhs(result[tmp_722]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_724)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_tanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_725;
for (tmp_725 = 0; tmp_725 < 1; ++tmp_725)
{
switch (tmp_725)
{
case 0 :
{
compvar_t *tmp_726;
tmp_726 = args[0][0];
emit_assign(make_lhs(result[tmp_725]), make_op_rhs(OP_TANH, make_compvar_primary(tmp_726)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_asinh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_727;

tmp_727 = make_temporary(TYPE_INT);
{
compvar_t *tmp_728;
tmp_728 = make_temporary(TYPE_INT);
{
compvar_t *tmp_729, *tmp_730;
tmp_729 = args[0][0];
tmp_730 = args[0][1];
emit_assign(make_lhs(tmp_728), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_729), make_compvar_primary(tmp_730)));
}
emit_assign(make_lhs(tmp_727), make_op_rhs(OP_C_ASINH, make_compvar_primary(tmp_728)));
}

{
int tmp_731;
for (tmp_731 = 0; tmp_731 < 2; ++tmp_731)
{
switch (tmp_731)
{
case 0 :
{
compvar_t *tmp_732;
tmp_732 = tmp_727;
emit_assign(make_lhs(result[tmp_731]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_732)));
}
break;
case 1 :
{
compvar_t *tmp_733;
tmp_733 = tmp_727;
emit_assign(make_lhs(result[tmp_731]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_733)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_asinh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_734;
for (tmp_734 = 0; tmp_734 < 1; ++tmp_734)
{
switch (tmp_734)
{
case 0 :
{
compvar_t *tmp_735;
tmp_735 = args[0][0];
emit_assign(make_lhs(result[tmp_734]), make_op_rhs(OP_ASINH, make_compvar_primary(tmp_735)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_acosh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_736;

tmp_736 = make_temporary(TYPE_INT);
{
compvar_t *tmp_737;
tmp_737 = make_temporary(TYPE_INT);
{
compvar_t *tmp_738, *tmp_739;
tmp_738 = args[0][0];
tmp_739 = args[0][1];
emit_assign(make_lhs(tmp_737), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_738), make_compvar_primary(tmp_739)));
}
emit_assign(make_lhs(tmp_736), make_op_rhs(OP_C_ACOSH, make_compvar_primary(tmp_737)));
}

{
int tmp_740;
for (tmp_740 = 0; tmp_740 < 2; ++tmp_740)
{
switch (tmp_740)
{
case 0 :
{
compvar_t *tmp_741;
tmp_741 = tmp_736;
emit_assign(make_lhs(result[tmp_740]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_741)));
}
break;
case 1 :
{
compvar_t *tmp_742;
tmp_742 = tmp_736;
emit_assign(make_lhs(result[tmp_740]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_742)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_acosh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_743;
for (tmp_743 = 0; tmp_743 < 1; ++tmp_743)
{
switch (tmp_743)
{
case 0 :
{
compvar_t *tmp_744;
tmp_744 = args[0][0];
emit_assign(make_lhs(result[tmp_743]), make_op_rhs(OP_ACOSH, make_compvar_primary(tmp_744)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_atanh_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_745;

tmp_745 = make_temporary(TYPE_INT);
{
compvar_t *tmp_746;
tmp_746 = make_temporary(TYPE_INT);
{
compvar_t *tmp_747, *tmp_748;
tmp_747 = args[0][0];
tmp_748 = args[0][1];
emit_assign(make_lhs(tmp_746), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_747), make_compvar_primary(tmp_748)));
}
emit_assign(make_lhs(tmp_745), make_op_rhs(OP_C_ATANH, make_compvar_primary(tmp_746)));
}

{
int tmp_749;
for (tmp_749 = 0; tmp_749 < 2; ++tmp_749)
{
switch (tmp_749)
{
case 0 :
{
compvar_t *tmp_750;
tmp_750 = tmp_745;
emit_assign(make_lhs(result[tmp_749]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_750)));
}
break;
case 1 :
{
compvar_t *tmp_751;
tmp_751 = tmp_745;
emit_assign(make_lhs(result[tmp_749]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_751)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_atanh_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_752;
for (tmp_752 = 0; tmp_752 < 1; ++tmp_752)
{
switch (tmp_752)
{
case 0 :
{
compvar_t *tmp_753;
tmp_753 = args[0][0];
emit_assign(make_lhs(result[tmp_752]), make_op_rhs(OP_ATANH, make_compvar_primary(tmp_753)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_gamma_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_754;

tmp_754 = make_temporary(TYPE_INT);
{
compvar_t *tmp_755;
tmp_755 = make_temporary(TYPE_INT);
{
compvar_t *tmp_756, *tmp_757;
tmp_756 = args[0][0];
tmp_757 = args[0][1];
emit_assign(make_lhs(tmp_755), make_op_rhs(OP_COMPLEX, make_compvar_primary(tmp_756), make_compvar_primary(tmp_757)));
}
emit_assign(make_lhs(tmp_754), make_op_rhs(OP_C_GAMMA, make_compvar_primary(tmp_755)));
}

{
int tmp_758;
for (tmp_758 = 0; tmp_758 < 2; ++tmp_758)
{
switch (tmp_758)
{
case 0 :
{
compvar_t *tmp_759;
tmp_759 = tmp_754;
emit_assign(make_lhs(result[tmp_758]), make_op_rhs(OP_C_REAL, make_compvar_primary(tmp_759)));
}
break;
case 1 :
{
compvar_t *tmp_760;
tmp_760 = tmp_754;
emit_assign(make_lhs(result[tmp_758]), make_op_rhs(OP_C_IMAG, make_compvar_primary(tmp_760)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_gamma_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_761;
tmp_761 = make_temporary(TYPE_INT);
{
compvar_t *tmp_762, *tmp_763;
tmp_762 = args[0][0];
tmp_763 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_763), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_761), make_op_rhs(OP_LESS, make_compvar_primary(tmp_762), make_compvar_primary(tmp_763)));
}
start_if_cond(make_compvar_rhs(tmp_761));
{
int tmp_764;
for (tmp_764 = 0; tmp_764 < 1; ++tmp_764)
{
switch (tmp_764)
{
case 0 :
emit_assign(make_lhs(result[tmp_764]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_765;
for (tmp_765 = 0; tmp_765 < 1; ++tmp_765)
{
switch (tmp_765)
{
case 0 :
{
compvar_t *tmp_766;
tmp_766 = args[0][0];
emit_assign(make_lhs(result[tmp_765]), make_op_rhs(OP_GAMMA, make_compvar_primary(tmp_766)));
}
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_ell_int_kcomp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_767;
for (tmp_767 = 0; tmp_767 < 1; ++tmp_767)
{
switch (tmp_767)
{
case 0 :
{
compvar_t *tmp_768;
tmp_768 = args[0][0];
emit_assign(make_lhs(result[tmp_767]), make_op_rhs(OP_ELL_INT_K_COMP, make_compvar_primary(tmp_768)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_ecomp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_769;
for (tmp_769 = 0; tmp_769 < 1; ++tmp_769)
{
switch (tmp_769)
{
case 0 :
{
compvar_t *tmp_770;
tmp_770 = args[0][0];
emit_assign(make_lhs(result[tmp_769]), make_op_rhs(OP_ELL_INT_E_COMP, make_compvar_primary(tmp_770)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_f (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_771;
for (tmp_771 = 0; tmp_771 < 1; ++tmp_771)
{
switch (tmp_771)
{
case 0 :
{
compvar_t *tmp_772, *tmp_773;
tmp_772 = args[0][0];
tmp_773 = args[1][0];
emit_assign(make_lhs(result[tmp_771]), make_op_rhs(OP_ELL_INT_F, make_compvar_primary(tmp_772), make_compvar_primary(tmp_773)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_e (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_774;
for (tmp_774 = 0; tmp_774 < 1; ++tmp_774)
{
switch (tmp_774)
{
case 0 :
{
compvar_t *tmp_775, *tmp_776;
tmp_775 = args[0][0];
tmp_776 = args[1][0];
emit_assign(make_lhs(result[tmp_774]), make_op_rhs(OP_ELL_INT_E, make_compvar_primary(tmp_775), make_compvar_primary(tmp_776)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_p (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_777;
for (tmp_777 = 0; tmp_777 < 1; ++tmp_777)
{
switch (tmp_777)
{
case 0 :
{
compvar_t *tmp_778, *tmp_779, *tmp_780;
tmp_778 = args[0][0];
tmp_779 = args[1][0];
tmp_780 = args[2][0];
emit_assign(make_lhs(result[tmp_777]), make_op_rhs(OP_ELL_INT_P, make_compvar_primary(tmp_778), make_compvar_primary(tmp_779), make_compvar_primary(tmp_780)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_d (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_781;
for (tmp_781 = 0; tmp_781 < 1; ++tmp_781)
{
switch (tmp_781)
{
case 0 :
{
compvar_t *tmp_782, *tmp_783, *tmp_784;
tmp_782 = args[0][0];
tmp_783 = args[1][0];
tmp_784 = args[2][0];
emit_assign(make_lhs(result[tmp_781]), make_op_rhs(OP_ELL_INT_D, make_compvar_primary(tmp_782), make_compvar_primary(tmp_783), make_compvar_primary(tmp_784)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_rc (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_785;
for (tmp_785 = 0; tmp_785 < 1; ++tmp_785)
{
switch (tmp_785)
{
case 0 :
{
compvar_t *tmp_786, *tmp_787;
tmp_786 = args[0][0];
tmp_787 = args[1][0];
emit_assign(make_lhs(result[tmp_785]), make_op_rhs(OP_ELL_INT_RC, make_compvar_primary(tmp_786), make_compvar_primary(tmp_787)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_rd (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_788;
for (tmp_788 = 0; tmp_788 < 1; ++tmp_788)
{
switch (tmp_788)
{
case 0 :
{
compvar_t *tmp_789, *tmp_790, *tmp_791;
tmp_789 = args[0][0];
tmp_790 = args[1][0];
tmp_791 = args[2][0];
emit_assign(make_lhs(result[tmp_788]), make_op_rhs(OP_ELL_INT_RD, make_compvar_primary(tmp_789), make_compvar_primary(tmp_790), make_compvar_primary(tmp_791)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_rf (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_792;
for (tmp_792 = 0; tmp_792 < 1; ++tmp_792)
{
switch (tmp_792)
{
case 0 :
{
compvar_t *tmp_793, *tmp_794, *tmp_795;
tmp_793 = args[0][0];
tmp_794 = args[1][0];
tmp_795 = args[2][0];
emit_assign(make_lhs(result[tmp_792]), make_op_rhs(OP_ELL_INT_RF, make_compvar_primary(tmp_793), make_compvar_primary(tmp_794), make_compvar_primary(tmp_795)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_int_rj (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_796;
for (tmp_796 = 0; tmp_796 < 1; ++tmp_796)
{
switch (tmp_796)
{
case 0 :
{
compvar_t *tmp_797, *tmp_798, *tmp_799, *tmp_800;
tmp_797 = args[0][0];
tmp_798 = args[1][0];
tmp_799 = args[2][0];
tmp_800 = args[3][0];
emit_assign(make_lhs(result[tmp_796]), make_op_rhs(OP_ELL_INT_RJ, make_compvar_primary(tmp_797), make_compvar_primary(tmp_798), make_compvar_primary(tmp_799), make_compvar_primary(tmp_800)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ell_jac_sn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_801;

tmp_801 = make_temporary(TYPE_INT);
{
compvar_t *tmp_802, *tmp_803;
tmp_802 = args[0][0];
tmp_803 = args[1][0];
emit_assign(make_lhs(tmp_801), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_802), make_compvar_primary(tmp_803)));
}

{
int tmp_804;
for (tmp_804 = 0; tmp_804 < 1; ++tmp_804)
{
switch (tmp_804)
{
case 0 :
{
compvar_t *tmp_805, *tmp_806;
tmp_805 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_805), make_int_const_rhs(0));
tmp_806 = tmp_801;
emit_assign(make_lhs(result[tmp_804]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_805), make_compvar_primary(tmp_806)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_ell_jac_cn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_807;

tmp_807 = make_temporary(TYPE_INT);
{
compvar_t *tmp_808, *tmp_809;
tmp_808 = args[0][0];
tmp_809 = args[1][0];
emit_assign(make_lhs(tmp_807), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_808), make_compvar_primary(tmp_809)));
}

{
int tmp_810;
for (tmp_810 = 0; tmp_810 < 1; ++tmp_810)
{
switch (tmp_810)
{
case 0 :
{
compvar_t *tmp_811, *tmp_812;
tmp_811 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_811), make_int_const_rhs(1));
tmp_812 = tmp_807;
emit_assign(make_lhs(result[tmp_810]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_811), make_compvar_primary(tmp_812)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_ell_jac_dn_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_813;

tmp_813 = make_temporary(TYPE_INT);
{
compvar_t *tmp_814, *tmp_815;
tmp_814 = args[0][0];
tmp_815 = args[1][0];
emit_assign(make_lhs(tmp_813), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_814), make_compvar_primary(tmp_815)));
}

{
int tmp_816;
for (tmp_816 = 0; tmp_816 < 1; ++tmp_816)
{
switch (tmp_816)
{
case 0 :
{
compvar_t *tmp_817, *tmp_818;
tmp_817 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_817), make_int_const_rhs(2));
tmp_818 = tmp_813;
emit_assign(make_lhs(result[tmp_816]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_817), make_compvar_primary(tmp_818)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_ell_jac_sn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_819;
compvar_t *tmp_822;

tmp_819 = make_temporary(TYPE_INT);
{
compvar_t *tmp_820, *tmp_821;
tmp_820 = args[0][0];
tmp_821 = args[1][0];
emit_assign(make_lhs(tmp_819), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_820), make_compvar_primary(tmp_821)));
}

tmp_822 = make_temporary(TYPE_INT);
{
compvar_t *tmp_823, *tmp_824;
tmp_823 = args[0][1];
tmp_824 = make_temporary(TYPE_INT);
{
compvar_t *tmp_825, *tmp_826;
tmp_825 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_825), make_int_const_rhs(1));
tmp_826 = args[1][0];
emit_assign(make_lhs(tmp_824), make_op_rhs(OP_SUB, make_compvar_primary(tmp_825), make_compvar_primary(tmp_826)));
}
emit_assign(make_lhs(tmp_822), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_823), make_compvar_primary(tmp_824)));
}

{
compvar_t *tmp_827;
compvar_t *tmp_830;
compvar_t *tmp_833;
compvar_t *tmp_836;
compvar_t *tmp_839;
compvar_t *tmp_842;

tmp_827 = make_temporary(TYPE_INT);
{
compvar_t *tmp_828, *tmp_829;
tmp_828 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_828), make_int_const_rhs(0));
tmp_829 = tmp_819;
emit_assign(make_lhs(tmp_827), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_828), make_compvar_primary(tmp_829)));
}

tmp_830 = make_temporary(TYPE_INT);
{
compvar_t *tmp_831, *tmp_832;
tmp_831 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_831), make_int_const_rhs(1));
tmp_832 = tmp_819;
emit_assign(make_lhs(tmp_830), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_831), make_compvar_primary(tmp_832)));
}

tmp_833 = make_temporary(TYPE_INT);
{
compvar_t *tmp_834, *tmp_835;
tmp_834 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_834), make_int_const_rhs(2));
tmp_835 = tmp_819;
emit_assign(make_lhs(tmp_833), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_834), make_compvar_primary(tmp_835)));
}

tmp_836 = make_temporary(TYPE_INT);
{
compvar_t *tmp_837, *tmp_838;
tmp_837 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_837), make_int_const_rhs(0));
tmp_838 = tmp_822;
emit_assign(make_lhs(tmp_836), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_837), make_compvar_primary(tmp_838)));
}

tmp_839 = make_temporary(TYPE_INT);
{
compvar_t *tmp_840, *tmp_841;
tmp_840 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_840), make_int_const_rhs(1));
tmp_841 = tmp_822;
emit_assign(make_lhs(tmp_839), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_840), make_compvar_primary(tmp_841)));
}

tmp_842 = make_temporary(TYPE_INT);
{
compvar_t *tmp_843, *tmp_844;
tmp_843 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_843), make_int_const_rhs(2));
tmp_844 = tmp_822;
emit_assign(make_lhs(tmp_842), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_843), make_compvar_primary(tmp_844)));
}

{
compvar_t *tmp_845;

tmp_845 = make_temporary(TYPE_INT);
{
compvar_t *tmp_846, *tmp_847;
tmp_846 = make_temporary(TYPE_INT);
{
compvar_t *tmp_848, *tmp_849;
tmp_848 = tmp_839;
tmp_849 = tmp_839;
emit_assign(make_lhs(tmp_846), make_op_rhs(OP_MUL, make_compvar_primary(tmp_848), make_compvar_primary(tmp_849)));
}
tmp_847 = make_temporary(TYPE_INT);
{
compvar_t *tmp_850, *tmp_851;
tmp_850 = args[1][0];
tmp_851 = make_temporary(TYPE_INT);
{
compvar_t *tmp_852, *tmp_853;
tmp_852 = make_temporary(TYPE_INT);
{
compvar_t *tmp_854, *tmp_855;
tmp_854 = tmp_827;
tmp_855 = tmp_827;
emit_assign(make_lhs(tmp_852), make_op_rhs(OP_MUL, make_compvar_primary(tmp_854), make_compvar_primary(tmp_855)));
}
tmp_853 = make_temporary(TYPE_INT);
{
compvar_t *tmp_856, *tmp_857;
tmp_856 = tmp_836;
tmp_857 = tmp_836;
emit_assign(make_lhs(tmp_853), make_op_rhs(OP_MUL, make_compvar_primary(tmp_856), make_compvar_primary(tmp_857)));
}
emit_assign(make_lhs(tmp_851), make_op_rhs(OP_MUL, make_compvar_primary(tmp_852), make_compvar_primary(tmp_853)));
}
emit_assign(make_lhs(tmp_847), make_op_rhs(OP_MUL, make_compvar_primary(tmp_850), make_compvar_primary(tmp_851)));
}
emit_assign(make_lhs(tmp_845), make_op_rhs(OP_ADD, make_compvar_primary(tmp_846), make_compvar_primary(tmp_847)));
}

{
compvar_t *tmp_858, *tmp_859;
tmp_858 = make_temporary(TYPE_INT);
{
compvar_t *tmp_860, *tmp_861;
tmp_860 = tmp_827;
tmp_861 = tmp_842;
emit_assign(make_lhs(tmp_858), make_op_rhs(OP_MUL, make_compvar_primary(tmp_860), make_compvar_primary(tmp_861)));
}
tmp_859 = tmp_845;
emit_assign(make_lhs(result[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_858), make_compvar_primary(tmp_859)));
}
{
compvar_t *tmp_862, *tmp_863;
tmp_862 = make_temporary(TYPE_INT);
{
compvar_t *tmp_864, *tmp_865;
tmp_864 = make_temporary(TYPE_INT);
{
compvar_t *tmp_866, *tmp_867;
tmp_866 = tmp_830;
tmp_867 = tmp_833;
emit_assign(make_lhs(tmp_864), make_op_rhs(OP_MUL, make_compvar_primary(tmp_866), make_compvar_primary(tmp_867)));
}
tmp_865 = make_temporary(TYPE_INT);
{
compvar_t *tmp_868, *tmp_869;
tmp_868 = tmp_836;
tmp_869 = tmp_839;
emit_assign(make_lhs(tmp_865), make_op_rhs(OP_MUL, make_compvar_primary(tmp_868), make_compvar_primary(tmp_869)));
}
emit_assign(make_lhs(tmp_862), make_op_rhs(OP_MUL, make_compvar_primary(tmp_864), make_compvar_primary(tmp_865)));
}
tmp_863 = tmp_845;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_862), make_compvar_primary(tmp_863)));
}
}
}
}
}

static void
gen_ell_jac_cn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_870;
compvar_t *tmp_873;

tmp_870 = make_temporary(TYPE_INT);
{
compvar_t *tmp_871, *tmp_872;
tmp_871 = args[0][0];
tmp_872 = args[1][0];
emit_assign(make_lhs(tmp_870), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_871), make_compvar_primary(tmp_872)));
}

tmp_873 = make_temporary(TYPE_INT);
{
compvar_t *tmp_874, *tmp_875;
tmp_874 = args[0][1];
tmp_875 = make_temporary(TYPE_INT);
{
compvar_t *tmp_876, *tmp_877;
tmp_876 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_876), make_int_const_rhs(1));
tmp_877 = args[1][0];
emit_assign(make_lhs(tmp_875), make_op_rhs(OP_SUB, make_compvar_primary(tmp_876), make_compvar_primary(tmp_877)));
}
emit_assign(make_lhs(tmp_873), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_874), make_compvar_primary(tmp_875)));
}

{
compvar_t *tmp_878;
compvar_t *tmp_881;
compvar_t *tmp_884;
compvar_t *tmp_887;
compvar_t *tmp_890;
compvar_t *tmp_893;

tmp_878 = make_temporary(TYPE_INT);
{
compvar_t *tmp_879, *tmp_880;
tmp_879 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_879), make_int_const_rhs(0));
tmp_880 = tmp_870;
emit_assign(make_lhs(tmp_878), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_879), make_compvar_primary(tmp_880)));
}

tmp_881 = make_temporary(TYPE_INT);
{
compvar_t *tmp_882, *tmp_883;
tmp_882 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_882), make_int_const_rhs(1));
tmp_883 = tmp_870;
emit_assign(make_lhs(tmp_881), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_882), make_compvar_primary(tmp_883)));
}

tmp_884 = make_temporary(TYPE_INT);
{
compvar_t *tmp_885, *tmp_886;
tmp_885 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_885), make_int_const_rhs(2));
tmp_886 = tmp_870;
emit_assign(make_lhs(tmp_884), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_885), make_compvar_primary(tmp_886)));
}

tmp_887 = make_temporary(TYPE_INT);
{
compvar_t *tmp_888, *tmp_889;
tmp_888 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_888), make_int_const_rhs(0));
tmp_889 = tmp_873;
emit_assign(make_lhs(tmp_887), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_888), make_compvar_primary(tmp_889)));
}

tmp_890 = make_temporary(TYPE_INT);
{
compvar_t *tmp_891, *tmp_892;
tmp_891 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_891), make_int_const_rhs(1));
tmp_892 = tmp_873;
emit_assign(make_lhs(tmp_890), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_891), make_compvar_primary(tmp_892)));
}

tmp_893 = make_temporary(TYPE_INT);
{
compvar_t *tmp_894, *tmp_895;
tmp_894 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_894), make_int_const_rhs(2));
tmp_895 = tmp_873;
emit_assign(make_lhs(tmp_893), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_894), make_compvar_primary(tmp_895)));
}

{
compvar_t *tmp_896;

tmp_896 = make_temporary(TYPE_INT);
{
compvar_t *tmp_897, *tmp_898;
tmp_897 = make_temporary(TYPE_INT);
{
compvar_t *tmp_899, *tmp_900;
tmp_899 = tmp_890;
tmp_900 = tmp_890;
emit_assign(make_lhs(tmp_897), make_op_rhs(OP_MUL, make_compvar_primary(tmp_899), make_compvar_primary(tmp_900)));
}
tmp_898 = make_temporary(TYPE_INT);
{
compvar_t *tmp_901, *tmp_902;
tmp_901 = args[1][0];
tmp_902 = make_temporary(TYPE_INT);
{
compvar_t *tmp_903, *tmp_904;
tmp_903 = make_temporary(TYPE_INT);
{
compvar_t *tmp_905, *tmp_906;
tmp_905 = tmp_878;
tmp_906 = tmp_878;
emit_assign(make_lhs(tmp_903), make_op_rhs(OP_MUL, make_compvar_primary(tmp_905), make_compvar_primary(tmp_906)));
}
tmp_904 = make_temporary(TYPE_INT);
{
compvar_t *tmp_907, *tmp_908;
tmp_907 = tmp_887;
tmp_908 = tmp_887;
emit_assign(make_lhs(tmp_904), make_op_rhs(OP_MUL, make_compvar_primary(tmp_907), make_compvar_primary(tmp_908)));
}
emit_assign(make_lhs(tmp_902), make_op_rhs(OP_MUL, make_compvar_primary(tmp_903), make_compvar_primary(tmp_904)));
}
emit_assign(make_lhs(tmp_898), make_op_rhs(OP_MUL, make_compvar_primary(tmp_901), make_compvar_primary(tmp_902)));
}
emit_assign(make_lhs(tmp_896), make_op_rhs(OP_ADD, make_compvar_primary(tmp_897), make_compvar_primary(tmp_898)));
}

{
compvar_t *tmp_909, *tmp_910;
tmp_909 = make_temporary(TYPE_INT);
{
compvar_t *tmp_911, *tmp_912;
tmp_911 = tmp_881;
tmp_912 = tmp_890;
emit_assign(make_lhs(tmp_909), make_op_rhs(OP_MUL, make_compvar_primary(tmp_911), make_compvar_primary(tmp_912)));
}
tmp_910 = tmp_896;
emit_assign(make_lhs(result[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_909), make_compvar_primary(tmp_910)));
}
{
compvar_t *tmp_913, *tmp_914;
tmp_913 = make_temporary(TYPE_INT);
{
compvar_t *tmp_915;
tmp_915 = make_temporary(TYPE_INT);
{
compvar_t *tmp_916, *tmp_917;
tmp_916 = make_temporary(TYPE_INT);
{
compvar_t *tmp_918, *tmp_919;
tmp_918 = tmp_878;
tmp_919 = tmp_884;
emit_assign(make_lhs(tmp_916), make_op_rhs(OP_MUL, make_compvar_primary(tmp_918), make_compvar_primary(tmp_919)));
}
tmp_917 = make_temporary(TYPE_INT);
{
compvar_t *tmp_920, *tmp_921;
tmp_920 = tmp_887;
tmp_921 = tmp_893;
emit_assign(make_lhs(tmp_917), make_op_rhs(OP_MUL, make_compvar_primary(tmp_920), make_compvar_primary(tmp_921)));
}
emit_assign(make_lhs(tmp_915), make_op_rhs(OP_MUL, make_compvar_primary(tmp_916), make_compvar_primary(tmp_917)));
}
emit_assign(make_lhs(tmp_913), make_op_rhs(OP_NEG, make_compvar_primary(tmp_915)));
}
tmp_914 = tmp_896;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_913), make_compvar_primary(tmp_914)));
}
}
}
}
}

static void
gen_ell_jac_dn_ri (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_922;
compvar_t *tmp_925;

tmp_922 = make_temporary(TYPE_INT);
{
compvar_t *tmp_923, *tmp_924;
tmp_923 = args[0][0];
tmp_924 = args[1][0];
emit_assign(make_lhs(tmp_922), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_923), make_compvar_primary(tmp_924)));
}

tmp_925 = make_temporary(TYPE_INT);
{
compvar_t *tmp_926, *tmp_927;
tmp_926 = args[0][1];
tmp_927 = make_temporary(TYPE_INT);
{
compvar_t *tmp_928, *tmp_929;
tmp_928 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_928), make_int_const_rhs(1));
tmp_929 = args[1][0];
emit_assign(make_lhs(tmp_927), make_op_rhs(OP_SUB, make_compvar_primary(tmp_928), make_compvar_primary(tmp_929)));
}
emit_assign(make_lhs(tmp_925), make_op_rhs(OP_ELL_JAC, make_compvar_primary(tmp_926), make_compvar_primary(tmp_927)));
}

{
compvar_t *tmp_930;
compvar_t *tmp_933;
compvar_t *tmp_936;
compvar_t *tmp_939;
compvar_t *tmp_942;
compvar_t *tmp_945;

tmp_930 = make_temporary(TYPE_INT);
{
compvar_t *tmp_931, *tmp_932;
tmp_931 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_931), make_int_const_rhs(0));
tmp_932 = tmp_922;
emit_assign(make_lhs(tmp_930), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_931), make_compvar_primary(tmp_932)));
}

tmp_933 = make_temporary(TYPE_INT);
{
compvar_t *tmp_934, *tmp_935;
tmp_934 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_934), make_int_const_rhs(1));
tmp_935 = tmp_922;
emit_assign(make_lhs(tmp_933), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_934), make_compvar_primary(tmp_935)));
}

tmp_936 = make_temporary(TYPE_INT);
{
compvar_t *tmp_937, *tmp_938;
tmp_937 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_937), make_int_const_rhs(2));
tmp_938 = tmp_922;
emit_assign(make_lhs(tmp_936), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_937), make_compvar_primary(tmp_938)));
}

tmp_939 = make_temporary(TYPE_INT);
{
compvar_t *tmp_940, *tmp_941;
tmp_940 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_940), make_int_const_rhs(0));
tmp_941 = tmp_925;
emit_assign(make_lhs(tmp_939), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_940), make_compvar_primary(tmp_941)));
}

tmp_942 = make_temporary(TYPE_INT);
{
compvar_t *tmp_943, *tmp_944;
tmp_943 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_943), make_int_const_rhs(1));
tmp_944 = tmp_925;
emit_assign(make_lhs(tmp_942), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_943), make_compvar_primary(tmp_944)));
}

tmp_945 = make_temporary(TYPE_INT);
{
compvar_t *tmp_946, *tmp_947;
tmp_946 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_946), make_int_const_rhs(2));
tmp_947 = tmp_925;
emit_assign(make_lhs(tmp_945), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_946), make_compvar_primary(tmp_947)));
}

{
compvar_t *tmp_948;

tmp_948 = make_temporary(TYPE_INT);
{
compvar_t *tmp_949, *tmp_950;
tmp_949 = make_temporary(TYPE_INT);
{
compvar_t *tmp_951, *tmp_952;
tmp_951 = tmp_942;
tmp_952 = tmp_942;
emit_assign(make_lhs(tmp_949), make_op_rhs(OP_MUL, make_compvar_primary(tmp_951), make_compvar_primary(tmp_952)));
}
tmp_950 = make_temporary(TYPE_INT);
{
compvar_t *tmp_953, *tmp_954;
tmp_953 = args[1][0];
tmp_954 = make_temporary(TYPE_INT);
{
compvar_t *tmp_955, *tmp_956;
tmp_955 = make_temporary(TYPE_INT);
{
compvar_t *tmp_957, *tmp_958;
tmp_957 = tmp_930;
tmp_958 = tmp_930;
emit_assign(make_lhs(tmp_955), make_op_rhs(OP_MUL, make_compvar_primary(tmp_957), make_compvar_primary(tmp_958)));
}
tmp_956 = make_temporary(TYPE_INT);
{
compvar_t *tmp_959, *tmp_960;
tmp_959 = tmp_939;
tmp_960 = tmp_939;
emit_assign(make_lhs(tmp_956), make_op_rhs(OP_MUL, make_compvar_primary(tmp_959), make_compvar_primary(tmp_960)));
}
emit_assign(make_lhs(tmp_954), make_op_rhs(OP_MUL, make_compvar_primary(tmp_955), make_compvar_primary(tmp_956)));
}
emit_assign(make_lhs(tmp_950), make_op_rhs(OP_MUL, make_compvar_primary(tmp_953), make_compvar_primary(tmp_954)));
}
emit_assign(make_lhs(tmp_948), make_op_rhs(OP_ADD, make_compvar_primary(tmp_949), make_compvar_primary(tmp_950)));
}

{
compvar_t *tmp_961, *tmp_962;
tmp_961 = make_temporary(TYPE_INT);
{
compvar_t *tmp_963, *tmp_964;
tmp_963 = tmp_942;
tmp_964 = make_temporary(TYPE_INT);
{
compvar_t *tmp_965, *tmp_966;
tmp_965 = tmp_936;
tmp_966 = tmp_945;
emit_assign(make_lhs(tmp_964), make_op_rhs(OP_MUL, make_compvar_primary(tmp_965), make_compvar_primary(tmp_966)));
}
emit_assign(make_lhs(tmp_961), make_op_rhs(OP_MUL, make_compvar_primary(tmp_963), make_compvar_primary(tmp_964)));
}
tmp_962 = tmp_948;
emit_assign(make_lhs(result[0]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_961), make_compvar_primary(tmp_962)));
}
{
compvar_t *tmp_967, *tmp_968;
tmp_967 = make_temporary(TYPE_INT);
{
compvar_t *tmp_969, *tmp_970;
tmp_969 = make_temporary(TYPE_INT);
{
compvar_t *tmp_971, *tmp_972;
tmp_971 = tmp_930;
tmp_972 = tmp_939;
emit_assign(make_lhs(tmp_969), make_op_rhs(OP_MUL, make_compvar_primary(tmp_971), make_compvar_primary(tmp_972)));
}
tmp_970 = make_temporary(TYPE_INT);
{
compvar_t *tmp_973, *tmp_974;
tmp_973 = args[1][0];
tmp_974 = tmp_933;
emit_assign(make_lhs(tmp_970), make_op_rhs(OP_MUL, make_compvar_primary(tmp_973), make_compvar_primary(tmp_974)));
}
emit_assign(make_lhs(tmp_967), make_op_rhs(OP_SUB, make_compvar_primary(tmp_969), make_compvar_primary(tmp_970)));
}
tmp_968 = tmp_948;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_967), make_compvar_primary(tmp_968)));
}
}
}
}
}

static void
gen_floor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_975;
for (tmp_975 = 0; tmp_975 < 1; ++tmp_975)
{
switch (tmp_975)
{
case 0 :
{
compvar_t *tmp_976;
tmp_976 = args[0][0];
emit_assign(make_lhs(result[tmp_975]), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_976)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_ceil (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_977;
for (tmp_977 = 0; tmp_977 < 1; ++tmp_977)
{
switch (tmp_977)
{
case 0 :
{
compvar_t *tmp_978;
tmp_978 = args[0][0];
emit_assign(make_lhs(result[tmp_977]), make_op_rhs(OP_CEIL, make_compvar_primary(tmp_978)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_sign_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_979;
for (tmp_979 = 0; tmp_979 < arglengths[0]; ++tmp_979)
{
{
compvar_t *tmp_980;
tmp_980 = make_temporary(TYPE_INT);
{
compvar_t *tmp_981, *tmp_982;
tmp_981 = args[0][tmp_979];
tmp_982 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_982), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_980), make_op_rhs(OP_LESS, make_compvar_primary(tmp_981), make_compvar_primary(tmp_982)));
}
start_if_cond(make_compvar_rhs(tmp_980));
emit_assign(make_lhs(result[tmp_979]), make_int_const_rhs(-1));
switch_if_branch();
{
compvar_t *tmp_983;
tmp_983 = make_temporary(TYPE_INT);
{
compvar_t *tmp_984, *tmp_985;
tmp_984 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_984), make_int_const_rhs(0));
tmp_985 = args[0][tmp_979];
emit_assign(make_lhs(tmp_983), make_op_rhs(OP_LESS, make_compvar_primary(tmp_984), make_compvar_primary(tmp_985)));
}
start_if_cond(make_compvar_rhs(tmp_983));
emit_assign(make_lhs(result[tmp_979]), make_int_const_rhs(1));
switch_if_branch();
emit_assign(make_lhs(result[tmp_979]), make_int_const_rhs(0));
end_if_cond();
}
end_if_cond();
}
}
}
}

static void
gen_min_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_986;
for (tmp_986 = 0; tmp_986 < arglengths[0]; ++tmp_986)
{
{
compvar_t *tmp_987;
tmp_987 = make_temporary(TYPE_INT);
{
compvar_t *tmp_988, *tmp_989;
tmp_988 = args[0][tmp_986];
tmp_989 = args[1][tmp_986];
emit_assign(make_lhs(tmp_987), make_op_rhs(OP_LESS, make_compvar_primary(tmp_988), make_compvar_primary(tmp_989)));
}
start_if_cond(make_compvar_rhs(tmp_987));
emit_assign(make_lhs(result[tmp_986]), make_compvar_rhs(args[0][tmp_986]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_986]), make_compvar_rhs(args[1][tmp_986]));
end_if_cond();
}
}
}
}

static void
gen_max_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_990;
for (tmp_990 = 0; tmp_990 < arglengths[0]; ++tmp_990)
{
{
compvar_t *tmp_991;
tmp_991 = make_temporary(TYPE_INT);
{
compvar_t *tmp_992, *tmp_993;
tmp_992 = args[0][tmp_990];
tmp_993 = args[1][tmp_990];
emit_assign(make_lhs(tmp_991), make_op_rhs(OP_LESS, make_compvar_primary(tmp_992), make_compvar_primary(tmp_993)));
}
start_if_cond(make_compvar_rhs(tmp_991));
emit_assign(make_lhs(result[tmp_990]), make_compvar_rhs(args[1][tmp_990]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_990]), make_compvar_rhs(args[0][tmp_990]));
end_if_cond();
}
}
}
}

static void
gen_clamp (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_994;
for (tmp_994 = 0; tmp_994 < arglengths[0]; ++tmp_994)
{
{
compvar_t *tmp_995;
tmp_995 = make_temporary(TYPE_INT);
{
compvar_t *tmp_996, *tmp_997;
tmp_996 = args[0][tmp_994];
tmp_997 = args[1][tmp_994];
emit_assign(make_lhs(tmp_995), make_op_rhs(OP_LESS, make_compvar_primary(tmp_996), make_compvar_primary(tmp_997)));
}
start_if_cond(make_compvar_rhs(tmp_995));
emit_assign(make_lhs(result[tmp_994]), make_compvar_rhs(args[1][tmp_994]));
switch_if_branch();
{
compvar_t *tmp_998;
tmp_998 = make_temporary(TYPE_INT);
{
compvar_t *tmp_999, *tmp_1000;
tmp_999 = args[2][tmp_994];
tmp_1000 = args[0][tmp_994];
emit_assign(make_lhs(tmp_998), make_op_rhs(OP_LESS, make_compvar_primary(tmp_999), make_compvar_primary(tmp_1000)));
}
start_if_cond(make_compvar_rhs(tmp_998));
emit_assign(make_lhs(result[tmp_994]), make_compvar_rhs(args[2][tmp_994]));
switch_if_branch();
emit_assign(make_lhs(result[tmp_994]), make_compvar_rhs(args[0][tmp_994]));
end_if_cond();
}
end_if_cond();
}
}
}
}

static void
gen_lerp_1 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1001;

tmp_1001 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1002, *tmp_1003;
tmp_1002 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1002), make_int_const_rhs(1));
tmp_1003 = args[0][0];
emit_assign(make_lhs(tmp_1001), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1002), make_compvar_primary(tmp_1003)));
}

{
int tmp_1004;
for (tmp_1004 = 0; tmp_1004 < arglengths[1]; ++tmp_1004)
{
{
compvar_t *tmp_1005, *tmp_1006;
tmp_1005 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1007, *tmp_1008;
tmp_1007 = tmp_1001;
tmp_1008 = args[1][tmp_1004];
emit_assign(make_lhs(tmp_1005), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1007), make_compvar_primary(tmp_1008)));
}
tmp_1006 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1009, *tmp_1010;
tmp_1009 = args[0][0];
tmp_1010 = args[2][tmp_1004];
emit_assign(make_lhs(tmp_1006), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1009), make_compvar_primary(tmp_1010)));
}
emit_assign(make_lhs(result[tmp_1004]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1005), make_compvar_primary(tmp_1006)));
}
}
}
}
}

static void
gen_lerp_n (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1011;
for (tmp_1011 = 0; tmp_1011 < arglengths[1]; ++tmp_1011)
{
{
compvar_t *tmp_1012, *tmp_1013;
tmp_1012 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1014, *tmp_1015;
tmp_1014 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1016, *tmp_1017;
tmp_1016 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1016), make_int_const_rhs(1));
tmp_1017 = args[0][tmp_1011];
emit_assign(make_lhs(tmp_1014), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1016), make_compvar_primary(tmp_1017)));
}
tmp_1015 = args[1][tmp_1011];
emit_assign(make_lhs(tmp_1012), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1014), make_compvar_primary(tmp_1015)));
}
tmp_1013 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1018, *tmp_1019;
tmp_1018 = args[0][tmp_1011];
tmp_1019 = args[2][tmp_1011];
emit_assign(make_lhs(tmp_1013), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1018), make_compvar_primary(tmp_1019)));
}
emit_assign(make_lhs(result[tmp_1011]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1012), make_compvar_primary(tmp_1013)));
}
}
}
}

static void
gen_scale (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1020;
for (tmp_1020 = 0; tmp_1020 < arglengths[0]; ++tmp_1020)
{
{
compvar_t *tmp_1021;

tmp_1021 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1022, *tmp_1023;
tmp_1022 = args[2][tmp_1020];
tmp_1023 = args[1][tmp_1020];
emit_assign(make_lhs(tmp_1021), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1022), make_compvar_primary(tmp_1023)));
}

{
compvar_t *tmp_1024;
tmp_1024 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1025, *tmp_1026;
tmp_1025 = tmp_1021;
tmp_1026 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1026), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1024), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1025), make_compvar_primary(tmp_1026)));
}
start_if_cond(make_compvar_rhs(tmp_1024));
emit_assign(make_lhs(result[tmp_1020]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1027, *tmp_1028;
tmp_1027 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1029, *tmp_1030;
tmp_1029 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1031, *tmp_1032;
tmp_1031 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1033, *tmp_1034;
tmp_1033 = args[0][tmp_1020];
tmp_1034 = args[1][tmp_1020];
emit_assign(make_lhs(tmp_1031), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1033), make_compvar_primary(tmp_1034)));
}
tmp_1032 = tmp_1021;
emit_assign(make_lhs(tmp_1029), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1031), make_compvar_primary(tmp_1032)));
}
tmp_1030 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1035, *tmp_1036;
tmp_1035 = args[4][tmp_1020];
tmp_1036 = args[3][tmp_1020];
emit_assign(make_lhs(tmp_1030), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1035), make_compvar_primary(tmp_1036)));
}
emit_assign(make_lhs(tmp_1027), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1029), make_compvar_primary(tmp_1030)));
}
tmp_1028 = args[3][tmp_1020];
emit_assign(make_lhs(result[tmp_1020]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1027), make_compvar_primary(tmp_1028)));
}
end_if_cond();
}
}
}
}
}

static void
gen_solve_poly_2 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1037;

tmp_1037 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1038, *tmp_1039, *tmp_1040;
tmp_1038 = args[0][0];
tmp_1039 = args[0][1];
tmp_1040 = args[0][2];
emit_assign(make_lhs(tmp_1037), make_op_rhs(OP_SOLVE_POLY_2, make_compvar_primary(tmp_1038), make_compvar_primary(tmp_1039), make_compvar_primary(tmp_1040)));
}

{
int tmp_1041;
for (tmp_1041 = 0; tmp_1041 < 2; ++tmp_1041)
{
switch (tmp_1041)
{
case 0 :
{
compvar_t *tmp_1042, *tmp_1043;
tmp_1042 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1042), make_int_const_rhs(0));
tmp_1043 = tmp_1037;
emit_assign(make_lhs(result[tmp_1041]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_1042), make_compvar_primary(tmp_1043)));
}
break;
case 1 :
{
compvar_t *tmp_1044, *tmp_1045;
tmp_1044 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1044), make_int_const_rhs(1));
tmp_1045 = tmp_1037;
emit_assign(make_lhs(result[tmp_1041]), make_op_rhs(OP_V2_NTH, make_compvar_primary(tmp_1044), make_compvar_primary(tmp_1045)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_solve_poly_3 (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1046;

tmp_1046 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1047, *tmp_1048, *tmp_1049, *tmp_1050;
tmp_1047 = args[0][0];
tmp_1048 = args[0][1];
tmp_1049 = args[0][2];
tmp_1050 = args[0][3];
emit_assign(make_lhs(tmp_1046), make_op_rhs(OP_SOLVE_POLY_3, make_compvar_primary(tmp_1047), make_compvar_primary(tmp_1048), make_compvar_primary(tmp_1049), make_compvar_primary(tmp_1050)));
}

{
int tmp_1051;
for (tmp_1051 = 0; tmp_1051 < 3; ++tmp_1051)
{
switch (tmp_1051)
{
case 0 :
{
compvar_t *tmp_1052, *tmp_1053;
tmp_1052 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1052), make_int_const_rhs(0));
tmp_1053 = tmp_1046;
emit_assign(make_lhs(result[tmp_1051]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1052), make_compvar_primary(tmp_1053)));
}
break;
case 1 :
{
compvar_t *tmp_1054, *tmp_1055;
tmp_1054 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1054), make_int_const_rhs(1));
tmp_1055 = tmp_1046;
emit_assign(make_lhs(result[tmp_1051]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1054), make_compvar_primary(tmp_1055)));
}
break;
case 2 :
{
compvar_t *tmp_1056, *tmp_1057;
tmp_1056 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1056), make_int_const_rhs(2));
tmp_1057 = tmp_1046;
emit_assign(make_lhs(result[tmp_1051]), make_op_rhs(OP_V3_NTH, make_compvar_primary(tmp_1056), make_compvar_primary(tmp_1057)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_not (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1058;
tmp_1058 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1059, *tmp_1060;
tmp_1059 = args[0][0];
tmp_1060 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1060), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1058), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1059), make_compvar_primary(tmp_1060)));
}
start_if_cond(make_compvar_rhs(tmp_1058));
{
int tmp_1061;
for (tmp_1061 = 0; tmp_1061 < 1; ++tmp_1061)
{
switch (tmp_1061)
{
case 0 :
emit_assign(make_lhs(result[tmp_1061]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1062;
for (tmp_1062 = 0; tmp_1062 < 1; ++tmp_1062)
{
switch (tmp_1062)
{
case 0 :
emit_assign(make_lhs(result[tmp_1062]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_or (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1063;
tmp_1063 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1064, *tmp_1065;
tmp_1064 = args[0][0];
tmp_1065 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1065), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1063), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1064), make_compvar_primary(tmp_1065)));
}
start_if_cond(make_compvar_rhs(tmp_1063));
{
compvar_t *tmp_1066, *tmp_1067;
tmp_1066 = args[1][0];
tmp_1067 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1067), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1063), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1066), make_compvar_primary(tmp_1067)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1063));
{
int tmp_1068;
for (tmp_1068 = 0; tmp_1068 < 1; ++tmp_1068)
{
switch (tmp_1068)
{
case 0 :
emit_assign(make_lhs(result[tmp_1068]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1069;
for (tmp_1069 = 0; tmp_1069 < 1; ++tmp_1069)
{
switch (tmp_1069)
{
case 0 :
emit_assign(make_lhs(result[tmp_1069]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_and (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1070;
tmp_1070 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1071, *tmp_1072;
tmp_1071 = args[0][0];
tmp_1072 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1072), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1070), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1071), make_compvar_primary(tmp_1072)));
}
start_if_cond(make_compvar_rhs(tmp_1070));
switch_if_branch();
{
compvar_t *tmp_1073, *tmp_1074;
tmp_1073 = args[1][0];
tmp_1074 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1074), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1070), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1073), make_compvar_primary(tmp_1074)));
}
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1070));
{
int tmp_1075;
for (tmp_1075 = 0; tmp_1075 < 1; ++tmp_1075)
{
switch (tmp_1075)
{
case 0 :
emit_assign(make_lhs(result[tmp_1075]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1076;
for (tmp_1076 = 0; tmp_1076 < 1; ++tmp_1076)
{
switch (tmp_1076)
{
case 0 :
emit_assign(make_lhs(result[tmp_1076]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_xor (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1077;
tmp_1077 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1078, *tmp_1079;
tmp_1078 = args[0][0];
tmp_1079 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1079), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1077), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1078), make_compvar_primary(tmp_1079)));
}
emit_assign(make_lhs(tmp_1077), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1077)));
start_if_cond(make_compvar_rhs(tmp_1077));
{
compvar_t *tmp_1080, *tmp_1081;
tmp_1080 = args[1][0];
tmp_1081 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1081), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1077), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1080), make_compvar_primary(tmp_1081)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1077));
switch_if_branch();
{
compvar_t *tmp_1082, *tmp_1083;
tmp_1082 = args[1][0];
tmp_1083 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1083), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1077), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1082), make_compvar_primary(tmp_1083)));
}
emit_assign(make_lhs(tmp_1077), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1077)));
start_if_cond(make_compvar_rhs(tmp_1077));
{
compvar_t *tmp_1084, *tmp_1085;
tmp_1084 = args[0][0];
tmp_1085 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1085), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1077), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1084), make_compvar_primary(tmp_1085)));
}
switch_if_branch();
end_if_cond();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1077));
{
int tmp_1086;
for (tmp_1086 = 0; tmp_1086 < 1; ++tmp_1086)
{
switch (tmp_1086)
{
case 0 :
emit_assign(make_lhs(result[tmp_1086]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1087;
for (tmp_1087 = 0; tmp_1087 < 1; ++tmp_1087)
{
switch (tmp_1087)
{
case 0 :
emit_assign(make_lhs(result[tmp_1087]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_equal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1088;
for (tmp_1088 = 0; tmp_1088 < 1; ++tmp_1088)
{
switch (tmp_1088)
{
case 0 :
{
compvar_t *tmp_1089, *tmp_1090;
tmp_1089 = args[0][0];
tmp_1090 = args[1][0];
emit_assign(make_lhs(result[tmp_1088]), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1089), make_compvar_primary(tmp_1090)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_less (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1091;
for (tmp_1091 = 0; tmp_1091 < 1; ++tmp_1091)
{
switch (tmp_1091)
{
case 0 :
{
compvar_t *tmp_1092, *tmp_1093;
tmp_1092 = args[0][0];
tmp_1093 = args[1][0];
emit_assign(make_lhs(result[tmp_1091]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1092), make_compvar_primary(tmp_1093)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_greater (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1094;
for (tmp_1094 = 0; tmp_1094 < 1; ++tmp_1094)
{
switch (tmp_1094)
{
case 0 :
{
compvar_t *tmp_1095, *tmp_1096;
tmp_1095 = args[1][0];
tmp_1096 = args[0][0];
emit_assign(make_lhs(result[tmp_1094]), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1095), make_compvar_primary(tmp_1096)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_lessequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1097;
for (tmp_1097 = 0; tmp_1097 < 1; ++tmp_1097)
{
switch (tmp_1097)
{
case 0 :
{
compvar_t *tmp_1098, *tmp_1099;
tmp_1098 = args[0][0];
tmp_1099 = args[1][0];
emit_assign(make_lhs(result[tmp_1097]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1098), make_compvar_primary(tmp_1099)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_greaterequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1100;
for (tmp_1100 = 0; tmp_1100 < 1; ++tmp_1100)
{
switch (tmp_1100)
{
case 0 :
{
compvar_t *tmp_1101, *tmp_1102;
tmp_1101 = args[1][0];
tmp_1102 = args[0][0];
emit_assign(make_lhs(result[tmp_1100]), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1101), make_compvar_primary(tmp_1102)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_notequal (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1103;
for (tmp_1103 = 0; tmp_1103 < 1; ++tmp_1103)
{
switch (tmp_1103)
{
case 0 :
{
compvar_t *tmp_1104;
tmp_1104 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1105, *tmp_1106;
tmp_1105 = args[0][0];
tmp_1106 = args[1][0];
emit_assign(make_lhs(tmp_1104), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1105), make_compvar_primary(tmp_1106)));
}
emit_assign(make_lhs(result[tmp_1103]), make_op_rhs(OP_NOT, make_compvar_primary(tmp_1104)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_inintv (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1107;
tmp_1107 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1108, *tmp_1109;
tmp_1108 = args[1][0];
tmp_1109 = args[0][0];
emit_assign(make_lhs(tmp_1107), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1108), make_compvar_primary(tmp_1109)));
}
start_if_cond(make_compvar_rhs(tmp_1107));
{
compvar_t *tmp_1110, *tmp_1111;
tmp_1110 = args[0][0];
tmp_1111 = args[2][0];
emit_assign(make_lhs(tmp_1107), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1110), make_compvar_primary(tmp_1111)));
}
switch_if_branch();
end_if_cond();
start_if_cond(make_compvar_rhs(tmp_1107));
{
int tmp_1112;
for (tmp_1112 = 0; tmp_1112 < 1; ++tmp_1112)
{
switch (tmp_1112)
{
case 0 :
emit_assign(make_lhs(result[tmp_1112]), make_int_const_rhs(1));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
int tmp_1113;
for (tmp_1113 = 0; tmp_1113 < 1; ++tmp_1113)
{
switch (tmp_1113)
{
case 0 :
emit_assign(make_lhs(result[tmp_1113]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
end_if_cond();
}
}

static void
gen_origvalxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1114;

tmp_1114 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1115, *tmp_1116, *tmp_1117, *tmp_1118;
tmp_1115 = args[0][0];
tmp_1116 = args[0][1];
tmp_1117 = args[2][0];
tmp_1118 = args[1][0];
emit_assign(make_lhs(tmp_1114), make_op_rhs(OP_ORIG_VAL, make_compvar_primary(tmp_1115), make_compvar_primary(tmp_1116), make_compvar_primary(tmp_1117), make_compvar_primary(tmp_1118)));
}

{
int tmp_1119;
for (tmp_1119 = 0; tmp_1119 < 4; ++tmp_1119)
{
switch (tmp_1119)
{
case 0 :
{
compvar_t *tmp_1120;
tmp_1120 = tmp_1114;
emit_assign(make_lhs(result[tmp_1119]), make_op_rhs(OP_RED, make_compvar_primary(tmp_1120)));
}
break;
case 1 :
{
compvar_t *tmp_1121;
tmp_1121 = tmp_1114;
emit_assign(make_lhs(result[tmp_1119]), make_op_rhs(OP_GREEN, make_compvar_primary(tmp_1121)));
}
break;
case 2 :
{
compvar_t *tmp_1122;
tmp_1122 = tmp_1114;
emit_assign(make_lhs(result[tmp_1119]), make_op_rhs(OP_BLUE, make_compvar_primary(tmp_1122)));
}
break;
case 3 :
{
compvar_t *tmp_1123;
tmp_1123 = tmp_1114;
emit_assign(make_lhs(result[tmp_1119]), make_op_rhs(OP_ALPHA, make_compvar_primary(tmp_1123)));
}
break;
default :
assert(0);
}
}
}
}
}

static void
gen_gray (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1124;
for (tmp_1124 = 0; tmp_1124 < 1; ++tmp_1124)
{
switch (tmp_1124)
{
case 0 :
{
compvar_t *tmp_1125, *tmp_1126;
tmp_1125 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1127, *tmp_1128;
tmp_1127 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1129, *tmp_1130;
tmp_1129 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1129), make_float_const_rhs(0.299));
tmp_1130 = args[0][0];
emit_assign(make_lhs(tmp_1127), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1129), make_compvar_primary(tmp_1130)));
}
tmp_1128 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1131, *tmp_1132;
tmp_1131 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1131), make_float_const_rhs(0.587));
tmp_1132 = args[0][1];
emit_assign(make_lhs(tmp_1128), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1131), make_compvar_primary(tmp_1132)));
}
emit_assign(make_lhs(tmp_1125), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1127), make_compvar_primary(tmp_1128)));
}
tmp_1126 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1133, *tmp_1134;
tmp_1133 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1133), make_float_const_rhs(0.114));
tmp_1134 = args[0][2];
emit_assign(make_lhs(tmp_1126), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1133), make_compvar_primary(tmp_1134)));
}
emit_assign(make_lhs(result[tmp_1124]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1125), make_compvar_primary(tmp_1126)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_tohsva (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1135;
compvar_t *tmp_1140;
compvar_t *tmp_1145;

tmp_1135 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1136, *tmp_1137;
tmp_1136 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1136), make_int_const_rhs(0));
tmp_1137 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1138, *tmp_1139;
tmp_1138 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1138), make_int_const_rhs(1));
tmp_1139 = args[0][0];
emit_assign(make_lhs(tmp_1137), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1138), make_compvar_primary(tmp_1139)));
}
emit_assign(make_lhs(tmp_1135), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1136), make_compvar_primary(tmp_1137)));
}

tmp_1140 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1141, *tmp_1142;
tmp_1141 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1141), make_int_const_rhs(0));
tmp_1142 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1143, *tmp_1144;
tmp_1143 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1143), make_int_const_rhs(1));
tmp_1144 = args[0][1];
emit_assign(make_lhs(tmp_1142), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1143), make_compvar_primary(tmp_1144)));
}
emit_assign(make_lhs(tmp_1140), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1141), make_compvar_primary(tmp_1142)));
}

tmp_1145 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1146, *tmp_1147;
tmp_1146 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1146), make_int_const_rhs(0));
tmp_1147 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1148, *tmp_1149;
tmp_1148 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1148), make_int_const_rhs(1));
tmp_1149 = args[0][2];
emit_assign(make_lhs(tmp_1147), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1148), make_compvar_primary(tmp_1149)));
}
emit_assign(make_lhs(tmp_1145), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1146), make_compvar_primary(tmp_1147)));
}

{
compvar_t *tmp_1150, *tmp_1151;
tmp_1150 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1150), make_int_const_rhs(0));
tmp_1151 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1152, *tmp_1153;
tmp_1152 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1152), make_int_const_rhs(1));
tmp_1153 = args[0][3];
emit_assign(make_lhs(tmp_1151), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1152), make_compvar_primary(tmp_1153)));
}
emit_assign(make_lhs(result[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1150), make_compvar_primary(tmp_1151)));
}
{
compvar_t *tmp_1154;
compvar_t *tmp_1159;

tmp_1154 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1155, *tmp_1156;
tmp_1155 = tmp_1135;
tmp_1156 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1157, *tmp_1158;
tmp_1157 = tmp_1140;
tmp_1158 = tmp_1145;
emit_assign(make_lhs(tmp_1156), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1157), make_compvar_primary(tmp_1158)));
}
emit_assign(make_lhs(tmp_1154), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1155), make_compvar_primary(tmp_1156)));
}

tmp_1159 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1160, *tmp_1161;
tmp_1160 = tmp_1135;
tmp_1161 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1162, *tmp_1163;
tmp_1162 = tmp_1140;
tmp_1163 = tmp_1145;
emit_assign(make_lhs(tmp_1161), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1162), make_compvar_primary(tmp_1163)));
}
emit_assign(make_lhs(tmp_1159), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1160), make_compvar_primary(tmp_1161)));
}

emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1154));
{
compvar_t *tmp_1164;
tmp_1164 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1165, *tmp_1166;
tmp_1165 = tmp_1154;
tmp_1166 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1166), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1164), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1165), make_compvar_primary(tmp_1166)));
}
start_if_cond(make_compvar_rhs(tmp_1164));
emit_assign(make_lhs(result[0]), make_int_const_rhs(0));
emit_assign(make_lhs(result[1]), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1167;
compvar_t *tmp_1170;

tmp_1167 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1168, *tmp_1169;
tmp_1168 = tmp_1154;
tmp_1169 = tmp_1159;
emit_assign(make_lhs(tmp_1167), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1168), make_compvar_primary(tmp_1169)));
}

tmp_1170 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1170), make_int_const_rhs(0));

{
compvar_t *tmp_1171, *tmp_1172;
tmp_1171 = tmp_1167;
tmp_1172 = tmp_1154;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1171), make_compvar_primary(tmp_1172)));
}
{
compvar_t *tmp_1173;
tmp_1173 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1174, *tmp_1175;
tmp_1174 = tmp_1135;
tmp_1175 = tmp_1154;
emit_assign(make_lhs(tmp_1173), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1174), make_compvar_primary(tmp_1175)));
}
start_if_cond(make_compvar_rhs(tmp_1173));
{
compvar_t *tmp_1176, *tmp_1177;
tmp_1176 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1178, *tmp_1179;
tmp_1178 = tmp_1140;
tmp_1179 = tmp_1145;
emit_assign(make_lhs(tmp_1176), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1178), make_compvar_primary(tmp_1179)));
}
tmp_1177 = tmp_1167;
emit_assign(make_lhs(tmp_1170), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1176), make_compvar_primary(tmp_1177)));
}
switch_if_branch();
{
compvar_t *tmp_1180;
tmp_1180 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1181, *tmp_1182;
tmp_1181 = tmp_1140;
tmp_1182 = tmp_1154;
emit_assign(make_lhs(tmp_1180), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1181), make_compvar_primary(tmp_1182)));
}
start_if_cond(make_compvar_rhs(tmp_1180));
{
compvar_t *tmp_1183, *tmp_1184;
tmp_1183 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1183), make_int_const_rhs(2));
tmp_1184 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1185, *tmp_1186;
tmp_1185 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1187, *tmp_1188;
tmp_1187 = tmp_1145;
tmp_1188 = tmp_1135;
emit_assign(make_lhs(tmp_1185), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1187), make_compvar_primary(tmp_1188)));
}
tmp_1186 = tmp_1167;
emit_assign(make_lhs(tmp_1184), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1185), make_compvar_primary(tmp_1186)));
}
emit_assign(make_lhs(tmp_1170), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1183), make_compvar_primary(tmp_1184)));
}
switch_if_branch();
{
compvar_t *tmp_1189, *tmp_1190;
tmp_1189 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1189), make_int_const_rhs(4));
tmp_1190 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1191, *tmp_1192;
tmp_1191 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1193, *tmp_1194;
tmp_1193 = tmp_1135;
tmp_1194 = tmp_1140;
emit_assign(make_lhs(tmp_1191), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1193), make_compvar_primary(tmp_1194)));
}
tmp_1192 = tmp_1167;
emit_assign(make_lhs(tmp_1190), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1191), make_compvar_primary(tmp_1192)));
}
emit_assign(make_lhs(tmp_1170), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1189), make_compvar_primary(tmp_1190)));
}
end_if_cond();
}
end_if_cond();
}
{
compvar_t *tmp_1195, *tmp_1196;
tmp_1195 = tmp_1170;
tmp_1196 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1196), make_float_const_rhs(6.0));
emit_assign(make_lhs(tmp_1170), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1195), make_compvar_primary(tmp_1196)));
}
{
compvar_t *tmp_1197;
tmp_1197 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1198, *tmp_1199;
tmp_1198 = tmp_1170;
tmp_1199 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1199), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1197), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1198), make_compvar_primary(tmp_1199)));
}
start_if_cond(make_compvar_rhs(tmp_1197));
{
compvar_t *tmp_1200, *tmp_1201;
tmp_1200 = tmp_1170;
tmp_1201 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1201), make_int_const_rhs(1));
emit_assign(make_lhs(result[0]), make_op_rhs(OP_ADD, make_compvar_primary(tmp_1200), make_compvar_primary(tmp_1201)));
}
switch_if_branch();
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1170));
end_if_cond();
}
}
end_if_cond();
}
}
}
}

static void
gen_torgba (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1202;
compvar_t *tmp_1207;

tmp_1202 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1203, *tmp_1204;
tmp_1203 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1203), make_int_const_rhs(0));
tmp_1204 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1205, *tmp_1206;
tmp_1205 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1205), make_int_const_rhs(1));
tmp_1206 = args[0][1];
emit_assign(make_lhs(tmp_1204), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1205), make_compvar_primary(tmp_1206)));
}
emit_assign(make_lhs(tmp_1202), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1203), make_compvar_primary(tmp_1204)));
}

tmp_1207 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1208, *tmp_1209;
tmp_1208 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1208), make_int_const_rhs(0));
tmp_1209 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1210, *tmp_1211;
tmp_1210 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1210), make_int_const_rhs(1));
tmp_1211 = args[0][2];
emit_assign(make_lhs(tmp_1209), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1210), make_compvar_primary(tmp_1211)));
}
emit_assign(make_lhs(tmp_1207), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1208), make_compvar_primary(tmp_1209)));
}

{
compvar_t *tmp_1212, *tmp_1213;
tmp_1212 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1212), make_int_const_rhs(0));
tmp_1213 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1214, *tmp_1215;
tmp_1214 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1214), make_int_const_rhs(1));
tmp_1215 = args[0][3];
emit_assign(make_lhs(tmp_1213), make_op_rhs(OP_MIN, make_compvar_primary(tmp_1214), make_compvar_primary(tmp_1215)));
}
emit_assign(make_lhs(result[3]), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1212), make_compvar_primary(tmp_1213)));
}
{
compvar_t *tmp_1216;
tmp_1216 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1217, *tmp_1218;
tmp_1217 = tmp_1202;
tmp_1218 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1218), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1216), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1217), make_compvar_primary(tmp_1218)));
}
start_if_cond(make_compvar_rhs(tmp_1216));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1207));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1207));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1207));
switch_if_branch();
{
compvar_t *tmp_1219;

tmp_1219 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1220, *tmp_1221;
tmp_1220 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1220), make_int_const_rhs(0));
tmp_1221 = args[0][0];
emit_assign(make_lhs(tmp_1219), make_op_rhs(OP_MAX, make_compvar_primary(tmp_1220), make_compvar_primary(tmp_1221)));
}

{
compvar_t *tmp_1222;
tmp_1222 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1223, *tmp_1224;
tmp_1223 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1223), make_int_const_rhs(1));
tmp_1224 = tmp_1219;
emit_assign(make_lhs(tmp_1222), make_op_rhs(OP_LEQ, make_compvar_primary(tmp_1223), make_compvar_primary(tmp_1224)));
}
start_if_cond(make_compvar_rhs(tmp_1222));
emit_assign(make_lhs(tmp_1219), make_int_const_rhs(0));
switch_if_branch();
{
compvar_t *tmp_1225, *tmp_1226;
tmp_1225 = tmp_1219;
tmp_1226 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1226), make_int_const_rhs(6));
emit_assign(make_lhs(tmp_1219), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1225), make_compvar_primary(tmp_1226)));
}
end_if_cond();
}
{
compvar_t *tmp_1227;

tmp_1227 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1228;
tmp_1228 = tmp_1219;
emit_assign(make_lhs(tmp_1227), make_op_rhs(OP_FLOOR, make_compvar_primary(tmp_1228)));
}

{
compvar_t *tmp_1229;

tmp_1229 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1230, *tmp_1231;
tmp_1230 = tmp_1219;
tmp_1231 = tmp_1227;
emit_assign(make_lhs(tmp_1229), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1230), make_compvar_primary(tmp_1231)));
}

{
compvar_t *tmp_1232;
compvar_t *tmp_1237;
compvar_t *tmp_1244;

tmp_1232 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1233, *tmp_1234;
tmp_1233 = tmp_1207;
tmp_1234 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1235, *tmp_1236;
tmp_1235 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1235), make_int_const_rhs(1));
tmp_1236 = tmp_1202;
emit_assign(make_lhs(tmp_1234), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1235), make_compvar_primary(tmp_1236)));
}
emit_assign(make_lhs(tmp_1232), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1233), make_compvar_primary(tmp_1234)));
}

tmp_1237 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1238, *tmp_1239;
tmp_1238 = tmp_1207;
tmp_1239 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1240, *tmp_1241;
tmp_1240 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1240), make_int_const_rhs(1));
tmp_1241 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1242, *tmp_1243;
tmp_1242 = tmp_1202;
tmp_1243 = tmp_1229;
emit_assign(make_lhs(tmp_1241), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1242), make_compvar_primary(tmp_1243)));
}
emit_assign(make_lhs(tmp_1239), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1240), make_compvar_primary(tmp_1241)));
}
emit_assign(make_lhs(tmp_1237), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1238), make_compvar_primary(tmp_1239)));
}

tmp_1244 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1245, *tmp_1246;
tmp_1245 = tmp_1207;
tmp_1246 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1247, *tmp_1248;
tmp_1247 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1247), make_int_const_rhs(1));
tmp_1248 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1249, *tmp_1250;
tmp_1249 = tmp_1202;
tmp_1250 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1251, *tmp_1252;
tmp_1251 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1251), make_int_const_rhs(1));
tmp_1252 = tmp_1229;
emit_assign(make_lhs(tmp_1250), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1251), make_compvar_primary(tmp_1252)));
}
emit_assign(make_lhs(tmp_1248), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1249), make_compvar_primary(tmp_1250)));
}
emit_assign(make_lhs(tmp_1246), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1247), make_compvar_primary(tmp_1248)));
}
emit_assign(make_lhs(tmp_1244), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1245), make_compvar_primary(tmp_1246)));
}

{
compvar_t *tmp_1253;
tmp_1253 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1254, *tmp_1255;
tmp_1254 = tmp_1227;
tmp_1255 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1255), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1253), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1254), make_compvar_primary(tmp_1255)));
}
start_if_cond(make_compvar_rhs(tmp_1253));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1207));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1244));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1232));
switch_if_branch();
{
compvar_t *tmp_1256;
tmp_1256 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1257, *tmp_1258;
tmp_1257 = tmp_1227;
tmp_1258 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1258), make_int_const_rhs(1));
emit_assign(make_lhs(tmp_1256), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1257), make_compvar_primary(tmp_1258)));
}
start_if_cond(make_compvar_rhs(tmp_1256));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1237));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1207));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1232));
switch_if_branch();
{
compvar_t *tmp_1259;
tmp_1259 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1260, *tmp_1261;
tmp_1260 = tmp_1227;
tmp_1261 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1261), make_int_const_rhs(2));
emit_assign(make_lhs(tmp_1259), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1260), make_compvar_primary(tmp_1261)));
}
start_if_cond(make_compvar_rhs(tmp_1259));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1232));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1207));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1244));
switch_if_branch();
{
compvar_t *tmp_1262;
tmp_1262 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1263, *tmp_1264;
tmp_1263 = tmp_1227;
tmp_1264 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1264), make_int_const_rhs(3));
emit_assign(make_lhs(tmp_1262), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1263), make_compvar_primary(tmp_1264)));
}
start_if_cond(make_compvar_rhs(tmp_1262));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1232));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1237));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1207));
switch_if_branch();
{
compvar_t *tmp_1265;
tmp_1265 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1266, *tmp_1267;
tmp_1266 = tmp_1227;
tmp_1267 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1267), make_int_const_rhs(4));
emit_assign(make_lhs(tmp_1265), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1266), make_compvar_primary(tmp_1267)));
}
start_if_cond(make_compvar_rhs(tmp_1265));
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1244));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1232));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1207));
switch_if_branch();
emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1207));
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1232));
emit_assign(make_lhs(result[2]), make_compvar_rhs(tmp_1237));
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
end_if_cond();
}
}
}
}
}
end_if_cond();
}
}
}

static void
gen_toxy (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1268;
for (tmp_1268 = 0; tmp_1268 < 2; ++tmp_1268)
{
switch (tmp_1268)
{
case 0 :
{
compvar_t *tmp_1269, *tmp_1270;
tmp_1269 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1271;
tmp_1271 = args[0][1];
emit_assign(make_lhs(tmp_1269), make_op_rhs(OP_COS, make_compvar_primary(tmp_1271)));
}
tmp_1270 = args[0][0];
emit_assign(make_lhs(result[tmp_1268]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1269), make_compvar_primary(tmp_1270)));
}
break;
case 1 :
{
compvar_t *tmp_1272, *tmp_1273;
tmp_1272 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1274;
tmp_1274 = args[0][1];
emit_assign(make_lhs(tmp_1272), make_op_rhs(OP_SIN, make_compvar_primary(tmp_1274)));
}
tmp_1273 = args[0][0];
emit_assign(make_lhs(result[tmp_1268]), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1272), make_compvar_primary(tmp_1273)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_tora (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
compvar_t *tmp_1275;

tmp_1275 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1276, *tmp_1277;
tmp_1276 = args[0][0];
tmp_1277 = args[0][1];
emit_assign(make_lhs(tmp_1275), make_op_rhs(OP_HYPOT, make_compvar_primary(tmp_1276), make_compvar_primary(tmp_1277)));
}

{
compvar_t *tmp_1278;
tmp_1278 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1279, *tmp_1280;
tmp_1279 = tmp_1275;
tmp_1280 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1280), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1278), make_op_rhs(OP_EQ, make_compvar_primary(tmp_1279), make_compvar_primary(tmp_1280)));
}
start_if_cond(make_compvar_rhs(tmp_1278));
{
int tmp_1281;
for (tmp_1281 = 0; tmp_1281 < 2; ++tmp_1281)
{
switch (tmp_1281)
{
case 0 :
emit_assign(make_lhs(result[tmp_1281]), make_int_const_rhs(0));
break;
case 1 :
emit_assign(make_lhs(result[tmp_1281]), make_int_const_rhs(0));
break;
default :
assert(0);
}
}
}
switch_if_branch();
{
compvar_t *tmp_1282;

tmp_1282 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1283;
tmp_1283 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1284, *tmp_1285;
tmp_1284 = args[0][0];
tmp_1285 = tmp_1275;
emit_assign(make_lhs(tmp_1283), make_op_rhs(OP_DIV, make_compvar_primary(tmp_1284), make_compvar_primary(tmp_1285)));
}
emit_assign(make_lhs(tmp_1282), make_op_rhs(OP_ACOS, make_compvar_primary(tmp_1283)));
}

emit_assign(make_lhs(result[0]), make_compvar_rhs(tmp_1275));
{
compvar_t *tmp_1286;
tmp_1286 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1287, *tmp_1288;
tmp_1287 = args[0][1];
tmp_1288 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1288), make_int_const_rhs(0));
emit_assign(make_lhs(tmp_1286), make_op_rhs(OP_LESS, make_compvar_primary(tmp_1287), make_compvar_primary(tmp_1288)));
}
start_if_cond(make_compvar_rhs(tmp_1286));
{
compvar_t *tmp_1289, *tmp_1290;
tmp_1289 = make_temporary(TYPE_INT);
{
compvar_t *tmp_1291, *tmp_1292;
tmp_1291 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1291), make_int_const_rhs(2));
tmp_1292 = make_temporary(TYPE_INT);
emit_assign(make_lhs(tmp_1292), make_float_const_rhs(M_PI));
emit_assign(make_lhs(tmp_1289), make_op_rhs(OP_MUL, make_compvar_primary(tmp_1291), make_compvar_primary(tmp_1292)));
}
tmp_1290 = tmp_1282;
emit_assign(make_lhs(result[1]), make_op_rhs(OP_SUB, make_compvar_primary(tmp_1289), make_compvar_primary(tmp_1290)));
}
switch_if_branch();
emit_assign(make_lhs(result[1]), make_compvar_rhs(tmp_1282));
end_if_cond();
}
}
end_if_cond();
}
}
}

static void
gen_rand (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1293;
for (tmp_1293 = 0; tmp_1293 < 1; ++tmp_1293)
{
switch (tmp_1293)
{
case 0 :
{
compvar_t *tmp_1294, *tmp_1295;
tmp_1294 = args[0][0];
tmp_1295 = args[1][0];
emit_assign(make_lhs(result[tmp_1293]), make_op_rhs(OP_RAND, make_compvar_primary(tmp_1294), make_compvar_primary(tmp_1295)));
}
break;
default :
assert(0);
}
}
}
}

static void
gen_noise (compvar_t ***args, int *arglengths, int *argnumbers, compvar_t **result)
{
{
int tmp_1296;
for (tmp_1296 = 0; tmp_1296 < 1; ++tmp_1296)
{
switch (tmp_1296)
{
case 0 :
{
compvar_t *tmp_1297, *tmp_1298, *tmp_1299;
tmp_1297 = args[0][0];
tmp_1298 = args[0][1];
tmp_1299 = args[0][2];
emit_assign(make_lhs(result[tmp_1296]), make_op_rhs(OP_NOISE, make_compvar_primary(tmp_1297), make_compvar_primary(tmp_1298), make_compvar_primary(tmp_1299)));
}
break;
default :
assert(0);
}
}
}
}


void
init_builtins (void)
{
register_overloaded_builtin("merd", "((T L) (T L))", gen_merd);
register_overloaded_builtin("print", "((nil 1) (_ _))", gen_print);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (ri 2))", gen_add_ri);
register_overloaded_builtin("__add", "((ri 2) (ri 2) (_ 1))", gen_add_ri_1);
register_overloaded_builtin("__add", "((ri 2) (_ 1) (ri 2))", gen_add_1_ri);
register_overloaded_builtin("__add", "((T 1) (T 1) (T 1))", gen_add_1);
register_overloaded_builtin("__add", "((T L) (T L) (_ 1))", gen_add_s);
register_overloaded_builtin("__add", "((T L) (T L) (T L))", gen_add_n);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (ri 2))", gen_sub_ri);
register_overloaded_builtin("__sub", "((ri 2) (ri 2) (_ 1))", gen_sub_ri_1);
register_overloaded_builtin("__sub", "((ri 2) (_ 1) (ri 2))", gen_sub_1_ri);
register_overloaded_builtin("__sub", "((T 1) (T 1) (T 1))", gen_sub_1);
register_overloaded_builtin("__sub", "((T L) (T L) (_ 1))", gen_sub_s);
register_overloaded_builtin("__sub", "((T L) (T L) (T L))", gen_sub_n);
register_overloaded_builtin("__neg", "((T L) (T L))", gen_neg);
register_overloaded_builtin("__mul", "((ri 2) (ri 2) (ri 2))", gen_mul_ri);
register_overloaded_builtin("__mul", "((ri 2) (_ 1) (ri 2))", gen_mul_1_ri);
register_overloaded_builtin("__mul", "((m2x2 4) (m2x2 4) (m2x2 4))", gen_mul_m2x2);
register_overloaded_builtin("__mul", "((m3x3 9) (m3x3 9) (m3x3 9))", gen_mul_m3x3);
register_overloaded_builtin("__mul", "((v2 2) (v2 2) (m2x2 4))", gen_mul_v2m2x2);
register_overloaded_builtin("__mul", "((v3 3) (v3 3) (m3x3 9))", gen_mul_v3m3x3);
register_overloaded_builtin("__mul", "((v2 2) (m2x2 4) (v2 2))", gen_mul_m2x2v2);
register_overloaded_builtin("__mul", "((v3 3) (m3x3 9) (v3 3))", gen_mul_m3x3v3);
register_overloaded_builtin("__mul", "((T 1) (T 1) (T 1))", gen_mul_1);
register_overloaded_builtin("__mul", "((T L) (T L) (_ 1))", gen_mul_s);
register_overloaded_builtin("__mul", "((T L) (T L) (T L))", gen_mul_n);
register_overloaded_builtin("__div", "((ri 2) (ri 2) (ri 2))", gen_div_ri);
register_overloaded_builtin("__div", "((ri 2) (T 1) (ri 2))", gen_div_1_ri);
register_overloaded_builtin("__div", "((v2 2) (_ 2) (m2x2 4))", gen_div_v2m2x2);
register_overloaded_builtin("__div", "((v3 3) (_ 3) (m3x3 9))", gen_div_v3m3x3);
register_overloaded_builtin("__div", "((T 1) (T 1) (T 1))", gen_div_1);
register_overloaded_builtin("__div", "((T L) (T L) (_ 1))", gen_div_s);
register_overloaded_builtin("__div", "((T L) (T L) (T L))", gen_div_n);
register_overloaded_builtin("__mod", "((T 1) (T 1) (T 1))", gen_mod_1);
register_overloaded_builtin("__mod", "((T L) (T L) (_ 1))", gen_mod_s);
register_overloaded_builtin("__mod", "((T L) (T L) (T L))", gen_mod_n);
register_overloaded_builtin("pmod", "((T 1) (T 1) (T 1))", gen_pmod);
register_overloaded_builtin("sqrt", "((ri 2) (ri 2))", gen_sqrt_ri);
register_overloaded_builtin("sqrt", "((T 1) (T 1))", gen_sqrt_1);
register_overloaded_builtin("sum", "((T 1) (T L))", gen_sum);
register_overloaded_builtin("dotp", "((nil 1) (T L) (T L))", gen_dotp);
register_overloaded_builtin("crossp", "((T 3) (T 3) (T 3))", gen_crossp);
register_overloaded_builtin("det", "((nil 1) (m2x2 4))", gen_det_m2x2);
register_overloaded_builtin("det", "((nil 1) (m3x3 9))", gen_det_m3x3);
register_overloaded_builtin("normalize", "((T L) (T L))", gen_normalize);
register_overloaded_builtin("abs", "((nil 1) (ri 2))", gen_abs_ri);
register_overloaded_builtin("abs", "((T 1) (T 1))", gen_abs_1);
register_overloaded_builtin("abs", "((T L) (T L))", gen_abs_n);
register_overloaded_builtin("deg2rad", "((nil 1) (_ 1))", gen_deg2rad);
register_overloaded_builtin("rad2deg", "((deg 1) (_ 1))", gen_rad2deg);
register_overloaded_builtin("sin", "((ri 2) (ri 2))", gen_sin_ri);
register_overloaded_builtin("sin", "((T 1) (T 1))", gen_sin);
register_overloaded_builtin("cos", "((ri 2) (ri 2))", gen_cos_ri);
register_overloaded_builtin("cos", "((T 1) (T 1))", gen_cos);
register_overloaded_builtin("tan", "((ri 2) (ri 2))", gen_tan_ri);
register_overloaded_builtin("tan", "((T 1) (T 1))", gen_tan);
register_overloaded_builtin("asin", "((ri 2) (ri 2))", gen_asin_ri);
register_overloaded_builtin("asin", "((T 1) (T 1))", gen_asin);
register_overloaded_builtin("acos", "((ri 2) (ri 2))", gen_acos_ri);
register_overloaded_builtin("acos", "((T 1) (T 1))", gen_acos);
register_overloaded_builtin("atan", "((ri 2) (ri 2))", gen_atan_ri);
register_overloaded_builtin("atan", "((T 1) (T 1))", gen_atan);
register_overloaded_builtin("atan", "((T 1) (T 1) (T 1))", gen_atan2);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (T 1))", gen_pow_ri_1);
register_overloaded_builtin("__pow", "((ri 2) (ri 2) (ri 2))", gen_pow_ri);
register_overloaded_builtin("__pow", "((ri 2) (T 1) (ri 2))", gen_pow_1_ri);
register_overloaded_builtin("__pow", "((T 1) (T 1) (T 1))", gen_pow_1);
register_overloaded_builtin("__pow", "((T L) (T L) (_ 1))", gen_pow_s);
register_overloaded_builtin("exp", "((ri 2) (ri 2))", gen_exp_ri);
register_overloaded_builtin("exp", "((T 1) (T 1))", gen_exp_1);
register_overloaded_builtin("log", "((ri 2) (ri 2))", gen_log_ri);
register_overloaded_builtin("log", "((T 1) (T 1))", gen_log_1);
register_overloaded_builtin("arg", "((nil 1) (ri 2))", gen_arg_ri);
register_overloaded_builtin("conj", "((ri 2) (ri 2))", gen_conj_ri);
register_overloaded_builtin("sinh", "((ri 2) (ri 2))", gen_sinh_ri);
register_overloaded_builtin("sinh", "((T 1) (T 1))", gen_sinh_1);
register_overloaded_builtin("cosh", "((ri 2) (ri 2))", gen_cosh_ri);
register_overloaded_builtin("cosh", "((T 1) (T 1))", gen_cosh_1);
register_overloaded_builtin("tanh", "((ri 2) (ri 2))", gen_tanh_ri);
register_overloaded_builtin("tanh", "((T 1) (T 1))", gen_tanh_1);
register_overloaded_builtin("asinh", "((ri 2) (ri 2))", gen_asinh_ri);
register_overloaded_builtin("asinh", "((T 1) (T 1))", gen_asinh_1);
register_overloaded_builtin("acosh", "((ri 2) (ri 2))", gen_acosh_ri);
register_overloaded_builtin("acosh", "((T 1) (T 1))", gen_acosh_1);
register_overloaded_builtin("atanh", "((ri 2) (ri 2))", gen_atanh_ri);
register_overloaded_builtin("atanh", "((T 1) (T 1))", gen_atanh_1);
register_overloaded_builtin("gamma", "((ri 2) (ri 2))", gen_gamma_ri);
register_overloaded_builtin("gamma", "((T 1) (T 1))", gen_gamma_1);
register_overloaded_builtin("ell_int_Kcomp", "((T 1) (T 1))", gen_ell_int_kcomp);
register_overloaded_builtin("ell_int_Ecomp", "((T 1) (T 1))", gen_ell_int_ecomp);
register_overloaded_builtin("ell_int_F", "((T 1) (T 1) (T 1))", gen_ell_int_f);
register_overloaded_builtin("ell_int_E", "((T 1) (T 1) (T 1))", gen_ell_int_e);
register_overloaded_builtin("ell_int_P", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_p);
register_overloaded_builtin("ell_int_D", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_d);
register_overloaded_builtin("ell_int_RC", "((T 1) (T 1) (T 1))", gen_ell_int_rc);
register_overloaded_builtin("ell_int_RD", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rd);
register_overloaded_builtin("ell_int_RF", "((T 1) (T 1) (T 1) (T 1))", gen_ell_int_rf);
register_overloaded_builtin("ell_int_RJ", "((T 1) (T 1) (T 1) (T 1) (T 1))", gen_ell_int_rj);
register_overloaded_builtin("ell_jac_sn", "((T 1) (T 1) (T 1))", gen_ell_jac_sn_1);
register_overloaded_builtin("ell_jac_cn", "((T 1) (T 1) (T 1))", gen_ell_jac_cn_1);
register_overloaded_builtin("ell_jac_dn", "((T 1) (T 1) (T 1))", gen_ell_jac_dn_1);
register_overloaded_builtin("ell_jac_sn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_sn_ri);
register_overloaded_builtin("ell_jac_cn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_cn_ri);
register_overloaded_builtin("ell_jac_dn", "((ri 2) (ri 2) (_ 1))", gen_ell_jac_dn_ri);
register_overloaded_builtin("floor", "((T 1) (T 1))", gen_floor);
register_overloaded_builtin("ceil", "((T 1) (T 1))", gen_ceil);
register_overloaded_builtin("sign", "((T L) (T L))", gen_sign_n);
register_overloaded_builtin("min", "((T L) (T L) (T L))", gen_min_n);
register_overloaded_builtin("max", "((T L) (T L) (T L))", gen_max_n);
register_overloaded_builtin("clamp", "((T L) (T L) (T L) (T L))", gen_clamp);
register_overloaded_builtin("lerp", "((T L) (_ 1) (T L) (T L))", gen_lerp_1);
register_overloaded_builtin("lerp", "((T L) (T L) (T L) (T L))", gen_lerp_n);
register_overloaded_builtin("scale", "((T L) (T L) (T L) (T L) (T L) (T L))", gen_scale);
register_overloaded_builtin("solve", "((nil 2) (poly 3))", gen_solve_poly_2);
register_overloaded_builtin("solve", "((nil 3) (poly 4))", gen_solve_poly_3);
register_overloaded_builtin("__not", "((T 1) (T 1))", gen_not);
register_overloaded_builtin("__or", "((T 1) (T 1) (T 1))", gen_or);
register_overloaded_builtin("__and", "((T 1) (T 1) (T 1))", gen_and);
register_overloaded_builtin("__xor", "((T 1) (T 1) (T 1))", gen_xor);
register_overloaded_builtin("__equal", "((T 1) (T 1) (T 1))", gen_equal);
register_overloaded_builtin("__less", "((T 1) (T 1) (T 1))", gen_less);
register_overloaded_builtin("__greater", "((T 1) (T 1) (T 1))", gen_greater);
register_overloaded_builtin("__lessequal", "((T 1) (T 1) (T 1))", gen_lessequal);
register_overloaded_builtin("__greaterequal", "((T 1) (T 1) (T 1))", gen_greaterequal);
register_overloaded_builtin("__notequal", "((T 1) (T 1) (T 1))", gen_notequal);
register_overloaded_builtin("inintv", "((T 1) (T 1) (T 1) (T 1))", gen_inintv);
register_overloaded_builtin("origVal", "((rgba 4) (xy 2) (nil 1) (image 1))", gen_origvalxy);
register_overloaded_builtin("gray", "((nil 1) (rgba 4))", gen_gray);
register_overloaded_builtin("toHSVA", "((hsva 4) (rgba 4))", gen_tohsva);
register_overloaded_builtin("toRGBA", "((rgba 4) (hsva 4))", gen_torgba);
register_overloaded_builtin("toXY", "((xy 2) (ra 2))", gen_toxy);
register_overloaded_builtin("toRA", "((ra 2) (xy 2))", gen_tora);
register_overloaded_builtin("rand", "((T 1) (T 1) (T 1))", gen_rand);
register_overloaded_builtin("noise", "((nil 1) (_ 3))", gen_noise);
}
