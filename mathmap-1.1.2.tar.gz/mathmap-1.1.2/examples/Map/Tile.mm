filter tile (image in, int n: 1-10 (3))
    in((xy+XY)*n%WH-XY)
end
