filter jitter (image in, float angle: 0-6.28318530 (0.68231853))
    in(ra:[r,a+(a+t*angle)%angle-angle/2])
end
