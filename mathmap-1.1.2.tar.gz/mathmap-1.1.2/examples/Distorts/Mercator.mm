filter mercator (image in)
    in(xy*xy:[cos(pi/2/Y*y+t*2*pi),1])
end
