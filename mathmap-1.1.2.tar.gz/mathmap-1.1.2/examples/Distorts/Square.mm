filter square (image in, float exponent: 1-10 (1.5))
    in(sign(xy)*abs(xy)^exponent/(XY^(exponent-1)))
end
