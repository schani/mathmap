filter pond (image in, float height: 0-100 (10), float wavelength: 1-50 (10))
    in(ra+ra:[sin(r/wavelength+t*2*pi)*height,0])
end
