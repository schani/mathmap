filter mosaic (image in, float size: 1-100 (20))
  in(xy-xy%size)
end
